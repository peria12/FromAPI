import express from "express";
import { entities, entity_fields, setEntities } from "../mocks/entity.js";

const router = express.Router();

router.get("/api/entity-master/fields", (req, res) => {
  console.log("Entity Master: Get fields");
  res.json({ fields: entity_fields });
});

router.get("/api/entity-master/entities", (req, res) => {
  console.log("Entity Master: Get records", req.query);
  let page_size = parseInt(req.query.page_size) || 100;
  let page = parseInt(req.query.page) || 1;
  page = page - 1;
  let start = page;
  if (page > 0) {
    start = page * page_size;
  }
  let records = entities.slice(start, page_size + start);
  console.log("enteries.length :>> ", records.length);
  res.json({ entities: records, total_records: entities.length });
});

router.use(express.json());

router.post("/api/entity-master/conflict-entities-resolve", (req, res) => {
  console.log("Entity Master (Conflict Entities):", req.body);
  const { em_conflict_ids, conflictEntity } = req.body;
  const latest = entities.filter(
    (ele) => !em_conflict_ids.includes(ele.entity_id)
  );
  latest.push(conflictEntity);
  setEntities(latest);
  res.json(latest);
});

router.get("/api/entity-master/conflict-entities", (req, res) => {
  console.log("Entity Master (Conflict Entities): Get records");
  res.json({ entities: entities });
});

export default router;
