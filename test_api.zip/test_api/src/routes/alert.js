import express from "express";
import { alert_fields, alerts } from "../mocks/alerts.js";

const router = express.Router();

router.get("/api/alerts/fields", (req, res) => {
  console.log("Get alerts fields");
  res.json({ fields: alert_fields });
});

router.get("/api/alerts/events", (req, res) => {
  console.log("Get alerts");
  res.json({ events: alerts, total_records: alerts.length });
});

router.get("/api/alerts/recent_events_count", (req, res) => {
  res.json({});
});

export default router;
