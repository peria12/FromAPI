import express from "express";
import { portfolios, portfolioPerformance } from "../mocks/portfolio.js";

const router = express.Router();

router.get("/api/portfolios/portfolios", (req, res) => {
  console.log("Get Portfolios");
  res.json({ portfolios: portfolios });
});

router.get("/api/portfolios/performance-summary", (req, res) => {
  console.log("Get portfolios performance summary");
  res.json({ records: portfolioPerformance });
});

export default router;
