import express from "express";
import { access, user_access } from "../mocks/access.js";
import { admin_settings } from "../mocks/admin_settings.js";
import { apps } from "../mocks/recommendations.js";

const router = express.Router();

router.get("/api/admin/apps", (req, res) => {
  console.log("apps", apps);
  res.json({ apps });
});

router.get("/api/admin/access", (req, res) => {
  console.log("Admin access");
  res.json(access);
});

router.get("/api/admin/all-access", (req, res) => {
  console.log("User access");
  res.json(user_access);
});

router.post("/api/admin/log", (req, res) => {
  console.log("Logs:", req.body);
  res.json({});
});

router.get("/api/admin/collections", (req, res) => {
  console.log("Get admin settings");
  res.json({ collections: admin_settings.collections });
});

router.get("/api/admin/system-info", (req, res) => {
  console.log("Get admin settings");
  res.json({
    version: "248",
    env: "dev",
  });
});

export default router;
