export let recommendations = [
  {
    _id: 0,
    name: "Rec One",
    desc: "The first recommendation",
    status: "active",
    author: "Jerrin K",
    create_date: "2021-01-22",
    update_date: "2021-02-12",
    read_only: false,
  },
  {
    _id: 1,
    name: "Buy everything",
    desc: "The second recommendation",
    status: "active",
    author: "Jerrin K",
    create_date: "2021-02-12",
    update_date: "2021-03-13",
    read_only: true,
  },
  {
    _id: 2,
    name: "Sell everything",
    desc: "The third recommendation",
    status: "review",
    author: "John Doe",
    create_date: "2021-02-13",
    update_date: "2021-02-22",
    read_only: true,
  },
  {
    _id: 3,
    name: "Rec Four",
    status: "deleted",
    desc: "The fourth recommendation",
    author: "Jerrin K",
    create_date: "2021-02-22",
    update_date: "2021-03-10",
    read_only: false,
  },
  {
    _id: 4,
    name: "Short GME",
    status: "deleted",
    desc: "The fifth recommendation",
    author: "Jerrin K",
    create_date: "2021-02-25",
    update_date: "2021-03-10",
    read_only: false,
  },
];

export let apps = [
  {
    _id: "entity-master",
    title: "Entity Master",
    title_html: "Entity Master",
    view_order: 1,
    show_on_portal: true,
    zones: [
      {
        name: "portal",
        title: "Portal",
        view_order: 1,
        access: [
          { name: "view", title: "View", revoked_by: "self" },
          {
            name: "admin",
            title: "Admin",
            granted_by: "admin",
            revoked_by: "self",
          },
        ],
      },
      {
        name: "data-ibes",
        title: "IBes data",
        view_order: 2,
        access: [
          {
            name: "admin",
            title: "Admin",
            granted_by: "admin",
            revoked_by: "self",
          },
        ],
      },
    ],
  },
  {
    _id: "research-gateway",
    title: "Research Gateway",
    title_html: "Research Gateway",
    view_order: 2,
    show_on_portal: true,
    zones: [
      {
        name: "portal",
        title: "Portal",
        view_order: 1,
        access: [
          { name: "view", title: "View", revoked_by: "self" },
          {
            name: "admin",
            title: "Admin",
            granted_by: "admin",
            revoked_by: "self",
          },
        ],
      },
      {
        name: "commentary",
        title: "Commentaries",
        view_order: 2,
        access: [
          { name: "view", title: "View", revoked_by: "self" },
          {
            name: "admin",
            title: "Admin",
            granted_by: "admin",
            revoked_by: "self",
          },
          {
            name: "analyst",
            title: "Analyst",
            granted_by: "admin",
            revoked_by: "self",
          },
        ],
      },
      {
        name: "recommendations",
        title: "Recommendations",
        view_order: 3,
        access: [
          { name: "view", title: "View", revoked_by: "self" },
          {
            name: "admin",
            title: "Admin",
            granted_by: "admin",
            revoked_by: "self",
          },
          {
            name: "analyst",
            title: "Analyst",
            granted_by: "admin",
            revoked_by: "self",
          },
        ],
      },
    ],
  },
  {
    _id: "admin",
    title: "Admin",
    title_html: "Admin",
    view_order: -1,
    show_on_portal: true,
    zones: [],
  },
  {
    _id: "portfolios",
    title: "Portfolios",
    title_html: "Portfolios",
    view_order: 3,
    show_on_portal: true,
    zones: [
      {
        name: "portal",
        title: "Portal",
        view_order: 1,
        access: [
          {
            name: "view",
            title: "View",
          },
          {
            name: "admin",
            title: "Admin",
            granted_by: "admin",
          },
        ],
        settings: "rg_portal_3",
      },
    ],
  },
  {
    _id: "research-tool",
    title: "Research Tool",
    title_html: "Research Tool",
    view_order: 4,
    show_on_portal: true,
    zones: [
      {
        name: "Fund Analyzer",
        title: "Fund Analyzer",
        view_order: 1,
        access: [
          {
            name: "view",
            title: "View",
          },
          {
            name: "admin",
            title: "Admin",
            granted_by: "admin",
          },
        ],
        settings: "rg_collection2",
      },
    ],
  },
];

export let next_recommendation_id = 5;
