export const access = {
  access: [
    {
      app: "research-gateway",
      zone: "commentary",
      type: "admin",
    },
    {
      app: "research-gateway",
      zone: "portal",
      type: "admin",
    },
    {
      app: "entity-master",
      zone: "portal",
      type: "admin",
    },
    {
      app: "research-gateway",
      zone: "recommendations",
      type: "view",
    },
    {
      app: "research-gateway",
      zone: "commentary",
      type: "view",
    },
    {
      app: "research-gateway",
      zone: "recommendations",
      type: "admin",
    },
    {
      app: "research-gateway",
      zone: "portal",
      type: "view",
    },
    {
      app: "research-gateway",
      zone: "commentary",
      type: "analyst",
    },
    {
      app: "entity-master",
      zone: "portal",
      type: "view",
    },
    {
      app: "entity-master",
      zone: "data-ibes",
      type: "admin",
    },
    {
      app: "admin",
      zone: "data-ibes",
      type: "admin",
    },
  ],
};

export const user_access = {
  user_access: {
    "ae96293a-132c-463f-b480-09f6fd76aab4": {
      access: [
        {
          app: "research-gateway",
          zone: "commentary",
          type: "admin",
        },
        {
          app: "research-gateway",
          zone: "portal",
          type: "admin",
        },
        {
          app: "entity-master",
          zone: "portal",
          type: "admin",
        },
        {
          app: "research-gateway",
          zone: "recommendations",
          type: "view",
        },
        {
          app: "research-gateway",
          zone: "commentary",
          type: "view",
        },
        {
          app: "research-gateway",
          zone: "recommendations",
          type: "admin",
        },
        {
          app: "research-gateway",
          zone: "portal",
          type: "view",
        },
        {
          app: "research-gateway",
          zone: "commentary",
          type: "analyst",
        },
        {
          app: "entity-master",
          zone: "portal",
          type: "view",
        },
        {
          app: "entity-master",
          zone: "data-ibes",
          type: "admin",
        },
      ],
    },
    "ae96293a-132c-463f-b481-09f6fd76aab5": {
      access: [
        {
          app: "research-gateway",
          zone: "commentary",
          type: "admin",
        },
        {
          app: "entity-master",
          zone: "portal",
          type: "admin",
        },
        {
          app: "research-gateway",
          zone: "recommendations",
          type: "view",
        },
        {
          app: "research-gateway",
          zone: "commentary",
          type: "view",
        },
        {
          app: "research-gateway",
          zone: "recommendations",
          type: "admin",
        },
        {
          app: "research-gateway",
          zone: "commentary",
          type: "analyst",
        },
        {
          app: "entity-master",
          zone: "portal",
          type: "view",
        },
        {
          app: "entity-master",
          zone: "data-ibes",
          type: "admin",
        },
      ],
    },
  },
};
