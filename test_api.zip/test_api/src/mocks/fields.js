export const fields = [{
    title: 'Name',
    _id: 'name',
    type: 'text',
    required: true
},
{
    title: 'Description',
    _id: 'desc',
    type: 'text',
},
{
    title: 'Author',
    _id: 'author',
    type: 'text'
},
{
    title: 'Created Date',
    _id: 'create_date',
    type: 'date',
    required: true
},
{
    title: 'Last Update',
    _id: 'update_date',
    type: 'date'
},
{
    title: 'Status',
    type: 'select',
    default: 'active',
    _id: 'status',
    options: [{
        key: 'active',
        value: 'Active'
    },
    {
        key: 'review',
        value: 'In Review'
    },
    {
        key: 'deleted',
        value: 'Deleted'
    }]
},
{
    title: 'Read Only',
    _id: 'read_only',
    type: 'checkbox',
    default: true
},
{
    title: 'Upload File',
    _id: 'files',
    type: 'file',
    multi: true
}
]