import express from "express";
import adminRoutes from "./src/routes/admin.js";
import entityMaterRoutes from "./src/routes/entity-master.js";
import researchGatewayRoutes from "./src/routes/research-gateway.js";
import portfoliosRoutes from "./src/routes/portfolio.js";
import researchRoutes from "./src/routes/research.js";
import alertRoutes from "./src/routes/alert.js";

const app = express();

const port = process.env.REST_API_PORT;
if (!port) {
  console.err("No port to listen to. Please set env variable REST_API_PORT");
  process.exit(1);
}

app.listen(port, () => console.log(`Listening on ${port}`));

app.get("/", (req, res) => {
  res.send("Hello World!");
});

app.use("/", adminRoutes);
app.use("/", entityMaterRoutes);
app.use("/", researchGatewayRoutes);
app.use("/", portfoliosRoutes);
app.use("/", researchRoutes);
app.use("/", alertRoutes);
