import React from "react"
import { act, render, screen, waitFor } from "@testing-library/react"
import { MemoryRouter as Router } from "react-router-dom"
import App from "./App"
import Api from "./utils/api"

test("renders learn react link", async () => {
    Api.start = jest.fn().mockResolvedValue(true)
    act(() => {
        render(
            <Router>
                <App />
            </Router>
        )
    })

    await waitFor(() => {
        const linkElement = screen.getByText(/Loading/i)
        expect(linkElement).toBeInTheDocument()
    })
})
