import React, { useState } from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { IconBtn } from "common/FTButtons";
import Api from "utils/api";
import { AdornedButton } from "common/FTButtons";
import ConfirmDialog from "common/ConfirmDialog";
import { downloadFile } from "utils/helpers";

const useStyles = makeStyles(() =>
    createStyles({
        headerContainer: {
            display: "flex",
            justifyContent: "flex-start",
            flexDirection: "column",
            width: "100%",
            padding: "18px",
        },
        title: {
            fontSize: "20px",
        },
        navigation: {
            display: "flex",
            flexDirection: "row",
            padding: "12px 0",
        },
        btn: {
            // textTransform: "capitalize",
            marginLeft: 5,
        },
    })
);

interface HeaderPanelProps {
    title: string;
    onBack: any;
    handler: any;
    buttons: any;
    isLastTab?: boolean;
    onSubmit?: (any?) => void;
    userId?: string;
    email?: string;
    state?: any;
    isAdmin?: boolean;
}

export default function HeaderPanel({
    title,
    onBack,
    handler,
    buttons = [],
    isLastTab = false,
    onSubmit,
    userId,
    email,
    state,
    isAdmin,
}: HeaderPanelProps) {
    const classes = useStyles();
    const [confirmOpen, setConfirmOpen] = useState(false);

    function getButtonLabel(btn) {
        if (isLastTab && btn?.id == "continue") {
            if (state?.type == "view" || state?.new == false) {
                return "Update";
            }
            return "Submit";
        }
        return btn.label;
    }

    const onClick = (values, btn) => {
        if (btn?.id == "reset_password") {
            setConfirmOpen(true);
            return;
        }

        if (btn?.id == "continue") {
            onSubmit?.(values);
        }

        handler(btn.id);
    };
    return (
        <div className={classes.headerContainer}>
            <div className={classes.title}> {title} </div>
            <div className={classes.navigation}>
                <IconBtn
                    color="primary"
                    classes={classes}
                    handler={onBack}
                    size={"small"}
                    startIcon={<ArrowBackIcon />}
                    label={"Back"}
                />
                <div style={{ marginLeft: "auto" }}>
                    {buttons.map((btn: any, index: number) => {
                        if (btn.id == "download") {
                            return (
                                <div
                                    key={btn?.id}
                                    style={{
                                        display: "inline-flex",
                                        alignItems: "center",
                                        textDecoration: "auto",
                                        cursor: "pointer",
                                    }}
                                    onClick={() => Api.goeDownloadConfigRaw(userId).then(downloadFile)}
                                >
                                    <AdornedButton className={classes.btn} variant="contained" color="primary">
                                        {btn.label}
                                    </AdornedButton>
                                </div>
                            );
                        }

                        if (isLastTab && state?.type == "view" && btn?.id == "continue") {
                            return
                        }

                        return (
                            <AdornedButton
                                key={"btn_" + index}
                                onClick={(values) => onClick(values, btn)}
                                variant="contained"
                                color={btn.color || "primary"}
                                className={classes.btn}
                                disabled={!isAdmin && btn.adminOnly}
                                loading={btn.isLoaderRequired && state?.btnLoading}
                            >
                                {getButtonLabel(btn)}
                            </AdornedButton>
                        );
                    })}
                </div>
                <ConfirmDialog
                    title={`Reset password and send email`}
                    open={confirmOpen}
                    setOpen={setConfirmOpen}
                    onConfirm={() => handler("reset_password")}
                >
                    This will invalidate user&apos;s current password. An email will be sent to <b>{email}</b> to set a
                    new password. Proceed?
                </ConfirmDialog>
            </div>
        </div>
    );
}
