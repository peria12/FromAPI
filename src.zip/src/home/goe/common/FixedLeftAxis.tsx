import React, { useEffect, useRef } from "react";
import * as d3 from "d3";
import { CHART_MARGIN, MAX_CHART_HEIGHT } from "home/goe/common/constants";
import { getScalesNDomainsForChartByData } from "home/goe/common/utils";
import { IChartData } from "home/goe/common/interfaces";

interface FixedLeftAxisProps {
    data: Array<IChartData>;
}

const FixedLeftAxis = ({ data }: FixedLeftAxisProps) => {
    const chartHeight = MAX_CHART_HEIGHT;

    // Create a new SVG element for the left y-axis
    const leftYAxisRef = useRef<SVGSVGElement>(null);
    useEffect(() => {
        if (leftYAxisRef.current) {
            const svg = d3.select(leftYAxisRef.current).attr("height", chartHeight);

            // scales for the charts
            const leftYScale = getScalesNDomainsForChartByData(data)[1];

            // Add left y-axis
            const leftYAxis = d3.axisLeft(leftYScale).tickFormat((d) => `$${d3.format(",")(d)}`);

            svg.selectAll("text").remove();

            // Add Y-axis left
            svg.append("g")
                .attr("class", "left-y-axis")
                .attr("transform", `translate(${CHART_MARGIN.left - 2}, ${CHART_MARGIN.top})`)
                .call(leftYAxis)
                .selectAll("text")
                .style("font-size", "12px")
                .style("line-height", "19px")
                .style("font-weight", "400")
                .style("font-family", "TT Commons");

            // Add left y-axis title
            svg.append("text")
                .attr("class", "y-axis-title")
                // .attr("x", -CHART_MARGIN.top - chartHeight / 2)
                .attr("y", CHART_MARGIN.left / 2)
                // .attr("x", -CHART_MARGIN.top - chartHeight / 2)
                .attr("x", -230)
                .attr("transform", "rotate(-90)")
                .style("text-anchor", "middle")
                .style("font-size", "16px")
                .style("line-height", "19px")
                .style("font-weight", "500")
                .text("Portfolio Value (In $)")
                .attr("dy", `-30px`);

            // Hide left y-axis tick
            svg.selectAll(".left-y-axis path.domain").style("display", "none");
            svg.selectAll(".tick line").style("display", "none");
        }
        //eslint-disable-next-line
    }, [data]);

    return (
        <svg ref={leftYAxisRef} className="left-y-axis-svg" width={CHART_MARGIN.left} height={chartHeight}>
            <g transform={`translate(${CHART_MARGIN.left},${CHART_MARGIN.top})`} className="y-axis" />
        </svg>
    );
};

export default FixedLeftAxis;
