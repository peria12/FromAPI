export interface IChartMargin {
    top: number;
    bottom: number;
    left: number;
    right: number;
}

export interface IChartData {
    year: number;
    value: number;
}

export type IChartDomain = [number, number];

export interface IGoalTenureData {
    startYear: number;
    endYear: number;
    tenure: number;
}

export type IGoalRelatedYear = number;

export interface IPortfolioComposition {
    equity: number;
    fixed_income: number;
}

export type IGoalKey =
    | "buy_car"
    | "own_house"
    | "plan_retirement"
    | "save_college"
    | "Draw_Income"
    | "Take_Vacation"
    | "Custom_Goal";

export interface IGoalData {
    achieve_this_goal: string;
    contribution_time: string;
    created_at: string;
    escalate_contributions: string;
    escalation_percentage: number;
    every_years: number;
    goalWorkspaceId: string;
    goal_amount: string;
    goal_key: IGoalKey;
    goal_priority: string;
    icon: string;
    initial_investment: string;
    name: string;
    recurring_contributions: string;
    tenure: string;
    updated_at: string;
    "goal-key": string;
    date_of_birth?: string;
    end_on_date?: string;
    leave_bequest?: string;
    my_withdrawal_frequency?: string;
    plan_start_retirement?: string;
    targeted_retirement_income?: string;
    start_first_withdrawal?: string;
    last_withdrawal?: string;
}

export type ID3ScaleMethod = (x: any) => number;

export interface IConfigFormInputChnageFuncArg {
    formName: string;
    fieldName: string;
    value: string | unknown;
}

export interface IConfigFormProp {
    data: unknown;
    onInputChange: (d: IConfigFormInputChnageFuncArg) => void;
}
