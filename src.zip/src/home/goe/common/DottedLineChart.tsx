import React, { useEffect, useRef } from "react";
import * as d3 from "d3";

import { getChartHeight, getChartTranslateValues, getYDomains } from "./utils";
import { IChartData, IChartDomain, ID3ScaleMethod } from "./interfaces";

export interface IChartDataPoint {
    year: number;
    value: number;
}
interface DottedLineChartProps {
    data: Array<number>;
    wealthPerYearData: Array<IChartData>;
    xScale: ID3ScaleMethod;
    yScale: ID3ScaleMethod;
    chartWidth: number;
    isZoomed: boolean;
}

const DottedLineChart = ({ data, wealthPerYearData, xScale, yScale, chartWidth }: DottedLineChartProps) => {
    const lineRef = useRef<SVGGElement>(null);
    const chartHeight = getChartHeight();
    const yDomains: IChartDomain = getYDomains(wealthPerYearData);

    useEffect(() => {
        if (lineRef.current && data.length > 0 && chartWidth > 0 && chartHeight > 0) {
            const { xTranslate, yTranslate } = getChartTranslateValues();
            const svg = d3.select(lineRef.current);

            svg.selectAll("line").remove();

            //To show dotted-lines
            svg.selectAll("line")
                .data(data)
                .enter()
                .append("line")
                .attr("x1", (d: Array<number>) => xScale(d))
                .attr("x2", (d: Array<number>) => xScale(d))
                .attr("y1", yScale(0))
                .attr("y2", yScale(yDomains[1]))
                .style("stroke-dasharray", "7, 7")
                .attr("stroke", "#23a29c")
                .attr("transform", `translate(${xTranslate}, ${yTranslate})`);
        }

        //eslint-disable-next-line
    }, [data, chartWidth, chartHeight]);

    return <g ref={lineRef} id="dotted-line-chart" />;
};

export default DottedLineChart;
