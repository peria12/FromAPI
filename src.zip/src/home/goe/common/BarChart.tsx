import React from "react";
import * as d3 from "d3";
import { useEffect, useRef } from "react";
import { IChartData, ID3ScaleMethod } from "./interfaces";
import {
    getChartHeight,
    getChartTranslateValues,
    getChartXAxisValueGap,
    getScalesNDomainsForChartByData,
} from "./utils";

interface BarChartProps {
    data: Array<Array<number>>;
    wealthPerYearData: Array<IChartData>;
    xScale: ID3ScaleMethod;
    yScale: ID3ScaleMethod;
    chartWidth: number;
    isZoomed: boolean;
}

const BarChart = ({ data, wealthPerYearData, xScale, chartWidth, isZoomed = false, yScale }: BarChartProps) => {
    const barRef = useRef<SVGGElement>(null);
    const BAR_CHART_FILL_COLOR = "#fbe5dc";
    const chartHeight = getChartHeight();
    const yDomains = getScalesNDomainsForChartByData(wealthPerYearData, undefined, chartWidth)[3];
    useEffect(() => {
        renderGraph();
        //eslint-disable-next-line
    }, [wealthPerYearData, chartWidth, isZoomed]);

    function renderGraph() {
        if (barRef.current && data.length > 0 && xScale && chartHeight > 0) {
            const { xTranslate, yTranslate } = getChartTranslateValues();
            const svg = d3.select(barRef.current);
            const xAxisValueGap = getChartXAxisValueGap(chartWidth, wealthPerYearData.length, isZoomed);

            svg.selectAll("rect").remove();
            const barGroupYValue = yScale(yDomains[1]);
            const barGroup = svg.append("g").attr("transform", `translate(${xTranslate}, ${yTranslate})`);
            console.log("yScale(yDomains[1])", yScale(yDomains[1]), yDomains[1]);
            console.log("yScale(0)", yScale(0));
            //To show startyear and end year bar
            barGroup
                .selectAll("rect")
                .data(data)
                .enter()
                .append("rect")
                .attr("x", (d: Array<number>) => xScale(d[0]))
                // .attr("y", 0)
                .attr("y", barGroupYValue)
                .attr("width", (item) => (item.length - 1) * (xAxisValueGap - 1))
                .attr("height", chartHeight - barGroupYValue)
                //.attr("height",)
                .attr("fill", BAR_CHART_FILL_COLOR)
                .attr("transform", `translate(0, 0)`);
        }
    }

    return <g ref={barRef} id="bar-chart" />;
};

export default BarChart;
