import React from "react";

export default function GoeForm({ label, children }) {
    return (
        <div className="row my-3">
            <div className="col-5 mt-2" style={{ color: "#9b9ba3", fontSize: "15px", fontWeight: 700 }}>
                {label}
            </div>
            <div className="col-7">{children}</div>
        </div>
    );
}
