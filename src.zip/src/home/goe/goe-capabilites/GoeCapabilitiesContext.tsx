import React, { createContext, useState, useMemo } from "react";

export interface GoeCapabilitiesComponentContext {
    name?: string;
    setName?: (name: string) => void;

    userFlag?: boolean;
    setUserFlag?: (name: boolean) => void;

    isEdit?: boolean;
    setIsEdit?: (name: boolean) => void;

    gender?: string;
    setGender?: (gender: string) => void;

    dob?: string;
    setDob?: (dob: string) => void;

    riskProfile?: string;
    setRiskProfile?: (riskProfile: string) => void;

    appId?: string;
    setAppId?: (appId: string) => void;
    zoneId?: string;
    setZoneId?: (zoneId: string) => void;

    journeyPath?: string;
    setJourneyPath?: (journeyPath: string) => void;

    goalList?: any;
    setGoalList?: (goalList: any) => void;
}

const innitialContext = {
    name: "",
    gender: "",
    userFlag: false,
    isEdit: false,
    dob: "",
    riskProfile: "",
    appId: "",
    zoneId: "",
    journeyPath: "basic-information",
    goalList: [],
};

export const GoeCapabilitiesContext = createContext<GoeCapabilitiesComponentContext>(innitialContext);

export const GoeCapabilitiesContextProvider = (props: any) => {
    const [name, setName] = useState<string>(props.name || innitialContext.name);

    const [userFlag, setUserFlag] = useState<boolean>(props.userFlag || innitialContext.userFlag);

    const [isEdit, setIsEdit] = useState<boolean>(props.isEdit || innitialContext.isEdit);

    const [dob, setDob] = useState<string>(props.dob || innitialContext.dob);

    const [gender, setGender] = useState<string>(props.gender || innitialContext.gender);

    const [riskProfile, setRiskProfile] = useState<string>(props.riskProfile || innitialContext.riskProfile);

    const [appId, setAppId] = useState<string>(props.appId || innitialContext.appId);

    const [zoneId, setZoneId] = useState<string>(props.zoneId || innitialContext.zoneId);

    const [journeyPath, setJourneyPath] = useState<string>(props.journeyPath || innitialContext.journeyPath);

    const [goalList, setGoalList] = useState<string>(props.goalList || innitialContext.goalList);

    const providerValue = useMemo(
        () => ({
            name,
            setName,
            gender,
            setGender,
            dob,
            setDob,
            riskProfile,
            setRiskProfile,
            zoneId,
            setZoneId,
            appId,
            setAppId,
            journeyPath,
            setJourneyPath,
            goalList,
            setGoalList,
            userFlag,
            setUserFlag,
            isEdit,
            setIsEdit,
        }),
        [name, gender, dob, riskProfile, zoneId, appId, journeyPath, goalList, userFlag, isEdit]
    );

    return <GoeCapabilitiesContext.Provider value={providerValue}>
        {props.children}
    </GoeCapabilitiesContext.Provider>;
};
