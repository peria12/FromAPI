import takeVacation from "../../assets/images/svg/goals_icons/take_vacation.svg";
import buyCar from "../../assets/images/svg/goals_icons/buy_car.svg";
import ownHouse from "../../assets/images/svg/goals_icons/own_house.svg";
import customGoal from "../../assets/images/svg/goals_icons/custom_goal.svg";
import saveCollage from "../../assets/images/svg/goals_icons/save_college.svg";
import drawIncome from "../../assets/images/svg/goals_icons/draw_income.svg";
import planRetirement from "../../assets/images/svg/goals_icons/plan_retirement.svg";
let allGoals = {
    "take_vacation": {
        "goal_id": 5,
        "label": "Take a Vacation",
        "icon":takeVacation,
        "input_data": [
            {
                "id": 1,
                "label": "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>goal amount</span> is</span>",
                "placeholder": "Enter Amount",
                "name": "goal_amount",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 2,
                "label": "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>initial investment </span> is</span>",
                "placeholder": "Enter Amount",
                "name": "initial_investment",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 3,
                "label": "<span class='gray-span-goalstemp'>with <span class='black-span-goalstemp'>recurring contributions </span>Of</span>",
                "placeholder": "Enter Amount",
                "name": "recurring_contributions",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 4,
                "label": "<span class='black-span-goalstemp'>every</span>",
                "name":"contribution_time",
                "placeholder": "0",
                "type": "button",
                "value": "",
                "options": [
                    "year",
                    "month"
                ]
            },
            {
                "id": 5,
                "label": "<span class='gray-span-goalstemp'>I plan to <span class='black-span-goalstemp'>escalate contributions</span></span> ",
                "placeholder": "",
                "name": "escalate_contributions",
                "type": "button",
                "value": "",
                "options": [
                    "yes",
                    "no"
                ]
            },
            {
                "id": 6,
                "label": "<span class='gray-span-goalstemp'>with an <span class='black-span-goalstemp'>escalation percentage</span> of</span>",
                "placeholder": "0%",
                "name": "escalation_percentage",
                "type": "range",
                "value": "",
                "options": []
            },
            {
                "id": 7,
                "label": "<span class='black-span-goalstemp'>every (in years)</span>",
                "placeholder": "0",
                "name": "every_years",
                "type": "range",
                "value": "",
                "options": []
            },
            {
                "id": 8,
                "label": "<span class='gray-span-goalstemp'>I want to <span class='black-span-goalstemp'>achieve this goal by</span></span>",
                "placeholder": "dd/mm/yyyy",
                "name": "achieve_this_goal",
                "type": "date",
                "value": "",
                "options": []
            },
            {
                "id": 9,
                "label": "<span class='gray-span-goalstemp'>with a <span class='black-span-goalstemp'>goal priority</span></span>",
                "placeholder": "Enter Amount",
                "type": "button",
                "name":"goal_priority",
                "value": "",
                "options": [
                    "Need",
                    "Want",
                    "Wish",
                    "Dream"
                ]
            }
        ],
        "help_data":[
            {
                "id": 1,
                "label": "Transportation Costs",
                "placeholder": "Enter amount",
                "name": "transportation_costs",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 2,
                "label": "Hotel (per night)",
                "placeholder": "Enter amount",
                "name": "hotel_per_night",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 3,
                "label": "Number of nights you'll stay",
                "placeholder": "Enter amount",
                "name": "number_of_nights",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 4,
                "label": "Meals (per day)",
                "placeholder": "Enter amount",
                "name": "food_per_day",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 5,
                "label": "Other (per day)",
                "placeholder": "Enter amount",
                "name": "other_per_day",
                "type": "text",
                "value": "",
                "options": []
            },
            // {
            //     "id": 6,
            //     "label": "Inflation rate",
            //     "placeholder": "0 %",
            //     "name": "perc_cost",
            //     "type": "range",
            //     "value": "",
            //     "options": []
            // },
            {
                "id": 7,
                "label": "When do you plan to take this vacation?",
                "placeholder": "",
                "name": "plan_take_vacation",
                "type": "date",
                "value": "",
                "options": []
            }
        ]
    },
    "buy_car": {
        "goal_id": 4,
        "label": "Buy a Car",
        "icon":buyCar,
        "input_data": [
            {
                "id": 1,
                "label": "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>goal amount</span> is</span> ",
                "placeholder": "Enter Amount",
                "name": "goal_amount",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 2,
                "label": "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>initial investment </span> is</span>",
                "placeholder": "Enter Amount",
                "name": "initial_investment",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 3,
                "label": "<span class='gray-span-goalstemp'>with <span class='black-span-goalstemp'>recurring contributions</span> of</span>",
                "placeholder": "Enter Amount",
                "name": "recurring_contributions",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 4,
                "label": "<span class='black-span-goalstemp'>every</span>",
                "placeholder": "",
                "type": "button",
                "name":"contribution_time",
                "value": "",
                "options": [
                    "year",
                    "month"
                ]
            },
            {
                "id": 5,
                "label": "<span class='gray-span-goalstemp'>I plan to <span class='black-span-goalstemp'>escalate contributions</span></span> ",
                "placeholder": "",
                "name": "escalate_contributions",
                "type": "button",
                "value": "",
                "options": [
                    "yes",
                    "no"
                ]
            },
            {
                "id": 6,
                "label": "<span class='gray-span-goalstemp'>with an <span class='black-span-goalstemp'>escalation percentage of</span></span>",
                "placeholder": "0%",
                "name": "escalation_percentage",
                "type": "range",
                "value": "",
                "options": []
            },
            {
                "id": 7,
                "label": "<span class='black-span-goalstemp'>every (in years)</span>",
                "placeholder": "0",
                "name": "every_years",
                "type": "range",
                "value": "",
                "options": []
            },
            {
                "id": 8,
                "label": "<span class='gray-span-goalstemp'>I want to <span class='black-span-goalstemp'>achieve this goal by</span></span>",
                "placeholder": "dd/mm/yyyy",
                "name": "achieve_this_goal",
                "type": "date",
                "value": "",
                "options": []
            },
            {
                "id": 9,
                "label": "<span class='gray-span-goalstemp'>with a <span class='black-span-goalstemp'>goal priority</span></span>",
                "placeholder": "Enter Amount",
                "type": "button",
                "name":"goal_priority",
                "value": "",
                "options": [
                    "Need",
                    "Want",
                    "Wish",
                    "Dream"
                ]
            }
        ],
        "help_data":[
            {
                "id": 1,
                "label": "What is the vehicle category?",
                "placeholder": "",
                "name": "vehicle_category",
                "type": "select",
                "value": "",
                "options": []
            },
            {
                "id": 3,
                "label": "When do you plan to buy this car?",
                "placeholder": "",
                "name": "year",
                "type": "date",
                "value": "",
                "options": []
            },
            {
                "id": 2,
                "label": "What percentage of the car's cost will this goal fund?",
                "placeholder": "0 %",
                "name": "perc_cost",
                "type": "range",
                "value": "",
                "options": []
            },
        ]
    },
    "own_house": {
        "goal_id": 2,
        "label": "Own a House",
        "icon":ownHouse,
        "input_data": [
            {
                "id": 1,
                "label": "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>goal amount</span> is</span> ",
                "placeholder": "Enter Amount",
                "name": "goal_amount",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 2,
                "label": "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>initial investment </span> is</span>",
                "placeholder": "Enter Amount",
                "name": "initial_investment",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 3,
                "label": "<span class='gray-span-goalstemp'>with <span class='black-span-goalstemp'>recurring contributions</span> of</span>",
                "placeholder": "Enter Amount",
                "name": "recurring_contributions",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 4,
                "label": "<span class='black-span-goalstemp'>every</span>",
                "placeholder": "0",
                "type": "button",
                "value": "",
                "name":"contribution_time",
                "options": [
                    "year",
                    "month"
                ]
            },
            {
                "id": 5,
                "label": "<span class='gray-span-goalstemp'>I plan to <span class='black-span-goalstemp'>escalate contributions</span></span> ",
                "placeholder": "",
                "name": "escalate_contributions",
                "type": "button",
                "value": "",
                "options": [
                    "yes",
                    "no"
                ]
            },
            {
                "id": 6,
                "label": "<span class='gray-span-goalstemp'>with an <span class='black-span-goalstemp'>escalation percentage of</span></span>",
                "placeholder": "0%",
                "name": "escalation_percentage",
                "type": "range",
                "value": "",
                "options": []
            },
            {
                "id": 7,
                "label": "<span class='black-span-goalstemp'>every (in years)</span>",
                "placeholder": "0",
                "name": "every_years",
                "type": "range",
                "value": "",
                "options": []
            },
            {
                "id": 8,
                "label": "<span class='gray-span-goalstemp'>I want to <span class='black-span-goalstemp'>achieve this goal by</span></span>",
                "placeholder": "dd/mm/yyyy",
                "name": "achieve_this_goal",
                "type": "date",
                "value": "",
                "options": []
            },
            {
                "id": 9,
                "label": "<span class='gray-span-goalstemp'>with a <span class='black-span-goalstemp'>goal priority</span></span>",
                "placeholder": "Enter Amount",
                "type": "button",
                "name":"goal_priority",
                "value": "",
                "options": [
                    "Need",
                    "Want",
                    "Wish",
                    "Dream"
                ]
            }
        ],
        "help_data":[
            {
                "id": 1,
                "label": "Where do you want to buy the house?",
                "placeholder": "Select",
                "name": "state",
                "type": "select",
                "value": "",
                "options": []
            },
            {
                "id": 2,
                "label": "What type of a house would this be?",
                "placeholder": "Select house type",
                "name": "type_of_house",
                "type": "select",
                "value": "",
                "options": []
            },
            {
                "id": 3,
                "label": "When do you want to buy this house?",
                "placeholder": "",
                "name": "year",
                "type": "date",
                "value": "",
                "options": []
            },
            {
                "id": 4,
                "label": "What percentage of the house's cost will this goal fund?",
                "placeholder": "0 %",
                "name": "perc_cost",
                "type": "range",
                "value": "",
                "options": []
            },
        ]
    },
    "custom_goal": {
        "goal_id": 7,
        "label": "Custom Goal",
        "icon":customGoal,
        "input_data": [
            {
                "id": 1,
                "label": "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>goal amount</span> is</span> ",
                "placeholder": "Enter Amount",
                "name": "goal_amount",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 2,
                "label": "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>initial investment </span> is</span>",
                "placeholder": "Enter Amount",
                "name": "initial_investment",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 3,
                "label": "<span class='gray-span-goalstemp'>with <span class='black-span-goalstemp'>recurring contributions</span> of</span>",
                "placeholder": "Enter Amount",
                "name": "recurring_contributions",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 4,
                "label": "<span class='black-span-goalstemp'>every</span>",
                "placeholder": "0",
                "type": "button",
                "name":"contribution_time",
                "value": "",
                "options": [
                    "year",
                    "month"
                ]
            },
            {
                "id": 5,
                "label": "<span class='gray-span-goalstemp'>I plan to <span class='black-span-goalstemp'>escalate contributions</span></span> ",
                "placeholder": "",
                "name": "escalate_contributions",
                "type": "button",
                "value": "",
                "options": [
                    "yes",
                    "no"
                ]
            },
            {
                "id": 6,
                "label": "<span class='gray-span-goalstemp'>with an <span class='black-span-goalstemp'>escalation percentage of</span></span>",
                "placeholder": "0%",
                "name": "escalation_percentage",
                "type": "range",
                "value": "",
                "options": []
            },
            {
                "id": 7,
                "label": "<span class='black-span-goalstemp'>every (in years)</span>",
                "placeholder": "0",
                "name": "every_years",
                "type": "range",
                "value": "",
                "options": []
            },
            {
                "id": 8,
                "label": "<span class='gray-span-goalstemp'>I want to <span class='black-span-goalstemp'>achieve this goal by</span></span>",
                "placeholder": "dd/mm/yyyy",
                "name": "achieve_this_goal",
                "type": "date",
                "value": "",
                "options": []
            },
            {
                "id": 9,
                "label": "<span class='gray-span-goalstemp'>with a <span class='black-span-goalstemp'>goal priority</span></span>",
                "placeholder": "Enter Amount",
                "type": "button",
                "name":"goal_priority",
                "value": "",
                "options": [
                    "Need",
                    "Want",
                    "Wish",
                    "Dream"
                ]
            }
        ]
    },
    "save_collage": {
        "goal_id": 3,
        "label": "Save for College",
        "icon":saveCollage,
        "input_data": [
            {
                "id": 1,
                "label": "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>goal amount</span> is</span> ",
                "placeholder": "Enter Amount",
                "name": "goal_amount",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 2,
                "label": "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>initial investment </span> is</span>",
                "placeholder": "Enter Amount",
                "name": "initial_investment",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 3,
                "label": "<span class='gray-span-goalstemp'>with <span class='black-span-goalstemp'>recurring contributions</span> of</span>",
                "placeholder": "Enter Amount",
                "name": "recurring_contributions",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 4,
                "label": "<span class='black-span-goalstemp'>every</span>",
                "placeholder": "0",
                "type": "button",
                "name":"contribution_time",
                "value": "",
                "options": [
                    "year",
                    "month"
                ]
            },
            {
                "id": 5,
                "label": "<span class='gray-span-goalstemp'>I plan to <span class='black-span-goalstemp'>escalate contributions</span></span> ",
                "placeholder": "",
                "name": "escalate_contributions",
                "type": "button",
                "value": "",
                "options": [
                    "yes",
                    "no"
                ]
            },
            {
                "id": 6,
                "label": "<span class='gray-span-goalstemp'>with an <span class='black-span-goalstemp'>escalation percentage of</span></span>",
                "placeholder": "0%",
                "name": "escalation_percentage",
                "type": "range",
                "value": "",
                "options": []
            },
            {
                "id": 7,
                "label": "<span class='black-span-goalstemp'>every (in years)</span>",
                "placeholder": "0",
                "name": "every_years",
                "type": "range",
                "value": "",
                "options": []
            },
            {
                "id": 8,
                "label": "<span class='gray-span-goalstemp'>I want to <span class='black-span-goalstemp'>achieve this goal by</span></span>",
                "placeholder": "dd/mm/yyyy",
                "name": "achieve_this_goal",
                "type": "date",
                "value": "",
                "options": []
            },
            {
                "id": 9,
                "label": "<span class='gray-span-goalstemp'>with a <span class='black-span-goalstemp'>goal priority</span></span>",
                "placeholder": "Enter Amount",
                "type": "button",
                "name":"goal_priority",
                "value": "",
                "options": [
                    "Need",
                    "Want",
                    "Wish",
                    "Dream"
                ]
            }
        ],
        "help_data":[
            {
                "id": 1,
                "label": "Where is the college located?",
                "placeholder": "Select",
                "name": "state",
                "type": "select",
                "value": "",
                "options": []
            },
            {
                "id": 2,
                "label": "What type of a college is it?",
                "placeholder": "Select collage",
                "name": "type",
                "type": "select",
                "value": "",
                "options": []
            },
            {
                "id": 3,
                "label": "What kind of a program would this be?",
                "placeholder": "Select program",
                "name": "type_of_program",
                "type": "select",
                "value": "",
                "options": []
            },
            {
                "id": 4,
                "label": "Do you want to include room and board costs?",
                "placeholder": "0",
                "type": "button",
                "value": "",
                "name":"include_room_and_board_cost",
                "options": [
                    "Yes",
                    "No"
                ]
            },
            {
                "id": 5,
                "label": "When do you plan to enroll your child?",
                "placeholder": "",
                "name": "year",
                "type": "date",
                "value": "",
                "options": []
            }
        ]
    },
    "draw_income": {
        "goal_id": 6,
        "label": "Draw Income",
        "icon":drawIncome,
        "input_data": [
            {
                "id": 1,
                "label": "<span class='gray-span-goalstemp'>I want to <span class='black-span-goalstemp'>draw an income</span> of</span>",
                "placeholder": "Enter Amount",
                "name": "draw_income",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 2,
                "label": "<span class='black-span-goalstemp'>every</span>",
                "placeholder": "0",
                "type": "button",
                "name":"contribution_time",
                "value": "",
                "options": [
                    "year",
                    "month"
                ]
            },
            {
                "id": 3,
                "label": "<span class='gray-span-goalstemp'>From an <span class='black-span-goalstemp'>initial investment</span> of</span>",
                "placeholder": "Enter Amount",
                "name": "initial_investment",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 4,
                "label": "<span class='gray-span-goalstemp'>I will make <span class='black-span-goalstemp'>my start first withdrawal on</span></span>",
                "placeholder": "dd/mm/yyyy",
                "name": "start_first_withdrawal",
                "type": "date",
                "value": "",
                "options": []
            },
            {
                "id": 5,
                "label": "<span class='gray-span-goalstemp'>and my <span class='black-span-goalstemp'>last withdrawal on</span></span>",
                "placeholder": "dd/mm/yyyy",
                "name": "last_withdrawal",
                "type": "date",
                "value": "",
                "options": []
            },
            {
                "id": 6,
                "label": "<span class='gray-span-goalstemp'>I plan to <span class='black-span-goalstemp'>leave a bequest</span></span>",
                "placeholder": "Enter Amount",
                "name": "plan_leave_bequest",
                "type": "button",
                "value": "",
                "options": [
                    "yes",
                    "no"
                ]
            },
            {
                "id": 7,
                "label": "<span class='gray-span-goalstemp'>with a <span class='black-span-goalstemp'> bequest amount of</span> of</span>",
                "placeholder": "Enter Amount",
                "name": "goal_amount",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 8,
                "label": "<span class='gray-span-goalstemp'>with a <span class='black-span-goalstemp'>goal priority</span></span>",
                "placeholder": "",
                "type": "button",
                "name":"goal_priority",
                "value": "",
                "options": [
                    "Need",
                    "Want",
                    "Wish",
                    "Dream"
                ]
            }
        ]
    },
    "plan_retirement": {
        "goal_id": 1,
        "label": "Plan for Retirement",
        "icon":planRetirement,
        "input_data": [
            // {
            //     "id": 1,
            //     "label": "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>Date of Birth </span>is</span> ",
            //     "placeholder": "dd/mm/yyyy",
            //     "name": "date_of_birth",
            //     "type": "date",
            //     "value": "",
            //     "options": []
            // },
            {
                "id": 2,
                "label": "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>initial investment </span> is</span> ",
                "placeholder": "Enter Amount",
                "name": "initial_investment",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 3,
                "label": "<span class='gray-span-goalstemp'>I plan to <span class='black-span-goalstemp'>start my retirement</span></span>",
                "placeholder": "dd/mm/yyyy",
                "name": "plan_start_retirement",
                "type": "date",
                "value": "",
                "options": []
            },
            {
                "id": 4,
                "label": "<span class='black-span-goalstemp'>and end on</span>",
                "placeholder": "dd/mm/yyyy",
                "name": "end_on_date",
                "type": "date",
                "value": "",
                "options": []
            },
            {
                "id": 5,
                "label": "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>targeted retirement income goal</span> is</span>",
                "placeholder": "Enter Amount",
                "name": "targeted_retirement_income",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 6,
                "label": "<span class='black-span-goalstemp'>My withdrawal frequency</span><span class='gray-span-goalstemp'> is</span> ",
                "placeholder": "",
                "name": "my_withdrawal_frequency",
                "type": "button",
                "value": "",
                "options": [
                    "Year",
                    "Month"
                ]
            },
            {
                "id": 7,
                "label": "<span class='gray-span-goalstemp'>with <span class='black-span-goalstemp'>recurring contributions</span> of</span>",
                "placeholder": "Enter Amount",
                "name": "recurring_contributions",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 8,
                "label": "<span class='gray-span-goalstemp'>I plan to <span class='black-span-goalstemp'>escalate contributions</span></span>",
                "placeholder": "",
                "name":"escalate_contributions",
                "type": "button",
                "value": "",
                "options": [
                    "yes",
                    "no"
                ]
            },
            {
                "id": 9,
                "label": "<span class='gray-span-goalstemp'>with an <span class='black-span-goalstemp'>escalation precentage of</span></span>",
                "placeholder": "0",
                "name": "escalation_percentage",
                "type": "range",
                "value": "",
                "options": []
            },
            {
                "id": 10,
                "label": "<span class='gray-span-goalstemp'>I plan to <span class='black-span-goalstemp'>leave a bequest</span></span>",
                "placeholder": "",
                "type": "button",
                "name": "leave_bequest",
                "value": "",
                "options": [
                    "yes",
                    "no"
                ]
            },
            {
                "id": 11,
                "label": "<span class='gray-span-goalstemp'>with a <span class='black-span-goalstemp'>bequest amount</span> of</span>",
                "placeholder": "Enter Amount",
                "name": "goal_amount",
                "type": "text",
                "value": "",
                "options": []
            },
            {
                "id": 12,
                "label": "<span class='gray-span-goalstemp'>with a <span class='black-span-goalstemp'>goal priority</span></span>",
                "placeholder": "",
                "type": "button",
                "name":"goal_priority",
                "value": "",
                "options": [
                    "Need",
                    "Want",
                    "Wish",
                    "Dream"
                ]
            }
        ]
    }
}

export default allGoals