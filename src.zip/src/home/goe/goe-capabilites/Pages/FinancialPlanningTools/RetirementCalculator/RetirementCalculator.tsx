import React, { useEffect, useState } from "react";
import "./RetirementCalculator.scss";
import TitleBar from "../../../Components/FinancialPlanningTools/TitleBar/TitleBar";
// import DatePickerGoe from "home/goe/goe-capabilites/Components/DatePickerGoe/DatePickerGoe";
// import InputGoe from "home/goe/goe-capabilites/Components/InputGoe/InputGoe";
// import SSCalculator from "..//SSCalculator/SSCalculator";
import moment from "moment";
import Modal from "../../../Components/Modal/Modal";
// import { propsToClassKey } from "@mui/styles";
import Slider from "@mui/material/Slider";
import Api from "utils/api";
import Loader from "../../../Components/Loader/Loader";

function RetirementCalculator(props: any) {
    const { inputData, setInputData } = props;
    const [showModal, setShowModal] = useState(false);
    const [responseData, setResponseData] = useState({});
    const [errorMsg, setErrorMsg] = useState("");
    const [errorMsgRet, setErrorMsgRet] = useState("");
    const [loading, setLoading] = useState(false);
    const calculatorName = "Retirement Income Calculator";
    const KeyArray = [
        "dateOfBirth",
        "currentSalary",
        "retirementAge",
        "planningAge",
        "salaryGrowthRate",
        // "outsideAccountBalance",
        // "socialSecurityIncome",
        // "YearlyIncomeDefinedBenefit",
        // "outsideIncome",
    ];

    const RetJsonKeys = Object.keys(inputData);
    const difference = KeyArray.filter((x) => !RetJsonKeys.includes(x));

    const getYearDiff = (todaydateValue, datevalue) => {
        const d1 = new Date(todaydateValue);
        const d2 = new Date(datevalue);
        return Number(new Number((d2.getTime() - d1.getTime()) / 31536000000).toFixed(0));
    };

    useEffect(() => {
        setInputData({});
        // eslint-disable-next-line
    }, []);

    const handleChangeSlider = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        const currentYear = new Date().getFullYear();
        const birthYear = new Date(inputData["dateOfBirth"]).getFullYear();
        const valueYear = new Date(value).getFullYear();

        if (name === "planningAge") {
            const retYear = new Date(inputData["retirementAge"]).getFullYear();
            if (retYear > valueYear) {
                setErrorMsg("Planing date should be greater than retirement date");
            } else {
                setErrorMsg("");
                setInputData({ ...inputData, [name]: value });
            }
        } else if (name === "retirementAge") {
            if (valueYear < birthYear || valueYear < currentYear) {
                setErrorMsgRet("Retirement age should be greater than dateOfBirth and CurrentYear");
            } else {
                setErrorMsgRet("");
                setInputData({ ...inputData, [name]: value });
            }
        } else {
            setInputData({ ...inputData, [name]: value });
        }
    };

    // const handleClick = () => {
    //     setShowModal(!showSSC)
    // };

    const turnSSC = () => {
        props.setIsRetshow(false);
        props.setIsSSCshow(true);
    };

    const handleBack = () => {
        props.setIsRetshow(false);
        props.setStartJourney(true);
        props.setIsSSCshow(false);
    };

    const handleChangeInputDollar = (event) => {
        const name = event.target.name;
        let value = event.target.value;
        value = event.target.value.replace(/\D/g, "");
        if (value) {
            setInputData({ ...inputData, [name]: "$" + parseInt(value.replaceAll("$", "")).toLocaleString() });
        } else {
            setInputData({ ...inputData, [name]: 0 });
        }
    };

    const unFormaAmount = (formatterNUmber) => {
        if (formatterNUmber && typeof formatterNUmber !== "number") {
            return Number(formatterNUmber.replace(/[$,]/g, ""));
        }
        return formatterNUmber;
    };

    // const ValidatedDate = ()=>{
    //     if(getYearDiff(inputData['dateOfBirth'],inputData['retirementAge'])>getYearDiff(inputData['retirementAge'],inputData['planningAge'])){

    //     }
    // }

    const onClickSubmit = async () => {
        const request = {
            dateOfBirth: moment(inputData["dateOfBirth"]).format("DD-MM-YYYY"),
            retirementAge: getYearDiff(inputData["dateOfBirth"], inputData["retirementAge"]),
            planningAge: getYearDiff(inputData["dateOfBirth"], inputData["planningAge"]),
            currentSalary: unFormaAmount(inputData["currentSalary"]),
            salaryGrowthRate: inputData["salaryGrowthRate"] ? inputData["salaryGrowthRate"] : 0,
            outsideAccountBalance: inputData["outsideAccountBalance"]
                ? unFormaAmount(inputData["outsideAccountBalance"])
                : 0,
            companyContribution: inputData["companyContribution"] ? inputData["companyContribution"] : 0,
            traditionContribution: inputData["traditionContribution"] ? inputData["traditionContribution"] : 0,
            rothContribution: inputData["rothContribution"] ? inputData["rothContribution"] : 0,
            autoEscalationRate: inputData["autoEscalationRate"] ? inputData["autoEscalationRate"] : 0,
            replacementRate: 100,
            outsideIncome:
                inputData["YearlyIncomeDefinedBenefit"] && inputData["outsideIncome"]
                    ? unFormaAmount(inputData["YearlyIncomeDefinedBenefit"]) + unFormaAmount(inputData["outsideIncome"])
                    : 0,
            state: "Default",
            inflation: 1,
            socialSecurityIncome: inputData["socialSecurityIncome"]
                ? unFormaAmount(inputData["socialSecurityIncome"])
                : 0,
        };
        setLoading(true);
        const response = await Api.getRetirementData(request);
        setLoading(false);
        if (response.body["IncomeGoalBeforeTax"]) {
            setLoading(false);
            setResponseData(response.body);
            setShowModal(!showModal);
        }
    };

    return (
        <div>
            {loading ? <Loader width={100} /> : <></>}
            <div className="outer-main-div-fpt">
                <div className="back" onClick={props.isFPT ? () => props.setcalculatorName("") : handleBack}>
                    <span className="arrow"></span>
                    <div>Back</div>
                </div>
                <div className="main-div-fpt-rc">
                    <TitleBar title={calculatorName} />
                    <div className="d-flex">
                        <span className="rc_heading_span">Personal Details</span>
                    </div>

                    <div className="row-div-fprc">
                        <div className="row-div-fpt-rc">
                            <div className="subcontent-div-fpt-rc">
                                <div className="span-div-fpt-rc">
                                    <div className="label-div-goe-invest-questiontemp">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>date of birth</span> is</span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div>
                                    <input
                                        name="dateOfBirth"
                                        className="input-goe-goal-amt"
                                        type="date"
                                        onChange={handleChangeSlider}
                                        value={inputData["dateOfBirth"]}
                                    ></input>
                                </div>
                            </div>
                            <div className="subcontent-div-fpt-rc subcontent-div-fpt-rc-right">
                                <div className="span-div-fpt-rc">
                                    <div className="label-div-goe-invest-questiontemp">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>current salary</span> is</span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div>
                                    <input
                                        name="currentSalary"
                                        className="input-goe-goal-amt"
                                        type="text"
                                        onChange={handleChangeInputDollar}
                                        value={inputData["currentSalary"]}
                                        placeholder="$0"
                                    ></input>
                                </div>
                            </div>
                        </div>

                        <div className="row-div-fpt-rc">
                            <div className="subcontent-div-fpt-rc">
                                <div className="span-div-fpt-rc">
                                    <div className="label-div-goe-invest-questiontemp">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='gray-span-goalstemp'>I <span class='black-span-goalstemp'>plan to retire</span> on</span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div>
                                    <input
                                        name="retirementAge"
                                        className="input-goe-goal-amt"
                                        type="date"
                                        onChange={handleChangeSlider}
                                        // value={inputData["retirementAge"]}
                                    ></input>
                                </div>
                            </div>
                            <div className="subcontent-div-fpt-rc subcontent-div-fpt-rc-right">
                                <div className="span-div-fpt-rc">
                                    <div className="label-div-goe-invest-questiontemp">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='gray-span-goalstemp'>with an <span class='black-span-goalstemp'>expected annual growth</span> of</span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="range-slider ft-goe-cap-retcalc-slider">
                                        <div className="range-group">
                                            <Slider
                                                size="small"
                                                defaultValue={0}
                                                aria-label="Small"
                                                valueLabelDisplay="auto"
                                                name="salaryGrowthRate"
                                                value={inputData["salaryGrowthRate"]}
                                                onChange={handleChangeSlider}
                                            />
                                        </div>
                                    </div>
                                    <input
                                        className={`input-range-goe-invest-questiontemp input-goe-invest-questiontemp`}
                                        type="text"
                                        name="salaryGrowthRate"
                                        value={
                                            (inputData["salaryGrowthRate"] ? inputData["salaryGrowthRate"] : "0") + "%"
                                        }
                                        placeholder="0%"
                                        disabled={true}
                                    ></input>
                                </div>
                                {/* <div>
                                <input
                                    name="salaryGrowthRate"
                                    className="input-goe-goal-amt"
                                    type="text"
                                    onChange={handleChangeInputDollar}
                                    value={inputData['salaryGrowthRate']}
                                    placeholder="$0"
                                    >

                                </input>
                            </div> */}
                            </div>
                        </div>
                        {errorMsgRet != "" && <span className="ft-goe-cap-ret-errormsg">{errorMsgRet}</span>}
                        <div className="row-div-fpt-rc">
                            <div className="subcontent-div-fpt-rc">
                                <div className="span-div-fpt-rc">
                                    <div className="label-div-goe-invest-questiontemp">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='gray-span-goalstemp'>and <span class='black-span-goalstemp'>plan to draw income until</span></span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div>
                                    <input
                                        name="planningAge"
                                        className="input-goe-goal-amt"
                                        type="date"
                                        onChange={handleChangeSlider}
                                        min={inputData["retirementAge"]}
                                        // value={inputData["planningAge"]}
                                    ></input>
                                </div>
                            </div>
                        </div>
                    </div>
                    <span className="ft-goe-cap-ret-errormsg">{errorMsg}</span>
                    <hr />
                    <div className="d-flex">
                        <span className="rc_heading_span">Contributions</span>
                    </div>
                    <div className="row-div-fpt-rc">
                        <div className="subcontent-head-div-fpt-rc">
                            <div className="subcontent-head-div-span-fpt-rc">
                                <span className="rc_subcontent_span">Traditional</span>
                            </div>
                            <div>
                                <div className="row-div-fpt-rc">
                                    <div className="subcontent-div-fpt-rc">
                                        <div className="span-div-fpt-rc">
                                            <div className="label-div-goe-invest-questiontemp">
                                                <div
                                                    dangerouslySetInnerHTML={{
                                                        __html: "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>current contribution rate</span> is</span>",
                                                    }}
                                                ></div>
                                            </div>
                                        </div>
                                        <div className="d-flex">
                                            <div className="range-slider ft-goe-cap-retcalc-slider">
                                                <div className="range-group">
                                                    <Slider
                                                        size="small"
                                                        defaultValue={0}
                                                        aria-label="Small"
                                                        valueLabelDisplay="auto"
                                                        name="traditionContribution"
                                                        value={inputData["traditionContribution"]}
                                                        onChange={handleChangeSlider}
                                                        max={50}
                                                    />
                                                </div>
                                            </div>
                                            <input
                                                className={`input-range-goe-invest-questiontemp input-goe-invest-questiontemp`}
                                                type="text"
                                                name="traditionContribution"
                                                value={
                                                    (inputData["traditionContribution"]
                                                        ? inputData["traditionContribution"]
                                                        : "0") + "%"
                                                }
                                                placeholder="0%"
                                                disabled={true}
                                            ></input>
                                        </div>
                                        {/* <div>
                                        <input
                                            name="traditionContribution"
                                            className="input-goe-goal-amt"
                                            type="text"
                                            placeholder="0%"
                                            onChange={handleChangeInputDollar}
                                            value={inputData['traditionContribution']}
                                        >
                                        </input>
                                    </div> */}
                                    </div>
                                </div>
                                <div className="row-div-fpt-rc">
                                    <div className="subcontent-div-fpt-rc">
                                        <div className="span-div-fpt-rc">
                                            <div className="label-div-goe-invest-questiontemp">
                                                <div
                                                    dangerouslySetInnerHTML={{
                                                        __html: "<span class='gray-span-goalstemp'>with a <span class='black-span-goalstemp'>company match</span> of</span>",
                                                    }}
                                                ></div>
                                            </div>
                                        </div>
                                        <div className="d-flex">
                                            <div className="range-slider ft-goe-cap-retcalc-slider">
                                                <div className="range-group">
                                                    <Slider
                                                        size="small"
                                                        defaultValue={0}
                                                        aria-label="Small"
                                                        valueLabelDisplay="auto"
                                                        name="companyContribution"
                                                        value={inputData["companyContribution"]}
                                                        onChange={handleChangeSlider}
                                                        max={100}
                                                    />
                                                </div>
                                            </div>
                                            <input
                                                className={`input-range-goe-invest-questiontemp input-goe-invest-questiontemp`}
                                                type="text"
                                                name="companyContribution"
                                                value={
                                                    (inputData["companyContribution"]
                                                        ? inputData["companyContribution"]
                                                        : "0") + "%"
                                                }
                                                placeholder="0%"
                                                disabled={true}
                                            ></input>
                                        </div>
                                        {/* <div>
                                        <input
                                            name="companyContribution"
                                            className="input-goe-goal-amt"
                                            type="text"
                                            placeholder="0%"
                                            onChange={handleChangeInputDollar}
                                            value={inputData['companyContribution']}
                                        >
                                        </input>
                                    </div> */}
                                    </div>
                                </div>
                                <div className="row-div-fpt-rc">
                                    <div className="subcontent-div-fpt-rc">
                                        <div className="span-div-fpt-rc">
                                            <div className="label-div-goe-invest-questiontemp">
                                                <div
                                                    dangerouslySetInnerHTML={{
                                                        __html: "<span class='gray-span-goalstemp'>and a <span class='black-span-goalstemp'>yearly auto-escalation</span> of</span>",
                                                    }}
                                                ></div>
                                            </div>
                                        </div>
                                        <div className="d-flex">
                                            <div className="range-slider ft-goe-cap-retcalc-slider">
                                                <div className="range-group">
                                                    <Slider
                                                        size="small"
                                                        defaultValue={0}
                                                        aria-label="Small"
                                                        valueLabelDisplay="auto"
                                                        name="autoEscalationRate"
                                                        value={inputData["autoEscalationRate"]}
                                                        onChange={handleChangeSlider}
                                                        max={20}
                                                    />
                                                </div>
                                            </div>
                                            <input
                                                className={`input-range-goe-invest-questiontemp input-goe-invest-questiontemp`}
                                                type="text"
                                                name="autoEscalationRate"
                                                value={
                                                    (inputData["autoEscalationRate"]
                                                        ? inputData["autoEscalationRate"]
                                                        : "0") + "%"
                                                }
                                                placeholder="0%"
                                                disabled={true}
                                            ></input>
                                        </div>
                                        {/* <div>
                                        <input
                                            name="autoEscalationRate"
                                            className="input-goe-goal-amt"
                                            type="text"
                                            placeholder="0%"
                                            onChange={handleChangeInputDollar}
                                            value={inputData['autoEscalationRate']}
                                        >
                                        </input>
                                    </div> */}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="subcontent-head-div-span-fpt-rc-right">
                            <div className="subcontent-head-div-span-fpt-rc">
                                <span className="rc_subcontent_span">Roth</span>
                            </div>
                            <div>
                                <div className="row-div-fpt-rc">
                                    <div className="subcontent-div-fpt-rc">
                                        <div className="span-div-fpt-rc">
                                            <div className="label-div-goe-invest-questiontemp">
                                                <div
                                                    dangerouslySetInnerHTML={{
                                                        __html: "<span class='gray-span-goalstemp'>My <span class='black-span-goalstemp'>current contribution rate</span> is</span>",
                                                    }}
                                                ></div>
                                            </div>
                                        </div>
                                        <div className="d-flex">
                                            <div className="range-slider ft-goe-cap-retcalc-slider">
                                                <div className="range-group">
                                                    <Slider
                                                        size="small"
                                                        defaultValue={0}
                                                        aria-label="Small"
                                                        valueLabelDisplay="auto"
                                                        name="rothContribution"
                                                        value={inputData["rothContribution"]}
                                                        onChange={handleChangeSlider}
                                                        max={50}
                                                    />
                                                </div>
                                            </div>
                                            <input
                                                className={`input-range-goe-invest-questiontemp input-goe-invest-questiontemp`}
                                                type="text"
                                                name="rothContribution"
                                                value={
                                                    (inputData["rothContribution"]
                                                        ? inputData["rothContribution"]
                                                        : "0") + "%"
                                                }
                                                placeholder="0%"
                                                disabled={true}
                                            ></input>
                                        </div>
                                        {/* <div>
                                        <input
                                            name="rothContribution"
                                            className="input-goe-goal-amt"
                                            type="text"
                                            placeholder="0%"
                                            onChange={handleChangeInputDollar}
                                            value={inputData['rothContribution']}
                                        >
                                        </input>
                                    </div> */}
                                    </div>
                                </div>
                                <div className="row-div-fpt-rc">
                                    <div className="subcontent-div-fpt-rc">
                                        <div className="span-div-fpt-rc">
                                            <div className="label-div-goe-invest-questiontemp">
                                                <div
                                                    dangerouslySetInnerHTML={{
                                                        __html: "<span class='gray-span-goalstemp'>with a <span class='black-span-goalstemp'>company match</span> of</span>",
                                                    }}
                                                ></div>
                                            </div>
                                        </div>
                                        <div className="d-flex">
                                            <div className="range-slider ft-goe-cap-retcalc-slider">
                                                <div className="range-group">
                                                    <Slider
                                                        size="small"
                                                        defaultValue={0}
                                                        aria-label="Small"
                                                        valueLabelDisplay="auto"
                                                        name="companyContributionRoth"
                                                        value={inputData["companyContributionRoth"]}
                                                        onChange={handleChangeSlider}
                                                        max={100}
                                                    />
                                                </div>
                                            </div>
                                            <input
                                                className={`input-range-goe-invest-questiontemp input-goe-invest-questiontemp`}
                                                type="text"
                                                name="companyContributionRoth"
                                                value={
                                                    (inputData["companyContributionRoth"]
                                                        ? inputData["companyContributionRoth"]
                                                        : "0") + "%"
                                                }
                                                placeholder="0%"
                                                disabled={true}
                                            ></input>
                                        </div>
                                        {/* <div>
                                        <input
                                            name="companyContribution"
                                            className="input-goe-goal-amt"
                                            type="text"
                                            placeholder="0%"
                                            onChange={handleChangeInputDollar}
                                            value={inputData['companyContribution']}
                                        >
                                        </input>
                                    </div> */}
                                    </div>
                                </div>
                                <div className="row-div-fpt-rc">
                                    <div className="subcontent-div-fpt-rc">
                                        <div className="span-div-fpt-rc">
                                            <div className="label-div-goe-invest-questiontemp">
                                                <div
                                                    dangerouslySetInnerHTML={{
                                                        __html: "<span class='gray-span-goalstemp'>and a <span class='black-span-goalstemp'>yearly auto-escalation</span> of</span>",
                                                    }}
                                                ></div>
                                            </div>
                                        </div>
                                        <div className="d-flex">
                                            <div className="range-slider ft-goe-cap-retcalc-slider">
                                                <div className="range-group">
                                                    <Slider
                                                        size="small"
                                                        defaultValue={0}
                                                        aria-label="Small"
                                                        valueLabelDisplay="auto"
                                                        name="autoEscalationRateRoth"
                                                        value={inputData["autoEscalationRateRoth"]}
                                                        onChange={handleChangeSlider}
                                                        max={20}
                                                    />
                                                </div>
                                            </div>
                                            <input
                                                className={`input-range-goe-invest-questiontemp input-goe-invest-questiontemp`}
                                                type="text"
                                                name="autoEscalationRateRoth"
                                                value={
                                                    (inputData["autoEscalationRateRoth"]
                                                        ? inputData["autoEscalationRateRoth"]
                                                        : "0") + "%"
                                                }
                                                placeholder="0%"
                                                disabled={true}
                                            ></input>
                                        </div>
                                        {/* <div>
                                        <input
                                            name="autoEscalationRate"
                                            className="input-goe-goal-amt"
                                            type="text"
                                            placeholder="0%"
                                            onChange={handleChangeInputDollar}
                                            value={inputData['autoEscalationRate']}
                                        >
                                        </input>
                                    </div> */}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div className="d-flex">
                        <span className="rc_heading_span">Other Accounts</span>
                    </div>

                    <div>
                        <div className="row-div-fpt-rc">
                            <div className="subcontent-div-fpt-rc">
                                <div className="span-div-fpt-rc span-div-fpt-rc-account">
                                    <div className="label-div-goe-invest-questiontemp">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='black-span-goalstemp'>Outside Account balance</span></span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div>
                                    <input
                                        name="outsideAccountBalance"
                                        className="input-goe-goal-amt input-goe-goal-amt-account"
                                        type="text"
                                        placeholder="$0"
                                        onChange={handleChangeInputDollar}
                                        value={inputData["outsideAccountBalance"]}
                                    ></input>
                                </div>
                            </div>
                        </div>
                        <div className="row-div-fpt-rc">
                            <div className="subcontent-div-fpt-rc">
                                <div className="span-div-fpt-rc span-div-fpt-rc-account">
                                    <div className="label-div-goe-invest-questiontemp">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='black-span-goalstemp'>My expected annual social security income is</span></span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div>
                                    <input
                                        name="socialSecurityIncome"
                                        className="input-goe-goal-amt input-goe-goal-amt-account"
                                        type="text"
                                        placeholder="$0"
                                        onChange={handleChangeInputDollar}
                                        value={inputData["socialSecurityIncome"]}
                                    ></input>
                                </div>
                            </div>
                            <div className="goal_amount_div_account">
                                <span className="help_span-goalstemp">
                                    Do you need&nbsp;
                                    <u
                                        className="blue-span-goalstemp"
                                        onClick={
                                            props.isFPT
                                                ? () => props.setcalculatorName("Social Security Calculator")
                                                : turnSSC
                                        }
                                    >
                                        help
                                    </u>
                                    &nbsp;with the annual social security income?{" "}
                                </span>
                            </div>
                        </div>
                        <div className="row-div-fpt-rc">
                            <div className="subcontent-div-fpt-rc">
                                <div className="span-div-fpt-rc span-div-fpt-rc-account">
                                    <div className="label-div-goe-invest-questiontemp">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='black-span-goalstemp'>Yearly income from my defined benefit plan is</span></span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div>
                                    <input
                                        name="YearlyIncomeDefinedBenefit"
                                        className="input-goe-goal-amt input-goe-goal-amt-account"
                                        type="text"
                                        placeholder="$0"
                                        onChange={handleChangeInputDollar}
                                        value={inputData["YearlyIncomeDefinedBenefit"]}
                                    ></input>
                                </div>
                            </div>
                        </div>
                        <div className="row-div-fpt-rc">
                            <div className="subcontent-div-fpt-rc">
                                <div className="span-div-fpt-rc span-div-fpt-rc-account">
                                    <div className="label-div-goe-invest-questiontemp">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='black-span-goalstemp'>with other annual income of</span></span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div>
                                    <input
                                        name="outsideIncome"
                                        className="input-goe-goal-amt input-goe-goal-amt-account"
                                        type="text"
                                        placeholder="$0"
                                        onChange={handleChangeInputDollar}
                                        value={inputData["outsideIncome"]}
                                    ></input>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="button-div-fpt-rc">
                    <div className="button-fpt-rc">
                        <button
                            className={
                                difference.length === 0
                                    ? "button-invest_quetiontemp"
                                    : "button-invest_quetiontemp-disable"
                            }
                            onClick={
                                difference.length === 0
                                    ? onClickSubmit
                                    : () => {
                                          console.log("test");
                                      }
                            }
                        >
                            Submit For Calculation
                        </button>
                    </div>
                </div>
                {showModal && (
                    <Modal
                        setShowModal={setShowModal}
                        responseData={responseData}
                        goalJson={props.goalJson}
                        setGoalJson={props.setGoalJson}
                        setIsRetshow={props.setIsRetshow}
                        isFPT={props.isFPT}
                    />
                )}
            </div>
        </div>
    );
}

export default RetirementCalculator;
