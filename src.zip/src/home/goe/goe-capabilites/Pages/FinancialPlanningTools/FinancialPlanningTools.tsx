import React, { useState } from "react";
import "./FinancialPlanningTools.scss";
import RetirementCalculator from "./RetirementCalculator/RetirementCalculator";
import SocialSecurityCalculator from "./SSCalculator/SSCalculator";
import closeIcon from "../../assets/images/svg/x-circle.svg";
import ComingSoon from "../../assets/images/svg/Coming_Soon.svg";
function FinancialPlanningTools() {
    const [calculatorName, setcalculatorName] = useState("");
    const [inputData, setInputData] = useState({});
    const [showModal, setShowModal] = useState(false);

    interface CalculatorData {
        id: number;
        title: string;
    }

    const Calculators: CalculatorData[] = [
        {
            id: 1,
            title: "Retirement Calculator",
        },
        {
            id: 2,
            title: "Social Security Calculator",
        },
        {
            id: 3,
            title: "Fixed discretionary expenses ",
        },
        {
            id: 4,
            title: "Salary growth Calculator",
        },
    ];

    const showCalculator = (calculatorName) => {
        if (calculatorName === "Retirement Calculator" || calculatorName === "Social Security Calculator")
            setcalculatorName(calculatorName);
        else setShowModal(true);
    };

    function Modal({ children, shown, close }) {
        return shown ? (
            <div
                className="modal-backdrop"
                onClick={() => {
                    // close modal when outside of modal is clicked
                    close();
                }}
            >
                <div
                    className="modal-content"
                    onClick={(e) => {
                        // do not close modal if anything inside modal content is clicked
                        e.stopPropagation();
                    }}
                >
                    <div className="model-fpt-ssc">
                        <label className="modal__close-coming-soon" htmlFor="ft-goe-cap-ret-modal__state">
                            <img src={closeIcon} onClick={close} />
                        </label>
                    </div>
                    {children}
                </div>
            </div>
        ) : null;
    }

    return (
        <div className="outer-main-div-fpt">
            {calculatorName != "" ? (
                calculatorName == "Retirement Calculator" ? (
                    <RetirementCalculator
                        isFPT={true}
                        setcalculatorName={setcalculatorName}
                        setInputData={setInputData}
                        inputData={inputData}
                    />
                ) : (
                    <SocialSecurityCalculator
                        isFPT={true}
                        setcalculatorName={setcalculatorName}
                        setInputData={setInputData}
                        inputData={inputData}
                    />
                )
            ) : (
                <div className="main-div-fpt">
                    <span className="heading-fpt">Financial Planning Tools</span>
                    <hr className="line_fpt" />
                    <div className="outer-calc-div-fpt">
                        {Calculators.map((item) => {
                            return (
                                <div onClick={() => showCalculator(item.title)} key={item.id} className="calc-div-fpt">
                                    <span>{item.title}</span>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}
            <Modal
                shown={showModal}
                close={() => {
                    setShowModal(false);
                }}
            >
                <img src={ComingSoon} className="uip-goe-fpt-wip-img" alt="test" />
            </Modal>
        </div>
    );
}

export default FinancialPlanningTools;
