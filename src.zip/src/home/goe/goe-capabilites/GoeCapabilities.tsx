import React, { useEffect, useState } from "react";
import Header from "./Components/Header/Header";
import Landing from "./Landing/Landing";
import "./styles/goe-capabilites.scss";
import { useLocation } from "react-router-dom";
import InvestorJourney from "./Components/InvestJourney/InvestLandingPage";
import FinancialPlanningTools from "./Pages/FinancialPlanningTools/FinancialPlanningTools";
import GoeConfig from "./Components/GoeConfig/GoeConfig";
import { useScreenshot } from "utils/helpers";
import ComingSoon from "./Components/InvestJourney/ComingSoon";

export default function GoeCapabilities() {
    const pathName = useLocation();
    const screenshot = useScreenshot();
    const [path, setPath] = useState("about");
    const [showModal, setShowModal] = useState(false);
    const setRoutingPath = (path) => {
        setPath(path);
        if (path == "backtest" || path == "goeconfig") {
            setShowModal(true);
        }
    };
    const getRoute = () => {
        const endpoints = pathName.pathname.split("/");
        if (endpoints[endpoints.length - 1] === "financialplanningtools") {
            return <FinancialPlanningTools />;
        } else if (endpoints[endpoints.length - 1] === "invest") {
            return <InvestorJourney setRoutingPath={setRoutingPath} />;
        } else if (endpoints[endpoints.length - 1] === "backtest") {
            return (
                <ComingSoon
                    show={showModal}
                    closeModal={() => {
                        setShowModal(false);
                    }}
                />
            );
        } else if (endpoints[endpoints.length - 1] === "goeconfig") {
            return <GoeConfig />;
            // return (
            //     <ComingSoon
            //         show={showModal}
            //         closeModal={() => {
            //             setShowModal(false);
            //         }}
            //     />
            // );
        } else {
            return <Landing setRoutingPath={setRoutingPath} />;
        }
    };
    useEffect(() => {
        screenshot.take();
    }, [screenshot]);

    useEffect(() => {
        document.title = "GOE Capabilities Support Tool";
        return () => {
            document.title = "Unified Investment Portal";
        };
    }, []);

    return (
        <div>
            <Header path={path} setRoutingPath={setRoutingPath} />
            {getRoute()}
        </div>
    );
}
