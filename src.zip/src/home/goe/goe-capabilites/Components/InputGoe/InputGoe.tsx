import React from "react";
import "./InputGoe.scss";
function InputGoe({ label_value, placeholder, is_others = false, is_right = false, handleChange, name, inputData }) {
    return (
        <div className={is_right ? "div-date-picker-goe right-div-date-picker-goe" : "div-date-picker-goe"}>
            <div className={is_others ? "div-date-picker-label-goe others-label-fpt-rc" : "div-date-picker-label-goe"}>
                <label>{label_value}</label>
            </div>
            <div className={is_others ? "div-date-picker-input-goe others-input-fpt-rc" : "div-date-picker-input-goe"}>
                <input
                    onChange={handleChange}
                    className="date-picker-goe"
                    type="input"
                    value={inputData?.name}
                    name={name}
                    placeholder={placeholder}
                ></input>
            </div>
        </div>
    );
}

export default InputGoe;
