import React, { useState } from "react";
import "./TitleBar.scss";
import EditImage from "../../../assets/images/svg/pen.svg";
function TitleBar(props: any) {
    const [isEdit, setIsEdit] = useState(false);
    return (
        <div className="title_bar_div_fpt">
            <div className="div-title-header">
                {props.isGoal && <img src={props.goalIcon} />}

                {isEdit ? (
                    <input
                        value={props.title}
                        onChange={props.handleChange}
                        className="input-goe-invest-questiontemp label-cursor input-title-bar"
                        name="name"
                        type="text"
                    />
                ) : (
                    <span className="title_bar_fpt">{props.title}</span>
                )}
                {props.isGoal && <img onClick={() => setIsEdit(!isEdit)} src={EditImage} />}

                {props.duplicateName && (
                    <div className="duplicate-goal-name">Duplicate goal name on record. Please rename the goal</div>
                )}
            </div>
            <div className="d-flex">
                <span className="subtitle-title-bar">{props.subtitle}</span>
            </div>
            <hr className="title_line_fpt" />
        </div>
    );
}

export default TitleBar;
