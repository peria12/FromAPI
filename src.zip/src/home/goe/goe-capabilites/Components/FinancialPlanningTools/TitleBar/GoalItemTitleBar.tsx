import React from "react";
import "./TitleBar.scss";
import TrashCan from "../../../assets/images/svg/trash-can.svg";
import UpdateIcon from "../../../assets/images/svg/Update-Can.svg";
import GoalCheck from "../../../assets/images/svg/goal-check.svg";
function GoalItemTitleBar({ title, isGoal = false, goalIcon = "", editGoal, deleteGoal }) {
    return (
        <div className="title_bar_div_fpt goal-item-toolbar">
            <div>
                {isGoal && <img src={goalIcon} />}
                <span className="title_bar_fpt">{title}</span>
            </div>

            <div className="edit-actions">
                {isGoal && (
                    <img
                        src={TrashCan}
                        onClick={() => {
                            deleteGoal();
                        }}
                    />
                )}
                {isGoal && (
                    <img
                        src={UpdateIcon}
                        onClick={() => {
                            editGoal();
                        }}
                    />
                )}
                {isGoal && <img src={GoalCheck} />}
            </div>
        </div>
    );
}

export default GoalItemTitleBar;
