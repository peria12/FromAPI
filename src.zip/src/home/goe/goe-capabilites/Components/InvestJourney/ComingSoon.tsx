import React from "react";
import closeIcon from "../../assets/images/svg/x-circle.svg";
import ComingSoonIcon from "../../assets/images/svg/Coming_Soon.svg";

const ComingSoon = (props) => {
    return (
        <Modal
            shown={props.show}
            close={() => {
                props.closeModal(false);
            }}
        >
            <img src={ComingSoonIcon} className="uip-goe-fpt-wip-img" alt="test" />
        </Modal>
    );
};

function Modal({ children, shown, close }) {
    return shown ? (
        <div
            className="modal-backdrop"
            onClick={() => {
                // close modal when outside of modal is clicked
                close();
            }}
        >
            <div
                className="modal-content"
                onClick={(e) => {
                    // do not close modal if anything inside modal content is clicked
                    e.stopPropagation();
                }}
            >
                <div className="model-fpt-ssc">
                    <label className="modal__close modal__close-coming-soon" htmlFor="ft-goe-cap-ret-modal__state">
                        <img src={closeIcon} onClick={close} />
                    </label>
                </div>
                {children}
            </div>
        </div>
    ) : null;
}

export default ComingSoon;
