import React, { useContext } from "react";
import GoalItemTitleBar from "../../Components/FinancialPlanningTools/TitleBar/GoalItemTitleBar";
import Loader from "./Loader";
import { GoeCapabilitiesContext } from "../../GoeCapabilitiesContext";
const GoalList = (props: any) => {
    const goalPrioritys = ["Need", "Want", "Wish", "Dream", undefined];
    const activeGoal = props.activeGoal || {};
    const { goalList } = useContext(GoeCapabilitiesContext);

    const goalListclass = goalList.length > 0 ? "has-goals" : "no-goals";

    return (
        <div className={"goal-list " + goalListclass}>
            {props.loading && goalList.length >= 1 ? <Loader /> : <></>}
            {goalList.length == 0 && (
                <div>
                    <div className="goal-list-img"></div>
                    <div>Please add a goal to proceed</div>
                </div>
            )}

            {goalList.length > 0 && (
                <div className="goals-header">
                    <div>My Goals</div>
                </div>
            )}

            <div className="goal-category-list">
                {goalPrioritys.map((goalPriority) => {
                    const priorityGoals =
                        goalList.filter((goal) => {
                            return goal["goal_priority"] === goalPriority;
                        }) || [];
                    return (
                        priorityGoals.length > 0 && (
                            <div className="goal-category">
                                <div className="header">
                                    <span>{goalPriority ? goalPriority : "No-Priority"}</span>
                                    <div className="border"></div>
                                </div>
                                <ul className="goal-category-list-items">
                                    {priorityGoals.map((goalItem: any, index) => {
                                        const active = activeGoal["goal-key"] === goalItem["goal-key"] ? "active" : "";
                                        return (
                                            <li key={goalItem.name + index} className={active}>
                                                <GoalItemTitleBar
                                                    title={goalItem.name}
                                                    isGoal={true}
                                                    goalIcon={goalItem.icon}
                                                    editGoal={() => {
                                                        props.editGoal(goalItem["goal-key"]);
                                                    }}
                                                    deleteGoal={() => {
                                                        props.deleteGoal(goalItem["goal-key"]);
                                                    }}
                                                />
                                                <div className="goal-details">
                                                    <div className="goal-value">
                                                        <label>Goal Value</label>
                                                        {goalItem["goal-key"] == "draw_income" && (
                                                            <span>{goalItem.draw_income}</span>
                                                        )}
                                                        {goalItem["goal-key"] != "draw_income" && (
                                                            <span>{goalItem.goal_amount}</span>
                                                        )}
                                                    </div>
                                                    <div className="goal-tenure">
                                                        <label>Tenure</label>
                                                        <span>{goalItem.tenure}</span>
                                                    </div>
                                                    <div className="goal-initial-wealth">
                                                        <label>Initial Wealth</label>
                                                        <span>{goalItem.initial_investment}</span>
                                                    </div>
                                                </div>
                                            </li>
                                        );
                                    })}
                                </ul>
                            </div>
                        )
                    );
                })}
            </div>
            {goalList.length > 0 && (
                <button onClick={() => props.saveGoals()} className="save-goals-btn">
                    I am done adding goals
                </button>
            )}
            {props.wlthSplitter == "wealth-splitter" && goalList.length > 0 && (
                <button onClick={() => props.addMoreGoals()} className="save-goals-btn">
                    Add More Goals
                </button>
            )}
        </div>
    );
};

export default GoalList;
