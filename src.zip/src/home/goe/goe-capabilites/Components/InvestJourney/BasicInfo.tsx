import React, { useState, useContext } from "react";
import { Button } from "react-bootstrap";
import Api from "utils/api";
import { debounce } from "lodash";
import { GoeCapabilitiesContext } from "../../GoeCapabilitiesContext";
import ComingSoon from "../../Components/InvestJourney/ComingSoon";
import Aggressive from "../../assets/images/svg/aggressive.svg";
import conservative from "../../assets/images/svg/conservative.svg";
import moderate from "../../assets/images/svg/moderate.svg";
import UpSelect from "../../assets/images/svg/UpSelect.svg";
import DownSelect from "../../assets/images/svg/DownSelect.svg";

const BasicInfo = () => {
    const [error, setError] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const [searchResult, setSearchResult] = useState([]);
    const [isUserExist, setIsUserExist] = useState(false);
    const [isDropdown, setIsDropDown] = useState(false);
    const [isSelectClicked, setIsSelectClicked] = useState(false);
    // const [isEdit,setIsEdit]=useState(false);
    const {
        name,
        gender,
        dob,
        riskProfile,
        userFlag,
        isEdit,
        setJourneyPath,
        setName,
        setGender,
        setDob,
        setRiskProfile,
        setUserFlag,
        setIsEdit,
    } = useContext(GoeCapabilitiesContext);
    const ProceedToAddGoals = async () => {
        // if (name && name == "" && name.length == 0 && name.trim().length == 0) {
        //     setError(true);
        // } else {
        setError(false);
        if (!userFlag) {
            const basicInfo = { full_name: name, dob: dob, gender: gender, risk_profile: riskProfile };
            const result = await Api.saveUserDetails(basicInfo);
            localStorage.setItem("clientId", result["client_id"]);
            setUserFlag!(true);
            setIsEdit!(true);
        }
        setJourneyPath!("goal-type");
        // }
    };

    const onSearch = async (value) => {
        const apiResult = await Api.onSearch(value);
        if (apiResult.body.length) {
            setSearchResult(apiResult.body);
            setIsUserExist(false);
            if (!isDropdown) {
                setIsDropDown(true);
            }
            setIsDropDown(true);
        } else {
            setIsUserExist(true);
            setSearchResult([]);
        }
    };

    const onSearchClick = (name) => {
        const filteredResult = searchResult.filter((item) => item["full_name"] === name);
        if (filteredResult.length) {
            localStorage.setItem("clientId", filteredResult[0]["_id"]);
            setName!(filteredResult[0]["full_name"]);
            setGender!(filteredResult[0]["gender"]);
            setDob!(filteredResult[0]["dob"]);
            setRiskProfile!(filteredResult[0]["risk_profile"]);
            setSearchResult([]);
            setUserFlag!(true);
            setIsEdit!(true);
            setIsDropDown(false);
            // setIsUserExist(false);
        }
    };
    const processChange = debounce((value) => {
        onSearch(value);
    }, 500);

    const editInfo = () => {
        setIsEdit!(false);
    };

    const onCreateNewClient = () => {
        setName!(name as string);
        setGender!("");
        setDob!("");
        setRiskProfile!("");
        setSearchResult([]);
        setUserFlag!(false);
        setIsEdit!(false);
        setIsUserExist(false);
        setIsDropDown(false);
        setIsEdit!(true);
        if (userFlag) {
            setUserFlag!(false);
        }
    };

    return (
        <>
            <div>
                <div className="basic-information">
                    <div className="basic-header">
                        <span>Basic Information</span>
                        <div className="basic-border"></div>
                    </div>
                    {/* <Search searchResult={searchResult}/> */}
                    <div className="basic-form">
                        <div className="name">
                            <div className="row-div row-div-left">
                                <label>Select Client</label>
                            </div>
                            <div className="row-div row-div-input">
                                <div className="d-flex">
                                    <div
                                        className={`dropdown ${isEdit ? "disabled" : isSelectClicked ? "selected" : ""
                                            }`}
                                        onClick={() => setIsSelectClicked(true)}
                                    >
                                        <input
                                            type="text"
                                            placeholder="Select Client"
                                            // defaultValue={name}
                                            value={name}
                                            className="dropdown-input"
                                            // onChange={(event) => {
                                            //     if (event.target) {
                                            //         setName!(event.target.value);
                                            //     }
                                            // }}
                                            onChange={(event) => {
                                                setName!(event.target.value);
                                                processChange(event.target.value);
                                            }}
                                            disabled={isEdit}
                                        />
                                        {!isEdit && (
                                            <img
                                                className="icon"
                                                src={isDropdown ? DownSelect : UpSelect}
                                                onClick={() => setIsDropDown(!isDropdown)}
                                            />
                                        )}
                                    </div>
                                    <div className="edit-icon">{isEdit && <span onClick={editInfo}>📝</span>}</div>
                                </div>
                                {(searchResult.length > 0 || isDropdown) && !isUserExist && (
                                    <div className="search">
                                        {!isUserExist && (
                                            <div
                                                // key={item["full_name"]}
                                                className="label-div"
                                                onClick={() => onCreateNewClient()}
                                            >
                                                <span>Create new client</span>
                                            </div>
                                        )}
                                        {searchResult.length > 0 &&
                                            name != "" &&
                                            searchResult.map((item) => {
                                                const fields = (item["full_name"] as string).split(name as string);
                                                console.log("fields", fields);
                                                return (
                                                    <div
                                                        key={item["full_name"]}
                                                        className="label-div"
                                                        onClick={() => onSearchClick(item["full_name"])}
                                                    >
                                                        <span>{name}</span>
                                                        <span className="gray">{fields[1]}</span>
                                                    </div>
                                                );
                                            })}
                                    </div>
                                )}
                                {isUserExist && (
                                    <div className="search">
                                        {" "}
                                        <div
                                            // key={item["full_name"]}
                                            className="label-div"
                                            onClick={() => onCreateNewClient()}
                                        >
                                            <span>Create new client</span>
                                        </div>
                                    </div>
                                )}
                            </div>
                            {error && <span className="error">Name is mandatory</span>}
                        </div>
                        <div className="name">
                            <div className="row-div row-div-left">
                                <label>DOB</label>
                            </div>
                            <div className="row-div">
                                <input
                                    type="date"
                                    onChange={(event) => {
                                        if (event.target) {
                                            setDob!(event.target.value);
                                        }
                                    }}
                                    defaultValue={dob}
                                    disabled={userFlag}
                                    value={dob}
                                />
                            </div>
                            {/* {error && <span className="error">Name is mandatory</span>} */}
                        </div>
                        <div className="name">
                            <div className="row-div row-div-left">
                                <label>Gender</label>
                            </div>
                            <div className="row-div">
                                <select
                                    name="gender"
                                    onChange={(event) => {
                                        if (event.target) {
                                            setGender!(event.target.value);
                                        }
                                    }}
                                    disabled={userFlag}
                                >
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            {/* {error && <span className="error">Name is mandatory</span>} */}
                        </div>
                        <div className="risk">
                            <label>Select your Risk Profile</label>
                            <div className="d-flex">
                                <div className="image-div">
                                    <div>
                                        <img src={conservative} />
                                    </div>
                                    <div className="radio-div">
                                        <input
                                            type="radio"
                                            onClick={() => {
                                                setRiskProfile!("Conservative");
                                            }}
                                            checked={riskProfile === "Conservative" ? true : false}
                                            disabled={userFlag}
                                        />
                                        <div>
                                            <label>Conservative</label>
                                        </div>
                                    </div>
                                </div>
                                {/* <button
                                    onClick={() => {
                                        setRiskProfile!("Conservative");
                                    }}
                                    className={riskProfile === "Conservative" ? "active" : ""}
                                >
                                    Conservative
                                </button> */}
                                <div className="image-div">
                                    <div>
                                        <img src={moderate} />
                                    </div>
                                    <div className="radio-div">
                                        <input
                                            type="radio"
                                            onClick={() => {
                                                setRiskProfile!("Moderate");
                                            }}
                                            checked={riskProfile === "Moderate" ? true : false}
                                            disabled={userFlag}
                                        />
                                        <label>Moderate</label>
                                    </div>
                                </div>

                                {/* <button
                                    onClick={() => {
                                        setRiskProfile!("Moderate");
                                    }}
                                    className={riskProfile === "Moderate" ? "active" : ""}
                                >
                                    Moderate
                                </button> */}
                                <div className="image-div">
                                    <div>
                                        <img src={Aggressive} />
                                    </div>
                                    <div className="radio-div">
                                        <input
                                            type="radio"
                                            onClick={() => {
                                                setRiskProfile!("Aggressive");
                                            }}
                                            value=""
                                            checked={riskProfile === "Aggressive" ? true : false}
                                            disabled={userFlag}
                                        />
                                        <label>Aggressive</label>
                                    </div>
                                </div>

                                {/* <button
                                    onClick={() => {
                                        setRiskProfile!("Aggressive");
                                    }}
                                    className={riskProfile === "Aggressive" ? "active" : ""}
                                >
                                    Aggressive
                                </button> */}
                            </div>
                        </div>
                        {/* <div className="help">
                            Do you need{" "}
                            <a
                                href="#"
                                onClick={() => {
                                    setRiskProfile!("Aggressive");
                                    setShowModal(true);
                                }}
                            >
                            help
                            </a>
                            {" "}
                            with your Risk Profile?
                        </div> */}
                    </div>
                </div>
                <div className="proceed-to-goals">
                    <Button
                        onClick={() => ProceedToAddGoals()}
                        className="proceed-goals-btn"
                    // disabled={!name}
                    >
                        Proceed To Add Goals
                    </Button>
                </div>
            </div>
            <ComingSoon
                show={showModal}
                closeModal={() => {
                    setShowModal(false);
                }}
            />
        </>
    );
};

export default BasicInfo;
