import React, { useState, useContext } from "react";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import Api from "utils/api";
import Loader from "./Loader";
import { GoeCapabilitiesContext } from "../../GoeCapabilitiesContext";

import EachGoalImage from "../../assets/images/svg/one-portfolio-each-goal.svg";
import AllGoalsImage from "../../assets/images/svg/one-portfolio-all-goal.svg";

function GoalUtilizeModal(props) {
    const {
        goalList,
        setGoalUpaReport,
        setIsUpa,
        setOverview,
        setGoalUpaReportConfig,
        setGoalWealthReportData,
        setGoalWealthReportDataConfig,
        loading,
        setLoading,
        goalSelection,
    } = props;
    const { name, riskProfile } = useContext(GoeCapabilitiesContext);
    const basicInfo = { name: name, risk_profile_type: riskProfile };
    const [utilizeGoalSelection, setUtilizeGoalSelection] = useState(goalSelection || "one-portfolio");
    const onUPAClick = async () => {
        setLoading(true);
        const result = await Api.UPA(goalList, basicInfo, false);
        const resultGeneratePaylaod = await Api.UPA(goalList, basicInfo, true);
        setGoalWealthReportData(result.body);
        setGoalWealthReportDataConfig(resultGeneratePaylaod.body);
        setGoalUpaReport(result.body);
        setGoalUpaReportConfig(resultGeneratePaylaod.body);
        setLoading(false);
        setIsUpa(true);
        setOverview("overview");
    };
    //goalList,basicInfo
    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            className="goal-utilize-modal"
        >
            {loading ? <Loader /> : <></>}
            <Modal.Header closeButton>
                <Modal.Title>I would like to utilize</Modal.Title>
                <div className="header-border"></div>
            </Modal.Header>
            <Modal.Body>
                <div className="utilize-goal-section">
                    <div className="utilize-goal-action" onClick={() => setUtilizeGoalSelection("one-portfolio")}>
                        <div className={`utilize-goal-image each-goal`} style={{
                            backgroundImage: `url(${EachGoalImage})`
                        }}></div>
                        <div className={`add  ${utilizeGoalSelection === "one-portfolio" ? "active" : ""}`}>
                            <input
                                type="radio"
                                id="utilize-goal"
                                checked={utilizeGoalSelection == "one-portfolio"}
                                name="goals"
                                value="one-portfolio"
                            />
                            <label>A different portfolio for each goal</label>
                        </div>
                    </div>
                    <div className="utilize-goal-action" onClick={() => setUtilizeGoalSelection("all-portfolios")}>
                        <div className={`utilize-goal-image all-goals`} style={{
                            backgroundImage: `url(${AllGoalsImage})`
                        }}></div>
                        <div className={`add  ${utilizeGoalSelection === "all-portfolios" ? "active" : ""}`}>
                            <input
                                type="radio"
                                id="utilize-goal"
                                checked={utilizeGoalSelection == "all-portfolios"}
                                name="goals"
                                value="all-portfolios"
                            // disabled={true}
                            />
                            <label>One Portfolio for all my Goals</label>
                        </div>
                    </div>
                </div>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="link" onClick={props.onHide}>
                    Cancel
                </Button>
                <Button
                    onClick={
                        utilizeGoalSelection === "all-portfolios"
                            ? onUPAClick
                            : () => {
                                props.showWealthSplitter(utilizeGoalSelection);
                            }
                    }
                >
                    Proceed
                </Button>
            </Modal.Footer>
        </Modal>
    );
}

export default GoalUtilizeModal;
