import React, { useEffect, useState, useContext, useCallback } from "react";
import "./invest-journey.scss";
import moment from "moment";
import GlobeIcon from "../../assets/images/svg/globe-icon.svg";
import BuildingInvestment from "../../assets/images/svg/Building_investment.svg";
import Invest from "../../Pages/Invest/Invest";
import GoalOverView from "../../Components/Invest/GoalOverview/GoalOverview";
import Disclosure from "../../Components/Disclosure/Disclosure";
import Api from "utils/api";
import RetirementCalculator from "../../Pages/FinancialPlanningTools/RetirementCalculator/RetirementCalculator";
import SSCalculator from "../../Pages/FinancialPlanningTools/SSCalculator/SSCalculator";
import TimeLine from "./TimeLine";
import GoalList from "./GoalList";
import GoalSelection from "./GoalSelection";
import BasicInfo from "./BasicInfo";
import WealthSplitter from "./WealthSplitter";
import WealthSplitterFull from "./WealthSplitterFull";
import GoalUtilizeModal from "./GoalUtilizeModal";
import { GoeCapabilitiesContext } from "../../GoeCapabilitiesContext";
import BackgroundImage1 from "../../assets/images/svg/background1.svg";
import BackgroundImage2 from "../../assets/images/svg/background2.svg";
import BackgroundImage3 from "../../assets/images/svg/background3.svg";
import OverviewBackground from "../../assets/images/svg/Overview_background.svg";

const welathRecommendationColors = ["#00847D", "#6CA2FF", "#FF8A1F", "#FAB518", "#A68CFF"];

const InvestorJourney = (props: any) => {
    const [startJourney, setStartJourney] = useState(false);
    const [isRetshow, setIsRetshow] = useState(false);
    const [isSSCshow, setIsSSCshow] = useState(false);
    const [addedGoalList, setAddedGoalList] = useState<any>([]);
    const [goalQuestionnaire, setGoalQuestionnaire] = useState("");
    const [journeyPath, setJourneyPath] = useState("basic-information");
    const [goalJson, setGoalJson] = useState<any>({});
    const [loading, setLoading] = useState(false);
    const [inputData, setInputData] = useState({});
    const [overview, setOverview] = useState("");

    const startInvestJourney = () => {
        setStartJourney(true);
        props.setRoutingPath("invest");
    };

    const investJourneyBackgroundClass = startJourney
        ? overview
            ? "investor-goal-overview"
            : "investor-journey-started"
        : "";
    const investJournetBackgroundImage = startJourney
        ? overview
            ? `url(${OverviewBackground})`
            : `url(${BackgroundImage3})`
        : `url(${BackgroundImage1}), url(${BackgroundImage2})`;
    return (
        <div className={"investor-journey " + investJourneyBackgroundClass} style={{
            backgroundImage: investJournetBackgroundImage
        }}>
            {!isRetshow && !isSSCshow && !startJourney && <InvestLandingPage startInvestJourney={startInvestJourney} />}
            {isRetshow && !isSSCshow && (
                <RetirementCalculator
                    setIsRetshow={setIsRetshow}
                    setIsSSCshow={setIsSSCshow}
                    setStartJourney={setStartJourney}
                    setGoalJson={setGoalJson}
                    goalJson={goalJson}
                    setLoading={setLoading}
                    loading={loading}
                    setInputData={setInputData}
                    inputData={inputData}
                />
            )}
            {isSSCshow && (
                <SSCalculator setIsRetshow={setIsRetshow} setIsSSCshow={setIsSSCshow} setInputData={setInputData} />
            )}
            {!isRetshow && !isSSCshow && startJourney && (
                <InvestGoalJourney
                    app_id={props.app_id}
                    zone_id={props.zone_id}
                    setIsRetshow={setIsRetshow}
                    setStartJourney={setStartJourney}
                    setAddedGoalList={setAddedGoalList}
                    addedGoalList={addedGoalList}
                    setGoalQuestionnaire={setGoalQuestionnaire}
                    goalQuestionnaire={goalQuestionnaire}
                    journeyPath={journeyPath}
                    setJourneyPath={setJourneyPath}
                    setGoalJson={setGoalJson}
                    goalJson={goalJson}
                    setLoading={setLoading}
                    loading={loading}
                    setOverview={setOverview}
                    overview={overview}
                />
            )}
            <Disclosure />
        </div>
    );
};

const InvestGoalJourney = (props: any) => {
    const {
        addedGoalList,
        setAddedGoalList,
        goalQuestionnaire,
        setGoalQuestionnaire,
        goalJson,
        setGoalJson,
        loading,
        setLoading,
        setOverview,
        overview,
    } = props;
    const [goalEditType, setGoalEditType] = useState("NEW");
    const [activeGoal, setActiveGoal] = useState({});
    const [showGoalUtilize, setShowGoalUtilize] = useState(false);
    const [wlthSplitter, setWlthSplitter] = useState("");
    const [wealthRecommendation, setWealthRecommendations] = useState([]);
    const [optimizedGoalList, setOptimizedGoalList] = useState<any>([]);
    const [goalSelection, setGoalSelection] = useState("");
    const [goalWealthReport, setGoalWealthReport] = useState({});
    const [goalWealthReportsGeneratepayloadonly, setGoalWealthReportGeneratepayloadonly] = useState({});
    const [goalUpaReport, setGoalUpaReport] = useState({});
    const [goalUpaReportConfig, setGoalUpaReportConfig] = useState({});
    const [isUpa, setIsUpa] = useState(false);
    const [goalOptimized, setGoalOptimized] = useState(false);
    const [goalWealthReportData, setGoalWealthReportData] = useState({});
    const [goalWealthReportDataConfig, setGoalWealthReportDataConfig] = useState({});

    const { name, riskProfile, journeyPath, setJourneyPath, setGoalList } = useContext(GoeCapabilitiesContext);

    const saveGoals = async () => {
        setIsUpa(false);
        if (addedGoalList.length > 1) {
            setShowGoalUtilize(true);
        } else {
            const runPipeCalls: any = [];
            const runPipeCallsGeneratepayloadonly: any = [];
            const runPipeGoalsKeys: any = [];
            setLoading(true);
            for (let i = 0; i < addedGoalList.length; i++) {
                runPipeGoalsKeys.push(addedGoalList[i]["goal-key"]);
                const goalDetails = addedGoalList[i];
                const recommendation: any = wealthRecommendation.filter((rc: any) => {
                    return rc.goalId == goalDetails["goal-key"];
                });
                if (recommendation && recommendation.length) {
                    // goalDetails initialWealth= recommendation.suggested
                    goalDetails["initial_investment"] = recommendation[0].suggested;
                }
                const basicInfo = { name: name, risk_profile_type: riskProfile };
                const runPipePromise = Api.runPipe(goalDetails, basicInfo, false, false, 0);
                const runPipePromiseGeneratepayloadonly = Api.runPipe(addedGoalList[i], basicInfo, true, false, 0);
                runPipeCalls.push(runPipePromise);
                runPipeCallsGeneratepayloadonly.push(runPipePromiseGeneratepayloadonly);
            }
            const goalWealthReports = {};
            const goalWealthReportsGeneratepayloadonly = {};

            const res = await Promise.all(runPipeCalls);
            const resGeneratepayloadonly = await Promise.all(runPipeCallsGeneratepayloadonly);
            await Promise.all(
                res.map((r, i) => {
                    goalWealthReports[runPipeGoalsKeys[i]] = r.body;
                    return r.body;
                })
            );

            await Promise.all(
                resGeneratepayloadonly.map((r, i) => {
                    goalWealthReportsGeneratepayloadonly[runPipeGoalsKeys[i]] = r.body;
                    return r.body;
                })
            );
            setLoading(false);
            setGoalWealthReport(goalWealthReports);
            setGoalWealthReportGeneratepayloadonly(goalWealthReportsGeneratepayloadonly);
            setOverview("overview");
        }
    };

    // useEffect(() => {
    //     Api.getUserDetails(appId, zoneId).then((response) => {
    //         if (response.body) {
    //             const userDetails = response.body["user_details"];
    //             if (!userDetails) {
    //                 setName!(response.body["name"]);
    //                 setRiskProfile!(response.body["risk_profile_type"]);
    //             } else {
    //                 setName!(userDetails["name"]);
    //                 setRiskProfile!(userDetails["risk_profile_type"]);
    //             }
    //         }
    //     });
    // }, [appId, zoneId, setName, setRiskProfile]);

    const getAllGoals = useCallback(() => {
        Api.getAllGoals().then((response) => {
            if (response.body.goal_data) {
                // localStorage.setItem("object_id", response.body._id);
                const goalData = response.body.goal_data;
                const goalList: any[] = [];
                for (const goalKey in goalData) {
                    const goalInfo = goalData[goalKey];
                    goalInfo["goal-key"] = goalKey;

                    goalList.push(goalInfo);
                }
                setGoalList!(goalList);
                setAddedGoalList(goalList);
                setLoading(false);
            }
        });
    }, [setAddedGoalList, setGoalList, setLoading]);

    useEffect(() => {
        getAllGoals();
    }, [getAllGoals]);

    const saveGoal = (goalDetails: any) => {
        let isGoalExist = false;
        const timeFrameType = goalDetails["contribution_time"] == "month" ? "months" : "years";
        if (goalDetails["goal_key"] == "plan_retirement") {
            const retirementTimeFrameType = goalDetails["my_withdrawal_frequency"] == "Month" ? "months" : "years";
            goalDetails.tenure = `${Math.abs(
                Math.ceil(moment().diff(goalDetails["end_on_date"], retirementTimeFrameType, true))
            )} ${retirementTimeFrameType}`;
        } else if (goalDetails["goal_key"] == "draw_income") {
            goalDetails.tenure = `${Math.abs(
                Math.ceil(moment().diff(goalDetails["last_withdrawal"], timeFrameType, true))
            )} ${timeFrameType}`;
            goalDetails["goal_amount"] = goalDetails["draw_income"];
        } else {
            goalDetails.tenure = `${Math.abs(
                Math.ceil(moment().diff(goalDetails["achieve_this_goal"], timeFrameType, true))
            )} ${timeFrameType}`;
        }

        for (let i = 0; i < addedGoalList.length; i++) {
            if (addedGoalList[i]["goal-key"] == goalDetails["goal-key"]) {
                addedGoalList[i] = goalDetails;
                isGoalExist = true;
            }
        }
        setLoading(true);
        if (isGoalExist) {
            Api.updateGoal(goalDetails, goalDetails["goal-key"]).then(() => {
                getAllGoals();
            });
        } else {
            Api.saveGoals(goalDetails).then(() => {
                getAllGoals();
            });
        }

        setGoalQuestionnaire("");
        setActiveGoal({});
        setGoalEditType("NEW");
    };

    const editGoal = (goalKey: string) => {
        setGoalEditType("EDIT");
        const currentGoal = addedGoalList.filter((goal) => {
            return goal["goal-key"] === goalKey;
        });
        if (currentGoal && currentGoal.length > 0) {
            setActiveGoal(currentGoal[0]);
        }
        setWlthSplitter("");
        setGoalQuestionnaire(currentGoal[0]["goal_key"]);
    };

    const deleteGoal = (goalKey: string) => {
        setLoading(true);
        Api.deleteGoal(goalKey).then(() => {
            getAllGoals();
            setGoalQuestionnaire("");
            setGoalEditType("NEW");
            setActiveGoal({});
        });
    };

    const addMoreGoals = () => {
        setJourneyPath!("goal-type");
        setGoalQuestionnaire("");
        setActiveGoal({});
        setWlthSplitter("");
    };

    return (
        <div className="goals-journey">
            {overview != "overview" && <TimeLine investJourneyPath={journeyPath} />}
            {journeyPath === "basic-information" && <BasicInfo />}
            {journeyPath == "goal-type" && overview != "overview" && (
                <div className="goal-type">
                    <div className="goal-selection-list">
                        {goalQuestionnaire && wlthSplitter == "" && (
                            <Invest
                                goalId={goalQuestionnaire}
                                setGoalQuestionnaire={setGoalQuestionnaire}
                                saveGoal={saveGoal}
                                goalEditType={goalEditType}
                                goalData={activeGoal}
                                addedGoalList={addedGoalList}
                                setIsRetshow={props.setIsRetshow}
                                setIsSSCshow={props.setIsSSCshow}
                                setStartJourney={() => props.setStartJourney}
                                setGoalJson={setGoalJson}
                                goalJson={goalJson}
                                backClick={() => {
                                    setGoalQuestionnaire("");
                                    setActiveGoal({});
                                    setGoalJson({});
                                }}
                            />
                        )}
                        {!goalQuestionnaire && wlthSplitter == "" && (
                            <GoalSelection
                                showGoalQuestioonaire={setGoalQuestionnaire}
                                setGoalEditType={(editType) => {
                                    setGoalEditType(editType);
                                }}
                            />
                        )}

                        {wlthSplitter === "wealth-splitter" && (
                            <WealthSplitter
                                goalList={addedGoalList}
                                loading={loading}
                                backClick={() => {
                                    getAllGoals();
                                    setWlthSplitter("");
                                    setJourneyPath!("goal-type");
                                    setActiveGoal({});
                                }}
                                showGoalUtilization={async () => {
                                    const basicInfo = {
                                        name: name,
                                        risk_profile_type: riskProfile,
                                    };
                                    setGoalOptimized(false);
                                    if (goalSelection === "one-portfolio") {
                                        const runPipeCalls: any = [];
                                        const runPipeCallsGeneratepayloadonly: any = [];
                                        const runPipeGoalsKeys: any = [];
                                        setLoading(true);

                                        for (let i = 0; i < addedGoalList.length; i++) {
                                            runPipeGoalsKeys.push(addedGoalList[i]["goal-key"]);
                                            const runPipePromise = Api.runPipe(
                                                addedGoalList[i],
                                                basicInfo,
                                                false,
                                                false,
                                                0
                                            );
                                            const runPipePromiseGeneratepayloadonly = Api.runPipe(
                                                addedGoalList[i],
                                                basicInfo,
                                                true,
                                                false,
                                                0
                                            );
                                            runPipeCalls.push(runPipePromise);
                                            runPipeCallsGeneratepayloadonly.push(runPipePromiseGeneratepayloadonly);
                                        }
                                        const goalWealthReports = {};
                                        const goalWealthReportsGeneratepayloadonly = {};

                                        const res = await Promise.all(runPipeCalls);
                                        const resGeneratepayloadonly = await Promise.all(
                                            runPipeCallsGeneratepayloadonly
                                        );
                                        await Promise.all(
                                            res.map((r, i) => {
                                                goalWealthReports[runPipeGoalsKeys[i]] = r.body;
                                                return r.body;
                                            })
                                        );

                                        await Promise.all(
                                            resGeneratepayloadonly.map((r, i) => {
                                                goalWealthReportsGeneratepayloadonly[runPipeGoalsKeys[i]] = r.body;
                                                return r.body;
                                            })
                                        );
                                        setGoalWealthReport(goalWealthReports);
                                        setGoalWealthReportGeneratepayloadonly(goalWealthReportsGeneratepayloadonly);
                                        setOverview("overview");
                                        setLoading(false);
                                    } else {
                                        Api.wealthSplitter(addedGoalList, basicInfo).then((response) => {
                                            console.log(response);
                                        });
                                    }
                                }}
                                showWealthSplitterFull={() => {
                                    setLoading(true);
                                    const basicInfo = {
                                        name: name,
                                        risk_profile_type: riskProfile,
                                    };
                                    Api.wealthSplitter(addedGoalList, basicInfo).then((response) => {
                                        const wealthSplitDonutResponse = response.body.goalResponseList.map(
                                            (gs, index) => {
                                                const goalData = addedGoalList.filter(
                                                    (g) => g["goal-key"] == gs.goalId
                                                )[0];
                                                return {
                                                    name: gs.goal,
                                                    initialInput: gs.origCurrWealth,
                                                    suggested: gs.wealthSplit,
                                                    recommendation: gs.wealthSplit - gs.origCurrWealth,
                                                    priority: goalData["goal_priority"],
                                                    tenure: goalData["tenure"],
                                                    fundStatus: gs.fundedStatus,
                                                    goalId: gs.goalId,
                                                    color: welathRecommendationColors[index % 5],
                                                };
                                            }
                                        );

                                        setLoading(false);
                                        setWealthRecommendations(wealthSplitDonutResponse);
                                        setWlthSplitter("wealth-splitter-full");
                                        setJourneyPath!("proposal");
                                    });
                                }}
                                setWlthSplitter={setWlthSplitter}
                            />
                        )}

                        <GoalList
                            addedGoalList={addedGoalList}
                            deleteGoal={deleteGoal}
                            editGoal={editGoal}
                            saveGoals={saveGoals}
                            wlthSplitter={wlthSplitter}
                            activeGoal={activeGoal}
                            loading={loading}
                            addMoreGoals={addMoreGoals}
                            getAllGoals={getAllGoals}
                        />
                    </div>
                </div>
            )}

            {journeyPath == "proposal" && overview != "overview" && (
                <>
                    <WealthSplitterFull
                        setWlthSplitter={setWlthSplitter}
                        setOverview={setOverview}
                        loading={loading}
                        generateOutPut={async (wealthRecommendation) => {
                            const basicInfo = { name: name, risk_profile_type: riskProfile };
                            if (goalSelection === "one-portfolio") {
                                const runPipeCalls: any = [];
                                const runPipeCallsGeneratepayloadonly: any = [];
                                const runPipeGoalsKeys: any = [];

                                const optGlList: any = [];

                                for (let i = 0; i < addedGoalList.length; i++) {
                                    const goalDetails = JSON.parse(JSON.stringify(addedGoalList[i]));
                                    const recommendation = wealthRecommendation.filter((rc) => {
                                        return rc.goalId == goalDetails["goal-key"];
                                    });
                                    if (recommendation && recommendation.length) {
                                        // goalDetails initialWealth= recommendation.suggested
                                        goalDetails["initial_investment"] = recommendation[0].suggested;
                                    }
                                    optGlList[i] = goalDetails;
                                }
                                setOptimizedGoalList(optGlList);
                                setLoading(true);
                                setGoalOptimized(true);

                                for (let i = 0; i < optGlList.length; i++) {
                                    runPipeGoalsKeys.push(optGlList[i]["goal-key"]);

                                    const runPipePromise = Api.runPipe(optGlList[i], basicInfo, false, false, 0);
                                    const runPipePromiseGeneratepayloadonly = Api.runPipe(
                                        optGlList[i],
                                        basicInfo,
                                        true,
                                        false,
                                        0
                                    );
                                    runPipeCalls.push(runPipePromise);
                                    runPipeCallsGeneratepayloadonly.push(runPipePromiseGeneratepayloadonly);
                                }
                                const goalWealthReports = {};
                                const goalWealthReportsGeneratepayloadonly = {};

                                const res = await Promise.all(runPipeCalls);
                                const resGeneratepayloadonly = await Promise.all(runPipeCallsGeneratepayloadonly);
                                await Promise.all(
                                    res.map((r, i) => {
                                        goalWealthReports[runPipeGoalsKeys[i]] = r.body;
                                        return r.body;
                                    })
                                );

                                await Promise.all(
                                    resGeneratepayloadonly.map((r, i) => {
                                        goalWealthReportsGeneratepayloadonly[runPipeGoalsKeys[i]] = r.body;
                                        return r.body;
                                    })
                                );

                                setLoading(false);
                                setGoalWealthReport(goalWealthReports);
                                setGoalWealthReportGeneratepayloadonly(goalWealthReportsGeneratepayloadonly);
                                setOverview("overview");
                            }
                        }}
                        wealthRecommendation={wealthRecommendation}
                    />
                </>
            )}

            {overview === "overview" && (
                <GoalOverView
                    setOverview={setOverview}
                    goalWealthReport={goalWealthReport}
                    goalWealthReportsGeneratepayloadonly={goalWealthReportsGeneratepayloadonly}
                    addedGoalList={
                        goalOptimized ? (optimizedGoalList.length ? optimizedGoalList : addedGoalList) : addedGoalList
                    }
                    setGoalWealthReport={setGoalWealthReport}
                    loading={loading}
                    setWlthSplitter={setWlthSplitter}
                    setActiveGoalOverView={(goalKey) => {
                        const actGoal = addedGoalList.filter((goal) => {
                            return goal["goal_key"] == goalKey;
                        });

                        setActiveGoal(actGoal[0] || {});
                    }}
                    setGoalQuestionnaire={setGoalQuestionnaire}
                    setGoalEditType={setGoalEditType}
                    goalUpaReport={goalUpaReport}
                    goalUpaReportConfig={goalUpaReportConfig}
                    goalWealthReportData={goalWealthReportData}
                    goalWealthReportDataConfig={goalWealthReportDataConfig}
                    setGoalWealthReportData={setGoalWealthReportData}
                    setGoalWealthReportDataConfig={setGoalWealthReportDataConfig}
                    isUpa={isUpa}
                    setLoading={setLoading}
                    setJourneyPath={setJourneyPath}
                    getAllGoals={getAllGoals}
                    onGoBackClick={(isUpa) => {
                        setActiveGoal({});

                        if (isUpa) {
                            setIsUpa(false);
                            setGoalSelection("all-portfolios");
                            setShowGoalUtilize(true);
                        } else {
                            setGoalSelection("one-portfolio");
                            setShowGoalUtilize(false);

                            setWlthSplitter("wealth-splitter");
                        }
                    }}
                />
            )}
            {!isUpa && (
                <GoalUtilizeModal
                    setOverview={setOverview}
                    goalSelection={goalSelection}
                    show={showGoalUtilize}
                    goalList={addedGoalList}
                    setGoalUpaReport={setGoalUpaReport}
                    goalUpaReportConfig={goalUpaReportConfig}
                    setGoalUpaReportConfig={setGoalUpaReportConfig}
                    setIsUpa={setIsUpa}
                    onHide={() => setShowGoalUtilize(false)}
                    setGoalWealthReportData={setGoalWealthReportData}
                    setGoalWealthReportDataConfig={setGoalWealthReportDataConfig}
                    setLoading={setLoading}
                    loading={loading}
                    showWealthSplitter={(goalSelection) => {
                        setGoalSelection(goalSelection);
                        setShowGoalUtilize(false);
                        setWlthSplitter("wealth-splitter");
                        setActiveGoal({});
                    }}
                />
            )}
        </div>
    );
};

const InvestLandingPage = (props: any) => {
    return (
        <div className="landing">
            <div className="top-half">
                <div>
                    <div className="begin-invest-journey">
                        <div>Begin your Investment Journey with Us</div>
                        <button onClick={() => props.startInvestJourney()} className="start-invest-btn">
                            Start Now
                        </button>
                    </div>
                    <div>
                        <div className="invest-journey-globe">
                            <img className="globe-image" src={GlobeIcon} alt="charts frames" />
                        </div>
                    </div>
                </div>
                <div className="ft-branding-info">
                    <div className="patented">
                        <div>Patented</div>
                        <div>
                            {" "}
                            <div className="patented-image" />
                        </div>
                    </div>
                    <div className="journals">
                        <div className="journals-left-blur" />
                        <div className="header">Published in Renowned Journals</div>
                        <div className="journals-scroll-animation">
                            <div className="journal-wealth-image" />
                            <div className="computational-science-image" />
                            <div className="join-image" />
                            <div className="journal-risk-image" />

                            <div className="journal-wealth-image" />
                            <div className="computational-science-image" />
                            <div className="join-image" />
                            <div className="journal-risk-image" />
                        </div>
                        <div className="journals-right-blur" />
                    </div>

                    <div className="awards">
                        <div>Recipient of Prestigious Awards</div>
                        <div>
                            <div className="harry-award-image" />
                            <div className="industry-award-image" />
                            <div className="best-award-image" />
                        </div>
                    </div>
                </div>
            </div>
            <div className="bottom-half">
                <div>
                    <p>
                        Traditional portfolio management sees risk as volatility within a portfolio. For investors, risk
                        is more about the outcome. The Goals Optimization Engine creates a portfolio for each goal an
                        investor has. GOE then actively adjusts the asset mix over time, seeking to maximize the
                        probability of successfully reaching each goal. Each portfolio is probability-driven,
                        personalized, and responsive to changes in the market or to any changes the investor might make
                        to the goal. GOE is available in select DC managed accounts, on our AdvisorEngine® platform for
                        RIAs, as well as in Thailand through our partnership with FINNOMENA. We can also deploy custom
                        implementations of GOE according to the specific needs of a firm.
                    </p>
                </div>
                <div>
                    <img className="building-investment" src={BuildingInvestment} alt="charts frames" />
                </div>
            </div>
        </div>
    );
};

export default InvestorJourney;
