import React from "react";
import Button from "react-bootstrap/Button";
import Loader from "./Loader";
const WealthSplitter = (props: any) => {
    let totalInitialAmount = 0;
    const goals = props.goalList ? props.goalList : [];
    const unFormaAmount = (formatterNUmber) => {
        if (formatterNUmber && typeof formatterNUmber !== "number") {
            return Number(formatterNUmber.replace(/[$,]/g, ""));
        }
        return formatterNUmber;
    };

    totalInitialAmount = goals.reduce((amount, goal) => {
        return amount + unFormaAmount(goal["initial_investment"]);
    }, 0);

    const formattedTotalInitialAmount = "$" + totalInitialAmount.toLocaleString();
    return (
        <div>
            <div
                className="back-button"
                onClick={() => {
                    props.backClick();
                }}
            >
                <span className="arrow"></span>
                <div>Back</div>
            </div>

            <div className="goal-selection wealth-splitter">
                {props.loading ? <Loader /> : <></>}

                <div className="header">
                    <span>Wealth Splitter</span>
                    <div className="border"></div>
                </div>
                <div className="wealth-splitter-info">
                    <div className="initial-investment">
                        <div className="ins-label">Total Initial Investment</div>
                        <div className="ins-value">{formattedTotalInitialAmount}</div>
                    </div>
                    <div className="ins-action">
                        <div>Do you want us to optimally distribute your initial investment across your goals?</div>
                        <div>
                            <Button variant="outline-primary" onClick={props.showGoalUtilization}>
                                No, Proceed to Output
                            </Button>
                            <Button onClick={props.showWealthSplitterFull} disabled={goals.length < 2}>
                                Yes, Optimize
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
export default WealthSplitter;
