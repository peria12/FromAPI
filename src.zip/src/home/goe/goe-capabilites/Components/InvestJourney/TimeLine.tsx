import React from "react";
import _ from "lodash";

const TimeLine = (props: any) => {
    const timelines = ["Basic Information", "Goal Type", "Proposal"];
    const journeyIndex = _.indexOf(timelines, _.startCase(props.investJourneyPath));
    return (
        <div className="goal-journey-path">
            <ul className="timeline">
                {timelines.map((timeline: string, index: any) => {
                    const isActive = journeyIndex >= index;
                    const isActivePath = journeyIndex - 1 >= index;
                    const checkboxClass = isActive ? "active" : "";
                    const checkboxPathClass = isActivePath ? "active" : "";
                    return (
                        <>
                            <li className="checkbox" key={timeline + index}>
                                <div className={"checkbox-label " + checkboxClass}>
                                    <span>{timeline}</span>
                                    <div className="checkbox-wrapper-18">
                                        <div className="round">
                                            <input type="checkbox" id="basic-info" checked={isActive} />
                                            <label htmlFor="basic-info"></label>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            {index < timelines.length - 1 && (
                                <li className={"line " + checkboxPathClass} key={timeline + index}>
                                    <div className="line-path"></div>
                                </li>
                            )}
                        </>
                    );
                })}
            </ul>
        </div>
    );
};

export default TimeLine;
