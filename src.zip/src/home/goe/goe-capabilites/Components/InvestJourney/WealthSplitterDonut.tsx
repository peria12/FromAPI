import React, { useEffect, useCallback, useState } from "react";
import * as d3 from "d3";
import "./ws-donut.scss";
import Highcharts from "highcharts";
import highchartsAccessibility from "highcharts/modules/accessibility";
import WSDonutSvg from "../../assets/images/svg/wealth_splitter.png";
import Chart from "./WealthHIghChart";

function drawCircle(svg, points, className) {
    svg.append("circle")
        .attr("cx", points["0"].x)
        .attr("cy", points["0"].y)
        .attr("r", "4")
        .attr("class", className)
        .attr("fill", "#BFBFBF");
}

function drawAnnotations(svg, cfg, className) {
    // Draw the rectangle
    svg.append("rect")
        .attr("x", cfg.x)
        .attr("y", cfg.y)
        .attr("width", cfg.width)
        .attr("height", cfg.height)
        .attr("class", className)
        .attr("fill", "white")
        .attr("stroke", "#E6E6E6");

    // add donut image
    svg.append("g")
        .attr("class", className)
        .append("svg:image")
        .attr("xlink:href", WSDonutSvg)
        .attr("x", cfg.x + 3.5)
        .attr("y", cfg.y + 2.5)
        .attr("width", "30")
        .attr("height", "30");

    // Add the label
    svg.append("text")
        .attr("x", cfg.textX)
        .attr("y", cfg.y + 4 + cfg.height / 2)
        .attr("text-anchor", "middle")
        .attr("class", "donut-label " + className)
        .text(cfg.label);
}

function loadChart(runAnimation, stopAnimation, wealthRecommendation, donutSize) {
    let width = 1250;
    let height = 500;
    if (donutSize === "small") {
        width = 550;
        height = 400;
    }
    const outerRadius = Math.min(width, height) / 2.9;
    const colors = wealthRecommendation.map((wrc) => {
        return wrc.color;
    });

    const pie = d3
        .pie()
        .value(function (d) {
            return d[1];
        })
        .sort(null);

    const optimizedInput = {};
    const userInput = {};
    wealthRecommendation.forEach((gr) => {
        optimizedInput[gr.name] = Math.abs(Math.round(gr.suggested));
    });

    wealthRecommendation.forEach((gr) => {
        userInput[gr.name] = Math.abs(Math.round(gr.initialInput));
    });

    const otrDonutData = pie(Object.entries(optimizedInput));
    const inrDonutData = pie(Object.entries(userInput));
    const outerDonut = {
        width: 28,
        data: otrDonutData,
        radius: outerRadius - 20,
        lineIndex: 0,
    };

    const innerDonut = {
        width: 14,
        data: inrDonutData,
        radius: outerRadius - outerDonut.width - 30,
        lineIndex: 1,
    };

    const labelDonut = {
        width: 42,
        data: otrDonutData,
        radius: Math.min(width - 30, height - 30) / 2,
        infoBox: {
            width: 180,
            height: 70,
            lineWidth: 220,
        },
    };

    const selector = d3.select("#chart");
    selector.html("");

    selector.append("div").attr("id", "backdrop").attr("class", "backdrop").style("display", "none");

    selector
        .append("button")
        .attr("id", "skipBtn")
        .attr("class", "skip-btn")
        .style("z-index", 11)
        .style("opacity", 0)
        .style("bottom", 40)
        .on("click", stopAnimation)
        .text("Skip");

    const svg = selector.append("svg").attr("width", width).attr("height", height).style("z-index", 10);

    const outerSvg = svg
        .append("g")
        .attr("id", "outerSvg")
        .style("opacity", 1)
        .attr("transform", `translate(${width / 2.5},${height / 2})`);
    const innerSvg = svg
        .append("g")
        .attr("id", "innerSvg")
        .style("opacity", 1)
        .attr("transform", `translate(${width / 2.5},${height / 2})`);

    const labelArc = d3
        .arc()
        .innerRadius(labelDonut.radius - labelDonut.width)
        .outerRadius(labelDonut.radius);

    const innerArc = d3
        .arc()
        .innerRadius(innerDonut.radius - innerDonut.width)
        .outerRadius(innerDonut.radius);

    const outerArc = d3
        .arc()
        .innerRadius(outerDonut.radius - outerDonut.width)
        .outerRadius(outerDonut.radius);

    outerSvg
        .selectAll("path")
        .data(outerDonut.data)
        .enter()
        .append("path")
        .attr("d", outerArc)
        .style("z-index", 1000)
        .attr("fill", (d, i) => colors[i])
        .append("text")
        .attr("transform", (d) => `translate(${outerArc.centroid(d)})`)
        .attr("dy", "0.35em")
        .text((d) => d.data[0]);

    innerSvg
        .selectAll("path")
        .data(innerDonut.data)
        .enter()
        .append("path")
        .attr("d", innerArc)
        .style("z-index", 1000)
        .attr("fill", (d, i) => colors[i]);

    innerSvg
        .append("circle")
        .attr("r", innerDonut.radius - innerDonut.width)
        .attr("fill", "white");

    // add total amount in the center

    const totalInitialAmount = wealthRecommendation.reduce((amount, goal) => {
        return amount + goal["initialInput"];
    }, 0);

    const formattedTotalInitialAmount = "$" + totalInitialAmount.toLocaleString();
    innerSvg
        .append("text")
        .attr("text-anchor", "middle")
        .attr("class", "center-text")
        .text(formattedTotalInitialAmount);

    const sliceTextPos = labelArc.centroid(labelDonut.data[0]);
    sliceTextPos[0] = sliceTextPos[0] * 0.47;
    sliceTextPos[1] = sliceTextPos[1] * 1.11;

    const otrClass = "outer-annotations-grp";
    const inrClass = "inner-annotations-grp";

    if (donutSize !== "small") {
        // Add the polylines between chart and labels:
        const outerPolyline = outerSvg
            .selectAll("allPolylines")
            .data(outerDonut.data)
            .join("polyline")
            .attr("class", "outer-annotations-grp")
            .attr("stroke", "#BFBFBF")
            .style("stroke-dasharray", "3,3.5")
            .style("z-index", 15)
            .style("fill", "none")
            .attr("stroke-width", 2)
            .attr("points", function (d) {
                if (d.index == outerDonut.lineIndex) {
                    return [
                        [137, -21.1],
                        [327.28, -98.2],
                        [540, -98.2],
                    ];
                }
                return;
            });

        const innerPolyline = innerSvg
            .selectAll("allPolylines")
            .data(innerDonut.data)
            .join("polyline")
            .attr("stroke", "#BFBFBF")
            .style("stroke-dasharray", "3,3.5")
            .style("fill", "none")
            .attr("stroke-width", 2)
            .style("z-index", 15)
            .attr("points", function (d) {
                if (d.index == innerDonut.lineIndex) {
                    return [
                        [101, 34],
                        [336.047, 92.56],
                        [540, 92.52],
                    ];
                }
                return null;
            });

        // draw starting point for line
        const otrPoints = outerPolyline?._groups?.[0]?.[outerDonut.lineIndex]?.points || {};
        const inrPoints = innerPolyline?._groups?.[0]?.[innerDonut.lineIndex]?.points || {};

        drawCircle(outerSvg, otrPoints, otrClass);
        drawCircle(innerSvg, inrPoints, inrClass);

        // Drawing annotation
        const labelBoxHeight = 40;
        const otrAnnotation = {
            label: "Optimized Investment",
            x: otrPoints["2"].x,
            y: otrPoints["2"].y - labelBoxHeight / 2,
            width: 180,
            height: labelBoxHeight,
        };
        otrAnnotation["textX"] = otrAnnotation.x + otrAnnotation.width / 1.7;
        const inrAnnotation = {
            label: "User Input",
            x: inrPoints["2"].x,
            y: inrPoints["2"].y - labelBoxHeight / 2,
            width: 180,
            height: labelBoxHeight,
        };
        inrAnnotation["textX"] = inrAnnotation.x + inrAnnotation.width / 2.4;

        drawAnnotations(outerSvg, otrAnnotation, otrClass);
        drawAnnotations(innerSvg, inrAnnotation, inrClass);
    }
    // animation
    const duration = 1000;
    const delay = 200;
    let transitions: any = [];
    const mutex = true;

    function addTransition(transition) {
        if (mutex) {
            transitions.push(transition);
        }
    }

    const startAnimation = () => {
        //  overlay and highlight labels
        addTransition(d3.select("#backdrop").transition().style("display", "block"));
        addTransition(d3.select("#backdrop").transition().style("opacity", 0.8));
        addTransition(d3.select("#skipBtn").transition().style("opacity", 1));
        addTransition(d3.selectAll(".slice-label").transition().style("fill", "#cdc7c7"));
        //  highlight inner ring and fade outer ring
        addTransition(d3.select("#outerSvg").transition().delay(delay).style("opacity", 0.2));
        addTransition(
            d3
                .select("#innerSvg")
                .transition()
                .delay(delay)
                .duration(duration)
                .style("background-color", "rgba(0, 0, 0, 0.5)")
                .style("opacity", 1)
                .on("end", () => step2())
        );
    };

    function step2() {
        // fade inner and highligh outer ring
        addTransition(
            d3
                .select("#innerSvg")
                .transition()
                .duration(duration)
                .style("background-color", "rgba(0, 0, 0, 0.5)")
                .style("opacity", 0.2)
        );
        addTransition(
            d3
                .select("#outerSvg")
                .transition()
                .duration(duration)
                .style("opacity", 1)
                .on("end", () => step3())
        );
    }

    const infoBox = d3.select(d3.selectAll(".slice-label")._groups[0][0]);

    function step3() {
        addTransition(
            d3
                .select("#infoBox")
                .transition()
                .style("opacity", 1)
                .delay(duration)
                .on("end", () => {
                    d3.selectAll(`.${otrClass}`)._groups[0].forEach((ele) => {
                        const otrAnnotationGrp = d3.select(ele);
                        otrAnnotationGrp.transition().style("opacity", 0.2);
                    });
                    infoBox.transition().style("fill", "#595959");
                    infoBox.select("#optWealth").transition().style("fill", "#cdc7c7");
                    infoBox.select("#reco").transition().style("fill", "#cdc7c7");
                    d3.select("#infoBoxLine").transition().style("opacity", 1);
                    d3.select("#infoBoxText")
                        .transition()
                        .style("opacity", 1)
                        .on("end", () => {
                            //step4();
                        });
                })
        );
    }

    if (runAnimation) {
        startAnimation();

        setTimeout(() => {
            stopAnimation();
        }, 3000);
    } else {
        transitions = [];
    }
}

export default function WealthSplitterDonut(props: any) {
    const stopAnimation = useCallback(() => {
        const selector = d3.select("#chart");
        selector.html("");
        loadChart(false, stopAnimation, props.wealthRecommendation, props.donutSize);
        props.setDonutSize("small");
    }, [props]);

    useEffect(() => {
        highchartsAccessibility(Highcharts);
    }, []);

    useEffect(() => {
        if (props.donutSize === "small") {
            const wealthSplitterHighChart = getHighChartOptions(props.wealthRecommendation);
            setHighchartsOptions(wealthSplitterHighChart);
        }
    }, [props.donutSize, props.wealthRecommendation]);

    const getHighChartOptions = (wealthRecommendation: any) => {
        const optimizedInput: any = [];
        const userInput: any = [];
        wealthRecommendation.forEach((gr) => {
            const opi = Object.assign({}, gr);
            opi.y = Math.abs(Math.round(gr.suggested));
            optimizedInput.push(opi);
        });

        wealthRecommendation.forEach((gr) => {
            const initialI = Object.assign({}, gr);
            initialI.y = Math.abs(Math.round(gr.initialInput));
            userInput.push(initialI);
        });
        const unFormaAmount = (formatterNUmber) => {
            if (formatterNUmber && typeof formatterNUmber !== "number") {
                return Number(formatterNUmber.replace(/[$,]/g, ""));
            }
            return formatterNUmber;
        };

        const totalInitialAmount = wealthRecommendation.reduce((amount, gr) => {
            return amount + unFormaAmount(gr.initialInput);
        }, 0);

        const formattedTotalInitialAmount = "$" + totalInitialAmount.toLocaleString();

        const options = {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: 0,
                plotShadow: false,
            },
            credits: {
                enabled: false,
            },
            title: {
                text: formattedTotalInitialAmount,
                align: "center",
                verticalAlign: "middle",
                y: 70,
            },
            tooltip: {
                pointFormat: "{series.name}: <b>{point.percentage:.1f}%</b>",
                borderColor: "transparent",
                borderRadius: 0,
                backgroundColor: "white",
                className: "wealth-tooltip",
                shadow: false,
                useHTML: true,
            },
            plotOptions: {
                pie: {
                    dataLabels: {
                        enabled: true,
                        distance: -50,
                        style: {
                            fontWeight: "bold",
                            color: "white",
                        },
                    },
                    startAngle: 0,
                    endAngle: 360,
                    center: ["50%", "65%"],
                },
                borderWidth: 0,
            },
            series: [
                {
                    type: "pie",
                    name: "Election",
                    size: 250,
                    innerSize: 200,
                    dataLabels: {
                        enabled: false,
                    },
                    data: optimizedInput,
                },
                {
                    type: "pie",
                    dataLabels: {
                        enabled: false,
                    },
                    name: "Proprietary or Undetectable",
                    size: 170,
                    innerSize: 130,
                    data: userInput,
                },
            ],
        };

        return options;
    };

    const [highchartsOptions, setHighchartsOptions] = useState({});
    useEffect(() => {
        if (props.donutSize === "small") {
            // loadChart(false, stopAnimation, props.wealthRecommendation, props.donutSize);
        } else if (props.donutSize === "large") {
            loadChart(false, stopAnimation, props.wealthRecommendation, props.donutSize);
        } else {
            loadChart(true, stopAnimation, props.wealthRecommendation, props.donutSize);
        }
    }, [props.donutSize, props.wealthRecommendation, stopAnimation]);

    return (
        <div className="wealth-splitter-donut-container">
            {props.donutSize !== "small" && (
                <div id="chart" className="d-flex w-100 justify-content-center">
                    <div id="backdrop" className="backdrop" />
                </div>
            )}
            {props.donutSize == "small" && <Chart data={highchartsOptions} />}

            {props.donutSize === "small" && (
                <div className="donut-annotations">
                    <div>
                        <span></span>
                        <span>Optimized Investment</span>
                    </div>
                    <div>
                        <span></span>
                        <span>Initial Investment</span>
                    </div>
                </div>
            )}
        </div>
    );
}
