import React, { useState } from "react";
const GoeToggleButton = ({ onChange, variantTrue, variantFalse }) => {
    const [isToggleFlag, setIsToggle] = useState<boolean>(false);

    function handleOnChange() {
        setIsToggle((stateVal) => {
            if (onChange) {
                onChange(!stateVal);
            }
            return !stateVal;
        });
    }

    return (
        <div className="ft-goe-cap-config-section-options-toggle-child-div">
            <span
                className={`slider-label-left ${
                    !isToggleFlag ? "ft-goe-cap-config-section-options-toggle-false-span" : ""
                }`}
            >
                {variantTrue}
            </span>
            <label className="switch">
                <input type="checkbox" onChange={() => handleOnChange()} />
                <span className="slider round"></span>
            </label>
            <span
                className={`slider-label-right ${
                    isToggleFlag ? "" : "ft-goe-cap-config-section-options-toggle-false-span"
                }`}
            >
                {variantFalse}
            </span>
        </div>
    );
};

export default GoeToggleButton;
