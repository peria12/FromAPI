import React from "react";
import GoeToggleButton from "../Toggle/GoeToggleButton";

import { IConfigFormProp } from "home/goe/common/interfaces";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";

const FORM_NAME = "portfolio_configurations";
function PortfolioConfigurations(props: IConfigFormProp) {
    const [selectedRiskVal, setSelectedRiskVal] = React.useState<number | null>(1);
    const riskValues = Array.from({ length: 16 }, (_, i) => i + 1);
    const handleRiskValChange = (event: React.MouseEvent<HTMLElement>, val: number | null) => {
        setSelectedRiskVal(val);
    };

    const { onInputChange } = props;

    const handleToggle = (fieldName: string, value: string) => {
        onInputChange({
            formName: FORM_NAME,
            fieldName,
            value,
        });
    };

    function handleInputChange(evt, fieldName: string) {
        const value: string = evt.target?.value;

        console.log("Value", value);

        onInputChange({
            formName: FORM_NAME,
            fieldName,
            value,
        });
    }

    return (
        <div className="ft-goe-cap-goe-config-down-protection ft-goe-cap-goe-config-ret-config-data-main-div">
            <div className="form_subsection_main_container">
                <label className="form_label">Re-allocation Configuration</label>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">Portfolio Origin</span>
                    </div>
                    <GoeToggleButton
                        onChange={(val) => handleToggle("portfolio_origin", val)}
                        variantTrue="Non_FT"
                        variantFalse="FT"
                    />
                </div>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">Portfolio Name</span>
                    </div>
                    <div>
                        <input
                            className="input-goe-goal-amt"
                            type="text"
                            placeholder="Enter text"
                            onChange={(evt) => handleInputChange(evt, "portfolio_name")}
                        ></input>
                    </div>
                </div>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">Portfolio Description</span>
                    </div>
                    <div>
                        <input
                            className="input-goe-goal-amt"
                            type="text"
                            placeholder="Enter text"
                            onChange={(evt) => handleInputChange(evt, "portfolio_description")}
                        ></input>
                    </div>
                </div>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">Distribution Channel</span>
                    </div>
                    <div>
                        <select
                            name="swingcontraintstatus"
                            className="input-goe-goal-amt"
                            onChange={(evt) => handleInputChange(evt, "distribution_channel")}
                        >
                            <option value="">Select</option>
                            <option value="1">Option 1</option>
                            <option value="2">Option 2</option>
                        </select>
                    </div>
                </div>
            </div>
            <div className="form_subsection_container">
                <label className="form_label">What Portfolios do different client risk profiles have access to</label>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">Conservative Risk Profile</span>
                    </div>
                    <div className="form_dropdown">
                        <div>
                            <select
                                name="swingcontraintstatus"
                                className="input-goe-goal-amt dropdown_field_width"
                                onChange={(evt) => handleInputChange(evt, "conservative_risk_profile_1")}
                            >
                                <option value="">Select</option>
                                <option value="1">Option 1</option>
                                <option value="2">Option 2</option>
                            </select>
                        </div>
                        <div>
                            <select
                                name="swingcontraintstatus"
                                className="input-goe-goal-amt dropdown_field_width"
                                onChange={(evt) => handleInputChange(evt, "conservative_risk_profile_2")}
                            >
                                <option value="">Select</option>
                                <option value="1">Option 1</option>
                                <option value="2">Option 2</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">Moderate Risk Profile</span>
                    </div>
                    <div className="form_dropdown">
                        <div>
                            <select
                                name="swingcontraintstatus"
                                className="input-goe-goal-amt dropdown_field_width"
                                onChange={(evt) => handleInputChange(evt, "moderate_risk_profile_1")}
                            >
                                <option value="">Select</option>
                                <option value="1">Option 1</option>
                                <option value="2">Option 2</option>
                            </select>
                        </div>
                        <div>
                            <select
                                name="swingcontraintstatus"
                                className="input-goe-goal-amt dropdown_field_width"
                                onChange={(evt) => handleInputChange(evt, "moderate_risk_profile_2")}
                            >
                                <option value="">Select</option>
                                <option value="1">Option 1</option>
                                <option value="2">Option 2</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">Aggressive Risk Profile</span>
                    </div>
                    <div className="form_dropdown">
                        <div>
                            <select
                                name="swingcontraintstatus"
                                className="input-goe-goal-amt dropdown_field_width"
                                onChange={(evt) => handleInputChange(evt, "aggressive_risk_profile_1")}
                            >
                                <option value="">Select</option>
                                <option value="1">Option 1</option>
                                <option value="2">Option 2</option>
                            </select>
                        </div>
                        <div>
                            <select
                                name="swingcontraintstatus"
                                className="input-goe-goal-amt dropdown_field_width"
                                onChange={(evt) => handleInputChange(evt, "aggressive_risk_profile_2")}
                            >
                                <option value="">Select</option>
                                <option value="1">Option 1</option>
                                <option value="2">Option 2</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">
                            Portfolio for Short Term Retail Goals
                        </span>
                    </div>
                    <div className="form_dropdown">
                        <div>
                            <select
                                name="swingcontraintstatus"
                                className="input-goe-goal-amt dropdown_field_width"
                                onChange={(evt) => handleInputChange(evt, "portfolio_goals_1")}
                            >
                                <option value="">Select</option>
                                <option value="1">Option 1</option>
                                <option value="2">Option 2</option>
                            </select>
                        </div>
                        <div>
                            <select
                                name="swingcontraintstatus"
                                className="input-goe-goal-amt dropdown_field_width"
                                onChange={(evt) => handleInputChange(evt, "portfolio_goals_2")}
                            >
                                <option value="">Select</option>
                                <option value="1">Option 1</option>
                                <option value="2">Option 2</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">
                            Goal Tenure for Short Term Retail Goals(Years)
                        </span>
                    </div>
                    <div>
                        <input
                            className="input-goe-goal-amt"
                            type="text"
                            placeholder="0"
                            onChange={(evt) => handleInputChange(evt, "goal_tenure")}
                            // onChange={handleChangeSlider}
                            // value={inputData["dateOfBirth"]}
                        ></input>
                    </div>
                </div>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">Segment</span>
                    </div>
                    <div>
                        <select
                            name="swingcontraintstatus"
                            className="input-goe-goal-amt"
                            onChange={(evt) => handleInputChange(evt, "segment")}
                        >
                            <option value="">Select</option>
                            <option value="1">Option 1</option>
                            <option value="2">Option 2</option>
                        </select>
                    </div>
                </div>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">Country</span>
                    </div>
                    <div>
                        <select
                            name="swingcontraintstatus"
                            className="input-goe-goal-amt"
                            onChange={(evt) => handleInputChange(evt, "country")}
                        >
                            <option value="">Select</option>
                            <option value="1">Option 1</option>
                            <option value="2">Option 2</option>
                        </select>
                    </div>
                </div>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">Channel</span>
                    </div>
                    <div>
                        <select
                            name="swingcontraintstatus"
                            className="input-goe-goal-amt"
                            onChange={(evt) => handleInputChange(evt, "channel")}
                        >
                            <option value="">Select</option>
                            <option value="1">Option 1</option>
                            <option value="2">Option 2</option>
                        </select>
                    </div>
                </div>
            </div>
            <div className="form_subsection_container">
                <label className="form_label">Risk Overlay</label>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">Risk Overlay</span>
                    </div>
                    <GoeToggleButton
                        onChange={(val) => handleToggle("risk_overlay", val)}
                        variantTrue="No"
                        variantFalse="Yes"
                    />
                </div>
                <div className="ft-goe-cap-goe-config-down-protection-toggle">
                    <div className="ft-goe-cap-config-section-options-toggle-div">
                        <span className="ft-goe-cap-config-section-options-span-black">Risk Indicator Thresholds</span>
                    </div>
                    <div className="form_dropdown">
                        <div>
                            <select
                                name="swingcontraintstatus"
                                className="input-goe-goal-amt dropdown_field_width"
                                onChange={(evt) => handleInputChange(evt, "risk_indicator_1")}
                            >
                                <option value="">Select</option>
                                <option value="1">Option 1</option>
                                <option value="2">Option 2</option>
                            </select>
                        </div>
                        <label>to</label>
                        <div>
                            <select
                                name="swingcontraintstatus"
                                className="input-goe-goal-amt dropdown_field_width"
                                onChange={(evt) => handleInputChange(evt, "risk_indicator_2")}
                            >
                                <option value="">Select</option>
                                <option value="1">Option 1</option>
                                <option value="2">Option 2</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div className="risk_value">
                    <ToggleButtonGroup
                        value={selectedRiskVal}
                        exclusive
                        onChange={handleRiskValChange}
                        aria-label="text alignment"
                        sx={{
                            "& .MuiToggleButton-root.Mui-selected": {
                                background: "var(--bs-primary)",
                                color: "white",
                            },
                            "& .MuiToggleButton-root.Mui-selected:hover": {
                                background: "var(--bs-primary)",
                                color: "white",
                            },
                        }}
                    >
                        {riskValues.map((number) => (
                            <ToggleButton key={number} value={number} aria-label={String(number)}>
                                {number}
                            </ToggleButton>
                        ))}
                    </ToggleButtonGroup>
                    <div className="risk_container">
                        <div className="ft-goe-cap-goe-config-down-protection-toggle">
                            <div className="ft-goe-cap-config-section-options-toggle-div">
                                <span className="ft-goe-cap-config-section-options-span-black">Risk On</span>
                            </div>
                            <div>
                                <GoeToggleButton
                                    onChange={(val) => handleToggle("risk_on", val)}
                                    variantTrue="Yes"
                                    variantFalse="No"
                                />
                            </div>
                        </div>
                        <div className="ft-goe-cap-goe-config-down-protection-toggle">
                            <div className="ft-goe-cap-config-section-options-toggle-div">
                                <span className="ft-goe-cap-config-section-options-span-black">Mean Returns</span>
                            </div>
                            <div>
                                <input
                                    className="input-goe-goal-amt"
                                    type="text"
                                    placeholder="0"
                                    onChange={(evt) => handleInputChange(evt, "mean_returns")}
                                ></input>
                            </div>
                        </div>
                        <div className="ft-goe-cap-goe-config-down-protection-toggle">
                            <div className="ft-goe-cap-config-section-options-toggle-div">
                                <span className="ft-goe-cap-config-section-options-span-black">Standard Deviation</span>
                            </div>
                            <div>
                                <input
                                    className="input-goe-goal-amt"
                                    type="text"
                                    placeholder="0"
                                    onChange={(evt) => handleInputChange(evt, "standard_deviation")}
                                ></input>
                            </div>
                        </div>
                        <div className="ft-goe-cap-goe-config-down-protection-toggle">
                            <div className="ft-goe-cap-config-section-options-toggle-div">
                                <span className="ft-goe-cap-config-section-options-span-black">Assets Allocation</span>
                            </div>
                            <div className="form_dropdown">
                                <div>
                                    <select
                                        name="swingcontraintstatus"
                                        className="input-goe-goal-amt dropdown_field_width"
                                        onChange={(evt) => handleInputChange(evt, "assets_allocation_1")}
                                    >
                                        <option value="">Select</option>
                                        <option value="1">Option 1</option>
                                        <option value="2">Option 2</option>
                                    </select>
                                </div>
                                <div>
                                    <input
                                        className={`ft-goe-cap-goe-config-down-protection-row-input input-goe-invest-questiontemp`}
                                        type="text"
                                        placeholder="0%"
                                        onChange={(evt) => handleInputChange(evt, "assets_allocation_input_1")}
                                    ></input>
                                </div>
                            </div>
                        </div>
                        <div className="ft-goe-cap-goe-config-down-protection-toggle">
                            <div className="ft-goe-cap-config-section-options-toggle-div">
                                <span className="ft-goe-cap-config-section-options-span-black"></span>
                            </div>
                            <div className="form_dropdown">
                                <div>
                                    <select
                                        name="swingcontraintstatus"
                                        className="input-goe-goal-amt dropdown_field_width"
                                        onChange={(evt) => handleInputChange(evt, "assets_allocation_2")}
                                    >
                                        <option value="">Select</option>
                                        <option value="1">Option 1</option>
                                        <option value="2">Option 2</option>
                                    </select>
                                </div>
                                <div>
                                    <input
                                        className={`ft-goe-cap-goe-config-down-protection-row-input input-goe-invest-questiontemp`}
                                        type="text"
                                        placeholder="0%"
                                        onChange={(evt) => handleInputChange(evt, "assets_allocation_input_2")}
                                    ></input>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default PortfolioConfigurations;
