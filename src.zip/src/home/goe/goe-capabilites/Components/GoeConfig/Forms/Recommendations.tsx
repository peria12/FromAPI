import React from "react";

import GoeToggleButton from "../Toggle/GoeToggleButton";
import { IConfigFormProp } from "home/goe/common/interfaces";

const FORM_NAME = "recommendations";

function Recommendations(props: IConfigFormProp) {
    const { onInputChange } = props;

    const handleToggle = (fieldName: string, value: string) => {
        onInputChange({
            formName: FORM_NAME,
            fieldName,
            value,
        });
    };

    return (
        <div className="ft-goe-cap-goe-config-down-protection ft-goe-cap-goe-config-ret-config-data-main-div">
            <div className="ft-goe-cap-goe-config-down-protection-toggle">
                <div className="ft-goe-cap-config-section-options-toggle-div">
                    <span className="ft-goe-cap-config-section-options-span-black">Recommend Tenure</span>
                </div>
                <GoeToggleButton
                    onChange={(val) => handleToggle("recommend_tenure", val)}
                    variantTrue="yes"
                    variantFalse="No"
                />
            </div>
            <div className="ft-goe-cap-goe-config-down-protection-toggle">
                <div className="ft-goe-cap-config-section-options-toggle-div">
                    <span className="ft-goe-cap-config-section-options-span-black">Recommend Top-up Infusion</span>
                </div>
                <div>
                    <GoeToggleButton
                        onChange={(val) => handleToggle("recommend_topup_infusion", val)}
                        variantTrue="yes"
                        variantFalse="No"
                    />
                </div>
            </div>
        </div>
    );
}

export default Recommendations;
