import React from "react";
import GoeToggleButton from "../Toggle/GoeToggleButton";
import Slider from "@mui/material/Slider";
import { IConfigFormProp } from "home/goe/common/interfaces";

const FORM_NAME = "general_settings";

function GeneralSettings(props: IConfigFormProp) {
    const { onInputChange } = props;

    const handleToggle = (fieldName: string, value: string) => {
        onInputChange({
            formName: FORM_NAME,
            fieldName,
            value,
        });
    };

    function handleInputChange(evt, fieldName: string) {
        const value: string = evt.target?.value;

        console.log("Value", value);

        onInputChange({
            formName: FORM_NAME,
            fieldName,
            value,
        });
    }

    return (
        <div className="ft-goe-cap-goe-config-down-protection ft-goe-cap-goe-config-ret-config-data-main-div">
            <div className="ft-goe-cap-goe-config-down-protection-toggle">
                <div className="ft-goe-cap-config-section-options-toggle-div">
                    <span className="ft-goe-cap-config-section-options-span-black">
                        What probability would you consider as unrealistic
                    </span>
                </div>
                <div className="d-flex">
                    <div className="range-slider ft-goe-cap-retcalc-slider">
                        <div className="range-group">
                            <Slider
                                size="small"
                                defaultValue={0}
                                aria-label="Small"
                                valueLabelDisplay="auto"
                                onChangeCommitted={(evt) => handleInputChange(evt, "unrealistic_probability")}
                            />
                        </div>
                    </div>
                    <input
                        className={`input-range-goe-invest-questiontemp input-goe-invest-questiontemp`}
                        type="text"
                        placeholder="0%"
                        disabled={true}
                    ></input>
                </div>
            </div>
            <div className="ft-goe-cap-goe-config-down-protection-toggle">
                <div className="ft-goe-cap-config-section-options-toggle-div">
                    <span className="ft-goe-cap-config-section-options-span-black">Swing Constraint</span>
                </div>
                <div>
                    <div className="general_padding">
                        <GoeToggleButton
                            onChange={(val) => handleToggle("swing_constraint", val)}
                            variantTrue="Normal"
                            variantFalse="Real"
                        />
                    </div>
                    <div>
                        <select
                            name="swingcontraintstatus"
                            className="input-goe-goal-amt"
                            onChange={(evt) => handleInputChange(evt, "swing_contraint_status")}
                        >
                            <option value="">Select</option>
                            <option value="1">Option 1</option>
                            <option value="2">Option 2</option>
                        </select>
                    </div>
                </div>
            </div>
            <div className="ft-goe-cap-goe-config-down-protection-toggle">
                <div className="ft-goe-cap-config-section-options-toggle-div">
                    <span className="ft-goe-cap-config-section-options-span-black">
                        Inflation Measure for Infusions
                    </span>
                </div>
                <div>
                    <div className="general_padding">
                        <GoeToggleButton
                            onChange={(val) => handleToggle("inflation_measure_for_infusions", val)}
                            variantTrue="yes"
                            variantFalse="No"
                        />
                    </div>
                    <input
                        className="input-goe-goal-amt"
                        type="text"
                        placeholder="0%"
                        onChange={(evt) => handleInputChange(evt, "inflation_input")}
                    ></input>
                </div>
            </div>
        </div>
    );
}

export default GeneralSettings;
