import React, { useState } from "react";
import Slider from "@mui/material/Slider";
const ReAllocation = () => {
    const [sliderData, setSliderData] = useState({"Need":0,
    "Want":0,
    "Wish":0,
    "Dream":0
});
    const priorityArray = [
        "Need",
        "Want",
        "Wish",
        "Dream"
    ];
    
    const handleSlider = (event) => {
        setSliderData({...sliderData,[event.target.name]:event.target.value})
    };
    return (
                <div>
                                    <div className="ft-goe-cap-config-section-options-div">
                                        <span className="ft-goe-cap-config-section-span ft-goe-cap-config-inner-div-span">
                                            Level of Goal Priority Settings
                                        </span>
                                        <div className="ft-goe-cap-config-section-options-div1">
                                            <div className="ft-goe-cap-config-section-options-toggle-div">
                                                <span className="ft-goe-cap-config-section-options-span-black">
                                                    When the user re-takes the RTQ
                                                </span>
                                            </div>
                                            <div className="ft-goe-cap-config-section-options-radio-group-div">
                                                <div className="ft-goe-cap-config-section-options-radio-div">
                                                    <input type="radio"></input>
                                                    <span className="ft-goe-cap-config-section-options-span-black">
                                                        1
                                                    </span>
                                                </div>
                                                <div className="ft-goe-cap-config-section-options-radio-div">
                                                    <input type="radio"></input>
                                                    <span className="ft-goe-cap-config-section-options-span-black">
                                                        2
                                                    </span>
                                                </div>
                                                <div className="ft-goe-cap-config-section-options-radio-div">
                                                    <input type="radio"></input>
                                                    <span className="ft-goe-cap-config-section-options-span-black">
                                                        3
                                                    </span>
                                                </div>
                                                <div className="ft-goe-cap-config-section-options-radio-div">
                                                    <input type="radio"></input>
                                                    <span className="ft-goe-cap-config-section-options-span-black">
                                                        4
                                                    </span>
                                                </div>
                                                <div className="ft-goe-cap-config-section-options-radio-div">
                                                    <input type="radio"></input>
                                                    <span className="ft-goe-cap-config-section-options-span-black">
                                                        5
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        {priorityArray.map((item, index) => {
                                            return (
                                                <div className="d-flex" key={index}>
                                                    <div className="ft-goe-cap-config-section-options-toggle-div">
                                                        <span className="ft-goe-cap-config-section-options-span-black">
                                                            {item}
                                                        </span>
                                                    </div>
                                                    <div className="d-flex">
                                    <div className="range-slider ft-goe-cap-retcalc-slider">
                                        <div className="range-group">
                                            <Slider
                                                size="small"
                                                defaultValue={0}
                                                aria-label="Small"
                                                valueLabelDisplay="auto"
                                                name={item}
                                                value={sliderData[item]}
                                                onChange={handleSlider}
                                            />
                                        </div>
                                    </div>
                                    <input
                                        className={`input-range-goe-invest-questiontemp input-goe-invest-questiontemp`}
                                        type="text"
                                        name={item}
                                        value={sliderData[item]}
                                        placeholder="0%"
                                        disabled={true}
                                    ></input>
                                </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                              
                </div>
    );
};

export default ReAllocation;
