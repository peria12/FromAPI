import React from "react";
import EditImage from "../../../assets/images/svg/pen.svg";

function PortfolioFormSectionHeader({ data, handleChange, duplicateName, subtitle, isEdit, handleDuplicate }) {
    const { name, goal_amount, icon, targeted_retirement_income, draw_income, goal_key } = data;
    return (
        <div>
            <div>
                <div className="pfs__header d-flex justify-content-between">
                    <div className="pfs__goal-name">
                        <span className="pfs__goal-icon">
                            <svg width="28" height="28">
                                <image xlinkHref={icon} width="28" height="28" />
                            </svg>
                        </span>
                        <div>
                            <div>
                                {isEdit ? (
                                    <input
                                        value={name}
                                        onChange={handleChange}
                                        className="input-goe-invest-questiontemp label-cursor input-title-bar"
                                        name="name"
                                        type="text"
                                    />
                                ) : (
                                    <span className="pfs__goal-name-text">{name}</span>
                                )}
                            </div>
                            <div className="d-flex">
                                <span className="ft-goe-cap-redesigned-forms-subtitile">{subtitle}</span>
                            </div>
                        </div>
                        <img onClick={() => handleDuplicate()} src={EditImage} />
                    </div>
                    <div className="pfs__goal-amount">
                        <span className="pfs__goal-amount-label">Goal Amount </span>
                        <span className="pfs__goal-amount-value">
                            {goal_key === "draw_income"
                                ? draw_income
                                : goal_key === "plan_retirement"
                                ? targeted_retirement_income
                                : goal_amount}
                        </span>
                    </div>
                </div>
            </div>
            <div className="d-flex">
                {duplicateName && (
                    <div className="ft-goe-cap-redesigned-forms-duplicate-goal">
                        Duplicate goal name on record. Please rename the goal.
                    </div>
                )}
            </div>
        </div>
    );
}

export default PortfolioFormSectionHeader;
