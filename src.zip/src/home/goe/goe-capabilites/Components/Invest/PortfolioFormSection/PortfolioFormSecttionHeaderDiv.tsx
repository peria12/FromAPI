import React from "react";
function PortfolioFormSectionHeaderDiv(props) {
    return (
        <div className={`ft-goe-cap-redesigned-forms-sec ${props.classnameouter}`}>
            <div className={`pfs__form-icon ${props.classname}`}>
                <svg width="50" height="50">
                    <image xlinkHref={props.icon} width="50" height="50" />
                </svg>
            </div>
        </div>
    );
}

export default PortfolioFormSectionHeaderDiv;
