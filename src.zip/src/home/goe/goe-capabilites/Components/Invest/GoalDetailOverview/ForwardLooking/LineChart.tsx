import React, { useEffect, useRef } from "react";
import * as d3 from "d3";
import { DataPoint, chartMargin } from "./ForwardLooking"; 

interface LineChartProps {
    data: DataPoint[];
    chartWidth: number;
    chartHeight: number;
    startDate: Date;
    donutChartData: { equity: number; fixed_income: number }[];
    endDate: Date;
    isZoomedOut
}

const LineChart = ({
    data,
    donutChartData,
    chartWidth,
    chartHeight,
    startDate,
    endDate,
    isZoomedOut
}: LineChartProps) => {
    const chartRef = useRef<SVGSVGElement>(null);

    useEffect(() => {
        if (chartRef.current && data.length > 0) {
            const xScale = d3.scaleTime().domain([startDate, endDate]).range([0, chartWidth]);
            const yScale = d3.scaleLinear().domain([0, 100]).range([chartHeight, 0]);

            const svg = d3.select(chartRef.current);

            // Remove existing donut charts and lines before rendering new ones
            svg.selectAll(".data-group").remove();
            svg.selectAll(".vertical-line").remove();

            // Create a group for each data point
            const dataGroups = svg
                .selectAll<SVGGElement, DataPoint>(".data-group")
                .data(data)
                .enter()
                .append("g")
                .attr("class", "data-group")
                .attr("transform", (d: DataPoint) => `translate(${xScale(d.date) + (isZoomedOut ? 8 : 0)}, ${yScale(d.value) - chartMargin.top})`);


            // Create vertical lines from each data point to x-axis
            dataGroups.each((d: DataPoint) => {
                svg.append("line")
                    .attr("class", "vertical-line")
                    .attr("x1", xScale(d.date) +  (isZoomedOut ? 20 : 25))
                    .attr("y1", yScale(d.value - chartMargin.top + (isZoomedOut ? 7 : 2.5)))
                    .attr("x2", xScale(d.date) + (isZoomedOut ? 20 : 25))
                    .attr("y2", chartHeight + chartMargin.top)
                    .attr("stroke", "#BFBFBF")
                    .attr("stroke-dasharray", "3,3");
            });
        }
    }, [data, chartWidth, chartHeight, endDate, startDate, donutChartData]);

    return <svg ref={chartRef}></svg>;
};

export default LineChart;
