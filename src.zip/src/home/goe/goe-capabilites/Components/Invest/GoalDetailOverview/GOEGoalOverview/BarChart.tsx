import React from "react";
import * as d3 from "d3";
import { useEffect, useRef } from "react";
import { IChartData } from "../../../../../common/interfaces";
import {
    getChartHeight,
    getChartTranslateValues,
    getChartWidth,
    getScalesNDomainsForChartByData,
} from "../../../../../common/utils";
import { CHART_MARGIN, CHART_X_AXIS_VALUE_GAP } from "home/goe/common/constants";

interface BarChartProps {
    data: Array<Array<number>>;
    wealthPerYearData: Array<IChartData>;
}

const BarChart = ({ data, wealthPerYearData }: BarChartProps) => {
    const barRef = useRef<SVGGElement>(null);
    const BAR_CHART_FILL_COLOR = "#fbe5dc";
    const chartHeight = getChartHeight();
    const chartWidth = getChartWidth(wealthPerYearData.length);
    const yDomains = getScalesNDomainsForChartByData(wealthPerYearData, undefined, chartWidth)[3];
    const yScale = getScalesNDomainsForChartByData(wealthPerYearData, undefined, chartWidth)[1];

    useEffect(() => {
        renderGraph();
        //eslint-disable-next-line
    }, [wealthPerYearData]);

    function renderGraph() {
        if (barRef.current && data.length > 0 && chartWidth > 0 && chartHeight > 0) {
            const svg = d3.select(barRef.current);
            const [xScale] = getScalesNDomainsForChartByData(wealthPerYearData);
            const { xTranslate } = getChartTranslateValues();

            svg.selectAll("rect").remove();

            const barGroup = svg.append("g").attr("transform", `translate(${0}, ${CHART_MARGIN.top})`);

            //To show startyear and end year bar
            barGroup
                .selectAll("rect")
                .data(data)
                .enter()
                .append("rect")
                .attr("x", (d: Array<number>) => xScale(d[0]))
                // .attr("y", 0)
                .attr("y", yScale(yDomains[1]) - 5)
                .attr("width", (item) => (item.length - 1) * (CHART_X_AXIS_VALUE_GAP - 2.25))
                // .attr("height", chartHeight - 5)
                .attr("height", chartHeight - 15)
                // .attr("height",yScale(yDomains[1]))
                .attr("fill", BAR_CHART_FILL_COLOR)
                .attr("transform", `translate(${xTranslate}, 0)`);
        }
    }

    return <g ref={barRef} />;
};

export default BarChart;
