import React, { useEffect, useRef } from "react";
import * as d3 from "d3";
import { DataPoint } from "../ForwardLooking/ForwardLooking";
import createDonutChartSvg from "./DonutChart";
import { getChartTranslateValues } from "home/goe/common/utils";
import { IChartData, IPortfolioComposition } from "home/goe/common/interfaces";
import { CHART_MARGIN, DONUT_CHART_SIZES } from "home/goe/common/constants";
import "./ScatterChart.scss";

interface ScatterChartProps {
    data: {
        data: Array<IChartData>;
        donutData: Array<IPortfolioComposition>;
    };
    xScale: any;
    leftYScale: any;
    rightYScale: any;
    isZoomed: boolean;
}

const ScatterChartOld = ({ data: { data, donutData }, xScale, rightYScale, isZoomed }: ScatterChartProps) => {
    const chartRef = useRef<SVGSVGElement>(null);

    function renderChart() {
        const { xTranslate } = getChartTranslateValues();
        let { height: donutChartHeight, width: donutChartWidth } = DONUT_CHART_SIZES.small;

        if (isZoomed) {
            donutChartWidth = DONUT_CHART_SIZES.large.width;
            donutChartHeight = DONUT_CHART_SIZES.large.height;
        }

        const conatiner = d3
            .select(chartRef.current)
            //.append("g")
            .attr("transform", `translate(${xTranslate}, ${CHART_MARGIN.top})`);

        // Remove existing donut charts and lines before rendering new ones
        conatiner.selectAll(".data-group").remove();
        conatiner.selectAll(".vertical-line").remove();

        // Create a group for each data point
        const dataGroups = conatiner
            .selectAll<SVGGElement, DataPoint>(".data-group")
            .data(data)
            .enter()
            .append("g")
            .attr("class", "data-group")
            .attr("transform", (d: IChartData) => {
                let translateX = xScale(d.year) - donutChartWidth / 2 - 3;
                const translateY = rightYScale(d.value) - donutChartHeight / 2;

                if (isZoomed) {
                    translateX += 3;
                }

                return `translate(${translateX}, ${translateY})`;
            });

        // Create a donut chart for each data point
        dataGroups.each((d: DataPoint, i: number, nodes: SVGGElement[]) => {
            const donutChartData = donutData[i];
            if (donutChartData) {
                const donutChartComponent = createDonutChartSvg({
                    initialData: donutChartData,
                    isZoomed,
                });
                d3.select(nodes[i]).node()?.appendChild(donutChartComponent);
            }
        });
    }

    useEffect(() => {
        if (chartRef.current && data.length > 0) {
            renderChart();
        }
        // eslint-disable-next-line
    }, [data, xScale, rightYScale]);

    return <g id="upa-overview-graph-scatter-chart" ref={chartRef}></g>;
};

export default ScatterChartOld;
