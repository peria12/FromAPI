import React, { useEffect, useRef } from "react";
import * as d3 from "d3";
import { getChartTranslateValues, getScalesNDomainsForChartByData } from "home/goe/common/utils";
export interface IChartDataPoint {
    year: number;
    value: number;
}
interface AreaChartProps {
    data: IChartDataPoint[];
}

const AreaChart = ({ data }: AreaChartProps) => {
    const areaRef = useRef<SVGGElement>(null);

    useEffect(() => {
        if (areaRef.current && data.length > 0) {
            const { xTranslate, yTranslate } = getChartTranslateValues();
            const [xScale, yScale] = getScalesNDomainsForChartByData(data);

            const areaGenerator = d3
                .area<IChartDataPoint>()
                .x((item) => xScale(item.year))
                .y0(yScale(0))
                .y1((item) => yScale(item.value))
                .curve(d3.curveLinear);

            const svg = d3.select(areaRef.current);

            // Remove existing AreaChart (path element) before rendering a new one. - this prevents overlapping of the area chart
            svg.select("path").remove();

            const gradientId = "areaGradient";

            // Define the gradient
            const gradient = svg
                .append("defs")
                .append("linearGradient")
                .attr("id", gradientId)
                .attr("gradientUnits", "userSpaceOnUse")
                .attr("x1", 0)
                .attr("y1", yScale(d3.max(data, (d) => d.value)))
                .attr("x2", 0)
                .attr("y2", yScale(0));

            gradient.append("stop").attr("offset", "0%").style("stop-color", "rgba(109, 192, 187, 0.75)");

            gradient.append("stop").attr("offset", "100%").style("stop-color", "rgba(225, 253, 253, 0.75)");

            svg.append("path")
                .datum(data)
                .attr("d", areaGenerator)
                .attr("fill", `url(#${gradientId})`)
                .attr("transform", `translate(${xTranslate}, ${yTranslate})`);
        }
        //eslint-disable-next-line
    }, [data]);

    return <g style={{ overflowX: "scroll" }} ref={areaRef}></g>;
};

export default AreaChart;
