import React, { useRef, useEffect, useState } from "react";
import * as d3 from "d3";
import { ZoomIn, ZoomOut } from "@mui/icons-material";

import { IChartData, IChartDomain, IPortfolioComposition } from "../../../../../common/interfaces";
import {
    // ChartData,
    checkZoomFeaturedEnabled,
    getChartHeight,
    getChartWidth,
    getGoalByYearFromGoalList,
    getGoalTenureData,
    getGoalTypeByGoal,
    getGoalWidthOnChartByTenure,
    getScalesNDomainsForChartByData,
    getWealthPathDataByAllData,
    getYearFromDateString,
} from "../../../../../common/utils";
import {
    CHART_MARGIN,
    GOAL_ICONS,
    GOAL_TYPES,
    GOE_GOAL_STAGES,
    GOE_GOAL_STAGE_ICONS,
    CHART_X_AXIS_START_MARGIN,
    RENDERABLE_CHART_WIDTH,
    MAX_CHART_HEIGHT,
    GOAL_ICON_SIZE,
    // ICON_CONTAINER_START_MARGIN
} from "../../../../../common/constants";
import FixedLeftAxis from "../../../../../common/FixedLeftAxis";
import BarChart from "../../../../../common/BarChart";
import AreaChart from "../../../../../common/AreaChart";
import DottedLineChart from "../../../../../common/DottedLineChart";
import GoalRelatedYearDots from "../../../../../common/GoalRelatedYearDots";

import "./GOEOverViewGraph.scss";

interface GoalOverviewGraphProps {
    goalWealthReport: any;
    goalWealthReportAllData: any;
    goalWealthReportConfigPayload: any;
    addedGoalList: Array<Array<number>>;
    portfolioComposition: Array<IPortfolioComposition>;
}

const GOEOverviewGraph = ({
    addedGoalList,
    goalWealthReportConfigPayload,
    goalWealthReportAllData,
}: GoalOverviewGraphProps) => {
    const chartRef = useRef<SVGSVGElement>(null);
    const divRef = useRef<HTMLDivElement>(null);

    const [goalProbData, setGoalProbData] = useState<any>(); // Store goal probabilities data like stage & prob

    const GOAL_INFO_WIDTH = { small: 20, large: 130 };

    const currentYear = new Date().getFullYear();
    const wealthPathData: Array<number> = getWealthPathDataByAllData(goalWealthReportAllData);

    const wealthPerYearData: Array<IChartData> = generateWealthPerYearData(wealthPathData);
    const goalRelatedYears = generateGoalRelatedYears(addedGoalList);

    const barChartData = generateBarChartData(addedGoalList);
    const dottedlineChartData = generateDottedLinesData(addedGoalList);
    const chartHeight = getChartHeight();
    const IS_ZOOM_FEATURE_ENABLED = checkZoomFeaturedEnabled("GOEOverviewGraph");

    const [isZoomed, setIsZoomed] = useState(false);
    const [chartWidth, setChartWidth] = useState(RENDERABLE_CHART_WIDTH);
    const [xScale, leftYScale, rightYScale] = createChartCanvasScales();
    let svg;

    useEffect(() => {
        if (chartRef.current && chartWidth > 0) {
            createChartCanvas(chartWidth, chartHeight);
        }
        // eslint-disable-next-line
    }, [chartWidth, chartHeight]);

    useEffect(() => {
        calcAndSetGoalProbs();
        // eslint-disable-next-line
    }, []);

    useEffect(() => {
        if (goalProbData && addedGoalList && goalRelatedYears) {
            renderGoalIcons();
        }
        // eslint-disable-next-line
    }, [goalRelatedYears, addedGoalList, chartWidth, goalProbData]);

    function getRightYDomains(): IChartDomain {
        return [0, 100];
    }

    function createChartCanvasScales() {
        // scales for the charts
        const [xScale, leftYScale] = getScalesNDomainsForChartByData(wealthPerYearData, undefined, chartWidth);

        const yDomains: IChartDomain = getRightYDomains();
        const rightYScale = d3.scaleLinear().domain(yDomains).range([chartHeight, 0]);

        return [xScale, leftYScale, rightYScale];
    }

    function createChartCanvas(chartWidth, chartHeight) {
        // eslint-disable-next-line react-hooks/exhaustive-deps
        svg = d3.select(chartRef.current).attr("width", chartWidth).attr("height", MAX_CHART_HEIGHT);

        svg.selectAll(".x-axis").remove();

        const { xAxis } = createChartCanvasAxis(xScale, rightYScale);

        addAxisToChartCanvas(svg, xAxis);

        transformChartCanvasAxis();

        // addChartCanvasYAxisTitle(svg);

        function createChartCanvasAxis(xScale, rightYScale) {
            const xAxis = d3
                .axisBottom(xScale)
                .tickValues(wealthPerYearData.map((data: IChartData) => data.year))
                .tickFormat((year: number) => ([currentYear, ...goalRelatedYears].includes(year) ? year : null));

            const rightYAxis = d3
                .axisRight(rightYScale)
                .ticks(10)
                .tickFormat((d) => `${d}%`);

            return { xAxis, rightYAxis };
        }

        function addAxisToChartCanvas(svg, xAxis) {
            //Add x-Axis
            svg.append("g")
                .attr("class", "x-axis")
                .attr("transform", `translate(${CHART_X_AXIS_START_MARGIN}, ${chartHeight + CHART_MARGIN.top})`)
                .call(xAxis)
                .selectAll("text")
                .attr("transform", "rotate(-90) translate(-25,-15)")
                .attr("text-anchor", "middle")
                .style("font-size", "14px")
                .style("line-height", "19px")
                .style("font-weight", "400")
                .style("font-family", "TT Commons");
        }

        function transformChartCanvasAxis() {
            svg.selectAll(".y-axis-right path.domain").style("display", "none");
            svg.selectAll(".tick line").style("display", "none");
            svg.selectAll(".y-axis path.domain").style("display", "none");
            svg.selectAll(".x-axis path.domain").style("display", "none");
        }
    }

    function generateGoalRelatedYears(addedGoalList: any) {
        //To generate only selected goal years
        const goalRelatedYears: Array<number> = [];

        addedGoalList.forEach((addedGoal) => {
            if (addedGoal.achieve_this_goal) {
                goalRelatedYears.push(getYearFromDateString(addedGoal.achieve_this_goal));
            } else if (addedGoal.plan_start_retirement) {
                goalRelatedYears.push(getYearFromDateString(addedGoal.plan_start_retirement));
                goalRelatedYears.push(getYearFromDateString(addedGoal.end_on_date));
            } else {
                goalRelatedYears.push(getYearFromDateString(addedGoal.start_first_withdrawal));
                goalRelatedYears.push(getYearFromDateString(addedGoal.last_withdrawal));
            }
        });

        return goalRelatedYears.sort();
    }

    function generateWealthPerYearData(wealthPathData: Array<number>): Array<IChartData> {
        let year = currentYear;

        const wealthPerYearData: Array<IChartData> = wealthPathData.map((wealthPathValue: any) => ({
            year: year++,
            value: wealthPathValue,
        }));

        return wealthPerYearData;
    }

    function generateBarChartData(addedGoalList): Array<Array<number>> {
        const barChartData: Array<Array<number>> = [];

        addedGoalList.forEach((addedGoal) => {
            if (addedGoal.plan_start_retirement) {
                const arr: Array<number> = [];
                const planStartDate = Number(getYearFromDateString(addedGoal.plan_start_retirement));
                const planEndDate = Number(getYearFromDateString(addedGoal.end_on_date));

                for (let i = planStartDate; i <= planEndDate; i++) {
                    arr.push(i);
                }

                barChartData.push(arr);
            } else if (addedGoal.start_first_withdrawal) {
                const arr: Array<number> = [];

                const planStartDate = Number(getYearFromDateString(addedGoal.start_first_withdrawal));
                const planEndDate = Number(getYearFromDateString(addedGoal.last_withdrawal));

                for (let i = planStartDate; i <= planEndDate; i++) {
                    arr.push(i);
                }

                barChartData.push(arr);
            }
        });

        return barChartData;
    }

    function generateDottedLinesData(addedGoalList): Array<number> {
        const dottedlineChartData: Array<number> = [];

        addedGoalList.forEach(({ achieve_this_goal }) => {
            if (achieve_this_goal) {
                const achieveGoalDate = Number(getYearFromDateString(achieve_this_goal));

                dottedlineChartData.push(achieveGoalDate);
            }
        });

        return dottedlineChartData;
    }

    function renderGoalIcons() {
        if (xScale(goalRelatedYears[goalRelatedYears.length - 1]) > 0) {
            const renderedGoals = {};
            const svgWrapper = d3.select(divRef.current);

            svgWrapper.selectAll(".goal-info").remove();

            let { width, height } = GOAL_ICON_SIZE.small;

            if (isZoomed) {
                width = GOAL_ICON_SIZE.large.width;
                height = GOAL_ICON_SIZE.large.height;
            }

            svgWrapper
                .selectAll("div")
                .data(goalRelatedYears)
                .enter()
                .append("div")
                .html((year) => {
                    const goal = getGoalByYearFromGoalList(addedGoalList, year);

                    if (goal) {
                        const { name, goal_amount, goal_key } = goal;
                        const goalId = goal["goal-key"];

                        if (!renderedGoals[goalId]) {
                            const { stage, percentage } = goalProbData[goalId];
                            renderedGoals[goalId] = true;
                            return `
                            <svg width="${width}" height="${height}" class="goal-info__icon">       
                                <image xlink:href="${
                                    GOAL_ICONS[goal_key + "_light"]
                                }" width="${width}" height="${height}"/>    
                            </svg>
                        <svg width="${width}" height="${height}" class="goal-info__icon--on-hover">       
                            <image xlink:href="${GOAL_ICONS[goal_key]}" width="${width}" height="${height}"/>    
                        </svg>
                        <h4 class="goal-info__name">${name}</h4>
                        <div class="goal-info__tooltip">
                            <div class="goal-info__tooltip-body goal-info__tooltip-body--${stage}">
                                <p class="goal-info__gv-amount">${goal_amount}</p>
                                <div class="goal-info__prob goal-info__prob--${stage}">
                                    <span class="goal-info__prob-icon">
                                        <img src="${GOE_GOAL_STAGE_ICONS[stage]}" height="16" width="16"/>
                                    </span>
                                    <span class="goal-info__prob-perc">${+percentage}%</span>
                                </div>
                            </div>
                        </div>`;
                        }
                    }
                })
                // .attr("class", "goal-info")
                .attr("class", () => {
                    const zoomClass = isZoomed ? "goal-info--zoomed" : "";
                    return `goal-info ${zoomClass}`;
                })
                .style("width", `${isZoomed ? GOAL_INFO_WIDTH.large : GOAL_INFO_WIDTH.small}px`)
                .style("left", (year) => {
                    const goal = getGoalByYearFromGoalList(addedGoalList, year);
                    const goalType = getGoalTypeByGoal(goal);

                    if (goalType === GOAL_TYPES.ONE_TIME) {
                        if (isZoomed) {
                            return `${xScale(year) - GOAL_INFO_WIDTH.large / 2}px`;
                        }
                        return `${xScale(year) - GOAL_INFO_WIDTH.small / 2}px`;
                    } else if (goalType === GOAL_TYPES.TENURE) {
                        const goalTenureData = getGoalTenureData(goal);
                        if (goalTenureData) {
                            const goalWidthOnChart = getGoalWidthOnChartByTenure(
                                goalTenureData.tenure,
                                wealthPerYearData.length,
                                chartWidth,
                                isZoomed
                            );

                            return `${xScale(year) + goalWidthOnChart / 2}px`;
                        }
                    }
                });
        }
    }

    function calcAndSetGoalProbs() {
        const goalProbsByKey = {};
        addedGoalList.forEach((goalItem) => {
            const goalKey = goalItem["goal-key"];

            const goalWealthReportData = goalWealthReportAllData[goalKey];
            const goalWealthReportConfig = goalWealthReportConfigPayload[goalKey];

            let currentGoalProb = goalWealthReportData["analysisReport"]["currentGoalProbability"].toFixed(2);
            const goalPriorityValue =
                goalWealthReportConfig["pipe_config"]["goal_priority_prob_list"][goalItem["goal_priority"]];

            goalWealthReportConfig["pipe_config"]["realistic_goal_prob"];
            const stage =
                currentGoalProb < 0.35
                    ? GOE_GOAL_STAGES.UNREALISTIC
                    : currentGoalProb < goalPriorityValue
                    ? GOE_GOAL_STAGES.REVIEW
                    : GOE_GOAL_STAGES.ALIGNED;

            currentGoalProb = currentGoalProb < 0.01 ? 0.01 : currentGoalProb > 0.99 ? 0.99 : currentGoalProb;
            const percentage = (currentGoalProb * 100).toFixed(1);

            goalProbsByKey[goalKey] = { stage, percentage };
        });

        setGoalProbData(goalProbsByKey);
    }

    function toggleZoom() {
        setIsZoomed((currentValue) => {
            if (currentValue === true) {
                //Chart is already zoomed In now Zoom it Out
                setChartWidth(RENDERABLE_CHART_WIDTH);
            } else {
                setChartWidth(getChartWidth(wealthPerYearData.length));
            }

            return !currentValue;
        });
    }

    // function generateScatteredChartData(portfolioPathData: Array<number>): {
    //     data: Array<IChartData>;
    //     donutData: Array<IPortfolioComposition>;
    // } {
    //     const data: Array<IChartData> = [];
    //     const donutData: Array<IPortfolioComposition> = [];

    //     if (portfolioPathData) {
    //         portfolioPathData.forEach((portfolioCompositionId, index) => {
    //             const composition: IPortfolioComposition = portfolioComposition[portfolioCompositionId];
    //             const year = wealthPerYearData[index].year;
    //             const value = composition.equity * 100;

    //             const chartData = new ChartData(year, value);

    //             data.push(chartData);
    //             donutData.push(composition);
    //         });
    //     }

    //     return { data, donutData };
    // }
    return (
        <div className="overview-container goe-overview-graph">
            <div className="overview-row header">
                <div className="div-flex-container">
                    <div className="div-chart-legend-left">
                        {Object.keys(GOE_GOAL_STAGES).map((key) => (
                            <li key={key} className="list-legend-left">
                                <img className="img-legend" src={GOE_GOAL_STAGE_ICONS[GOE_GOAL_STAGES[key]]} />
                                {GOE_GOAL_STAGES[key]}
                            </li>
                        ))}
                    </div>
                </div>
                {/* <div className="my-goals-prob-border-gradient-green zoom-row"> */}
                <div>
                    <span className="main-div-goal-probability-span"></span>
                    {IS_ZOOM_FEATURE_ENABLED && (
                        <span className="span-equity-exposure d-flex">
                            <label className={`${isZoomed ? "label-grey-out" : ""}`} onClick={toggleZoom}>
                                <ZoomOut fontSize="large" />
                            </label>
                            <label className={`${!isZoomed ? "label-grey-out" : ""}`} onClick={toggleZoom}>
                                <ZoomIn fontSize="large" />
                            </label>
                        </span>
                    )}
                </div>
            </div>
            <div className="d-flex body">
                <FixedLeftAxis data={wealthPerYearData} />
                <div style={{ maxWidth: `${RENDERABLE_CHART_WIDTH}px` }} className="main-container">
                    <svg ref={chartRef} className="d-flex" width="100%" height={chartHeight}>
                        <BarChart
                            data={barChartData}
                            wealthPerYearData={wealthPerYearData}
                            xScale={xScale}
                            yScale={leftYScale}
                            chartWidth={chartWidth}
                            isZoomed={isZoomed}
                        />
                        <AreaChart
                            data={wealthPerYearData}
                            wealthPerYearData={wealthPerYearData}
                            xScale={xScale}
                            yScale={leftYScale}
                        />
                        <GoalRelatedYearDots
                            goalRelatedYears={[currentYear, ...goalRelatedYears]}
                            wealthPerYearData={wealthPerYearData}
                            isZoomed={isZoomed}
                            xScale={xScale}
                            chartWidth={chartWidth}
                        />
                        <DottedLineChart
                            data={dottedlineChartData}
                            wealthPerYearData={wealthPerYearData}
                            xScale={xScale}
                            yScale={leftYScale}
                            chartWidth={chartWidth}
                            isZoomed={isZoomed}
                        />
                    </svg>
                    <div
                        className="icons-container"
                        ref={divRef}
                        style={{
                            height: chartHeight,
                            top: CHART_MARGIN.top,
                            left: CHART_X_AXIS_START_MARGIN,
                            width: chartWidth - CHART_X_AXIS_START_MARGIN,
                        }}
                    ></div>
                </div>
            </div>
        </div>
    );
};

export default GOEOverviewGraph;
