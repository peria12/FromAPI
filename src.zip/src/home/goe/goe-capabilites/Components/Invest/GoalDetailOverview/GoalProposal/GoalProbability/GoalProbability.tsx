import React, { useEffect, useState, useCallback, useMemo } from "react";
import "./GoalProbability.scss";
import DonutChart from "../../../GoalOverview/DonutChart";
import Progressbar from "./ProgressBar.js";
import EditImage from "../../../../../assets/images/svg/pen.svg";
import Line from "../../../../../assets/images/svg/line.svg";
import Api from "utils/api";

function GoalProbability(props: any) {
    const {
        addedGoalList,
        applyRecommendationFlag,
        setApplyRecommendationFlag,
        goalWealthReport,
        goalWealthReportConfig,
        goalDataPriority,
        getgoalLabels,
        formatDollar,
        basicInfo,
        setJourneyPath,
        setOverview,
        setActiveGoal,
        setGoalQuestionnaire,
        setGoalWealthReportData,
        setGoalWealthReportDataConfig,
        isUpa,
        setViewDetails,
    } = props;
    const [delayData, setDelayData] = useState({ years: 0, oldDate: "", newDate: "", fulldateData: "" });
    const goalJson = useMemo(() => {
        return goalDataPriority.length > 0 ? JSON.parse(JSON.stringify(goalDataPriority[0])) : {};
    }, [goalDataPriority]);
    const [selectedRecommend, setSelectRecommend] = useState("oneTimeTopUp");
    const [loading, setLoading] = useState(false);
    const dateLabel =
        goalJson[
        goalJson["goal_key"] === "plan_retirement"
            ? "plan_start_retirement"
            : goalJson["goal_key"] === "draw_income"
                ? "start_first_withdrawal"
                : "achieve_this_goal"
        ];
    const goalPriorityValueArr = [0];
    let initialInvestment = 0;
    const unFormaAmount = (formatterNUmber) => {
        if (typeof formatterNUmber != "number") {
            return Number(formatterNUmber.replace(/[$,]/g, ""));
        }
        return formatterNUmber;
    };
    addedGoalList.forEach((item) => {
        const goalProbData = goalWealthReportConfig["pipe_config"]["goal_priority_prob_list"][item["goal_priority"]];
        initialInvestment = initialInvestment + unFormaAmount(item["initial_investment"]);

        goalPriorityValueArr.push(goalProbData);
    });
    const currentGoalProb = goalWealthReport["analysisReport"]["currentGoalProbability"].toFixed(2);
    const goalPriorityValue = isUpa
        ? Math.max(...goalPriorityValueArr)
        : goalWealthReportConfig["pipe_config"]["goal_priority_prob_list"][goalJson["goal_priority"]];
    const stageData =
        currentGoalProb < 0.35 ? "Unrealistic" : currentGoalProb < goalPriorityValue ? "Review" : "Aligned";

    const findYears = useCallback(
        (probData) => {
            if (probData != "NA") {
                const splitedData = probData.split(";");
                let years = 0;
                let splitedDataPer = splitedData[0].split(":");
                if (splitedData.length > 1) {
                    splitedDataPer = splitedData[1].split(":");
                }
                const splitedDataPerT = splitedDataPer[0].trim().split(" ");
                if (goalJson["goal_key"] === "plan_retirement") {
                    splitedDataPerT.forEach((element) => {
                        if (Number(element)) {
                            years = Number(element);
                        }
                    });
                } else {
                    years = parseInt(splitedDataPerT[3].split("+")[1]);
                }

                const d = new Date(dateLabel);
                const year = d.getFullYear();
                const month = d.getMonth();
                const day = d.getDate();

                const oldFulldate = new Date(year, month, day);
                const months = [
                    "Jan",
                    "Feb",
                    "March",
                    "Apr",
                    "May",
                    "June",
                    "July",
                    "Aug",
                    "Sept",
                    "Oct",
                    "Nov",
                    "Dec",
                ];
                const oldConvertedDate = months[oldFulldate.getMonth()] + " " + oldFulldate.getFullYear();
                const fulldate = new Date(year + years, month, day);
                const convertedDate = months[fulldate.getMonth()] + " " + fulldate.getFullYear();
                setDelayData({
                    years: years,
                    oldDate: oldConvertedDate,
                    newDate: convertedDate,
                    fulldateData: fulldate.toDateString(),
                });
            }
            return probData;
        },
        [dateLabel, goalJson]
    );

    useEffect(() => {
        if (stageData === "Aligned") {
            setApplyRecommendationFlag(true);
        }
        if (!isUpa) {
            findYears(goalWealthReport["analysisReport"]["recommendedTenure"]);
            if (
                goalJson["goal_key"] === "plan_retirement" &&
                goalWealthReport["analysisReport"]["oneTimeTopUp"] == 0 &&
                (goalJson["contribution_time"] === "month"
                    ? goalWealthReport["analysisReport"]["monthlyTopUpAccumulation"]
                    : goalWealthReport["analysisReport"]["yearlyTopUpAccumulation"]) == 0 &&
                (goalJson["contribution_time"] === "month"
                    ? goalWealthReport["analysisReport"]["monthlyTopUpDecumulation"]
                    : goalWealthReport["analysisReport"]["yearlyTopUpDecumulation"]) &&
                goalWealthReport["analysisReport"]["recommendedTenure"] == "NA"
            ) {
                setApplyRecommendationFlag(true);
            } else if (
                goalJson["goal_key"] === "draw_income" &&
                goalWealthReport["analysisReport"]["oneTimeTopUp"] == 0 &&
                (goalJson["contribution_time"] === "month"
                    ? goalWealthReport["analysisReport"]["monthlyTopUpDecumulation"]
                    : goalWealthReport["analysisReport"]["yearlyTopUpDecumulation"])
            ) {
                setApplyRecommendationFlag(true);
            } else if (
                goalWealthReport["analysisReport"]["oneTimeTopUp"] == 0 &&
                (goalJson["contribution_time"] === "month"
                    ? goalWealthReport["analysisReport"]["monthlyTopUpAccumulation"]
                    : goalWealthReport["analysisReport"]["yearlyTopUpAccumulation"]) == 0 &&
                goalWealthReport["analysisReport"]["recommendedTenure"] == "NA"
            ) {
                setApplyRecommendationFlag(true);
            }
        } else {
            if (goalWealthReport["analysisReport"]["oneTimeTopUp"] == 0) {
                setApplyRecommendationFlag(true);
            }
        }
    }, [findYears, goalJson, goalWealthReport, isUpa, setApplyRecommendationFlag, stageData]);

    const applyRecommendation = async () => {
        const goalJson = goalDataPriority.length > 0 ? JSON.parse(JSON.stringify(goalDataPriority[0])) : {};
        let resultApi;
        let resultApiConfig;
        setLoading(true);
        if (selectedRecommend === "oneTimeTopUp") {
            if (isUpa) {
                resultApi = await Api.UPA(
                    addedGoalList,
                    basicInfo,
                    false,
                    true,
                    goalWealthReport["analysisReport"]["oneTimeTopUp"]
                );
                resultApiConfig = await Api.UPA(
                    addedGoalList,
                    basicInfo,
                    true,
                    true,
                    goalWealthReport["analysisReport"]["oneTimeTopUp"]
                );
            } else {
                goalJson["initial_investment"] =
                    unFormaAmount(goalJson["initial_investment"]) + goalWealthReport["analysisReport"]["oneTimeTopUp"];
                resultApi = await Api.runPipe(goalJson, basicInfo, false, false, 0);
                resultApiConfig = await Api.runPipe(goalJson, basicInfo, true, false, 0);
            }
        } else if (selectedRecommend === "yearlyTopUpDecumulation") {
            // need to work on that logic
            if (goalJson["goal_key"] === "plan_retirement" || goalJson["goal_key"] === "draw_income") {
                resultApi = await Api.runPipe(
                    goalJson,
                    basicInfo,
                    false,
                    true,
                    goalJson["contribution_time"] === "month"
                        ? goalWealthReport["analysisReport"]["monthlyTopUpDecumulation"]
                        : goalWealthReport["analysisReport"]["yearlyTopUpDecumulation"],
                    0,
                    "Dec"
                );
                resultApiConfig = await Api.runPipe(
                    goalJson,
                    basicInfo,
                    true,
                    true,
                    goalJson["contribution_time"] === "month"
                        ? goalWealthReport["analysisReport"]["monthlyTopUpDecumulation"]
                        : goalWealthReport["analysisReport"]["yearlyTopUpDecumulation"],
                    0,
                    "Dec"
                );
            } else {
                goalJson["recurring_contributions"] =
                    unFormaAmount(goalJson["recurring_contributions"]) +
                    (goalJson["contribution_time"] === "month"
                        ? goalWealthReport["analysisReport"]["monthlyTopUpDecumulation"]
                        : goalWealthReport["analysisReport"]["yearlyTopUpDecumulation"]);
                resultApi = await Api.runPipe(goalJson, basicInfo, false, false, 0);
                resultApiConfig = await Api.runPipe(goalJson, basicInfo, true, false, 0);
            }
        } else if (selectedRecommend === "yearlyTopUpAccumulation") {
            if (goalJson["goal_key"] === "plan_retirement" || goalJson["goal_key"] === "draw_income") {
                resultApi = await Api.runPipe(
                    goalJson,
                    basicInfo,
                    false,
                    true,
                    goalJson["contribution_time"] === "month"
                        ? goalWealthReport["analysisReport"]["monthlyTopUpAccumulation"]
                        : goalWealthReport["analysisReport"]["yearlyTopUpAccumulation"],
                    0,
                    "Acc"
                );
                resultApiConfig = await Api.runPipe(
                    goalJson,
                    basicInfo,
                    true,
                    true,
                    goalJson["contribution_time"] === "month"
                        ? goalWealthReport["analysisReport"]["monthlyTopUpAccumulation"]
                        : goalWealthReport["analysisReport"]["yearlyTopUpAccumulation"],
                    0,
                    "Acc"
                );
            } else {
                resultApi = await Api.runPipe(
                    goalJson,
                    basicInfo,
                    false,
                    true,
                    goalJson["contribution_time"] === "month"
                        ? goalWealthReport["analysisReport"]["monthlyTopUpAccumulation"]
                        : goalWealthReport["analysisReport"]["yearlyTopUpAccumulation"]
                );
                resultApiConfig = await Api.runPipe(
                    goalJson,
                    basicInfo,
                    true,
                    true,
                    goalJson["contribution_time"] === "month"
                        ? goalWealthReport["analysisReport"]["monthlyTopUpAccumulation"]
                        : goalWealthReport["analysisReport"]["yearlyTopUpAccumulation"]
                );
            }
        } else if (selectedRecommend === "recommendedTenure") {
            if (goalJson["goal_key"] === "plan_retirement" || goalJson["goal_key"] === "draw_income") {
                resultApi = await Api.runPipe(goalJson, basicInfo, false, true, 0, delayData, "", true);

                resultApiConfig = await Api.runPipe(goalJson, basicInfo, true, true, 0, delayData, "", true);
            } else {
                goalJson["achieve_this_goal"] = delayData.fulldateData;

                resultApi = await Api.runPipe(goalJson, basicInfo, false, false, 0);

                resultApiConfig = await Api.runPipe(goalJson, basicInfo, true, false, 0);
            }
        }
        setGoalWealthReportData(resultApi.body);
        setGoalWealthReportDataConfig(resultApiConfig.body);
        setApplyRecommendationFlag(!applyRecommendationFlag);
        setLoading(false);
        setViewDetails(false);
    };

    const handleEditgoal = () => {
        setJourneyPath("goal-type");
        setOverview("");
        setActiveGoal(goalJson["goal_key"]);
        setGoalQuestionnaire(isUpa ? "" : goalJson["goal_key"]);
    };

    const formatDollarVal = (dollarValue) => {
        if (dollarValue && typeof dollarValue !== "number") {
            return dollarValue.replace(/[$,]/g, "");
        }
        return dollarValue;
    };
    const digitFromatorRecom = (leftvalue, rightvalue, if_left = false) => {
        let leftformat = "";
        let rightformat = "";
        if (leftvalue < rightvalue) {
            if (Math.abs(Number(rightvalue)) >= 1.0e9) {
                leftformat = (Math.abs(Number(leftvalue)) / 1.0e9).toFixed(1) + "B";
                rightformat = (Math.abs(Number(rightvalue)) / 1.0e9).toFixed(1) + "B";
            } else if (Math.abs(Number(rightvalue)) >= 1.0e6) {
                leftformat = (Math.abs(Number(leftvalue)) / 1.0e6).toFixed(1) + "M";
                rightformat = (Math.abs(Number(rightvalue)) / 1.0e6).toFixed(1) + "M";
            } else {
                leftformat = (Math.abs(Number(leftvalue)) / 1.0e3).toFixed(1) + "K";
                rightformat = (Math.abs(Number(rightvalue)) / 1.0e3).toFixed(1) + "K";
            }
        } else {
            if (Math.abs(Number(leftvalue)) >= 1.0e9) {
                leftformat = (Math.abs(Number(leftvalue)) / 1.0e9).toFixed(1) + "B";
                rightformat = (Math.abs(Number(rightvalue)) / 1.0e9).toFixed(1) + "B";
            } else if (Math.abs(Number(leftvalue)) >= 1.0e6) {
                leftformat = (Math.abs(Number(leftvalue)) / 1.0e6).toFixed(1) + "M";
                rightformat = (Math.abs(Number(rightvalue)) / 1.0e6).toFixed(1) + "M";
            } else {
                leftformat = (Math.abs(Number(leftvalue)) / 1.0e3).toFixed(1) + "K";
                rightformat = (Math.abs(Number(rightvalue)) / 1.0e3).toFixed(1) + "K";
            }
        }
        if (if_left) {
            return "$ " + leftformat.replace(".0", "");
        } else {
            return "$ " + rightformat.replace(".0", "");
        }
    };

    return (
        <div>
            {loading ? (
                <div className="loader-overlay-prob">
                    {" "}
                    <div className="lds-spinner">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                </div>
            ) : (
                <></>
            )}
            <div
                className={
                    applyRecommendationFlag
                        ? "main-div-goal-probability main-div-goal-probability-apply-flag"
                        : "main-div-goal-probability"
                }
            >
                <div className="my-goals-prob-border-gradient-green">
                    <span className="main-div-goal-probability-span">
                        {isUpa ? "Plan Achievement Probability" : "Goal Probability"}
                    </span>
                </div>
                {goalWealthReport["analysisReport"] && (
                    <DonutChart
                        isProbability={true}
                        currentGoalProb={goalWealthReport["analysisReport"]["currentGoalProbability"].toFixed(2)}
                        realisticGoalProb={goalWealthReportConfig["pipe_config"]["realistic_goal_prob"]}
                        goalPriorityValue={goalPriorityValue}
                        applyRecommendationFlag={applyRecommendationFlag}
                    />
                )}

                {stageData !== "Aligned" && !applyRecommendationFlag && (
                    <div className="scrollable">
                        <div className="my-goals-prob-div-recommendations">
                            <span className="my-goals-prob-div-recommendations-span">Recommendations</span>
                        </div>
                        {isUpa ? (
                            <div>
                                {goalWealthReport["analysisReport"]["oneTimeTopUp"] != 0 && (
                                    <div
                                        className={
                                            selectedRecommend === "oneTimeTopUp"
                                                ? "my-goals-prob-div-recommendations-child-selected my-goals-prob-div-recommendations-child"
                                                : "my-goals-prob-div-recommendations-child"
                                        }
                                    >
                                        <div className="d-flex">
                                            <span className="my-goals-prob-div-recommendations-progres-span">
                                                Add a one time Lumpsum
                                            </span>
                                        </div>
                                        <div className="d-flex" style={{ marginTop: "8px" }}>
                                            <div className="d-flex" style={{ width: "100%", marginLeft: "-23px" }}>
                                                <span className="my-goals-prob-recommendations-progress-span-left">
                                                    {digitFromatorRecom(
                                                        formatDollarVal(goalJson["initial_investment"]),
                                                        goalWealthReport["analysisReport"]["oneTimeTopUp"],
                                                        true
                                                    )}
                                                </span>
                                            </div>
                                            <div
                                                className="d-flex"
                                                style={{
                                                    width: "100%",
                                                    marginRight: "-23px",
                                                    justifyContent: "center",
                                                }}
                                            >
                                                <span className={"my-goals-prob-recommendations-progress-span-right"}>
                                                    +
                                                    {digitFromatorRecom(
                                                        formatDollarVal(goalJson["initial_investment"]),
                                                        goalWealthReport["analysisReport"]["oneTimeTopUp"],
                                                        false
                                                    )}
                                                </span>
                                            </div>
                                        </div>
                                        <div className="my-goals-prob-div-recommendations-progress">
                                            <div className="my-goals-prob-div-recommendations-progress-div">
                                                <Progressbar
                                                    bgcolor="orange"
                                                    progress={goalJson["initial_investment"]}
                                                    height={30}
                                                    leftSpan={initialInvestment}
                                                    rightSpan={goalWealthReport["analysisReport"]["oneTimeTopUp"]}
                                                    formatDollar={formatDollar}
                                                />
                                            </div>
                                            <div className="my-goals-prob-div-recommendations-progress-radio-div">
                                                <input
                                                    checked={selectedRecommend === "oneTimeTopUp"}
                                                    type="radio"
                                                    onClick={() => {
                                                        setSelectRecommend("oneTimeTopUp");
                                                    }}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                        ) : (
                            <div>
                                <div>
                                    {goalWealthReport["analysisReport"]["oneTimeTopUp"] != 0 && (
                                        <div
                                            className={
                                                selectedRecommend === "oneTimeTopUp"
                                                    ? "my-goals-prob-div-recommendations-child-selected my-goals-prob-div-recommendations-child"
                                                    : "my-goals-prob-div-recommendations-child"
                                            }
                                        >
                                            <div className="d-flex">
                                                <span className="my-goals-prob-div-recommendations-progres-span">
                                                    {getgoalLabels(goalJson)["analysisReport_oneTimeTopUp"]}
                                                </span>
                                            </div>
                                            <div className="d-flex" style={{ marginTop: "8px" }}>
                                                <div className="d-flex" style={{ width: "100%", marginLeft: "-23px" }}>
                                                </div>
                                                <div
                                                    className="d-flex"
                                                    style={{
                                                        width: "100%",
                                                        marginRight: "-23px",
                                                        justifyContent: "center",
                                                    }}
                                                >
                                                    <span
                                                        className={"my-goals-prob-recommendations-progress-span-right"}
                                                    >
                                                        +
                                                        {digitFromatorRecom(
                                                            formatDollarVal(goalJson["initial_investment"]),
                                                            goalWealthReport["analysisReport"]["oneTimeTopUp"],
                                                            false
                                                        )}
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="my-goals-prob-div-recommendations-progress">
                                                <div className="my-goals-prob-div-recommendations-progress-div">
                                                    <Progressbar
                                                        bgcolor="orange"
                                                        progress={goalJson["initial_investment"]}
                                                        height={30}
                                                        leftSpan={goalJson["initial_investment"]}
                                                        rightSpan={goalWealthReport["analysisReport"]["oneTimeTopUp"]}
                                                        formatDollar={formatDollar}
                                                    />
                                                </div>
                                                <div className="my-goals-prob-div-recommendations-progress-radio-div">
                                                    <input
                                                        checked={selectedRecommend === "oneTimeTopUp"}
                                                        type="radio"
                                                        onClick={() => {
                                                            setSelectRecommend("oneTimeTopUp");
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {(goalJson["contribution_time"] === "month"
                                        ? formatDollar(goalWealthReport["analysisReport"]["monthlyTopUpAccumulation"])
                                        : formatDollar(
                                            goalWealthReport["analysisReport"]["yearlyTopUpAccumulation"]
                                        )) != "$0" &&
                                        goalJson["goal_key"] !== "draw_income" && (
                                            <div
                                                className={
                                                    selectedRecommend === "yearlyTopUpAccumulation"
                                                        ? "my-goals-prob-div-recommendations-child-selected my-goals-prob-div-recommendations-child my-goals-prob-div-recommendations-child-1"
                                                        : "my-goals-prob-div-recommendations-child my-goals-prob-div-recommendations-child-1"
                                                }
                                            >
                                                <div className="d-flex">
                                                    <span className="my-goals-prob-div-recommendations-progres-span">
                                                        {goalJson["contribution_time"] === "month"
                                                            ? getgoalLabels(goalJson)[
                                                            "analysisReport_MonthlyTopUpAccumulation"
                                                            ]
                                                            : getgoalLabels(goalJson)[
                                                            "analysisReport_yearlyTopUpAccumulation"
                                                            ]}
                                                    </span>
                                                </div>
                                                <div className="d-flex" style={{ marginTop: "8px" }}>
                                                    <div
                                                        className="d-flex"
                                                        style={{ width: "100%", marginLeft: "-23px" }}
                                                    >
                                                    </div>
                                                    <div
                                                        className="d-flex"
                                                        style={{
                                                            width: "100%",
                                                            marginRight: "-23px",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <span
                                                            className={
                                                                "my-goals-prob-recommendations-progress-span-right"
                                                            }
                                                        >
                                                            +{" "}
                                                            {digitFromatorRecom(
                                                                formatDollarVal(
                                                                    goalDataPriority[0]["recurring_contributions"]
                                                                ),
                                                                goalJson["contribution_time"] === "month"
                                                                    ? goalWealthReport["analysisReport"][
                                                                    "monthlyTopUpAccumulation"
                                                                    ]
                                                                    : goalWealthReport["analysisReport"][
                                                                    "yearlyTopUpAccumulation"
                                                                    ]
                                                            )}
                                                        </span>
                                                    </div>
                                                </div>
                                                <div className="my-goals-prob-div-recommendations-progress">
                                                    <div className="my-goals-prob-div-recommendations-progress-div">
                                                        {/* <Progressbar bgcolor="orange" progress='30'  height={30} /> */}
                                                        <Progressbar
                                                            bgcolor="orange"
                                                            progress={goalDataPriority[0]["recurring_contributions"]}
                                                            height={30}
                                                            leftSpan={goalDataPriority[0]["recurring_contributions"]}
                                                            formatDollar={formatDollar}
                                                            rightSpan={
                                                                goalJson["contribution_time"] === "month"
                                                                    ? goalWealthReport["analysisReport"][
                                                                    "monthlyTopUpAccumulation"
                                                                    ]
                                                                    : goalWealthReport["analysisReport"][
                                                                    "yearlyTopUpAccumulation"
                                                                    ]
                                                            }
                                                        />
                                                    </div>
                                                    <div className="my-goals-prob-div-recommendations-progress-radio-div">
                                                        <input
                                                            type="radio"
                                                            checked={selectedRecommend === "yearlyTopUpAccumulation"}
                                                            onClick={() => {
                                                                setSelectRecommend("yearlyTopUpAccumulation");
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        )}

                                    {(goalJson["goal_key"] === "plan_retirement" ||
                                        goalJson["goal_key"] === "draw_income") &&
                                        (goalJson["contribution_time"] === "month"
                                            ? formatDollar(
                                                goalWealthReport["analysisReport"]["monthlyTopUpDecumulation"]
                                            )
                                            : formatDollar(
                                                goalWealthReport["analysisReport"]["yearlyTopUpDecumulation"]
                                            )) != "$0" && (
                                            <div
                                                className={
                                                    selectedRecommend === "yearlyTopUpDecumulation"
                                                        ? "my-goals-prob-div-recommendations-child-selected my-goals-prob-div-recommendations-child my-goals-prob-div-recommendations-child-2"
                                                        : "my-goals-prob-div-recommendations-child my-goals-prob-div-recommendations-child-2"
                                                }
                                            >
                                                <div className="d-flex">
                                                    <span className="my-goals-prob-div-recommendations-progres-span">
                                                        {goalJson["contribution_time"] === "month"
                                                            ? getgoalLabels(goalJson)[
                                                            "analysisReport_MonthlyTopUpDecumulation"
                                                            ]
                                                            : getgoalLabels(goalJson)[
                                                            "analysisReport_yearlyTopUpDecumulation"
                                                            ]}
                                                    </span>
                                                </div>
                                                <div className="d-flex" style={{ marginTop: "8px" }}>
                                                    <div
                                                        className="d-flex"
                                                        style={{ width: "100%", marginLeft: "-23px" }}
                                                    >
                                                        <span className="my-goals-prob-recommendations-progress-span-left">
                                                        </span>
                                                    </div>
                                                    <div
                                                        className="d-flex"
                                                        style={{
                                                            width: "100%",
                                                            marginRight: "-23px",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <span
                                                            className={
                                                                "my-goals-prob-recommendations-progress-span-right span-right-div-chart-s3-red"
                                                            }
                                                        >
                                                            -{" "}
                                                            {digitFromatorRecom(
                                                                formatDollarVal(
                                                                    goalDataPriority[0][
                                                                    goalJson["goal_key"] === "plan_retirement"
                                                                        ? "targeted_retirement_income"
                                                                        : "draw_income"
                                                                    ]
                                                                ),
                                                                goalJson["contribution_time"] === "month"
                                                                    ? goalWealthReport["analysisReport"][
                                                                    "monthlyTopUpDecumulation"
                                                                    ]
                                                                    : goalWealthReport["analysisReport"][
                                                                    "yearlyTopUpDecumulation"
                                                                    ],
                                                                false
                                                            )}
                                                        </span>
                                                    </div>
                                                </div>

                                                <div className="my-goals-prob-div-recommendations-progress">
                                                    <div className="my-goals-prob-div-recommendations-progress-div">
                                                        <Progressbar
                                                            isDecumulation={true}
                                                            bgcolor="orange"
                                                            progress={
                                                                goalDataPriority[0][
                                                                goalJson["goal_key"] === "plan_retirement"
                                                                    ? "targeted_retirement_income"
                                                                    : "draw_income"
                                                                ]
                                                            }
                                                            height={30}
                                                            leftSpan={
                                                                goalDataPriority[0][
                                                                goalJson["goal_key"] === "plan_retirement"
                                                                    ? "targeted_retirement_income"
                                                                    : "draw_income"
                                                                ]
                                                            }
                                                            formatDollar={formatDollar}
                                                            rightSpan={
                                                                goalJson["contribution_time"] === "month"
                                                                    ? goalWealthReport["analysisReport"][
                                                                    "monthlyTopUpDecumulation"
                                                                    ]
                                                                    : goalWealthReport["analysisReport"][
                                                                    "yearlyTopUpDecumulation"
                                                                    ]
                                                            }
                                                        />
                                                    </div>
                                                    <div className="my-goals-prob-div-recommendations-progress-radio-div">
                                                        <input
                                                            className="goal-probability-radio"
                                                            type="radio"
                                                            checked={selectedRecommend === "yearlyTopUpDecumulation"}
                                                            onClick={() => {
                                                                setSelectRecommend("yearlyTopUpDecumulation");
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        )}

                                    {goalWealthReport["analysisReport"]["recommendedTenure"] != "NA" &&
                                        goalJson["goal_key"] !== "draw_income" &&
                                        delayData.years != 0 && (
                                            <div
                                                className={
                                                    selectedRecommend === "recommendedTenure"
                                                        ? "my-goals-prob-div-recommendations-child-selected my-goals-prob-div-recommendations-child my-goals-prob-div-recommendations-child-3"
                                                        : "my-goals-prob-div-recommendations-child my-goals-prob-div-recommendations-child-3"
                                                }
                                            >
                                                <div className="d-flex">
                                                    <span className="my-goals-prob-div-recommendations-progres-span">
                                                        {getgoalLabels(goalJson)["analysisReport_recommendedTenure"]}
                                                    </span>
                                                </div>
                                                <div
                                                    className="my-goals-prob-div-recommendations-progress"
                                                    style={{ marginTop: "30px" }}
                                                >
                                                    <div className="d-flex">
                                                        <div className="my-goals-prob-div-recommendations-leftdate">
                                                            <span className="my-goals-prob-div-recommendations-leftdate-span">
                                                                {delayData.oldDate}
                                                            </span>
                                                        </div>
                                                        <div className="my-goals-prob-div-recommendations-arrow">
                                                            <span className="my-goals-prob-div-recommendations-arrow-span">
                                                                (+ {delayData.years} years)
                                                            </span>
                                                            <img src={Line} />
                                                        </div>
                                                        <div className="my-goals-prob-div-recommendations-rightdate">
                                                            <span className="my-goals-prob-div-recommendations-rightdate-span">
                                                                {delayData.newDate}
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div
                                                        className="my-goals-prob-div-recommendations-progress-radio-div"
                                                        style={{ marginLeft: "20px" }}
                                                    >
                                                        <input
                                                            type="radio"
                                                            checked={selectedRecommend === "recommendedTenure"}
                                                            onClick={() => {
                                                                setSelectRecommend("recommendedTenure");
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        )}
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>
            <div
                className={
                    applyRecommendationFlag
                        ? "my-goals-prob-div-buttons my-goals-prob-div-buttons-apply-flag"
                        : "my-goals-prob-div-buttons"
                }
            >
                <div className="my-goals-prob-div-buttons-editgoal" onClick={handleEditgoal}>
                    <img src={EditImage} className="my-goals-prob-editgoal-span-img" />{" "}
                    <span className="my-goals-prob-editgoal-span">{isUpa ? "Edit Plan" : "Edit this Goal"}</span>
                </div>
                {!applyRecommendationFlag && (
                    <div className="my-goals-prob-div-buttons-applyreco" onClick={applyRecommendation}>
                        <span className="my-goals-prob-applyreco-span">Apply Recommendation</span>
                    </div>
                )}
            </div>
        </div>
    );
}

export default GoalProbability;