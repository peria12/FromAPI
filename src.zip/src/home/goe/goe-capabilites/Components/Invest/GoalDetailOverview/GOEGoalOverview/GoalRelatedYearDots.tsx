import React, { useEffect, useRef } from "react";
import * as d3 from "d3";
import { IGoalRelatedYear } from "home/goe/common/interfaces";
import { getChartHeight, getChartTranslateValues, getScalesNDomainsForChartByData } from "home/goe/common/utils";

interface IGoalRelatedYearDotsProp {
    goalRelatedYears: Array<IGoalRelatedYear>;
    wealthPerYearData: any;
}

const DOT_RADIUS = 4;
const DOT_FILL_COLOUR = "#000000";

const GoalRelatedYearDots = function ({ goalRelatedYears, wealthPerYearData }: IGoalRelatedYearDotsProp) {
    const gRef = useRef<SVGGElement>(null);

    useEffect(() => {
        if (goalRelatedYears && goalRelatedYears.length > 0 && wealthPerYearData && wealthPerYearData.length > 0)
            createDots(goalRelatedYears, wealthPerYearData);
    }, [goalRelatedYears, wealthPerYearData]);

    function createDots(data: Array<IGoalRelatedYear>, wealthPerYearData) {
        const svg = d3.select(gRef.current);
        const [xScale] = getScalesNDomainsForChartByData(wealthPerYearData);
        const chartHeight = getChartHeight();
        const { xTranslate, yTranslate } = getChartTranslateValues();

        svg.selectAll("circle")
            .data(data)
            .enter()
            .append("circle")
            .attr("cx", xScale)
            .attr("cy", chartHeight)
            .attr("r", DOT_RADIUS)
            .attr("fill", DOT_FILL_COLOUR)
            .attr("transform", `translate(${xTranslate}, ${yTranslate})`);
    }

    if (goalRelatedYears && goalRelatedYears.length > 0 && wealthPerYearData && wealthPerYearData.length > 0) {
        return <g ref={gRef}></g>;
    }
    return null;
};

export default GoalRelatedYearDots;
