import * as d3 from "d3";
import React, { useEffect, useRef } from "react";
import createDonutChartSvg from "./DonutChart";
import { DataPoint, chartMargin } from "./ForwardLooking";
import createPieChartSvg from "./PieChart";
interface ScatterChartProps {
    data: DataPoint[];
    chartWidth: number;
    chartHeight: number;
    startDate: Date;
    donutChartData: { equity: number; fixed_income: number }[];
    endDate: Date;
    isZoomedOut;
}

const ScatterChart = ({
    data,
    donutChartData,
    chartWidth,
    chartHeight,
    startDate,
    endDate,
    isZoomedOut,
}: ScatterChartProps) => {
    const chartRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (chartRef.current && data.length > 0) {
            const xScale = d3.scaleTime().domain([startDate, endDate]).range([0, chartWidth]);
            const yScale = d3.scaleLinear().domain([0, 100]).range([chartHeight, 0]);

            const svg = d3.select(chartRef.current);

            // Remove existing donut charts and lines before rendering new ones
            svg.selectAll(".scatter-chart__item").remove();
            svg.selectAll(".vertical-line").remove();
            svg.selectAll("tooltip").remove();

            // Create a group for each data point
            const dataGroups = svg
                .selectAll<SVGGElement, DataPoint>(".scatter-chart__item")
                .data(data)
                .enter()
                .append("div")
                .attr("class", "scatter-chart__item")
                .style("position", "absolute")
                .style("left", (d: DataPoint) => {
                    const translateX = xScale(d.date) + (isZoomedOut ? -3 : 0);
                    return translateX + "px";
                })
                .style("top", (d: DataPoint) => {
                    const translateY = yScale(d.value) - chartMargin.top;
                    return translateY + "px";
                });

            // Create a donut chart for each data point
            dataGroups.each((d: DataPoint, i: number, nodes: SVGGElement[]) => {
                const donutChartDataItem = donutChartData[i];
                if (donutChartDataItem) {
                    const donutChartComponent = createDonutChartSvg({ initialData: donutChartDataItem, isZoomedOut });
                    const pieChartSvg = createPieChartSvg({
                        data: [
                            { label: "equity", value: donutChartDataItem.equity },
                            { label: "fixed_income", value: donutChartDataItem.fixed_income },
                        ],
                        isZoomed: isZoomedOut,
                    });
                    const year = new Date(d.date).getFullYear();

                    const tooltipNode = d3
                        .create("div")
                        .attr("class", "scatter-chart__tooltip")
                        .style("transform", `translatey(0%)  translatex(${0}px)`).html(`
                            <div class="div-portfolio-composition">
                                ${!isZoomedOut ? pieChartSvg?.outerHTML : ""}
                                <div class= "div-portfolio-composition-details"  style=" border-left:${
                                    !isZoomedOut ? "1px solid #8C8C8C" : ""
                                } ">
                                    <div class="portfolio-year">Year: ${year}</div>
                                   
                                        <div>${(donutChartDataItem.equity * 100).toFixed(0)}% Equity &  
                                        ${(donutChartDataItem.fixed_income * 100).toFixed(0)}% Fixed Income. </div> 
                                     
                                </div>
                            </div>      
                        `);
                    const dataGroup = d3.select(nodes[i]);
                    dataGroup.node()?.appendChild(donutChartComponent);

                    dataGroup.node()?.appendChild(tooltipNode.node());

                    // Create the arrow element
                    const arrowElement = d3
                        .create("div")
                        .attr("class", "scatter-chart__tooltip-arrow")
                        .style("position", "absolute")
                        .style("bottom", "-12px")
                        .style("left", "48%")
                        .style("transform", "translateX(-50%) rotate(180deg)")
                        .style("border-width", "6px")
                        .style("border-style", "solid")
                        .style("top", isZoomedOut ? "-0px" : "-12px")
                        .style("transform", "translateY(-90%) rotate(0deg)")
                        .style("border-color", "transparent transparent white transparent");

                    tooltipNode.style("transform", `translatey(0%) translatex(${0}px)`);
                    tooltipNode.node()?.insertBefore(arrowElement.node(), tooltipNode.node().lastChild);

                    // Add event listeners for mouse enter and leave
                    dataGroup
                        .on("mouseenter", () => {
                            const translateX = 120;
                            arrowElement.style("top", isZoomedOut ? "-8px" : "-12px");
                            tooltipNode.style("transform", `translatey(0) translatex(${translateX}px)`);
                            arrowElement.style("left", "10%");
                            arrowElement.style("transform", "translateY(-92%) rotate(0deg)");
                            tooltipNode.node()?.appendChild(arrowElement.node(), tooltipNode.node().firstChild);
                            return;
                        })
                        .on("mouseleave", () => {
                            tooltipNode.style("transform", `translatey(${isZoomedOut ? -125 : -140}%)`); // Reset position on leave
                        });
                }
            });
        }
    }, [data, chartWidth, chartHeight, endDate, startDate, donutChartData]);

    return (
        <div
            style={{
                height: chartHeight,
                top: 0,
                position: "absolute",
                left: 0,
                width: chartWidth - chartMargin.left - chartMargin.right,
            }}
            ref={chartRef}
            className="graph-container scatter-chart"
        />
    );
};

export default ScatterChart;