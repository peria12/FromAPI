import React from "react";
import * as d3 from "d3";
import { useEffect, useRef } from "react";
import { IChartData } from "../../../../../common/interfaces";
import { getChartHeight, getChartXAxisValueGap, getScalesNDomainsForChartByData } from "../../../../../common/utils";
import { CHART_MARGIN, CHART_X_AXIS_START_MARGIN } from "home/goe/common/constants";

interface BarChartProps {
    data: Array<Array<number>>;
    wealthPerYearData: Array<IChartData>;
    xScale: (x: any) => number;
    chartWidth: number;
    isZoomed: boolean;
}

const BarChart = ({ data, wealthPerYearData, xScale, chartWidth, isZoomed = false }: BarChartProps) => {
    const barRef = useRef<SVGGElement>(null);
    const BAR_CHART_FILL_COLOR = "#fbe5dc";
    const chartHeight = getChartHeight();
    const yDomains = getScalesNDomainsForChartByData(wealthPerYearData, undefined, chartWidth)[3];
    const yScale = getScalesNDomainsForChartByData(wealthPerYearData, undefined, chartWidth)[1];

    useEffect(() => {
        renderGraph();
        //eslint-disable-next-line
    }, [wealthPerYearData, chartWidth, isZoomed]);

    function renderGraph() {
        if (barRef.current && data.length > 0 && xScale && chartHeight > 0) {
            const svg = d3.select(barRef.current);
            const xAxisValueGap = getChartXAxisValueGap(chartWidth, wealthPerYearData.length, isZoomed);

            svg.selectAll("rect").remove();

            const barGroup = svg
                .append("g")
                .attr("transform", `translate(${CHART_X_AXIS_START_MARGIN}, ${CHART_MARGIN.top})`);

            //To show startyear and end year bar
            barGroup
                .selectAll("rect")
                .data(data)
                .enter()
                .append("rect")
                .attr("x", (d: Array<number>) => xScale(d[0]))
                // .attr("y", 0)
                .attr("y", yScale(yDomains[1]) - 5)
                .attr("width", (item) => (item.length - 1) * xAxisValueGap)
                // .attr("height", chartHeight - 5)
                .attr("height", chartHeight - 15)
                .attr("fill", BAR_CHART_FILL_COLOR)
                .attr("transform", `translate(0, 5)`);
        }
    }

    return <g ref={barRef} />;
};

export default BarChart;
