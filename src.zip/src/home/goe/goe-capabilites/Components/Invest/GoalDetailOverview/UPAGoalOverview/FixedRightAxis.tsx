import React, { useEffect, useRef } from "react";
import { chartMargin } from "../ForwardLooking/ForwardLooking";
import * as d3 from "d3";
import { CHART_MARGIN } from "home/goe/common/constants";

interface FixedRightAxisProps {
    chartHeight: number;
    displayEquityExposure: boolean;
}
const FixedRightAxis = ({ chartHeight, displayEquityExposure }: FixedRightAxisProps) => {
    // Create a new SVG element for the right y-axis
    const rightYAxisRef = useRef<SVGSVGElement>(null);

    useEffect(() => {
        if (rightYAxisRef.current) {
            // Remove any existing right y-axis
            // d3.select(".y-axis-right").remove();

            const svg = d3
                .select(rightYAxisRef.current)
                .attr("height", chartHeight + chartMargin.top + chartMargin.bottom);

            const rightYScale = d3.scaleLinear().domain([0, 100]).range([chartHeight, 0]);

            // Add right y-axis
            const yAxisRight = d3
                .axisRight(rightYScale)
                .ticks(10)
                .tickFormat((d) => `${d}%`);

            svg.selectAll("text").remove();

            svg.append("g")
                .attr("class", "y-axis-right")
                .attr("transform", `translate(0, ${CHART_MARGIN.top})`)
                .call(yAxisRight)
                .selectAll("text")
                .style("font-size", "12px")
                .style("line-height", "19px")
                .style("font-weight", "400")
                .style("fill", displayEquityExposure ? "000" : "#BFBFBF")
                .style("font-family", "TT Commons");

            // Add right y-axis title
            svg.append("text")
                .attr("class", "y-axis-title-right")
                .style("writing-mode", "vertical-lr")
                .attr("transform", `translate(${chartMargin.left / 2},${chartHeight / 2 - chartMargin.top} )`)
                .style("text-anchor", "middle")
                .style("font-size", "16px")
                .style("line-height", "19px")
                .style("font-weight", "500")
                .text("Equity Exposure")
                .style("fill", displayEquityExposure ? "000" : "#BFBFBF")
                .attr("dy", `30px`);

            // Hide right y-axis tick line
            svg.selectAll(".y-axis-right path.domain").style("display", "none");
            svg.selectAll(".tick line").style("display", "none");
        }
        //eslint-disable-next-line
    }, [displayEquityExposure]);

    return (
        <svg ref={rightYAxisRef} className="right-y-axis-svg" width={chartMargin.right} height={chartHeight}>
            <g transform={`translate(0,${chartMargin.top})`} className="y-axis right-y-axis" />
        </svg>
    );
};

export default FixedRightAxis;
