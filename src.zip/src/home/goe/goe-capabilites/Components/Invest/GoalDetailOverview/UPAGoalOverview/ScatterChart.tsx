import React, { useEffect, useRef } from "react";
import * as d3 from "d3";
import { DataPoint } from "../ForwardLooking/ForwardLooking";
import createDonutChartSvg from "./DonutChart";
// import { getChartTranslateValues } from "home/goe/common/utils";
import { IChartData, IPortfolioComposition } from "home/goe/common/interfaces";
import { CHART_X_AXIS_START_MARGIN, DONUT_CHART_SIZES } from "home/goe/common/constants";
import "./ScatterChart.scss";
import createPieChartSvg from "./PieChart";

interface ScatterChartProps {
    data: {
        data: Array<IChartData>;
        donutData: Array<IPortfolioComposition>;
    };
    xScale: any;
    leftYScale: any;
    rightYScale: any;
    isZoomed: boolean;
    chartWidth: number;
    chartHeight: number;
}

const ScatterChart = ({
    data: { data, donutData },
    xScale,
    rightYScale,
    isZoomed,
    chartWidth,
    chartHeight,
}: ScatterChartProps) => {
    const chartRef = useRef<HTMLDivElement>(null);
    console.log("ddata", data);
    let { height: donutChartHeight, width: donutChartWidth } = DONUT_CHART_SIZES.small;
    if (isZoomed) {
        donutChartWidth = DONUT_CHART_SIZES.large.width;
        donutChartHeight = DONUT_CHART_SIZES.large.height;
    }

    function renderChart() {
        const container = d3.select(chartRef.current);
        // const container = svg.append("g")
        //     .attr("transform", `translate(${xTranslate},0)`);

        // Remove existing donut charts and lines before rendering new ones
        container.selectAll(".uog-scatter-chart__item").remove();
        container.selectAll(".vertical-line").remove();

        // Create a group for each data point
        const dataGroups = container
            .selectAll<SVGGElement, DataPoint>(".uog-scatter-chart__item")
            .data(data)
            .enter()
            .append("div")
            .attr("class", "uog-scatter-chart__item")
            .style("position", "absolute")
            .style("left", (d: IChartData) => {
                let translateX = xScale(d.year) - donutChartWidth / 2 - 3 + CHART_X_AXIS_START_MARGIN;

                if (isZoomed) {
                    translateX += 3;
                }

                return translateX + "px";
            })
            .style("top", (d: IChartData) => {
                const translateY = rightYScale(d.value) - donutChartHeight / 2;

                return translateY + "px";
            });

        // Create a donut chart for each data point
        dataGroups.each((d: IChartData, i: number, nodes: SVGGElement[]) => {
            const chartData: IPortfolioComposition = donutData[i];
            if (chartData) {
                const donutChartComponent = createDonutChartSvg({
                    initialData: chartData,
                    isZoomed,
                });
                const pieChartComponent = createPieChartSvg({
                    initialData: chartData,
                    isZoomed,
                    isLabelVisible: true,
                });
                const tooltipNode = d3
                    .create("div")
                    .attr("class", "uog-scatter-chart__tooltip")
                    .style(
                        "transform",
                        `translatey(${isZoomed ? "-200px" : "65%"})  translatex(${isZoomed ? -125 : -5}px)`
                    ).html(`
                            ${
                                isZoomed
                                    ? `<div class="uog-scatter-chart__tooltip-section">${pieChartComponent?.outerHTML}</div>`
                                    : ""
                            }
                            <div class="uog-scatter-chart__tooltip-section uog-scatter-chart__tooltip-section--right">
                                <p class="uog-scatter-chart__tooltip-heading">Year: ${d.year}</p>
                                <p class="uog-scatter-chart__tooltip-content">${chartData.equity * 100}% Equity & ${
                    chartData.fixed_income * 100
                }% Fixed Income</p>
                            </div>
                        `);

                d3.select(nodes[i]).node()?.appendChild(donutChartComponent);
                //s.node()?.appendChild(pieChartComponent)
                d3.select(nodes[i]).node()?.appendChild(tooltipNode.node());

                // Create the arrow element
                const arrowElement = d3
                    .create("div")
                    .attr("class", "scatter-chart__tooltip-arrow")
                    .style("position", "absolute")
                    .style("bottom", "-12px")
                    .style("left", "48%")
                    .style("transform", "translateX(-50%) rotate(180deg)")
                    .style("border-width", "6px")
                    .style("border-style", "solid")
                    .style("top", isZoomed ? "-0px" : "-12px")
                    .style("transform", "translateY(-90%) rotate(0deg)")
                    .style("border-color", "transparent transparent white transparent");

                tooltipNode.node()?.insertBefore(arrowElement.node(), tooltipNode.node().lastChild);

                d3.select(nodes[i])
                    .on("mouseenter", () => {
                        arrowElement.style("top", "-8px");
                        tooltipNode.style("transform", `translatey(70%) translatex(${isZoomed ? 115 : 75}px)`);
                        arrowElement.style("left", "10%");
                        arrowElement.style("transform", "translateY(-92%) rotate(0deg)");
                        tooltipNode.node()?.appendChild(arrowElement.node(), tooltipNode.node().firstChild);
                    })
                    .on("mouseleave", () => {
                        tooltipNode.style("transform", `translatey(${isZoomed ? -125 : -5}%)`); // Reset position on leave
                    });
            }
        });
    }

    useEffect(() => {
        if (chartRef.current && data.length > 0) {
            renderChart();
        }
        // eslint-disable-next-line
    }, [data, xScale, rightYScale]);

    let classes = "graph-container uog-scatter-chart";

    if (isZoomed) {
        classes += " uog-scatter-chart--zoomed";
    }

    return (
        <div
            className={classes}
            style={{
                height: chartHeight,
                top: 0,
                left: -(donutChartWidth / 2),
                width: chartWidth - CHART_X_AXIS_START_MARGIN,
            }}
            ref={chartRef}
        ></div>
    );
};

export default ScatterChart;
