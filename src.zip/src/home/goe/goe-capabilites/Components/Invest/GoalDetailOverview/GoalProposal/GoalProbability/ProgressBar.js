import React from 'react'

const Progress_bar = ({ bgcolor, progress, height, leftSpan, rightSpan, isDecumulation = false, formatDollar }) => {
	const unFormaAmount = (formatterNUmber) => {
		console.log("formatterNUmber", formatterNUmber, "rightSpan", rightSpan, "leftSpan", leftSpan)
		if (typeof (formatterNUmber) != 'number') {
			const forNum = Number(formatterNUmber.replace(/[$,]/g, ""));

			return forNum
		}
		return formatterNUmber
	};
	progress = (unFormaAmount(leftSpan) / (unFormaAmount(rightSpan) + unFormaAmount(leftSpan)))
	const Parentdiv = {
		display: "flex",
		// height: height,
		// width: '100%',
		width: '499px',
		height: '27px',
		backgroundColor: 'whitesmoke',
		// borderRadius: 20,
		background: "#EAE2FF",
		borderRadius: "0px 4px 4px 0px",
		// justifyContent:'center'
		// margin: 50
	}

	const ParentdivProg = {
		width: `${499 - progress * 499}px`
	}



	const Childdiv = {
		display: "flex",
		height: '100%',
		width: `${progress.toFixed(2) * 100}%`,
		// backgroundColor: bgcolor,
		background: "linear-gradient(268.46deg, #AA8AFF 11.71%, #6CA2FF 161.75%)",
		borderRadius: 10,
		textAlign: 'right',
		justifyContent: 'center'
	}

	const ProgressBarWrapper = {
		position: 'relative',

	}

	const Amount = {
		position: 'absolute',
		top: '30px',
		left: `${(progress.toFixed(2) * 100) - 5}%`,
	}

	const progresstext = {
		padding: 10,
		color: 'black',
		fontWeight: 900
	}

	return (
		<div style={ProgressBarWrapper}>
			<div style={Parentdiv}>
				<div style={Childdiv}>
					<div className="my-goals-prob-recommendations-progress-span-left-div">
						{/* <span className="my-goals-prob-recommendations-progress-span-left">{formatDollar(leftSpan,true)}</span> */}
					</div>
				</div>
				<div className="my-goals-prob-recommendations-progress-span-right-div" style={ParentdivProg}>
					{/* <span className={isDecumulation ? "my-goals-prob-recommendations-progress-span-right span-right-div-chart-s3-red" :"my-goals-prob-recommendations-progress-span-right"}>{formatDollar(rightSpan)}</span> */}
				</div>
			</div>
			<span style={Amount}>{formatDollar(leftSpan, true)}</span>
		</div>
	)
}

export default Progress_bar;
