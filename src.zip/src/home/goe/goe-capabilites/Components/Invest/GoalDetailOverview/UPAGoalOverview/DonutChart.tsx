import * as d3 from "d3";
import { IChartData } from "home/goe/common/interfaces";

interface DonutChartProps {
    initialData: { equity: number; fixed_income: number };
    isZoomed?: boolean;
}

const createDonutChartSvg = ({ initialData, isZoomed = false }: DonutChartProps): SVGSVGElement | null => {
    const width = isZoomed ? 50 : 25;
    const height = isZoomed ? 50 : 25;

    const data: { label: string; value: number }[] = Object.keys(initialData).map((key) => {
        return { label: key, value: initialData[key] };
    });

    const svg = d3.create("svg").attr("width", width).attr("height", height);

    const radius = Math.min(width, height) / 2;
    const arc = d3
        .arc<IChartData>()
        .innerRadius(radius * 0.6)
        .outerRadius(radius * 0.8);

    const pie = d3
        .pie<IChartData>()
        .value((d) => d.value)
        .sort(null);

    const equityGradient = svg.append("defs").append("linearGradient").attr("id", "equityGradient");

    equityGradient.append("stop").attr("offset", "0%").attr("stop-color", "#00847D"); // deep green

    equityGradient.append("stop").attr("offset", "100%").attr("stop-color", "#67F5DC"); // light green

    const fixedIncomeGradient = svg.append("defs").append("linearGradient").attr("id", "fixedIncomeGradient");

    fixedIncomeGradient.append("stop").attr("offset", "0%").attr("stop-color", "#E15000"); // deep orange

    fixedIncomeGradient.append("stop").attr("offset", "100%").attr("stop-color", "#F2AE00"); // light orange

    const color = d3
        .scaleOrdinal<string>()
        .domain(data.map((_, i) => i.toString()))
        .range(["url(#fixedIncomeGradient)", "url(#equityGradient)"]);

    const chart = svg.append("g").attr("transform", `translate(${width / 2}, ${height / 2})`);

    const arcs = chart.selectAll("arc").data(pie(data)).enter().append("g").attr("class", "arc");

    arcs.append("path")
        .attr("d", arc)
        .attr("fill", (d, i) => color(i));

    return svg.node() as SVGSVGElement;
};

export default createDonutChartSvg;
