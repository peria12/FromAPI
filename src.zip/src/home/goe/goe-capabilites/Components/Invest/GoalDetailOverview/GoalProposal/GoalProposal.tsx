import React, { useState } from "react";
import GoalProbability from "./GoalProbability/GoalProbability";
import PortfolioComposition from "./PortfolioComposition/PortfolioComposition";
function GoalProposal(props: any) {
    const {
        addedGoalList,
        goalWealthReport,
        goalWealthReportConfig,
        goalDataPriority,
        getgoalLabels,
        formatDollar,
        findYears,
        setGoalWealthReport,
        basicInfo,
        digitFromator,
        setJourneyPath,
        setOverview,
        setActiveGoal,
        setGoalQuestionnaire,
        setGoalWealthReportData,
        setGoalWealthReportDataConfig,
        setApplyRecommendationFlag,
        applyRecommendationFlag,
        isUpa,
        goalUpaReport,
        goalUpaReportConfig,
        viewDetails,
        setViewDetails,
    } = props;

    return (
        <div>
            <div className="d-flex">
                <GoalProbability
                    goalWealthReportConfig={goalWealthReportConfig}
                    goalWealthReport={goalWealthReport}
                    isUpa={isUpa}
                    addedGoalList={addedGoalList}
                    goalDataPriority={goalDataPriority}
                    getgoalLabels={getgoalLabels}
                    formatDollar={formatDollar}
                    findYears={findYears}
                    setGoalWealthReport={setGoalWealthReport}
                    basicInfo={basicInfo}
                    digitFromator={digitFromator}
                    setJourneyPath={setJourneyPath}
                    setOverview={setOverview}
                    setActiveGoal={setActiveGoal}
                    setGoalQuestionnaire={setGoalQuestionnaire}
                    setGoalWealthReportData={setGoalWealthReportData}
                    setGoalWealthReportDataConfig={setGoalWealthReportDataConfig}
                    setApplyRecommendationFlag={setApplyRecommendationFlag}
                    applyRecommendationFlag={applyRecommendationFlag}
                    setViewDetails={setViewDetails}
                    viewDetails={viewDetails}
                />
                <PortfolioComposition
                    applyRecommendationFlag={applyRecommendationFlag}
                    goalWealthReport={isUpa ? goalUpaReport : goalWealthReport}
                    setApplyRecommendationFlag={setApplyRecommendationFlag}
                    setViewDetails={setViewDetails}
                    viewDetails={viewDetails}
                />
            </div>
        </div>
    );
}

export default GoalProposal;
