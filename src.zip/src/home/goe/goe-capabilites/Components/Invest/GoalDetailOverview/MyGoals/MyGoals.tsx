import React from "react";
import "./MyGoals.scss";
// import PlanRet from "../../../../assets/images/svg/my_goals/ret-disabled.svg";
import PlanRetDis from "../../../../assets/images/svg/goals_icons/plan_retirement_dis.svg";
import PlanRet from "../../../../assets/images/svg/goals_icons/plan_retirement.svg";
import DrawIncomeDis from "../../../../assets/images/svg/goals_icons/draw_income_dis.svg";
import DrawIncome from "../../../../assets/images/svg/goals_icons/draw_income.svg";
import BuyCarDis from "../../../../assets/images/svg/goals_icons/buy_car_dis.svg";
import BuyCar from "../../../../assets/images/svg/goals_icons/buy_car.svg";
import OwnHouseDis from "../../../../assets/images/svg/goals_icons/own_house_dis.svg";
import OwnHouse from "../../../../assets/images/svg/goals_icons/own_house.svg";
import SaveCollegeDis from "../../../../assets/images/svg/goals_icons/save_college_dis.svg";
import SaveCollege from "../../../../assets/images/svg/goals_icons/save_college.svg";
import TakeVacation from "../../../../assets/images/svg/goals_icons/take_vacation.svg";
import TakeVacationDis from "../../../../assets/images/svg/goals_icons/take_vacation_dis.svg";
import CustomGoal from "../../../../assets/images/svg/goals_icons/custom_goal.svg";
import CustomGoaldis from "../../../../assets/images/svg/goals_icons/custom_goal_dis.svg";

function MyGoals(props: any) {
    // const titleName = "What is a goal priority? ";
    const goalList = props.addedGoalList || [];
    const goalKey = props.goalKey;
    console.log("goalKey123", goalKey);
    const MapIcon = (goal_key_name, goal_key) => {
        if (goal_key_name === "plan_retirement") {
            return goal_key === goalKey ? PlanRet : PlanRetDis;
        } else if (goal_key_name === "buy_car") {
            return goal_key === goalKey ? BuyCar : BuyCarDis;
        } else if (goal_key_name === "own_house") {
            return goal_key === goalKey ? OwnHouse : OwnHouseDis;
        } else if (goal_key_name === "save_collage") {
            return goal_key === goalKey ? SaveCollege : SaveCollegeDis;
        } else if (goal_key_name === "draw_income") {
            return goal_key === goalKey ? DrawIncome : DrawIncomeDis;
        } else if (goal_key_name === "take_vacation") {
            return goal_key === goalKey ? TakeVacation : TakeVacationDis;
        } else if (goal_key_name === "custom_goal") {
            //need to modify in future
            return goal_key === goalKey ? CustomGoal : CustomGoaldis;
        }
    };

    // console.log("goal_key_name",goal_key_name)
    return (
        <div className="my-goals-main-div">
            <div className="my-goals-left-div">
                <span>My Goals ({goalList.length})</span>
                <div
                    className="my-goals-button-see-overview"
                    onClick={() => {
                        props.setSeeOverviewFlag(!props.seeOverviewFlag);
                    }}
                >
                    <span className="my-goals-button-see-overview-span">
                        {props.seeOverviewFlag ? "See Overview" : "Back"}
                    </span>
                </div>
            </div>
            <div className="my-goals-scroller">
                {props.goalPrioritys.map((goalPriority) => {
                    const priorityGoals =
                        goalList.filter((goal) => {
                            return goal["goal_priority"] === goalPriority;
                        }) || [];
                    return (
                        priorityGoals.length > 0 && (
                            <div className="my-goals-scroller-div">
                                <div className="my-goals-border-gradient-green">
                                    <span className="my-goals-scroller-span">{goalPriority}</span>
                                </div>
                                <div className="my-goals-div-span-parent">
                                    {priorityGoals.map((goalItem: any, index) => {
                                        return (
                                            <div
                                                onClick={
                                                    props.isUpa || !props.seeOverviewFlag
                                                        ? () => false
                                                        : () => {
                                                              props.setGoalData(goalItem["goal-key"]);
                                                          }
                                                }
                                                key={goalItem.name + index}
                                                className={
                                                    props.isUpa || !props.seeOverviewFlag
                                                        ? "my-goal my-goal--disabled"
                                                        : goalKey === goalItem["goal-key"]
                                                        ? "my-goal my-goal--selected"
                                                        : "my-goal my-goal--disable"
                                                }
                                            >
                                                <img
                                                    className="my-goals-div-span-img"
                                                    src={
                                                        props.isUpa || !props.seeOverviewFlag
                                                            ? MapIcon(goalItem["goal_key"], "")
                                                            : MapIcon(goalItem["goal_key"], goalItem["goal-key"])
                                                    }
                                                />
                                                <span className="my-goals-div-span-span">{goalItem.name}</span>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        )
                    );
                })}
            </div>
            {/* {
       goalList.length>0 && goalData[0]['name']
      } */}
        </div>
    );
}

export default MyGoals;
