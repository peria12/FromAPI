import React, { useEffect, useContext } from "react";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import { GoeCapabilitiesContext } from "../../GoeCapabilitiesContext";
import "./Header.scss";
// import FtIcon from "../../assets/images/svg/ft_icon.svg";
import GoeIcon from "../../assets/images/svg/goe_icon.svg";
function Header(props: any) {
    const history = useHistory();
    const routeFunc = (path: string) => {
        props.setRoutingPath(path);
    };
    const { zoneId } = useContext(GoeCapabilitiesContext);
    useEffect(() => {
        if (props.path) {
            history.push({ pathname: `/goe-capabilities/${zoneId}` + "/" + props.path });
        }
    }, [props.path, history, zoneId]);
    return (
        <Navbar bg="#FFFFFF" expand="lg">
            <Container className="header_div">
                <div>
                    <Navbar.Brand href="#home">
                        <Link to="/">
                            {/* <img src={FtIcon} alt="franklin logo icon" /> */}
                            <img src={GoeIcon} alt="" />
                        </Link>
                        {/* <img src ="assets/images/goe_icon.svg" alt="" /> */}
                    </Navbar.Brand>
                </div>
                <div>
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-auto ">
                            <Nav.Link
                                className={props.path === "about" ? "Navbar_text_active" : "Navbar_text"}
                                onClick={() => routeFunc("about")}
                            >
                                About
                            </Nav.Link>
                            <Nav.Link
                                className={props.path === "invest" ? "Navbar_text_active" : "Navbar_text"}
                                onClick={() => routeFunc("invest")}
                            >
                                Invest
                            </Nav.Link>
                            <Nav.Link
                                className={props.path === "backtest" ? "Navbar_text_active" : "Navbar_text"}
                                onClick={() => routeFunc("backtest")}
                            >
                                Backtest
                            </Nav.Link>
                            <Nav.Link
                                className={
                                    props.path === "financialplanningtools" ? "Navbar_text_active" : "Navbar_text"
                                }
                                onClick={() => routeFunc("financialplanningtools")}
                            >
                                Financial Planning Tools
                            </Nav.Link>
                            <Nav.Link
                                className={props.path === "goeconfig" ? "Navbar_text_active" : "Navbar_text"}
                                onClick={() => routeFunc("goeconfig")}
                            >
                                GOE configuration
                            </Nav.Link>
                        </Nav>
                    </Navbar.Collapse>
                </div>
            </Container>
        </Navbar>
    );
}

export default Header;
