import React from "react";
import "./Features.scss";
import ProbabilityDriveImage from "../assets/images/svg/Probability.svg";
import PersonalisedImage from "../assets/images/svg/Personalised.svg";
import ResponsiveImage from "../assets/images/svg/Responsive.svg";

function Features() {
    interface ListData {
        id: number;
        title: string;
        content: string;
        image: string;
        alt: string;
    }

    const FEATURES: ListData[] = [
        {
            id: 1,
            title: "Probability Driven",
            content: "Probability of goal success drives the portfolio advice",
            image: ProbabilityDriveImage,
            alt: "Probability Driven",
        },
        {
            id: 2,
            title: "Personalised",
            content:
                "An initial asset allocation and a unique investment path based on individual goal parameters and capital market expectations",
            image: PersonalisedImage,
            alt: "Personalised",
        },
        {
            id: 3,
            title: "Responsive",
            content:
                "The portfolio advice is adjusted periodically in response to market performance, capital market expectation and goal proximity",
            image: ResponsiveImage,
            alt: "Responsive",
        },
    ];

    return (
        <div className="landing-components">
            <div className="feature-heading">
                <span className="components-heading-content">Features of&nbsp;</span>
                <span className="components-heading-content components-heading-content-blue"> GOE</span>
            </div>
            <div className="feature-main-div">
                {FEATURES.map((item) => {
                    return (
                        <div key={item.id} className="feature-inner-div">
                            <img src={item.image} alt={item.alt} />
                            <span className="feature-title">{item.title}</span>
                            <span className="feature-content">{item.content}</span>
                        </div>
                    );
                })}
            </div>
        </div>
    );
}

export default Features;
