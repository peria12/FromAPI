import React, { useEffect, useState } from "react";
import { Switch, Route, Link, useLocation } from "react-router-dom";
import { Button } from "@mui/material";
import Table from "common/Table";
import { goePortfolioUpdateNotification } from "utils/events";
import { useScreenshot } from "utils/helpers";

import Api from "utils/api";
import CreatePortfolio from "./CreatePortfolio";
import moment from "moment";
import Access from "utils/access";
const DATE_FORMAT = "YYYY-MM-DD HH:mm:ss";
import AppCover from "home/dashboad/AppCover";

const getName = ({ cell }) => <Link to={`/goe/portfolios/${cell.row.original.id}`}> {cell.value} </Link>;
const NewPortfolio = () => {
    const [isAdmin] = useState<any>(Access.hasAccessToZone("goe", "portfolios", ["admin"]));
    return (
        <Button
            component={Link}
            to="/goe/portfolios/create"
            className="no-hover-link"
            color="primary"
            variant="contained"
            disabled={!isAdmin}
        >
            Create New Portfolio
        </Button>
    );
};

export default function Portfolios() {
    const columns = [
        { Header: "Name", Cell: getName, width: "col-2", accessor: "name" },
        { Header: "Portfolio Origin", accessor: "is_ft", width: "col-1" },
        { Header: "Distribution Channel", accessor: "distributionChannel", width: "col-2" },
        { Header: "Region", accessor: "region", width: "col-1" },
        { Header: "Segment", accessor: "segment", width: "col-2" },
        { Header: "Portfolio Status", accessor: "status", width: "col-1" },
        { Header: "Created Date", accessor: "created_date", width: "col-2" },
        { Header: "Created By", accessor: "created_by", width: "col-1" },
    ];
    const [rows, setRows] = useState<any>(null);
    const [draft, setDraft] = useState<any>({});
    const location = useLocation();
    const screenshot = useScreenshot();

    useEffect(() => {
        refresh();
        const sub = goePortfolioUpdateNotification.subscribe(refresh);
        return () => {
            sub.unsubscribe();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    function refresh() {
        const call1 = Api.getGoePortfolioBundles({ take: 50000, skip: 0 }).then((resp) => {
            return resp?.data?.map((x) => ({
                id: x.id,
                name: x.name,
                is_ft: x.isFtPortfolio ? "FT" : "Non FT",
                distributionChannel: `${x.country?.name}_${x.segment?.name}`,
                region: x.country?.name,
                segment: x.segment?.name,
                status: x.portfolio_status || "Active",
                created_by: x.createdBy?.name,
                created_date: x.createdAt ? moment(x.createdAt).format(DATE_FORMAT) : "",
                orig: x,
            }));
        });

        const call2 = Api.getGoeLatestDraft().then((resp) => {
            setDraft(resp?.data || {});
            const p = resp?.data?.portfolio;
            const id = resp?.userId;
            if (p && Object.keys(p).length > 0) {
                return [
                    {
                        id: id,
                        name: p.name,
                        region: p.country,
                        segment: p.segment,
                        is_ft: p.isFtPortfolio ? "FT" : "Non FT",
                        status: "Draft",
                        distributionChannel: `${p.country || ""}_${p.segment || ""}`,
                        created_by: p.createdBy?.name,
                        created_date: p.createdAt ? moment(p.createdAt).format(DATE_FORMAT) : "",
                        orig: { ...p, id },
                    },
                ];
            }

            return [];
        });

        Promise.all([call1, call2]).then((resps) => {
            setRows(resps.filter((x) => x).flat());
            screenshot.take();
        });
    }

    return (
        <AppCover>
            <Switch>
                <Route
                    path="/goe/portfolios/:id"
                    render={(props) => <CreatePortfolio {...props} data={rows} draft={draft} />}
                />
            </Switch>
            <div
                className={
                    location.pathname == "/goe/portfolios" || location.pathname == "/goe/portfolios/" ? "" : "d-none"
                }
            >
                <div className="portfolio-table">
                    <Table columns={columns} data={rows || []} loading={!rows} start_widgets={NewPortfolio()}></Table>
                </div>
            </div>
        </AppCover>
    );
}
