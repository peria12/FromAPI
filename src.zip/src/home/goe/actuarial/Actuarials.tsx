    import React, { useEffect, useState } from "react";
import { Switch, Route, Link, useLocation } from "react-router-dom";
import { Button } from "@mui/material";
import Table from "common/Table";

import Api from "utils/api";
import moment from "moment";
import CreateActuarial from "./CreateActuarial";
import { goeActuarialUpdateNotification } from "utils/events";
import { useScreenshot } from "utils/helpers";
import Access from "utils/access";
import AppCover from "home/dashboad/AppCover";

const DATE_FORMAT = "YYYY-MM-DD HH:mm:ss";

const getName = ({ cell }) => <Link to={`/goe/actuarials/${cell.row.original.id}`}> {cell.value} </Link>;
const NewActuarials = () => {
    const [isAdmin] = useState<any>(Access.hasAccessToZone("goe", "actuarials", ["admin"]));
    return (
        <Button
            component={Link}
            className="no-hover-link"
            to="/goe/actuarials/create"
            color="primary"
            variant="contained"
            disabled={!isAdmin}
        >
            Create New Data Table
        </Button>
    );
};

export default function Actuarials() {
    const columns = [
        { Header: "Data Table Name", Cell: getName, width: "col-2", accessor: "name" },
        { Header: "Type", accessor: "type", width: "col-2" },
        { Header: "Region", accessor: "region", width: "col-1" },
        { Header: "Segment", accessor: "segment", width: "col-2" },
        { Header: "Channel Name", accessor: "channel", width: "col-2" },
        { Header: "Created Date", accessor: "created_date", width: "col-2" },
        { Header: "Created By", accessor: "created_by", width: "col-1" },
    ];
    const [rows, setRows] = useState<any>(null);
    const location = useLocation();

    const screenshot = useScreenshot();

    const refresh = () => {
        Api.getGoeActuarials({ take: 50000, skip: 0 }).then((resp) => {
            const rows = resp?.data?.map((x) => ({
                id: x.id,
                name: x.name,
                type: x.type?.name,
                region: x.country?.name,
                segment: x.segment?.name,
                channel: `${x.country?.name}_${x.segment?.name}`,
                created_by: x.createdBy?.name,
                created_date: moment(x.createdAt).format(DATE_FORMAT),
                orig: x,
            }));

            setRows(rows || []);
            screenshot.take();
        });
    };

    useEffect(() => {
        refresh();
        const sub = goeActuarialUpdateNotification.subscribe(refresh);
        return () => {
            sub.unsubscribe();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <AppCover>
            <Switch>
                <Route path="/goe/actuarials/:id" render={(props) => <CreateActuarial {...props} data={rows} />} />
            </Switch>
            <div
                className={
                    location.pathname == "/goe/actuarials" || location.pathname == "/goe/actuarials/" ? "" : "d-none"
                }
            >
                <div className="actuarial-table">
                    <Table columns={columns} data={rows || []} loading={!rows} start_widgets={NewActuarials()}></Table>
                </div>
            </div>
        </AppCover>
    );
}
