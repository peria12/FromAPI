const formatKeyToCamel = (key) => {
    switch (key) {
        case "VeryConservative":
            return "veryConservativeRiskProfiles";
        case "Conservative":
            return "conservativeRiskProfiles";
        case "ConservativelyModerate":
            return "conservativelyModerateRiskProfiles";
        case "Moderate":
            return "moderateRiskProfiles";
        case "ModeratelyAggressive":
            return "moderatelyAggressiveRiskProfiles";
        case "Aggressive":
            return "aggressiveRiskProfiles";
        case "VeryAggressive":
            return "veryAggressiveRiskProfiles";
        default:
            return "Default";
    }
};

const extractDisplayablePortfolioConfig = (rawPortfolioConfig, key, actualPortfoliosNumbers) => {
    const configNumbers: any = [];
    for (const key in actualPortfoliosNumbers) {
        configNumbers.push(actualPortfoliosNumbers[key]);
    }
    const uniq = [...configNumbers.sort((a, b) => a - b)];
    const uniqueArray: any = uniq.filter(function (item, pos) {
        return uniq.indexOf(item) === pos;
    });

    return uniqueArray.indexOf(key);
};

export function get(object, path, value?: any) {
    const pathArray = Array.isArray(path) ? path : path.split(".").filter((key) => key);
    const pathArrayFlat = pathArray.flatMap((part) => (typeof part === "string" ? part.split(".") : part));
    const checkValue = pathArrayFlat.reduce((obj, key) => obj && obj[key], object);
    return checkValue === undefined ? value : checkValue;
}

const mapPortfolioRiskLabels = (portfolioConfig, labels) => {
    const portfolioConfigClone = { ...portfolioConfig };
    const labelsClone = {};
    for (const key in labels) {
        labelsClone[formatKeyToCamel(labels[key])] = key;
    }
    for (const key in portfolioConfig) {
        if (Object.keys(labelsClone).includes(key)) {
            portfolioConfigClone[key].labelValue = labelsClone[key];
        }
    }
    return portfolioConfigClone;
};

export const ActuarialTypes: any = [
    { key: "Mortality", value: "Mortality" },
    { key: "LifeExpectancy", value: "LifeExpectancy" },
    { key: "AgeBasedGlidePath", value: "AgeBasedGlidePath" },
    { key: "BendPoints", value: "Bend Points" },
    {
        key: "BenefitsAcrossRetirementAges",
        value: "Benefits Across Retirement Ages",
    },
    { key: "BenefitBase", value: "Benefit Base" },
    { key: "CostOfLivingAdjustment", value: "CostOfLivingAdjustment" },
    { key: "DelayedRetirementCredit", value: "DelayedRetirementCredit" },
    { key: "IndexFactor", value: "Index Factor" },
    { key: "MortalityGenericMale", value: "MortalityGenericMale" },
    { key: "MortalityGenericFemale", value: "MortalityGenericFemale" },
    { key: "MortalityByLifestyle", value: "MortalityByLifestyle" },
    { key: "FullRetirementAge", value: "FullRetirementAge" },
    {
        key: "PortfolioMapAggRetirementAccounts-H",
        value: "PortfolioMapAggRetirementAccounts-H",
    },
    { key: "TaxBracket", value: "TaxBracket" },
    { key: "RIConfigParam", value: "RIConfigParam" },
    // { key: "LYTargetAllocations", value: "LY Target Allocations" },
    // { key: "LYCMEPackage", value: "LY CME Package" },
    { key: "FixedDiscretionary", value: "Fixed Discretionary" },
    { key: "AgeBasedEquityCap", value: "AgeBasedEquityCap" },
    { key: "DecumulationLookUp", value: "DecumulationLookUp" },
    { key: "FTLongTermCME", value: "FTLongTermCME" },
    { key: "HistoricalIndexList", value: "HistoricalIndexList" },
];

export const taxDataTableTypes: any = [
    { key: "LYTargetAllocations", value: "LYTargetAllocations" },
    { key: "LYCMEPackage", value: "LYCMEPackage" },
];
export const defaultPortfolioConfig: any = {
    defaultRiskProfiles: {},
    conservativeRiskProfiles: {},
    veryConservativeRiskProfiles: {},
    moderateRiskProfiles: {},
    conservativelyModerateRiskProfiles: {},
    moderatelyAggressiveRiskProfiles: {},
    aggressiveRiskProfiles: {},
    veryAggressiveRiskProfiles: {},
};

const AgeRange = (start, end) => {
    const values = Array(end + 1 - start)
        .fill(1)
        .map((_, index) => {
            const age = index + start;
            return { key: age, value: age };
        });
    return values;
};

export const editModeButtons: any = [
    {
        id: "stop_edit",
        label: "Stop Edit",
        color: "secondary",
        adminOnly: true,
    },
    {
        id: "reset_password",
        label: "Reset Password",
        color: "secondary",
        adminOnly: true,
    },
    {
        id: "download",
        label: "Download",
        adminOnly: true,
    },
    {
        id: "continue",
        label: "Continue",
        isLoaderRequired: true,
    },
];

export const createModeButtons: any = [
    {
        id: "save_draft",
        label: "Save Draft",
        adminOnly: true,
    },
    {
        id: "continue",
        label: "Continue",
        isLoaderRequired: true,
    },
];

export const viewModeButtons: any = [
    {
        id: "edit",
        label: "Edit",
        adminOnly: true,
    },
    {
        id: "reset_password",
        label: "Reset Password",
        color: "secondary",
        adminOnly: true,
    },
    {
        id: "download",
        label: "Download",
        adminOnly: true,
    },
    {
        id: "continue",
        label: "Continue",
        isLoaderRequired: true,
    },
];

export const tabs = [
    {
        id: "client_profile",
        label: "Client Profile",
        tab_id: 1,
    },
    {
        id: "portfolio_configuration",
        label: "Portfolio",
        tab_id: 2,
    },
    {
        id: "configuration",
        label: "Configuration",
        tab_id: 3,
    },
    {
        id: "retirement",
        label: "Retirement",
        tab_id: 4,
    },
    {
        id: "tax",
        label: "Tax",
        tab_id: 5,
    },
    {
        id: "upa",
        label: "UPA",
        tab_id: 6,
    },
];

const customSwitchConfig = {
    on: "YES",
    off: "NO",
};
const probabilityThresholdLevels = [
    {
        key: "min_probability",
        name: "min_probability",
        required: false,
        display: true,
    },
    {
        key: "max_probability",
        name: "max_probability",
        required: false,
        display: true,
    },
    {
        key: "threshold",
        name: "threshold",
        required: false,
        display: true,
    },
];

export const clientFormConfig = {
    client_profile: [
        {
            label: "Client Profile",
            type: "heading",
            key: "client_Profile",
        },
        {
            label: "Email",
            name: "email",
            type: "email",
            key: "email",
            pattern: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
            required: true,
        },
        {
            label: "Country",
            name: "country",
            type: "select",
            key: "country",
            stateKey: "countries",
            required: true,
        },
        {
            label: "Segment",
            name: "segment",
            type: "select",
            key: "segment",
            stateKey: "segments",
            required: true,
        },
        {
            label: "Using FT Portfolio",
            name: "using_ft_portfolio",
            type: "switch",
            // defaultValue: true,
            skipRequired: true,
            states: { on: "FT", off: "Non FT" },
            wider: true,
            key: "using_ft_portfolio",
            id: "using_ft_portfolio",
        },
        {
            label: "Portfolio Selection",
            name: "portfolio_selection",
            type: "select",
            key: "portfolio_selection",
            stateKey: "portfolios",
            // display: false,
            skipRequired: true,
        },
        {
            label: "Portfolio Description",
            name: "portfolio_description",
            type: "text",
            disabled: true,
            key: "portfolio_description",
            stateKey: "portfolio_description",
            skipRequired: true,
        },
        {
            label: "Customer Name",
            name: "customer_name",
            type: "text",
            key: "customer_name",
            required: true,
            maxLength: 60,
        },
        {
            label: "Contact ID",
            name: "contact_id",
            type: "text",
            required: true,
            key: "contact_id",
            maxLength: 20,
        },
        {
            label: "Contact Name",
            name: "contact_name",
            type: "text",
            required: true,
            key: "contact_name",
            maxLength: 60,
        },
        {
            label: "Contact Phone Number",
            name: "contact_phone_number",
            type: "text",
            maxLength: 20,
            required: true,
            key: "contact_phone_number",
            // eslint-disable-next-line no-useless-escape
        },
        {
            label: "Notes",
            name: "notes",
            type: "text",
            required: true,
            key: "notes",
            maxLength: 50,
        },
    ],
    portfolio_configuration: [
        {
            label: "Portfolio Configuration",
            type: "heading",
            key: "portfolio_configuration",
        },
        {
            label: "Distribution Channel",
            name: "distribution_channel",
            type: "select",
            key: "distribution_channel",
            stateKey: "channels",
            states: [
                { key: "US_DEFAULT", label: "US_DEFAULT" },
                { key: "US_RIA", label: "US_RIA" },
                { key: "US_INSTITUTIONAL", label: "US_INSTITUTIONAL" },
                { key: "CANADA_DEFAULT", label: "CANADA_DEFAULT" },
                { key: "CANADA_HNW", label: "CANADA_HNW" },
            ],
            disabled: true,
            required: true,
        },
        {
            label: "What portfolios do different Client Risk Profiles have access to",
            type: "subheading",
            key: "what_portfolios_do_different_client_risk_profiles_have_access_to",
        },
        {
            label: "Levels of risk profile",
            name: "risk_level",
            variant: "h4",
            type: "radio",
            color: "primary",
            key: "risk_level",
            states: [
                { key: "1", label: "1", disabled: false },
                { key: "3", label: "3", disabled: false },
                { key: "5", label: "5", disabled: false },
                { key: "7", label: "7", disabled: false },
            ],
            required: true,
        },
        {
            name: "portfolioConfig",
            type: "range-select-group",
            key: "portfolioConfig",
            config: [
                {
                    label: "Very Conservative Risk Profile",
                    objectKey: "veryConservativeRiskProfiles",
                    master: false,
                    levels: ["7"],
                    customLabel: true,
                    enableLowerLimit: true,
                },
                {
                    label: "Conservative Risk Profile",
                    objectKey: "conservativeRiskProfiles",
                    master: false,
                    levels: ["3", "5", "7"],
                    customLabel: true,
                    enableLowerLimit: true,
                },
                {
                    label: "Conservatively Moderate Risk Profile",
                    objectKey: "conservativelyModerateRiskProfiles",
                    master: false,
                    levels: ["5", "7"],
                    customLabel: true,
                    enableLowerLimit: true,
                },
                {
                    label: "MODERATE Risk Profile",
                    objectKey: "moderateRiskProfiles",
                    master: false,
                    levels: ["3", "5", "7"],
                    customLabel: true,
                    enableLowerLimit: true,
                },
                {
                    label: "MODERATELY Aggressive Risk Profile",
                    objectKey: "moderatelyAggressiveRiskProfiles",
                    master: false,
                    levels: ["5", "7"],
                    customLabel: true,
                    enableLowerLimit: true,
                },
                {
                    label: "AGGRESSIVE Risk Profile",
                    objectKey: "aggressiveRiskProfiles",
                    master: false,
                    levels: ["3", "5", "7"],
                    customLabel: true,
                    enableLowerLimit: true,
                },
                {
                    label: "Very AGGRESSIVE Risk Profile",
                    objectKey: "veryAggressiveRiskProfiles",
                    master: false,
                    levels: ["7"],
                    customLabel: true,
                    enableLowerLimit: true,
                },
                {
                    label: "One Risk Profile",
                    objectKey: "defaultRiskProfiles",
                    master: true,
                    levels: ["1"],
                    customLabel: true,
                    disabledLabel: true,
                    enableLowerLimit: true,
                },
                {
                    label: "Portfolio for Short Term Retail Goals",
                    objectKey: "shortTermGoalProfiles",
                    master: true,
                    levels: ["1", "3", "5", "7"],
                    enableLowerLimit: true,
                },
            ],
            max: 16,
            min: 1,
        },
        {
            label: "GOAL TENURE FOR SHORT TERM RETAIL GOALS UPTO(IN YEARS)",
            name: "tenure_years",
            type: "number",
            required: true,
            key: "tenure_years",
            max: 100,
            min: 1,
        },
        {
            name: "decumulationProfile",
            type: "range-select-group",
            key: "decumulationProfile",
            config: [
                {
                    label: "Portfolios for Decumulation Period",
                    objectKey: "decumulationScenarioProfiles",
                    master: true,
                    display: true,
                    enableLowerLimit: true,
                },
            ],
            max: 16,
            min: 1,
        },
        {
            label: "Risk Overlay",
            name: "riskOverlay",
            type: "switch",
            required: true,
            states: customSwitchConfig,
            key: "riskOverlay",
        },
        {
            label: "",
            name: "risk_indicator_flag_value",
            type: "range-text",
            required: true,
            text: true,
            key: "risk_indicator_flag_value",
            defaultValue: { lower: "0.4", upper: "0.5" },
            bottomText: "Enter value from 0.01 - 0.99",
            max: 0.99,
            min: 0.01,
        },
        {
            label: "Portfolio List",
            type: "subheading",
            key: "portfolio_list_label",
        },
    ],
    configuration: [
        {
            label: "Select Configuration",
            name: "select_configuration",
            variant: "h4",
            type: "radio",
            color: "primary",
            key: "select_configuration",
            states: [
                { key: "Configuration1", value: "Configuration 1", disabled: false },
                { key: "Configuration2", value: "Configuration 2", disabled: false },
                { key: "Configuration3", value: "Configuration 3", disabled: false },
            ],
            required: true,
        },
        {
            label: "Allocation Configuration",
            type: "heading",
            key: "allocation_configuration",
        },
        {
            label: "Reallocation Frequency",
            name: "reallocationFrequency",
            variant: "h4",
            type: "radio",
            color: "primary",
            key: "reallocationFrequency",
            states: [
                { key: "yearly", value: "Yearly", disabled: false },
                { key: "half-yearly", value: "Half Yearly", disabled: false },
                { key: "quarterly", value: "Quarterly", disabled: false },
            ],
            required: true,
        },
        {
            name: "reallocation_frequency_dates",
            type: "date-group",
            key: "reallocation_frequency_dates",
            isInt: true,
            required: true,
            labels: ["Reallocation Frequency", "Reallocation Date"],
            radioProps: {
                color: "primary",
                key: "reallocation_frequency",
            },
            states: [
                { key: 1, value: "one", disabled: false },
                { key: 2, value: "Two", disabled: false },
                { key: 4, value: "Four", disabled: false },
            ],
            dateProps: {
                key: "reallocation_dates",
            },
        },
        {
            label: "When Do You Want Reallocation To Happen",
            type: "subheading",
            key: "when_do_you_want_reallocation_to_happen",
        },
        {
            label: "WHEN THE USER RE-TAKES THE RTQ",
            name: "allocation_on_retake_rtq",
            type: "switch",
            states: customSwitchConfig,
            key: "allocation_on_retake_rtq",
            required: true,
        },
        {
            label: "When the user changes the Investment Tenure",
            name: "allocation_on_invest_tenure_change",
            type: "switch",
            states: customSwitchConfig,
            key: "allocation_on_invest_tenure_change",
            required: true,
        },
        {
            label: "When the user re-prioritizes a goal",
            name: "allocation_on_re_prioritizing_goal",
            type: "switch",
            states: customSwitchConfig,
            key: "allocation_on_re_prioritizing_goal",
            required: true,
        },
        {
            label: "When Risk Indicator Flashes",
            name: "when_risk_indicator_flashes",
            type: "switch",
            states: customSwitchConfig,
            key: "when_risk_indicator_flashes",
            required: true,
        },
        {
            label: "When the user changes the goal",
            name: "new_goal",
            type: "switch",
            states: customSwitchConfig,
            key: "new_goal",
            required: true,
        },
        {
            label: "When the client wants to reallocate",
            name: "wantsToReallocate",
            type: "switch",
            states: customSwitchConfig,
            key: "wantsToReallocate",
            required: true,
        },
        {
            label: "Goal Priority",
            type: "heading",
            key: "goal_priority",
        },
        {
            label: "LEVEL OF GOAL PRIORITY SETTINGS",
            type: "subheading",
            key: "level_of_goal_priority_settings",
        },
        {
            label: "LEVELS OF GOAL PRIORITY",
            name: "select_goal_level",
            variant: "h4",
            type: "radio",
            color: "primary",
            key: "select_goal_level",
            states: [
                { key: "1", value: "1", disabled: false },
                { key: "2", value: "2", disabled: false },
                { key: "3", value: "3", disabled: false },
                { key: "4", value: "4", disabled: false },
                { key: "5", value: "5", disabled: false },
            ],
            required: true,
        },
        {
            type: "field-group",
            name: "goal_priority_level_and_loss_threshold_values",
            elements: [
                {
                    label: "",
                    name: "levelsOfGoalPriority",
                    type: "slider-group-with-label",
                    key: "levelsOfGoalPriority",
                    config: [
                        {
                            id: 1,
                            levels: ["1", "2", "3", "4", "5"],
                        },
                        {
                            id: 2,
                            levels: ["2", "3", "4", "5"],
                        },
                        {
                            id: 3,
                            levels: ["3", "4", "5"],
                        },
                        {
                            id: 4,
                            levels: ["4", "5"],
                        },
                        {
                            id: 5,
                            levels: ["5"],
                        },
                    ],
                },
                // {
                //     label: "LOSS THRESHOLD VALUES",
                //     type: "subheading",
                //     key: "loss_threshold_value_label",
                //     name: "loss_threshold_value_label",
                //     display: false,
                //     indent: true,
                // },
                {
                    name: "loss_threshold_values",
                    key: "loss_threshold_values",
                    type: "range-input-group",
                    display: false,
                    config: [
                        {
                            accessKey: "accumulation",
                            heading: "Accumulation",
                            inputs: [
                                {
                                    id: 1,
                                    key: "need",
                                    label: "NEED",
                                    percent: true,
                                },
                                {
                                    id: 2,
                                    key: "want",
                                    label: "WANT",
                                    percent: true,
                                },
                                {
                                    id: 3,
                                    key: "wish",
                                    label: "WISH",
                                    percent: true,
                                },
                                {
                                    id: 4,
                                    key: "dream",
                                    label: "DREAM",
                                    percent: true,
                                },
                                {
                                    id: 5,
                                    key: "desire",
                                    label: "DESIRE",
                                    percent: true,
                                },
                            ],
                        },
                        {
                            accessKey: "decumulation",
                            heading: "Decumulation",
                            inputs: [
                                {
                                    id: 1,
                                    key: "need",
                                    label: "NEED",
                                    percent: true,
                                },
                                {
                                    id: 2,
                                    key: "want",
                                    label: "WANT",
                                    bottomText: " ",
                                    bottomTextContainer: true,
                                    percent: true,
                                },
                                {
                                    id: 3,
                                    key: "wish",
                                    label: "WISH",
                                    percent: true,
                                },
                                {
                                    id: 4,
                                    key: "dream",
                                    label: "DREAM",
                                    percent: true,
                                },
                                {
                                    id: 5,
                                    key: "desire",
                                    label: "DESIRE",
                                    percent: true,
                                },
                            ],
                        },
                    ],
                },
            ],
        },
        {
            label: "DOWNSIDE PROTECTION",
            type: "subheading",
            key: "downside_protection_title",
        },
        {
            label: "LOSS THRESHOLD FLOOR",
            name: "loss_threshold_floor",
            type: "switch",
            states: customSwitchConfig,
            key: "loss_threshold_floor",
            required: true,
        },
        {
            label: "Loss Threshold Probability",
            name: "loss_threshold_probability",
            type: "percent",
            key: "loss_threshold_probability",
            display: false,
        },
        {
            label: "DownSide Protection Overlay",
            name: "downside_protection",
            type: "radio",
            color: "primary",
            key: "downside_protection",
            // indent: true,
            states: [
                {
                    key: "Maximize Goal Probability",
                    value: "Maximize Goal Probability",
                    disabled: false,
                },
                {
                    key: "Maximize Loss Threshold Probability",
                    value: "Maximize Loss Threshold Probability",
                    disabled: false,
                },
            ],
            required: true,
        },
        {
            label: "DE-RISK",
            type: "subheading",
            key: "derisk",
        },
        {
            label: "Safe-guard achieved wealth in last year ",
            name: "safe_guard_wealth_last_year",
            type: "switch",
            states: customSwitchConfig,
            key: "safe_guard_wealth_last_year",
            required: true,
        },
        {
            label: "Minimum portfolios for last year",
            name: "minimum_portfolios_for_last_year",
            type: "number",
            key: "minimum_portfolios_for_last_year",
            required: true,
            min: 0,
        },
        {
            label: "RECOMMENDATIONS",
            type: "subheading",
            key: "recommendations",
        },
        {
            label: "RECOMMEND TENURE",
            name: "recommended_tenure",
            type: "switch",
            states: customSwitchConfig,
            key: "recommended_tenure",
            required: true,
        },
        {
            label: "RECOMMEND Top Up Infusion",
            name: "recommended_top_up_infusion",
            type: "switch",
            states: customSwitchConfig,
            key: "recommended_top_up_infusion",
            required: true,
        },
        {
            label: "Recommend Escalated Goal",
            name: "recommend_escalated_goal",
            type: "switch",
            states: customSwitchConfig,
            key: "recommend_escalated_goal",
            required: true,
        },
        {
            label: "GENERAL SETTINGS",
            type: "subheading",
            key: "general_settings",
        },
        {
            label: "What probability would you consider as unrealistic",
            name: "goal_unrealistic",
            type: "slider-group",
            note: "",
            key: "goal_unrealistic",
            required: true,
        },
        {
            label: "SWING CONSTRAINT",
            name: "swing_constraint",
            type: "switch",
            states: customSwitchConfig,
            key: "swing_constraint",
            required: true,
        },
        {
            label: "SWING CONSTRAINT NUMBER",
            name: "swing_constraint_number",
            type: "select",
            key: "swing_constraint_number",
            stateKey: "swingConstraintNumber",
            required: true,
        },
        {
            label: "Inflation measure for Infusions",
            name: "inflation_measure_for_infusions",
            type: "switch",
            required: true,
            key: "inflation_measure_for_infusions",
            wider: true,
            states: {
                on: "NOMINAL",
                off: "REAL",
            },
        },
        {
            label: "Inflation",
            name: "inflation",
            type: "percent",
            key: "inflation",
            required: true,
            maxVal: 100,
            minVal: -100,
        },
        {
            label: "Do you want to split your wealth across goal optimally?",
            name: "spit_wealth_across_goal",
            type: "switch",
            states: customSwitchConfig,
            key: "spit_wealth_across_goal",
            required: true,
        },
        {
            label: "IRR for range adjustment",
            name: "irr_range_adjustment",
            type: "percent",
            required: true,
            key: "irr_range_adjustment",
        },
        {
            label: "Select Grid Frequency",
            name: "grid_frequency",
            variant: "h4",
            type: "radio",
            color: "primary",
            key: "grid_frequency",
            states: [
                { key: "yearly", value: "Yearly", disabled: false },
                { key: "half-yearly", value: "Half Yearly", disabled: false },
                { key: "quarterly", value: "Quarterly", disabled: false },
            ],
            required: true,
        },
        {
            label: "Sigma",
            name: "sigma",
            type: "number",
            required: true,
            key: "sigma",
        },
        {
            label: "Alternate Sigma",
            name: "alternative_sigma",
            type: "number",
            required: true,
            key: "alternative_sigma",
            max: 10,
            min: 1,
        },
        {
            label: "NODES PER SD",
            name: "nodes_per_sd",
            type: "number",
            key: "nodes_per_sd",
            required: true,
        },
        {
            label: "IRR PERFORMANCE THRESHOLD",
            name: "irr_performance_threshold",
            type: "percent",
            key: "irr_performance_threshold",
            required: true,
            maxVal: 100,
            minVal: -100,
        },
        {
            label: "LONG TENURE THRESHOLD",
            name: "long_tenure_threshold",
            type: "number",
            key: "long_tenure_threshold",
            required: true,
            max: 100,
            min: 1,
        },
        {
            label: "ALTERNATE NODES PER SD",
            name: "alt_nodes_per_sd",
            type: "number",
            key: "alt_nodes_per_sd",
            required: true,
            max: 100,
            min: 1,
        },
        {
            label: "Run Backward Pass Only",
            name: "back_pass_only",
            type: "switch",
            states: customSwitchConfig,
            key: "back_pass_only",
            required: true,
        },
        {
            label: "Adjust Fees",
            name: "adjust_fees",
            type: "select",
            key: "adjust_fees",
            options: [
                { key: "Common", value: "Common" },
                { key: "Variable", value: "Variable" },
                { key: "No", value: "No" },
            ],
            required: true,
        },
        {
            label: "FEE ADJUSTER (ANNUAL FEE IN BPS)",
            name: "annual_in_bps",
            type: "number",
            key: "annual_in_bps",
            required: false,
            max: 10000,
            min: 0,
        },
        {
            label: "Wealth Path",
            name: "wealth_path",
            type: "select",
            key: "wealth_path",
            required: true,
            options: [
                { key: "Custom", value: "Custom" },
                { key: "PriorityBased", value: "PriorityBased" },
            ],
        },
        {
            label: "Wealth Path Probability",
            name: "wealth_path_probability",
            type: "percent",
            key: "wealth_path_probability",
            required: false,
            max: 100,
            min: 0,
        },
        // {
        //     label: "Wealth Path Frequency",
        //     name: "wealth_path_frequency",
        //     type: "select",
        //     key: "wealth_path_frequency",
        //     options: [
        //         { key: "yearly", value: "Yearly" },
        //         { key: "half-yearly", value: "Half Yearly" },
        //         { key: "quarterly", value: "Quarterly" },
        //     ],
        //     required: true,
        // },
        {
            label: "DEFAULT PROBABILITIES",
            type: "subheading",
            key: "Configuration1",
        },
        {
            label: "Additional Wealth Paths",
            name: "additional_wealth_paths",
            type: "select",
            key: "additional_wealth_paths",
            options: [
                { key: "Yes", value: "Yes" },
                { key: "No", value: "No" },
            ],
            required: true,
        },
        {
            label: "Pessimistic Path Probability",
            name: "pessimistic_path_probability",
            type: "percent",
            key: "pessimistic_path_probability",
            required: false,
            display: false,
        },
        {
            label: "Optimistic Path Probability",
            name: "optimistic_path_probability",
            type: "percent",
            key: "optimistic_path_probability",
            required: false,
            display: false,
        },
        {
            label: "Algorithmic Configuration & Global Variables",
            type: "subheading",
            key: "algorithmic_config_and_variables",
        },
        {
            label: "Probability Thresholds",
            type: "subheading",
            key: "probability_thresholds",
        },
        {
            labels: ["Min Probability", "Max Probability", "Threshold"],
            name: "probabilityThresholds",
            key: "probabilityThresholds",
            type: "columnar-input",
            showTextInput: true,
            display: true,
            config: [
                {
                    id: 1,
                    levels: probabilityThresholdLevels,
                },
                {
                    id: 2,
                    levels: probabilityThresholdLevels,
                },
                {
                    id: 3,
                    levels: probabilityThresholdLevels,
                },
            ],
        },
        {
            label: "Composite Portfolios",
            name: "composite_portfolios",
            type: "switch",
            states: customSwitchConfig,
            key: "composite_portfolios",
            required: true,
        },

    ],
    retirement: [
        {
            label: "RETIREMENT",
            type: "heading",
            key: "retirementHeading",
        },
        {
            label: "DATA TABLE ASSUMPTIONS",
            type: "subheading",
            key: "actuarialHeading",
            indent: true,
        },
        {
            label: "DATA TABLE DATA",
            name: "actuarialData",
            type: "select-group-two",
            key: "actuarialData",
            options: ActuarialTypes,
            stateKey: "actuarialNames",
            indent: true,
            selectFieldLabels: ["TYPE", "DATA TABLE NAME"],
        },
        {
            label: "Max Age",
            name: "maxAge",
            type: "number",
            required: true,
            key: "maxAge",
            max: 150,
            min: 0,
            indent: true,
        },
        {
            label: "DE-RISK",
            type: "subheading",
            key: "deriskRetirement",
            indent: true,
        },
        {
            label: "Tenure For Short Term Retirement Goals (In Years to Retirement)",
            name: "tenureForShortTerm",
            type: "number-group",
            config: [
                {
                    label: "Engaged",
                    objectKey: "shortTermRetirementGoalTenure",
                    master: true,
                    display: true,
                },
                {
                    label: "Un-Engaged",
                    objectKey: "shortTermRetirementGoalTenureUnengaged",
                    master: true,
                    display: true,
                },
            ],
            key: "tenureForShortTerm",
            required: true,
            max: 100,
            min: 1,
            indent: true,
        },
        {
            name: "retirementProfile",
            type: "range-select-group",
            key: "retirementProfile",
            config: [
                {
                    label: "Portfolios For Short Term Retirement Goals",
                    objectKey: "shortTermRetirementGoalProfiles",
                    master: true,
                    display: true,
                    enableLowerLimit: true,
                },
            ],
            max: 16,
            min: 1,
            indent: true,
        },
        {
            label: "Aggregated Retirement Accounts",
            type: "subheading",
            key: "aggregatedRetirementAccountsHeading",
            indent: true,
        },
        {
            label: "Aggregated Retirement Accounts",
            name: "aggregatedRetirementAccounts",
            type: "switch",
            states: customSwitchConfig,
            key: "aggregatedRetirementAccounts",
            required: true,
        },
        {
            label: "Portfolio Mapping Table",
            name: "PortfolioMappingTable",
            type: "text",
            display: false,
            key: "PortfolioMappingTable",
            required: false,
            disabled: true,
        },
        {
            label: "Contribution Rate",
            name: "contributionRate",
            type: "percent",
            key: "contributionRate",
            required: false,
            display: false,
        },
        {
            label: "Fixed Benefits",
            name: "fixedBenefits",
            type: "percent",
            key: "fixedBenefits",
            required: false,
            display: false,
        },
        {
            label: "Calculate Goals",
            name: "calculateGoals",
            type: "switch",
            key: "calculateGoals",
            states: customSwitchConfig,
            required: false,
            display: false,
        },
        {
            label: "GOE FOR DECUMMULATION",
            type: "heading",
            key: "goefordecummulation",
            indent: true,
        },
        {
            label: "Guardrails",
            type: "subheading",
            key: "guardrails",
            indent: true,
        },
        {
            label: "DE-RISKING",
            name: "deriskingPortfolios",
            type: "select-group-two",
            key: "deriskingPortfolios",
            stateKey: "deriskingPortfolioNames",
            options: AgeRange(65, 120),
            selectFieldLabels: ["AGE", "PORTFOLIO"],
            validation: {
                max: 5,
                optOrders: true,
            },
            indent: true,
        },
        {
            label: "Additional Consumption Cap",
            name: "additionalConsumptionCap",
            type: "file-upload-download",
            key: "additionalConsumptionCap",
            path: "/api/goe/upload_file",
            stateKey: "fileTemplates",
            indent: true,
        },
        {
            label: "Minimum Consumption Floor",
            name: "minConsumptionFloor",
            type: "file-upload-download",
            key: "minConsumptionFloor",
            path: "/api/goe/upload_file",
            stateKey: "fileTemplates",
            indent: true,
        },
        {
            label: "Maximum Equity Exposure",
            name: "maxEquityExposure",
            type: "file-upload-download",
            key: "maxEquityExposure",
            path: "/api/goe/upload_file",
            stateKey: "fileTemplates",
            indent: true,
        },
        {
            label: "Age Based Annuity Cap",
            name: "ageBasedAnnuityCap",
            type: "file-upload-download",
            key: "ageBasedAnnuityCap",
            path: "/api/goe/upload_file",
            stateKey: "fileTemplates",
            indent: true,
        },
        {
            label: "Age Based GI% Cap",
            name: "ageBasedGICap",
            type: "file-upload-download",
            key: "ageBasedGICap",
            stateKey: "fileTemplates",
            path: "/api/goe/upload_file",
            indent: true,
        },
        {
            label: "Guaranteed Income %",
            type: "subheading",
            key: "guaranteedIncome",
            indent: true,
        },
        {
            name: "guaranteedIncomePercent",
            type: "slider-group-with-label",
            labels: ["Solvency Risk", "Probability Threshold", "Min GI%"],
            key: "guaranteedIncomePercent",
            showTextInput: true,
            config: [
                {
                    id: 1,
                    levels: ["1", "2", "3", "4", "5"],
                },
                {
                    id: 2,
                    levels: ["2", "3", "4", "5"],
                },
                {
                    id: 3,
                    levels: ["3", "4", "5"],
                },
                {
                    id: 4,
                    levels: ["4", "5"],
                },
                {
                    id: 5,
                    levels: ["5"],
                },
            ],
        },
        {
            label: "Planning Age",
            type: "subheading",
            key: "planningage",
            indent: true,
        },
        {
            label: "Use a Fixed Planning Age",
            name: "useAFixedPlanningAge",
            type: "switch",
            key: "useAFixedPlanningAge",
            states: customSwitchConfig,
            required: true,
            display: true,
        },
        {
            label: "Planning Age",
            name: "planningAge",
            type: "number",
            key: "planningAge",
            required: true,
            display: true,
        },
        {
            label: "Minimum Planning Age",
            name: "minimumPlanningAge",
            type: "number",
            key: "minimumPlanningAge",
            required: false,
            display: false,
        },
        {
            label: "Minimum Annuitisation Amount",
            name: "minimumAnnuitisationAmount",
            type: "number",
            key: "minimumAnnuitisationAmount",
            required: true,
            display: true,
            min: 0,
        },
        {
            label: "Type Of Mortality Table",
            name: "typeOfMortalityTable",
            type: "select",
            key: "typeOfMortalityTable",
            options: [
                { key: "Unisex", value: "Unisex" },
                { key: "GenderBased", value: "GenderBased" },
                { key: "HealthStatusBased", value: "HealthStatusBased" },
                {
                    key: "GenderAndHealthStatusBased",
                    value: "GenderAndHealthStatusBased",
                },
            ],
            required: true,
            display: true,
        },
        {
            label: "Social Security Filing Age",
            name: "socialSecurityFilingAge",
            type: "number-group",
            config: [
                {
                    label: "Minimum",
                    objectKey: "minimumSocialSecurityFilingAge",
                    master: true,
                    display: true,
                },
                {
                    label: "Maximum",
                    objectKey: "maximumSocialSecurityFilingAge",
                    master: true,
                    display: true,
                },
            ],
            key: "socialSecurityFilingAge",
            required: true,
            max: 200,
            min: 0,
            indent: true,
        },
    ],
    tax: [
        {
            label: "TAX",
            type: "heading",
            key: "taxHeading",
        },
        {
            label: "DATA TABLE MAPPING",
            type: "subheading",
            key: "dataTableMapping",
        },
        {
            label: "DATA TABLE DATA",
            name: "taxActuarialData",
            type: "select-group-two",
            key: "taxActuarialData",
            options: taxDataTableTypes,
            stateKey: "taxActuarialNames",
            indent: true,
            selectFieldLabels: ["TYPE", "DATA TABLE NAME"],
        },
        {
            label: "LY Package ID",
            name: "LYPackageID",
            type: "text",
            display: true,
            key: "LYPackageID",
            required: false,
            disabled: false,
        },
        {
            label: "Total Allowed Contribution",
            name: "totalAllowedContribution",
            type: "number",
            display: true,
            key: "totalAllowedContribution",
            required: false,
            disabled: false,
            min: 0,
        },
        {
            label: "Total Allowed Catchup Contribution",
            name: "totalAllowedCatchupContribution",
            type: "number",
            display: true,
            key: "totalAllowedCatchupContribution",
            required: false,
            disabled: false,
            min: 0,
        },
        {
            label: "LifeYield Environment",
            name: "lifeYieldEnvironment",
            type: "select",
            key: "lifeYieldEnvironment",
            options: [
                { key: "LifeYieldUAT", value: "LifeYieldUAT" },
                { key: "LifeYieldProduction", value: "LifeYieldProduction" },
            ],
            required: false,
            display: true,
        },
        {
            label: "Simulation Type",
            name: "simulationType",
            type: "select",
            key: "simulationType",
            options: [
                { key: "GlidePath", value: "GlidePath" },
                { key: "RiskProfile", value: "RiskProfile" },
            ],
            required: false,
            display: true,
        },
        {
            label: "Simulation Count",
            name: "simulationCount",
            key: "simulationCount",
            type: "number",
            required: true,
            max: 1000000,
            min: 0,
        },
    ],
    upa: [
        {
            label: "Goal Modification",
            type: "subheading",
            key: "goal_modification",
        },
        {
            name: "goalModification",
            type: "slider-group-with-label",
            labels: ["Priority", "Maximum Goal Modification %"],
            key: "goalModification",
            config: [
                {
                    id: 1,
                    levels: ["1", "2", "3", "4", "5"],
                },
                {
                    id: 2,
                    levels: ["2", "3", "4", "5"],
                },
                {
                    id: 3,
                    levels: ["3", "4", "5"],
                },
                {
                    id: 4,
                    levels: ["4", "5"],
                },
                {
                    id: 5,
                    levels: ["5"],
                },
            ],
        },
        {
            label: "Mode",
            type: "subheading",
            key: "upa_mode",
        },
        {
            label: "Use Case",
            name: "use_case",
            type: "select",
            key: "use_case",
            options: [
                { key: "UPA2", value: "UPA2" },
                { key: "UPA4", value: "UPA4" },
                { key: "Hantz", value: "Hantz" },
            ],
            required: true,
            display: true,
        },
        {
            label: "Maximum Goal Modification per Iteration",
            name: "goal_drop_step",
            type: "percent",
            key: "goal_drop_step",
            required: true,
            max: 100,
            min: 0,
        },
    ],
};

const getInitialDate = (month) => {
    const currentDate = new Date();

    const currentYear = currentDate.getFullYear();

    const displayDate = new Date(currentYear, month, 1);

    const displayDateString = displayDate.toString().slice(0, 15);

    return displayDateString;
};

const defaultGIP = {
    1: { labelValue: "need", value: 85, val: 0 },
    2: { labelValue: "want", value: 70, val: 25 },
    3: { labelValue: "wish", value: 60, val: 50 },
    4: { labelValue: "dream", value: 50, val: 75 },
    5: { labelValue: "desire", value: 40, val: 100 },
};

const defaultGoalModification = {
    1: { labelValue: "need", value: 0, val: 0 },
    2: { labelValue: "want", value: 100, val: 100 },
    3: { labelValue: "wish", value: 100, val: 100 },
    4: { labelValue: "dream", value: 100, val: 100 },
    5: { labelValue: "desire", value: 100, val: 100 },
};

const probabilityThresholdsDefault = {
    1: { labelValue: 0.0, value: 90, val: 0.00075 },
    2: { labelValue: 90, value: 100, val: 0.0015 },
    3: { labelValue: 65, value: 90, val: 0.00075 },
};
export const clientFormConfigDefaults = {
    country: "",
    segment: "",
    using_ft_portfolio: true,
    portfolioConfig: {
        defaultRiskProfiles: {
            lowerLimit: null,
            upperLimit: null,
            labelValue: "DefaultRisk",
        },
        conservativeRiskProfiles: {
            lowerLimit: null,
            upperLimit: null,
        },
        veryConservativeRiskProfiles: {
            lowerLimit: null,
            upperLimit: null,
        },
        moderateRiskProfiles: {
            lowerLimit: null,
            upperLimit: null,
        },
        conservativelyModerateRiskProfiles: {
            lowerLimit: null,
            upperLimit: null,
        },
        moderatelyAggressiveRiskProfiles: {
            lowerLimit: null,
            upperLimit: null,
        },
        aggressiveRiskProfiles: {
            lowerLimit: null,
            upperLimit: null,
        },
        veryAggressiveRiskProfiles: {
            lowerLimit: null,
            upperLimit: null,
        },
        shortTermGoalProfiles: { lowerLimit: null, upperLimit: null },
    },
    decumulationProfile: {
        decumulationScenarioProfiles: { lowerLimit: null, upperLimit: null },
    },
    retirementProfile: {
        shortTermRetirementGoalProfiles: { lowerLimit: null, upperLimit: null },
    },
    levelsOfGoalPriority: {
        1: {
            labelValue: "need",
            value: 85,
        },
        2: {
            labelValue: "want",
            value: 70,
        },
        3: {
            labelValue: "wish",
            value: 60,
        },
        4: {
            labelValue: "dream",
            value: 50,
        },
        5: {
            labelValue: "desire",
            value: 40,
        },
    },
    select_configuration: "Configuration1",
    select_goal_level: "4",
    risk_level: "1",
    reallocation_frequency_dates: {
        reallocationDatesByFrequency: {
            yearly: [getInitialDate(0)],
            halfyearly: [getInitialDate(0), getInitialDate(6)],
            quarterly: [getInitialDate(0), getInitialDate(3), getInitialDate(6), getInitialDate(9)],
        },
    },
    allocation_on_retake_rtq: true,
    new_goal: true,
    wantsToReallocate: false,
    allocation_on_invest_tenure_change: true,
    when_risk_indicator_flashes: true,
    allocation_on_re_prioritizing_goal: true,
    goal_unrealistic: 35,
    loss_threshold_floor: true,
    loss_threshold_probability: 95,
    loss_threshold_values: {
        accumulation: {
            1: { labelValue: "need", value: 10 },
            2: { labelValue: "want", value: -20 },
            3: { labelValue: "wish", value: -50 },
            4: { labelValue: "dream", value: -100 },
            5: { labelValue: "desire", value: 40 },
        },
        decumulation: {
            1: { labelValue: "need", value: 50 },
            2: { labelValue: "want", value: 25 },
            3: { labelValue: "wish", value: 0 },
            4: { labelValue: "dream", value: 0 },
            5: { labelValue: "desire", value: 0 },
        },
    },
    swing_constraint: true,
    minimum_portfolios_for_last_year: 5,
    safe_guard_wealth_last_year: true,
    recommended_top_up_infusion: true,
    recommended_tenure: true,
    recommend_escalated_goal: false,
    maxAge: 120,
    recommend_initial_wealth: false,
    downside_protection: "Maximize Loss Threshold Probability",
    grid_frequency: "yearly",
    reallocationFrequency: "yearly",
    back_pass_only: false,
    adjust_fees: "Variable",
    annual_in_bps: 0,
    wealth_path: "PriorityBased",
    wealth_path_probability: null,
    additional_wealth_paths: "No",
    pessimistic_path_probability: null,
    optimistic_path_probability: null,
    // wealth_path_frequency: "yearly",
    aggregatedRetirementAccounts: false,
    use_case: false,
    contributionRate: 0,
    fixedBenefits: 0,
    portfolioMappingTable: "",
    calculateGoals: false,
    spit_wealth_across_goal: true,
    inflation: 2.5,
    inflation_measure_for_infusions: true,
    riskOverlay: true,
    risk_indicator_flag_value: { lower: "0.3", upper: "0.7" },
    irr_range_adjustment: -100,
    sigma: 5,
    alternative_sigma: 4,
    nodes_per_sd: 8,
    swing_constraint_number: 4,
    tenureForShortTerm: {
        shortTermRetirementGoalTenure: 1,
        shortTermRetirementGoalTenureUnengaged: 5,
    },
    tenure_years: 3,
    irr_performance_threshold: 3.39,
    long_tenure_threshold: 30,
    alt_nodes_per_sd: 4,
    useAFixedPlanningAge: true,
    deriskingPortfolios: [],
    guaranteedIncomePercent: defaultGIP,
    goalModification: defaultGoalModification,
    probabilityThresholds: probabilityThresholdsDefault,
    socialSecurityFilingAge: {
        minimumSocialSecurityFilingAge: 62,
        maximumSocialSecurityFilingAge: 70,
    },
    LYPackageID: "",
    lifeYieldEnvironment: "LifeYieldUAT",
    simulationType: "RiskProfile",
    simulationCount: 0,
    goal_drop_step: null,
    totalAllowedContribution: 22500,
    totalAllowedCatchupContribution: 30000,
    composite_portfolios: false,
};

function getPorfolioConfigData(data, actualPortfolios) {
    const actualPortfoliosNumbers: any = [];
    for (const key in actualPortfolios.portfolios) {
        actualPortfoliosNumbers.push(actualPortfolios.portfolios[key]["id"]);
    }
    const dataObj = data?.portfolioConfig || {};
    const portfolioConfig = {};
    for (const key in dataObj) {
        portfolioConfig[key] = {
            lowerLimit:
                extractDisplayablePortfolioConfig(dataObj, dataObj[key][0], actualPortfoliosNumbers) === -1
                    ? null
                    : extractDisplayablePortfolioConfig(dataObj, dataObj[key][0], actualPortfoliosNumbers) + 1,
            upperLimit:
                extractDisplayablePortfolioConfig(
                    dataObj,
                    dataObj[key][dataObj[key].length - 1],
                    actualPortfoliosNumbers
                ) === -1
                    ? null
                    : extractDisplayablePortfolioConfig(
                          dataObj,
                          dataObj[key][dataObj[key].length - 1],
                          actualPortfoliosNumbers
                      ) + 1,
        };
    }
    return portfolioConfig;
}

function getRangeTextGrp(values: any = []) {
    const result = { accumulation: {}, decumulation: {} };
    values.map((valueItem, index) => {
        const itemName = valueItem.name;
        result["accumulation"][index + 1] = {
            labelValue: itemName,
            value: valueItem["accumulation"] * 100,
        };
        result["decumulation"][index + 1] = {
            labelValue: itemName,
            value: valueItem["decumulation"] * 100,
        };
    });
    return result;
}

function getGoalPriorityLevels(goalPriority, isGIField = false, isGoalModifiedField = false) {
    let dataArr: any = [];
    if (isGIField) {
        if (goalPriority?.guaranteedIncomePercent) {
            dataArr = goalPriority?.guaranteedIncomePercent;
        } else {
            return { ...defaultGIP };
        }
    } else if (isGoalModifiedField) {
        if (goalPriority?.goalModification) {
            dataArr = goalPriority?.goalModification;
        } else {
            return { ...defaultGoalModification };
        }
    } else {
        dataArr = goalPriority?.probabilityLevels;
    }
    const goalPriorityLevels = {};
    for (let i = 0; i < dataArr?.length; i++) {
        goalPriorityLevels[i + 1] = {
            labelValue: dataArr[i]?.name,
            value: dataArr[i]?.value * 100,
        };
        if (isGIField) {
            goalPriorityLevels[i + 1].val = Math.round(dataArr[i]?.min * 100);
        }
    }
    return goalPriorityLevels;
}
function getprobabilityThresholds(probabilityThresholds) {
    const dataArr: any = {};
    if (probabilityThresholds) {
        for (const thv in probabilityThresholds) {
            dataArr[parseInt(thv) + 1] = {
                labelValue: getDecimalValue(probabilityThresholds[thv].labelValue),
                value: getDecimalValue(probabilityThresholds[thv].value),
                val: probabilityThresholds[thv].val,
            };
        }
    } else {
        return { ...probabilityThresholdsDefault };
    }
    return dataArr;
}
const inflation_measure = { NOMINAL: true, REAL: false };

function getDecimalValue(val) {
    return val ? val * 100 : 0;
}

function getActuarialData(dataArr) {
    if (dataArr?.length < 0) {
        return [{ key: "Mortality", value: "Mortality" }];
    }
    return dataArr?.map((item) => ({
        key: item.type,
        value: item.type,
        valueTwo: item.name,
    }));
}

function getDeriskData(dataArr) {
    if (dataArr?.length < 0) {
        return [];
    }
    return dataArr?.map((item) => ({
        key: item.age,
        value: item.age,
        valueTwo: item.portfolio,
    }));
}

function getLYTargetAllocations(dataArr) {
    if (!dataArr || dataArr?.length < 0) {
        return [];
    }
    return dataArr?.map((item) => ({
        key: item.type,
        value: item.type,
        valueTwo: item.name,
    }));
}

export const makeClientForm = (obj, selectedPortfolio) => {
    const config = obj?.config || {};
    const portfolioData = config?.portfolioConfig || {};
    const portfolioConfig = getPorfolioConfigData(portfolioData, selectedPortfolio);
    const mappedPortfolioConfig = mapPortfolioRiskLabels(portfolioConfig, portfolioData.portfolioMapping);

    const goalPriority = config?.goalPriority;
    const reallocationTriggers = config?.allocationConfiguration?.reallocationTriggers || [];
    const generalSettings = goalPriority?.generalSettings;
    const decummulationFiles = config?.decummulationFiles || {};
    return {
        country: obj.country.name,
        segment: obj.segment.name,
        email: obj.email,
        portfolio_selection: obj.portfolioBundle.name,
        portfolio_description: obj.portfolioBundle.description,
        customer_name: obj.name,
        contact_id: obj.contactId,
        contact_name: obj.contactName,
        contact_phone_number: obj.phone,
        notes: obj.notes,
        using_ft_portfolio: true,
        risk_level: portfolioData.level || "1",
        portfolioConfig: mappedPortfolioConfig,
        tenure_years: portfolioData?.shortTermGoalTenure,
        decumulationProfile: {
            decumulationScenarioProfiles: mappedPortfolioConfig?.decumulationScenarioProfiles,
        },
        retirementProfile: {
            shortTermRetirementGoalProfiles: mappedPortfolioConfig?.shortTermRetirementGoalProfiles,
        },
        riskOverlay: goalPriority?.performance?.riskOverlay,
        risk_indicator_flag_value: goalPriority?.performance?.riskIndicator,
        select_configuration: config?.configuration || "Configuration1",
        grid_frequency: goalPriority?.generalSettings?.gridFrequency || "yearly",
        // wealth_path_frequency: goalPriority?.generalSettings?.wealthPathFrequency || "yearly",
        reallocationFrequency: config?.allocationConfiguration?.reallocationFrequency || "yearly",
        reallocation_frequency_dates: {
            reallocationDatesByFrequency: config?.allocationConfiguration?.reallocationDatesByFrequency,
        },
        allocation_on_retake_rtq: reallocationTriggers?.[0]?.value,
        allocation_on_invest_tenure_change: reallocationTriggers?.[1]?.value,
        when_risk_indicator_flashes: reallocationTriggers?.[2]?.value,
        allocation_on_re_prioritizing_goal: reallocationTriggers?.[3]?.value,
        new_goal: reallocationTriggers?.[4]?.value,
        wantsToReallocate: reallocationTriggers?.[5]?.value,
        select_goal_level: config?.goalLevel || "1",
        levelsOfGoalPriority: getGoalPriorityLevels(goalPriority),
        goalModification: getGoalPriorityLevels(goalPriority, false, true),
        loss_threshold_floor: goalPriority?.lossThreshold,
        loss_threshold_probability: getDecimalValue(goalPriority.lossThresholdProbability),
        downside_protection: generalSettings?.downsideProtection,
        loss_threshold_values: getRangeTextGrp(goalPriority?.lossthresholdValues),
        safe_guard_wealth_last_year: generalSettings?.safeGuardAchievedWealthInLastYear,
        minimum_portfolios_for_last_year: generalSettings?.minPortfoliosForLastYear,
        recommended_tenure: generalSettings.recommendTenure,
        recommended_top_up_infusion: generalSettings.recommendTopUpInfusion,
        recommend_escalated_goal: generalSettings.recommendEscalatedGoal,
        goal_unrealistic: getDecimalValue(generalSettings?.unrealisticProbability),
        swing_constraint: generalSettings?.swingConstraint,
        swing_constraint_number: generalSettings?.swingConstraintNumber,
        inflation_measure_for_infusions: inflation_measure?.[generalSettings?.inflationMeasureForInfusions],
        inflation: getDecimalValue(generalSettings?.inflation),
        spit_wealth_across_goal: generalSettings?.splitWealthAcrossGoalOptimally,
        irr_range_adjustment: getDecimalValue(goalPriority?.performance?.irrForRangeAdjustment),
        sigma: goalPriority.performance.sigma,
        alternative_sigma: goalPriority?.performance?.alternativeSigma,
        nodes_per_sd: goalPriority?.performance?.nodesPerSd,
        irr_performance_threshold: getDecimalValue(goalPriority?.performance?.irrPerformanceThreshold),
        long_tenure_threshold: goalPriority?.performance?.longTenureThreshold,
        alt_nodes_per_sd: goalPriority?.performance?.altNodesPerSd,
        actuarialData: getActuarialData(generalSettings?.actuarials),
        maxAge: generalSettings?.maxAge,
        tenureForShortTerm: {
            shortTermRetirementGoalTenure: config?.portfolioConfig?.shortTermRetirementGoalTenure,
            shortTermRetirementGoalTenureUnengaged: config?.portfolioConfig?.shortTermRetirementGoalTenureUnengaged,
        },
        back_pass_only: generalSettings?.backPassOnly,
        adjust_fees: generalSettings?.adjustFees || null,
        annual_in_bps: generalSettings?.annualInBPS,
        wealth_path: generalSettings?.wealthPath || "PriorityBased",
        wealth_path_probability:
            generalSettings?.wealthPathProbability === null ||
            generalSettings?.wealthPathProbability === "" ||
            generalSettings?.wealthPathProbability === undefined
                ? null
                : getDecimalValue(generalSettings?.wealthPathProbability),
        additional_wealth_paths:
            generalSettings?.additionalWealthPaths === null ||
            generalSettings?.additionalWealthPaths === "" ||
            generalSettings?.additionalWealthPaths === undefined
                ? "No"
                : generalSettings?.additionalWealthPaths,
        pessimistic_path_probability:
            generalSettings?.pessimisticPathProbability === null ||
            generalSettings?.pessimisticPathProbability === "" ||
            generalSettings?.pessimisticPathProbability === undefined
                ? null
                : getDecimalValue(generalSettings?.pessimisticPathProbability),
        optimistic_path_probability:
            generalSettings?.optimisticPathProbability === null ||
            generalSettings?.optimisticPathProbability === "" ||
            generalSettings?.optimisticPathProbability === undefined
                ? null
                : getDecimalValue(generalSettings?.optimisticPathProbability),
        aggregatedRetirementAccounts: generalSettings?.aggregatedRetirementAccounts,
        composite_portfolios: generalSettings?.composite_portfolios,
        use_case: generalSettings?.useCase,
        portfolioMappingTable: generalSettings?.portfolioMappingTable,
        contributionRate: getDecimalValue(generalSettings?.contributionRate),
        fixedBenefits: getDecimalValue(generalSettings?.fixedBenefits),
        calculateGoals: generalSettings?.calculateGoals,
        useAFixedPlanningAge:
            generalSettings?.useAFixedPlanningAge === null ||
            generalSettings?.useAFixedPlanningAge === "" ||
            generalSettings?.useAFixedPlanningAge === undefined
                ? true
                : generalSettings?.useAFixedPlanningAge,
        planningAge: generalSettings?.planningAge,
        minimumPlanningAge: generalSettings?.minimumPlanningAge,
        minimumAnnuitisationAmount:
            generalSettings?.minimumAnnuitisationAmount === null ||
            generalSettings?.minimumAnnuitisationAmount === "" ||
            generalSettings?.minimumAnnuitisationAmount === undefined
                ? 0
                : generalSettings?.minimumAnnuitisationAmount,
        typeOfMortalityTable: generalSettings?.typeOfMortalityTable,
        deriskingPortfolios: getDeriskData(generalSettings?.derisking),
        guaranteedIncomePercent: getGoalPriorityLevels(goalPriority, true),
        probabilityThresholds: getprobabilityThresholds(goalPriority?.probabilityThresholds),
        additionalConsumptionCap: decummulationFiles?.additionalConsumptionCap,
        minConsumptionFloor: decummulationFiles?.minConsumptionFloor,
        maxEquityExposure: decummulationFiles?.maxEquityExposure,
        ageBasedAnnuityCap: decummulationFiles?.ageBasedAnnuityCap,
        ageBasedGICap: decummulationFiles?.ageBasedGICap,
        socialSecurityFilingAge: {
            minimumSocialSecurityFilingAge:
                generalSettings?.socialSecurityFilingAge?.minimumSocialSecurityFilingAge || 62,
            maximumSocialSecurityFilingAge:
                generalSettings?.socialSecurityFilingAge?.maximumSocialSecurityFilingAge || 70,
        },
        taxActuarialData: getLYTargetAllocations(generalSettings?.taxActuarialData),
        LYPackageID: generalSettings?.LYPackageID,
        totalAllowedContribution: generalSettings?.totalAllowedContribution || 22500,
        totalAllowedCatchupContribution: generalSettings?.totalAllowedCatchupContribution || 30000,
        lifeYieldEnvironment: generalSettings?.lifeYieldEnvironment || "LifeYieldUAT",
        goal_drop_step:
            generalSettings?.goalDropStep === null ||
            generalSettings?.goalDropStep === "" ||
            generalSettings?.goalDropStep === undefined
                ? null
                : getDecimalValue(generalSettings?.goalDropStep),
        simulationType: generalSettings?.simulationType || "RiskProfile",
        simulationCount: generalSettings?.simulationCount || 10000,
    };
};

export const generalSettingsConfigs = {
    Configuration1: {
        reallocation_frequency_dates: {
            reallocationDatesByFrequency: {
                yearly: [getInitialDate(0)],
                halfyearly: [getInitialDate(0), getInitialDate(6)],
                quarterly: [getInitialDate(0), getInitialDate(3), getInitialDate(6), getInitialDate(9)],
            },
        },
        allocation_on_retake_rtq: true,
        new_goal: true,
        wantsToReallocate: false,
        allocation_on_invest_tenure_change: true,
        when_risk_indicator_flashes: true,
        allocation_on_re_prioritizing_goal: true,
        levelsOfGoalPriority: {
            1: {
                labelValue: "need",
                value: 85,
            },
            2: {
                labelValue: "want",
                value: 70,
            },
            3: {
                labelValue: "wish",
                value: 60,
            },
            4: {
                labelValue: "dream",
                value: 50,
            },
            5: {
                labelValue: "desire",
                value: 40,
            },
        },
        goal_unrealistic: 35,
        loss_threshold_floor: true,
        tenure_years: 3,
        tenureForShortTerm: {
            shortTermRetirementGoalTenure: 1,
            shortTermRetirementGoalTenureUnengaged: 5,
        },
        socialSecurityFilingAge: {
            minimumSocialSecurityFilingAge: 62,
            maximumSocialSecurityFilingAge: 70,
        },
        loss_threshold_probability: 99,
        loss_threshold_values: {
            accumulation: {
                1: { labelValue: "need", value: 10 },
                2: { labelValue: "want", value: -20 },
                3: { labelValue: "wish", value: -50 },
                4: { labelValue: "dream", value: -100 },
                5: { labelValue: "desire", value: 40 },
            },
            decumulation: {
                1: { labelValue: "need", value: 50 },
                2: { labelValue: "want", value: 25 },
                3: { labelValue: "wish", value: 0 },
                4: { labelValue: "dream", value: 0 },
                5: { labelValue: "desire", value: 0 },
            },
        },
        swing_constraint: true,
        minimum_portfolios_for_last_year: 5,
        safe_guard_wealth_last_year: false,
        recommended_top_up_infusion: true,
        recommend_initial_wealth: false,
        recommend_escalated_goal: false,
        recommended_tenure: true,
        maxAge: 120,
        downside_protection: "Maximize Loss Threshold Probability",
        grid_frequency: "yearly",
        // wealth_path_frequency: "yearly",
        reallocationFrequency: "yearly",
        back_pass_only: false,
        adjust_fees: "Variable",
        annual_in_bps: 0,
        portfolioMappingTable: "",
        contributionRate: 0,
        fixedBenefits: 0,
        calculateGoals: false,
        LYPackageID: "",
        spit_wealth_across_goal: true,
        inflation: 2.5,
        inflation_measure_for_infusions: true,
        irr_range_adjustment: -100,
        sigma: 5,
        alternative_sigma: 4,
        nodes_per_sd: 8,
        irr_performance_threshold: 3.39,
        long_tenure_threshold: 30,
        alt_nodes_per_sd: 4,
    },
    Configuration2: {
        reallocation_frequency_dates: {
            reallocationDatesByFrequency: {
                yearly: [getInitialDate(0)],
                halfyearly: [getInitialDate(0), getInitialDate(6)],
                quarterly: [getInitialDate(0), getInitialDate(3), getInitialDate(6), getInitialDate(9)],
            },
        },
        allocation_on_retake_rtq: false,
        new_goal: false,
        wantsToReallocate: false,
        allocation_on_invest_tenure_change: false,
        when_risk_indicator_flashes: false,
        allocation_on_re_prioritizing_goal: false,
        levelsOfGoalPriority: {
            1: {
                labelValue: "need",
                value: 85,
            },
            2: {
                labelValue: "want",
                value: 70,
            },
            3: {
                labelValue: "wish",
                value: 60,
            },
            4: {
                labelValue: "dream",
                value: 50,
            },
            5: {
                labelValue: "desire",
                value: 40,
            },
        },
        goal_unrealistic: 35,
        loss_threshold_floor: false,
        loss_threshold_probability: 0,
        loss_threshold_values: {
            accumulation: {
                1: { labelValue: "need", value: 5 },
                2: { labelValue: "want", value: -1 },
                3: { labelValue: "wish", value: 80 },
                4: { labelValue: "dream", value: 60 },
                5: { labelValue: "desire", value: 40 },
            },
            decumulation: {
                1: { labelValue: "need", value: 50 },
                2: { labelValue: "want", value: 25 },
                3: { labelValue: "wish", value: 0 },
                4: { labelValue: "dream", value: 0 },
                5: { labelValue: "desire", value: 0 },
            },
        },
        swing_constraint: false,
        minimum_portfolios_for_last_year: 7,
        safe_guard_wealth_last_year: false,
        recommended_top_up_infusion: false,
        recommended_tenure: false,
        recommend_escalated_goal: false,
        maxAge: 120,
        recommend_initial_wealth: false,
        downside_protection: "Maximize Goal Probability",
        grid_frequency: "yearly",
        // wealth_path_frequency: "yearly",
        reallocationFrequency: "yearly",
        back_pass_only: false,
        adjust_fees: "Variable",
        annual_in_bps: 0,
        use_case: false,
        portfolioMappingTable: "",
        contributionRate: 0,
        fixedBenefits: 0,
        calculateGoals: false,
        LYPackageID: "",
        spit_wealth_across_goal: false,
        inflation: 2.0,
        inflation_measure_for_infusions: false,
        irr_range_adjustment: "2.00",
        sigma: 3,
        alternative_sigma: 4,
        nodes_per_sd: 4,
    },
    Configuration3: {
        reallocation_frequency_dates: {
            reallocationDatesByFrequency: {
                yearly: [getInitialDate(0)],
                halfyearly: [getInitialDate(0), getInitialDate(6)],
                quarterly: [getInitialDate(0), getInitialDate(3), getInitialDate(6), getInitialDate(9)],
            },
        },
        allocation_on_retake_rtq: false,
        new_goal: false,
        wantsToReallocate: false,
        allocation_on_invest_tenure_change: false,
        when_risk_indicator_flashes: false,
        allocation_on_re_prioritizing_goal: false,
        levelsOfGoalPriority: {
            1: {
                labelValue: "need",
                value: 85,
            },
            2: {
                labelValue: "want",
                value: 70,
            },
            3: {
                labelValue: "wish",
                value: 60,
            },
            4: {
                labelValue: "dream",
                value: 50,
            },
            5: {
                labelValue: "desire",
                value: 40,
            },
        },
        goal_unrealistic: 35,
        loss_threshold_floor: true,
        loss_threshold_probability: 99,
        loss_threshold_values: {
            accumulation: {
                1: { labelValue: "need", value: 5 },
                2: { labelValue: "want", value: -1 },
                3: { labelValue: "wish", value: 80 },
                4: { labelValue: "dream", value: 60 },
                5: { labelValue: "desire", value: 40 },
            },
            decumulation: {
                1: { labelValue: "need", value: 50 },
                2: { labelValue: "want", value: 25 },
                3: { labelValue: "wish", value: 0 },
                4: { labelValue: "dream", value: 0 },
                5: { labelValue: "desire", value: 0 },
            },
        },
        swing_constraint: true,
        minimum_portfolios_for_last_year: 3,
        safe_guard_wealth_last_year: false,
        recommended_top_up_infusion: true,
        recommended_tenure: true,
        recommend_escalated_goal: false,
        maxAge: 120,
        recommend_initial_wealth: false,
        downside_protection: "Maximize Loss Threshold Probability",
        grid_frequency: "yearly",
        // wealth_path_frequency: "yearly",
        reallocationFrequency: "yearly",
        back_pass_only: false,
        adjust_fees: "Variable",
        annual_in_bps: 0,
        use_case: false,
        aggregatedRetirementAccounts: false,
        composite_portfolios: false,
        portfolioMappingTable: "",
        contributionRate: 0,
        fixedBenefits: 0,
        calculateGoals: false,
        LYPackageID: "",
        spit_wealth_across_goal: true,
        inflation: 0.5,
        inflation_measure_for_infusions: false,
        irr_range_adjustment: "2.50",
        sigma: 3,
        alternative_sigma: 4,
        nodes_per_sd: 10,
    },
};

export const generalSettingsKeys = {
    portfolioConfig: [
        { name: "usingFtPortfolio", accessKey: "using_ft_portfolio", type: "text" },
        {
            name: "distributionChannel",
            accessKey: "distribution_channel.value",
            type: "text",
        },
        { name: "level", accessKey: "risk_level", type: "text" },
        { name: "portfolioConfig", accessKey: "portfolioConfig", type: "text" },
    ],
    allocationConfiguration: [
        {
            name: "reallocationFrequency",
            type: "text",
            accessKey: "reallocationFrequency",
        },
        {
            name: "reallocationDatesByFrequency",
            type: "text",
            accessKey: "reallocation_frequency_dates.reallocationDatesByFrequency",
        },
        {
            name: "reallocationTriggers",
            type: "switchGroup",
            keyValuePairs: [
                { name: "newRiskProfile", accessKey: "allocation_on_retake_rtq" },
                {
                    name: "changesInvestmentTenure",
                    accessKey: "allocation_on_invest_tenure_change",
                },
                {
                    name: "riskIndicatorFlashes",
                    accessKey: "when_risk_indicator_flashes",
                },
                {
                    name: "rePrioritizesGoal",
                    accessKey: "allocation_on_re_prioritizing_goal",
                },
                { name: "newGoal", accessKey: "new_goal" },
                { name: "wantsToReallocate", accessKey: "wantsToReallocate" },
            ],
        },
    ],
    goalPriority: [
        {
            name: "probabilityLevels",
            type: "sliderGroupWithLabel",
            accessKey: "levelsOfGoalPriority",
        },
        { name: "lossThreshold", type: "text", accessKey: "loss_threshold_floor" },
        {
            name: "lossThresholdProbability",
            type: "percent",
            accessKey: "loss_threshold_probability",
            conditionalExtract: true,
            dependency: "loss_threshold_floor",
            dependentValue: true,
        },
        {
            name: "lossthresholdValues",
            type: "rangeTextGroup",
            accessKey: "loss_threshold_values",
            conditionalExtract: true,
            dependency: "loss_threshold_floor",
            dependentValue: true,
            keyValuePairs: [
                {
                    name: "need",
                    accessKeys: [
                        {
                            name: "accumulation",
                            accessKey: "accumulation.need",
                            percent: true,
                        },
                        {
                            name: "decumulation",
                            accessKey: "decumulation.need",
                            percent: true,
                        },
                    ],
                },
                {
                    name: "want",
                    accessKeys: [
                        {
                            name: "accumulation",
                            accessKey: "accumulation.want",
                            percent: true,
                        },
                        {
                            name: "decumulation",
                            accessKey: "decumulation.want",
                            percent: true,
                        },
                    ],
                },
                {
                    name: "wish",
                    accessKeys: [
                        {
                            name: "accumulation",
                            accessKey: "accumulation.wish",
                            percent: true,
                        },
                        {
                            name: "decumulation",
                            accessKey: "decumulation.wish",
                            percent: true,
                        },
                    ],
                },
                {
                    name: "dream",
                    accessKeys: [
                        {
                            name: "accumulation",
                            accessKey: "accumulation.dream",
                            percent: true,
                        },
                        {
                            name: "decumulation",
                            accessKey: "decumulation.dream",
                            percent: true,
                        },
                    ],
                },
                {
                    name: "desire",
                    accessKeys: [
                        {
                            name: "accumulation",
                            accessKey: "accumulation.desire",
                            percent: true,
                        },
                        {
                            name: "decumulation",
                            accessKey: "decumulation.desire",
                            percent: true,
                        },
                    ],
                },
            ],
        },
        {
            name: "guaranteedIncomePercent",
            type: "sliderGroupWithLabel",
            accessKey: "guaranteedIncomePercent",
        },
        {
            name: "probabilityThresholds",
            type: "columnarInput",
            accessKey: "probabilityThresholds",
        },
        {
            name: "goalModification",
            type: "sliderGroupWithLabel",
            accessKey: "goalModification",
        },
        {
            name: "generalSettings",
            type: "general",
            keyValuePairs: [
                {
                    name: "unrealisticProbability",
                    type: "percent",
                    accessKey: "goal_unrealistic",
                },
                {
                    name: "swingConstraint",
                    type: "text",
                    accessKey: "swing_constraint",
                },
                {
                    name: "swingConstraintNumber",
                    type: "text",
                    accessKey: "swing_constraint_number",
                },
                {
                    name: "safeGuardAchievedWealthInLastYear",
                    type: "text",
                    accessKey: "safe_guard_wealth_last_year",
                },
                {
                    name: "minPortfoliosForLastYear",
                    type: "text",
                    accessKey: "minimum_portfolios_for_last_year",
                    conditionalExtract: true,
                    dependency: "safe_guard_wealth_last_year",
                    dependentValue: true,
                },
                {
                    name: "recommendTenure",
                    type: "text",
                    accessKey: "recommended_tenure",
                },
                {
                    name: "recommendTopUpInfusion",
                    type: "text",
                    accessKey: "recommended_top_up_infusion",
                },
                {
                    name: "recommendEscalatedGoal",
                    type: "text",
                    accessKey: "recommend_escalated_goal",
                },
                {
                    name: "downsideProtection",
                    type: "text",
                    accessKey: "downside_protection",
                },
                { name: "gridFrequency", type: "text", accessKey: "grid_frequency" },
                // { name: "wealthPathFrequency", type: "text", accessKey: "wealth_path_frequency" },
                {
                    name: "recommendInitialWealth",
                    type: "text",
                    accessKey: "recommend_initial_wealth",
                },
                { name: "backPassOnly", type: "text", accessKey: "back_pass_only" },
                { name: "adjustFees", type: "text", accessKey: "adjust_fees" },
                { name: "annualInBPS", type: "number", accessKey: "annual_in_bps" },
                { name: "wealthPath", type: "text", accessKey: "wealth_path" },
                {
                    name: "wealthPathProbability",
                    type: "percent",
                    accessKey: "wealth_path_probability",
                },
                {
                    name: "additionalWealthPaths",
                    type: "text",
                    accessKey: "additional_wealth_paths",
                },
                {
                    name: "pessimisticPathProbability",
                    type: "percent",
                    accessKey: "pessimistic_path_probability",
                },
                {
                    name: "optimisticPathProbability",
                    type: "percent",
                    accessKey: "optimistic_path_probability",
                },
                { name: "useCase", type: "text", accessKey: "use_case" },
                { name: "goalDropStep", type: "percent", accessKey: "goal_drop_step" },
                {
                    name: "aggregatedRetirementAccounts",
                    type: "text",
                    accessKey: "aggregatedRetirementAccounts",
                },
                {
                    name: "composite_portfolios",
                    type: "text",
                    accessKey: "composite_portfolios",
                },
                {
                    name: "PortfolioMappingTable",
                    type: "text",
                    accessKey: "PortfolioMappingTable",
                },
                {
                    name: "contributionRate",
                    type: "percent",
                    accessKey: "contributionRate",
                },
                { name: "fixedBenefits", type: "percent", accessKey: "fixedBenefits" },
                { name: "calculateGoals", type: "text", accessKey: "calculateGoals" },
                { name: "maxAge", type: "text", accessKey: "maxAge" },
                {
                    name: "splitWealthAcrossGoalOptimally",
                    type: "text",
                    accessKey: "spit_wealth_across_goal",
                },
                { name: "inflation", type: "percent", accessKey: "inflation" },
                {
                    name: "inflationMeasureForInfusions",
                    type: "customRadio",
                    accessKey: "inflation_measure_for_infusions",
                    onTrue: "NOMINAL",
                    onFalse: "REAL",
                },
                {
                    name: "useAFixedPlanningAge",
                    type: "text",
                    accessKey: "useAFixedPlanningAge",
                },
                { name: "planningAge", type: "number", accessKey: "planningAge" },
                {
                    name: "minimumPlanningAge",
                    type: "number",
                    accessKey: "minimumPlanningAge",
                },
                {
                    name: "minimumAnnuitisationAmount",
                    type: "number",
                    accessKey: "minimumAnnuitisationAmount",
                },
                {
                    name: "typeOfMortalityTable",
                    type: "text",
                    accessKey: "typeOfMortalityTable",
                },
                { name: "LYPackageID", type: "text", accessKey: "LYPackageID" },
                {
                    name: "simulationCount",
                    type: "number",
                    accessKey: "simulationCount",
                },
                {
                    name: "totalAllowedContribution",
                    type: "number",
                    accessKey: "totalAllowedContribution",
                },
                {
                    name: "totalAllowedCatchupContribution",
                    type: "number",
                    accessKey: "totalAllowedCatchupContribution",
                },
                {
                    name: "lifeYieldEnvironment",
                    type: "text",
                    accessKey: "lifeYieldEnvironment",
                },
                {
                    name: "simulationType",
                    type: "text",
                    accessKey: "simulationType",
                },
            ],
        },
        {
            name: "performance",
            type: "general",
            keyValuePairs: [
                { name: "riskOverlay", type: "text", accessKey: "riskOverlay" },
                {
                    name: "riskIndicator",
                    type: "selectGroup",
                    accessKey: "risk_indicator_flag_value",
                    conditionalExtract: true,
                    dependency: "riskOverlay",
                    dependentValue: true,
                    keyValuePairs: [
                        { name: "lower", accessKey: "lower" },
                        { name: "upper", accessKey: "upper" },
                    ],
                },
                {
                    name: "irrForRangeAdjustment",
                    type: "percent",
                    accessKey: "irr_range_adjustment",
                },
                { name: "sigma", type: "text", accessKey: "sigma" },
                {
                    name: "alternativeSigma",
                    type: "text",
                    accessKey: "alternative_sigma",
                },
                { name: "nodesPerSd", type: "text", accessKey: "nodes_per_sd" },
                {
                    name: "irrPerformanceThreshold",
                    type: "percent",
                    accessKey: "irr_performance_threshold",
                },
                {
                    name: "longTenureThreshold",
                    type: "number",
                    accessKey: "long_tenure_threshold",
                },
                {
                    name: "altNodesPerSd",
                    type: "number",
                    accessKey: "alt_nodes_per_sd",
                },
            ],
        },
    ],
    Configuration1: [
        { name: "portfolio_bundle", key: "portfolio_bundle.value" },
        {
            name: "reallocation_frequency_dates",
            key: "reallocation_frequency_dates",
        },
        { name: "allocation_on_retake_rtq", key: "allocation_on_retake_rtq" },
        {
            name: "allocation_on_invest_tenure_change",
            key: "allocation_on_invest_tenure_change",
        },
        {
            name: "allocation_on_re_prioritizing_goal",
            key: "allocation_on_re_prioritizing_goal",
        },
        { name: "new_goal", key: "new_goal" },
        { name: "wantsToReallocate", key: "wantsToReallocate" },
        { name: "goal_unrealistic", key: "goal_unrealistic" },
        { name: "loss_threshold_floor", key: "loss_threshold_floor" },
        { name: "swing_constraint", key: "swing_constraint" },
        { name: "swing_constraint_number", key: "swing_constraint_number" },
        {
            name: "minimum_portfolios_for_last_year",
            key: "minimum_portfolios_for_last_year",
        },
        { name: "safe_guard_wealth_last_year", key: "safe_guard_wealth_last_year" },
        { name: "recommended_top_up_infusion", key: "recommended_top_up_infusion" },
        { name: "recommended_tenure", key: "recommended_tenure" },
        { name: "recommend_escalated_goal", key: "recommend_escalated_goal" },
        { name: "maxAge", key: "maxAge" },
        { name: "downside_protection", key: "downside_protection" },
        { name: "grid_frequency", key: "grid_frequency" },
        // { name: "wealthPathFrequency", accessKey: "wealth_path_frequency" },
        { name: "reallocationFrequency", key: "reallocationFrequency" },
        { name: "recommend_initial_wealth", key: "recommend_initial_wealth" },
        { name: "back_pass_only", key: "back_pass_only" },
        { name: "adjust_fees", key: "adjust_fees" },
        { name: "annual_in_bps", key: "annual_in_bps" },
        { name: "wealth_path", key: "wealth_path" },
        { name: "wealth_path_probability", key: "wealth_path_probability" },
        { name: "additionalWealthPaths", key: "additional_wealth_paths" },
        { name: "pessimisticPathProbability", key: "pessimistic_path_probability" },
        { name: "optimisticPathProbability", key: "optimistic_path_probability" },
        {
            name: "aggregatedRetirementAccounts",
            key: "aggregatedRetirementAccounts",
        },
        {
            name: "composite_portfolios",
            key: "composite_portfolios",
        },
        { name: "useCase", key: "use_case" },
        { name: "PortfolioMappingTable", key: "PortfolioMappingTable" },
        { name: "contributionRate", key: "contributionRate" },
        { name: "fixedBenefits", key: "fixedBenefits" },
        { name: "calculateGoals", key: "calculateGoals" },
        { name: "spit_wealth_across_goal", key: "spit_wealth_across_goal" },
        { name: "inflation", key: "inflation" },
        {
            name: "inflation_measure_for_infusions",
            key: "inflation_measure_for_infusions",
        },
        { name: "riskOverlay", key: "riskOverlay" },
        { name: "risk_indicator_flag_value", key: "risk_indicator_flag_value" },
        { name: "irr_range_adjustment", key: "irr_range_adjustment" },
        { name: "sigma", key: "sigma" },
        { name: "alternative_sigma", key: "alternative_sigma" },
        { name: "nodes_per_sd", key: "nodes_per_sd" },
        { name: "useAFixedPlanningAge", key: "useAFixedPlanningAge" },
        { name: "planningAge", key: "planningAge" },
        { name: "minimumPlanningAge", key: "minimumPlanningAge" },
        { name: "minimumAnnuitisationAmount", key: "minimumAnnuitisationAmount" },
        { name: "typeOfMortalityTable", key: "typeOfMortalityTable" },
        { name: "goalDropStep", accessKey: "goal_drop_step" },
        { name: "simulationCount", accessKey: "simulationCount" },
    ],
    Configuration2: [
        { name: "portfolio_bundle", key: "portfolio_bundle.value" },
        {
            name: "reallocation_frequency_dates",
            key: "reallocation_frequency_dates",
        },
        { name: "allocation_on_retake_rtq", key: "allocation_on_retake_rtq" },
        {
            name: "allocation_on_invest_tenure_change",
            key: "allocation_on_invest_tenure_change",
        },
        {
            name: "allocation_on_re_prioritizing_goal",
            key: "allocation_on_re_prioritizing_goal",
        },
        { name: "new_goal", key: "new_goal" },
        { name: "wantsToReallocate", key: "wantsToReallocate" },
        { name: "goal_unrealistic", key: "goal_unrealistic" },
        { name: "loss_threshold_floor", key: "loss_threshold_floor" },
        { name: "swing_constraint", key: "swing_constraint" },
        { name: "swing_constraint_number", key: "swing_constraint_number" },
        {
            name: "minimum_portfolios_for_last_year",
            key: "minimum_portfolios_for_last_year",
        },
        { name: "recommended_top_up_infusion", key: "recommended_top_up_infusion" },
        { name: "recommended_tenure", key: "recommended_tenure" },
        { name: "recommend_escalated_goal", key: "recommend_escalated_goal" },
        { name: "maxAge", key: "maxAge" },
        { name: "downside_protection", key: "downside_protection" },
        { name: "grid_frequency", key: "grid_frequency" },
        // { name: "wealthPathFrequency", accessKey: "wealth_path_frequency" },
        { name: "reallocationFrequency", key: "reallocationFrequency" },
        { name: "recommend_initial_wealth", key: "recommend_initial_wealth" },
        { name: "back_pass_only", key: "back_pass_only" },
        { name: "adjust_fees", key: "adjust_fees" },
        { name: "annual_in_bps", key: "annual_in_bps" },
        { name: "wealth_path", key: "wealth_path" },
        { name: "wealth_path_probability", key: "wealth_path_probability" },
        { name: "additionalWealthPaths", key: "additional_wealth_paths" },
        { name: "pessimisticPathProbability", key: "pessimistic_path_probability" },
        { name: "optimisticPathProbability", key: "optimistic_path_probability" },
        {
            name: "aggregatedRetirementAccounts",
            key: "aggregatedRetirementAccounts",
        },
        {
            name: "composite_portfolios",
            key: "composite_portfolios",
        },
        { name: "useCase", key: "use_case" },
        { name: "PortfolioMappingTable", key: "PortfolioMappingTable" },
        { name: "contributionRate", key: "contributionRate" },
        { name: "fixedBenefits", key: "fixedBenefits" },
        { name: "calculateGoals", key: "calculateGoals" },
        { name: "spit_wealth_across_goal", key: "spit_wealth_across_goal" },
        { name: "inflation", key: "inflation" },
        {
            name: "inflation_measure_for_infusions",
            key: "inflation_measure_for_infusions",
        },
        { name: "riskOverlay", key: "riskOverlay" },
        { name: "risk_indicator_flag_value", key: "risk_indicator_flag_value" },
        { name: "irr_range_adjustment", key: "irr_range_adjustment" },
        { name: "sigma", key: "sigma" },
        { name: "alternative_sigma", key: "alternative_sigma" },
        { name: "nodes_per_sd", key: "nodes_per_sd" },
        { name: "useAFixedPlanningAge", key: "useAFixedPlanningAge" },
        { name: "planningAge", key: "planningAge" },
        { name: "minimumPlanningAge", key: "minimumPlanningAge" },
        { name: "minimumAnnuitisationAmount", key: "minimumAnnuitisationAmount" },
        { name: "typeOfMortalityTable", key: "typeOfMortalityTable" },
        { name: "goalDropStep", accessKey: "goal_drop_step" },
    ],
    Configuration3: [
        { name: "portfolio_bundle", key: "portfolio_bundle.value" },
        {
            name: "reallocation_frequency_dates",
            key: "reallocation_frequency_dates",
        },
        { name: "allocation_on_retake_rtq", key: "allocation_on_retake_rtq" },
        {
            name: "allocation_on_invest_tenure_change",
            key: "allocation_on_invest_tenure_change",
        },
        {
            name: "allocation_on_re_prioritizing_goal",
            key: "allocation_on_re_prioritizing_goal",
        },
        { name: "new_goal", key: "new_goal" },
        { name: "wantsToReallocate", key: "wantsToReallocate" },
        { name: "goal_unrealistic", key: "goal_unrealistic" },
        { name: "loss_threshold_floor", key: "loss_threshold_floor" },
        { name: "swing_constraint", key: "swing_constraint" },
        { name: "swing_constraint_number", key: "swing_constraint_number" },
        {
            name: "minimum_portfolios_for_last_year",
            key: "minimum_portfolios_for_last_year",
        },
        { name: "recommended_top_up_infusion", key: "recommended_top_up_infusion" },
        { name: "recommended_tenure", key: "recommended_tenure" },
        { name: "recommend_escalated_goal", key: "recommend_escalated_goal" },
        { name: "maxAge", key: "maxAge" },
        { name: "downside_protection", key: "downside_protection" },
        { name: "grid_frequency", key: "grid_frequency" },
        // { name: "wealthPathFrequency", accessKey: "wealth_path_frequency" },
        { name: "reallocationFrequency", key: "reallocationFrequency" },
        { name: "recommend_initial_wealth", key: "recommend_initial_wealth" },
        { name: "back_pass_only", key: "back_pass_only" },
        { name: "adjust_fees", key: "adjust_fees" },
        { name: "annual_in_bps", key: "annual_in_bps" },
        { name: "wealth_path", key: "wealth_path" },
        { name: "wealth_path_probability", key: "wealth_path_probability" },
        { name: "additionalWealthPaths", key: "additional_wealth_paths" },
        { name: "pessimisticPathProbability", key: "pessimistic_path_probability" },
        { name: "optimisticPathProbability", key: "optimistic_path_probability" },
        { name: "useCase", key: "use_case" },
        {
            name: "aggregatedRetirementAccounts",
            key: "aggregatedRetirementAccounts",
        },
        {
            name: "composite_portfolios",
            key: "composite_portfolios",
        },
        { name: "PortfolioMappingTable", key: "PortfolioMappingTable" },
        { name: "contributionRate", key: "contributionRate" },
        { name: "fixedBenefits", key: "fixedBenefits" },
        { name: "calculateGoals", key: "calculateGoals" },
        { name: "LYPackageID", key: "LYPackageID" },
        { name: "spit_wealth_across_goal", key: "spit_wealth_across_goal" },
        { name: "inflation", key: "inflation" },
        {
            name: "inflation_measure_for_infusions",
            key: "inflation_measure_for_infusions",
        },
        { name: "riskOverlay", key: "riskOverlay" },
        { name: "risk_indicator_flag_value", key: "risk_indicator_flag_value" },
        { name: "irr_range_adjustment", key: "irr_range_adjustment" },
        { name: "sigma", key: "sigma" },
        { name: "alternative_sigma", key: "alternative_sigma" },
        { name: "nodes_per_sd", key: "nodes_per_sd" },
        { name: "useAFixedPlanningAge", key: "useAFixedPlanningAge" },
        { name: "planningAge", key: "planningAge" },
        { name: "minimumPlanningAge", key: "minimumPlanningAge" },
        { name: "minimumAnnuitisationAmount", key: "minimumAnnuitisationAmount" },
        { name: "typeOfMortalityTable", key: "typeOfMortalityTable" },
        { name: "goalDropStep", accessKey: "goal_drop_step" },
    ],
};
