import React, { useState, useEffect, Fragment } from "react";
import { useForm } from "react-hook-form";
import { Tabs, Tab } from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import { MuiForm } from "common/mui-form/MuiForm";
import GoeForm from "../common/GoeForm";

const formFields = [
    {
        label: "RISK ON",
        name: "riskOn",
        type: "text",
        values: ["Yes", "No"],
        key: "riskOn",
        id: "riskOn",
        disabled: true,
    },
    {
        label: "MEAN RETURNS",
        name: "meanPercent",
        type: "number",

        default: "mean returns",
        key: "meanPercent",
        disabled: true,
    },
    {
        label: "STANDARD DEVIATION",
        name: "sdPercent",
        type: "number",
        default: "standard deviation",
        key: "sdPercent",
        disabled: true,
    },
    {
        label: "ASSETS ALLOCATION",
        name: "assetAllocations",
        type: "select-group",
        key: "assets_allocation",
        defaultValues: [{ name: { key: "bond", value: "Bond" }, value: 0 }],
        disabled: true,
        options: [
            { key: "bond", value: "Bond" },
            { key: "equity", value: "Equity" },
            { key: "money_market", value: "Money Market" },
        ],
    },
    {
        label: "FEES ADJUSTER(ANNUAL IN BPS)",
        name: "feesAdjuster",
        type: "number",
        key: "feesAdjuster",
        default: "fees adjuster",
        disabled: true,
    },
];

const useStyles = makeStyles((theme) => ({
    paginationContainer: {
        margin: "2rem",
        boxShadow: "0 0 11px 0 rgba(0, 0, 0, 0.1)",
        border: "solid 1px #f2f2f2",
        backgroundColor: "#ffffff",
        "& .MuiTab-root": {
            minWidth: "0px",
            padding: "0px 12px",
            boxShadow: "0 0 11px 0 rgba(0,0,0,0.1)",
            border: "solid 1px #f2f2f2",
            color: theme.palette.primary.main,
        },
        "& .MuiTabs-root": {
            marginBottom: "1rem",
        },
        "& .Mui-selected": {
            borderBottom: "0px !important",
            color: theme.palette.common.white,
            background: theme.palette.primary.main,
        },
    },
    tabIndicator: {
        background: "rgba(0,0,0,0)",
    },
}));

function getValue(data, index) {
    const value = { ...data?.[index] };
    if (value["riskOn"]) {
        value["riskOn"] = "Yes";
    } else {
        value["riskOn"] = "No";
    }
    return value;
}

export default function PortfolioCard({ data }) {
    const classes = useStyles();
    const methods = useForm({ mode: "onChange", defaultValues: getValue(data, 0) });
    const { reset, getValues } = methods;
    const dummyArray = Array(data.length).fill({ name: "", riskOn: "No", meanPercent: 0, sdPercent: 0 ,   feesAdjuster: "",});
    const [selected, setSelected] = useState(0);

    const handleTabChange = (e, tabIndex) => {
        setSelected(tabIndex);
        reset(getValue(data, tabIndex));
    };

    useEffect(() => {
        setSelected(0);
    }, [data]);

    const TabPanel = ({ index }) => {
        const values = getValues();
        return (
            <Fragment key={index}>
                <div hidden={selected !== index} style={{ marginLeft: "50px" }}>
                    {formFields.map((field) => {
                        const value = values[field.name];
                        return (
                            <GoeForm label={field.label} key={field.name}>
                                <MuiForm
                                    key={field.key}
                                    field={field}
                                    methods={methods}
                                    style={{ width: "45%" }}
                                    variant="outlined"
                                    value={value}
                                />
                            </GoeForm>
                        );
                    })}
                </div>
            </Fragment>
        );
    };

    return (
        <div className={classes.paginationContainer} hidden={data.length === 0}>
            <Tabs
                value={selected}
                indicatorColor="primary"
                textColor="primary"
                onChange={handleTabChange}
                aria-label="disabled tabs example"
                TabIndicatorProps={{ className: classes.tabIndicator }}
            >
                {dummyArray.map((item, index) => (
                    <Tab key={item.toString() + index.toString()} value={index} label={index + 1} />
                ))}
            </Tabs>
            <TabPanel index={selected} />
        </div>
    );
}
