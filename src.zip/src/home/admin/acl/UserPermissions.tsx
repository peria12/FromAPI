import React, { useEffect, useState, useRef } from "react";
import makeStyles from "@mui/styles/makeStyles";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { green } from "@mui/material/colors";
import Chip from "@mui/material/Chip";
import Tooltip from "@mui/material/Tooltip";
import HighlightOffIcon from "@mui/icons-material/HighlightOff";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";

const useRowStyles = makeStyles((theme) => ({
    root: {
        display: "flex",
        justifyContent: "center",
        flexWrap: "wrap",
        "& > *": {
            margin: theme.spacing(0.5),
        },
    },
    dialog: {
        minWidth: 120,
    },
    header: {
        color: "grey",
        fontSize: "1.12rem",
    },
    red: {
        backgroundColor: "#f50057",
        color: "#ffffff",
    },
    green: {
        backgroundColor: green[500],
        color: "#ffffff",
    },
    btn: {
        textTransform: "capitalize",
    },
    delBtn: {
        color: "#ffffff",
    },
    closeBtn: {
        position: "absolute",
        right: theme.spacing(1),
        top: theme.spacing(1),
        color: theme.palette.grey[500],
    },
}));

const findDetails = (list, prop, val) => list.find((item) => item[prop] === val);

const getTitle = (items) => items.map((item) => item["title"]).join(" / ");

const Permissions = ({ entries, setEntries, userRemovedEvent, zoneId, typeId, app }) => {
    const classes = useRowStyles();

    const handleDelete = (id) => {
        const entry = entries.find(e => e.id == id)
        setEntries(entries.filter((e) => e.id != id));

        if (entry.type == "user") {
            userRemovedEvent(app._id, zoneId, typeId, id, entry.color == "red", false);
        } else {
            userRemovedEvent(app._id, zoneId, typeId, id, false, entry.color == "red");
        }
    };

    return (
        <React.Fragment>
            <div className={classes.root}>
                {entries.map((entry, index) => (
                    <Tooltip title={entry.description} key={index}>
                        <Chip
                            variant="outlined"
                            size="small"
                            label={entry.title || entry.description}
                            deleteIcon={<HighlightOffIcon className={classes.delBtn} />}
                            onDelete={entry.isClickable ? () => handleDelete(entry.id) : undefined}
                            className={entry.color === "red" ? classes.red : classes.green}
                        />
                    </Tooltip>
                ))}
            </div>
        </React.Fragment>
    );
};

export default function UserPermissions({
    typeId,
    zoneId,
    app,
    allUserAccess,
    setOpenDialog,
    openDialog,
    userRemovedEvent,
    tab
}) {
    const [entries, setEntries] = useState([]);
    const descriptionElementRef: any = useRef<any>(null);
    const classes = useRowStyles();

    useEffect(() => {
        if (openDialog) {
            const { current: descriptionElement } = descriptionElementRef;
            if (descriptionElement !== null) {
                descriptionElement.focus();
            }
        }
    }, [openDialog]);

    const sync = (people, color, allUserAccess) => {
        function addDefault(people: any) {
            let initialEntry = {};
            if (color === "green") {
                initialEntry = {
                    id: "no_one",
                    title: "No One",
                    description: "No Users",
                    color: "red",
                };
            } else {
                initialEntry = {
                    id: "everyone",
                    title: "Everyone",
                    description: "All Users",
                    color: "green",
                };
            }
            const records: any = [initialEntry];
            if (people) {
                records.push(...people);
            }
            setEntries(records);
        }
        if (people.length > 0) {
            const users = people.map((id: any) => {
                const person = allUserAccess[id]?.info;
                if (person) {
                    return {
                        id,
                        title: person.name,
                        description: person.email,
                        color,
                        isClickable: true,
                        type: "user"
                    };
                }
                return {};
            });
            addDefault(users);
        } else {
            addDefault(null);
        }
    }

    const title = React.useMemo(() => {
        if (!app) {
            return "";
        }
        let zoneInfo: any = {};
        let permissionType: any = {};
        let title = app["title"];
        if (zoneId) {
            zoneInfo = findDetails(app.zones, "name", zoneId);
            permissionType = findDetails(zoneInfo.access, "name", typeId);
            title = getTitle([app, zoneInfo, permissionType]);
        }
        return title;
    }, [app, typeId, zoneId]);

    const getName = React.useCallback((info) => {
        if (info.type == "adgroup") {
            return `${info.name} (Group)`
        }
        if (info.type == "supervisor") {
            return `${info.name} (Org)`
        }
        if (info.type == "department") {
            return `${info.name} (Dept)`
        }

    }, [])

    React.useMemo(() => {

        if (!allUserAccess) {
            if (entries.length) setEntries([])
            return ;
        }

        const findAccess = (ac) => ac.app === app._id && ac.zone === zoneId && ac.type === typeId;

        if (tab == "user") {
            const userIds = Object.keys(allUserAccess).filter(x => !allUserAccess[x].info.type || allUserAccess[x].info.type == "user");
            const isDefaultAccessType = allUserAccess?.new_user?.access.find(findAccess);
            const index = userIds.indexOf("new_user");
            if (index > -1) {
                userIds.splice(index, 1);
            }
            if (isDefaultAccessType) {
                const usersWithoutAccess: any = userIds.filter(
                    (id) => !allUserAccess[id].access?.find(findAccess)
                );
                sync(usersWithoutAccess, "red", allUserAccess)
            } else {
                const usersWithAccess: any = userIds.filter(
                    (id) => allUserAccess[id].access?.find(findAccess)
                );
                sync(usersWithAccess, "green", allUserAccess)
            }
        } else {
            const groupIds = Object.keys(allUserAccess).filter(x => allUserAccess[x].info.type && allUserAccess[x].info.type != "user");
            const newEntries: any = []
            groupIds.forEach(gid => {
                const group = allUserAccess[gid]

                if (group.access?.find(findAccess)) {
                    newEntries.push({
                        id: gid,
                        title: getName(group.info),
                        description: group.info.id,
                        color: "green",
                        isClickable: true,
                        type: "group"
                    })
                }
                if (group.exclude_access?.find(findAccess)) {
                    newEntries.push({
                        id: gid,
                        title: getName(group.info),
                        description: group.info.id,
                        color: "red",
                        isClickable: true,
                        type: "group"
                    })
                }
            })
            newEntries.sort((a, b) => b.color.localeCompare(a.color))
            setEntries(newEntries)
        }
    }, [allUserAccess, app, typeId, zoneId, tab]);

    const handleClose = () => {
        setOpenDialog(false);
    };

    return (
        <React.Fragment>
            <Dialog
                open={openDialog}
                onClose={handleClose}
                scroll={"paper"}
                aria-labelledby="dialog-title"
                aria-describedby="dialog-description"
                maxWidth={"sm"}
                fullWidth={true}
            >
                <DialogTitle id="dialog-title" className={classes.header}>
                    {title}
                    <IconButton aria-label="close" className={classes.closeBtn} onClick={handleClose} size="large">
                        <CloseIcon fontSize="small" />
                    </IconButton>
                </DialogTitle>
                <DialogContent dividers={true}>
                    <DialogContentText component="div" id="dialog-description" ref={descriptionElementRef}>
                        <Permissions
                            entries={entries}
                            setEntries={setEntries}
                            userRemovedEvent={userRemovedEvent}
                            zoneId={zoneId}
                            typeId={typeId}
                            app={app}
                        />
                    </DialogContentText>
                </DialogContent>
            </Dialog>
        </React.Fragment>
    );
}
