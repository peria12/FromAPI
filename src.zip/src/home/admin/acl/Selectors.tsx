import { Chip, Tooltip } from "@mui/material";
import AutocompleteField from "common/AutocompleteField";
import React, { useCallback, useState } from "react";
import Api from "utils/api";

function Selector({ name, type, items: peopleMap, setItems: setPeopleMap, placeholder, provider, fields }) {
    const [value, setValue] = useState("");
    const handler = (_, item) => {
        if (item) {
            setPeopleMap({ ...peopleMap, [item.id]: item });
            setValue(item.id);
        }
    };
    const handleDelete = (id) => {
        const newPeopleMap = { ...peopleMap };
        delete newPeopleMap[id];
        setPeopleMap(newPeopleMap);
    };

    const getColor: any = useCallback((type) => {
        if (type == "user") return "primary";
        if (type == "adgroup") return "secondary";
        if (type == "supervisor") return "success";
        return "warning";
    }, []);

    return (
        <div className="d-flex flex-column border rounded m-1 px-2" style={{ minHeight: "12em" }} title={name}>
            <div className="p-2" style={{ width: "15em" }}>
                <AutocompleteField
                    key={value}
                    onChange={handler}
                    provider={provider}
                    isGrouped={true}
                    placeholder={placeholder}
                    inputPropsStyle={{ height: "40px" }}
                    fields={fields}
                    popperWidth="900px"
                />
            </div>
            <div className="d-flex mb-2">
                <div className="flex-grow-1">
                    {Object.values(peopleMap)
                        .sort((a: any, b: any) => a.label.localeCompare(b.label))
                        .filter((p: any) => p.type == type)
                        .map((p: any) => (
                            <Tooltip title={p.mail || p.description} key={p.id}>
                                <Chip
                                    label={p.label}
                                    size="small"
                                    color={getColor(type)}
                                    onDelete={() => handleDelete(p.id)}
                                    className="m-1"
                                />
                            </Tooltip>
                        ))}
                </div>
            </div>
        </div>
    );
}

const mapGroup = (obj) => ({
    id: `adgroup-${obj.id}`,
    group_id: obj.id,
    name: obj.displayName,
    description: obj.description,
    type: "adgroup",
    label: `${obj.displayName}`,
});

const mapDepartment = (obj) => ({
    id: `department-${obj.dept_code}`,
    dept_id: obj.dept_code,
    group_id: obj.dept_code,
    name: obj.dept_name,
    description: obj.dept_name,
    type: "department",
    label: `${obj.dept_name}`,
});

const mapUserOrg = (obj) => ({
    id: `supervisor-${obj.emp_id}`,
    emp_id: obj.emp_id,
    email: obj.emailaddress,
    group_id: `${obj.emp_id}`,
    name: `${obj.first_name} ${obj.last_name}`,
    description: `${obj.last_name}, ${obj.first_name}'s Organization`,
    label: `${obj.first_name} ${obj.last_name}`,
    type: "supervisor",
});

export const mapUser = (obj) => ({
    id: obj.id,
    label: obj.displayName,
    mail: obj.mail,
    givenName: obj.givenName,
    name: obj.displayName,
    category: "Users",
    type: "user",
});

const mapUserOkta = (obj) => ({
    id: obj.id,
    label: `${obj.profile.firstName} ${obj.profile.lastName} ${obj.profile.login} (External)`,
    mail: obj.profile.email,
    givenName: obj.profile.lastName,
    name: `${obj.profile.firstName} ${obj.profile.lastName}`,
    local: true,
    type: "user",
    category: "External Users (Okta)",
});

const provider = (query) => {
    if (!query) return Promise.resolve([[], 0]);

    const query1 = Api.searchUsersOkta(query).then((data) => data.users?.map(mapUserOkta) || []);

    const query2 = Api.searchUsers(query)
        .then((results: any) => results.value.map(mapUser))
        .catch((e) => console.log(e));

    return Promise.all([query1, query2]).then(([a, b]) => {
        return [[...a, ...b], a.length + b.length];
    });
};

const providerGroup = (query) => {
    if (!query) return Promise.resolve([[], 0]);

    return Api.searchGroups(query)
        .then((results: any) => {
            const ret = results.value.map(mapGroup);
            return [ret, ret.length];
        })
        .catch((e) => console.log(e));
};

const providerDepartment = (query) => {
    if (!query) return Promise.resolve([[], 0]);

    return Api.searchDepartments(query)
        .then((results: any) => {
            const ret = results.departments.map(mapDepartment);
            return [ret, ret.length];
        })
        .catch((e) => console.log(e));
};

const providerUserOrg = (query) => {
    if (!query) return Promise.resolve([[], 0]);

    return Api.searchUserOrgs(query)
        .then((results: any) => {
            const ret = results.user_orgs.map(mapUserOrg);
            return [ret, ret.length];
        })
        .catch((e) => console.log(e));
};

const peopleFields = [
    { label: "Name", key: "name", width: "50%" },
    { label: "Email", key: "mail", width: "50%" },
];
const groupFields = [
    { label: "Name", key: "name", width: "40%" },
    { label: "Description", key: "description", width: "60%" },
];
const userOrgFields = [
    { label: "ID", key: "emp_id", width: "10%" },
    { label: "Name", key: "name", width: "40%" },
    { label: "Email", key: "email", width: "50%" },
];
const deptFields = [
    { label: "Dept ID", key: "dept_id", width: "30%" },
    { label: "Dept Name", key: "name", width: "70%" },
];

export function Selectors({ peopleMap, setPeopleMap, tab }) {
    return (
        <div className="d-flex flex-column me-2">
            {tab == "user" && (
                <Selector
                    name="Users"
                    placeholder="Users"
                    type="user"
                    items={peopleMap}
                    setItems={setPeopleMap}
                    provider={provider}
                    fields={peopleFields}
                />
            )}
            {tab == "group" && (
                <>
                    <Selector
                        name="AD Groups"
                        placeholder="AD Groups"
                        type="adgroup"
                        items={peopleMap}
                        setItems={setPeopleMap}
                        provider={providerGroup}
                        fields={groupFields}
                    />
                    <Selector
                        name="User Orgs"
                        placeholder="User Orgs"
                        type="supervisor"
                        items={peopleMap}
                        setItems={setPeopleMap}
                        provider={providerUserOrg}
                        fields={userOrgFields}
                    />
                    <Selector
                        name="Departments"
                        placeholder="Departments"
                        type="department"
                        items={peopleMap}
                        setItems={setPeopleMap}
                        provider={providerDepartment}
                        fields={deptFields}
                    />
                </>
            )}
        </div>
    );
}
