import React, { useEffect } from "react";
import Popover from "@mui/material/Popover";
import Button from "@mui/material/Button";
import { Badge, Box } from "@mui/material";
import SaveIcon from "@mui/icons-material/Save";
import FTTable from "common/FTTable";

export default function ActionPopover({ changes, onSave, peopleMap }) {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const [rows, setRows] = React.useState([]);
    const entityTypeMap = {
        "user": "User",
        "adgroup": "AD Group",
        "supervisor": "User Org",
        "department": "Department",
    }

    useEffect(() => {
        setRows(
            changes
                .map((c) => ({
                    app: c[0],
                    zone: c[1],
                    type: c[2],
                    person: peopleMap[c[3]]?.label,
                    userType: entityTypeMap[peopleMap[c[3]]?.type],
                    accessType: c[4] ? "Grant" : "Revoke",
                    action: c[5] ? <Box color="success.main">Add</Box> : <Box color="error.main">Remove</Box>,
                }))
                .sort(
                    (a, b) => a.app.localeCompare(b.app) || a.zone.localeCompare(b.zone) || a.type.localeCompare(b.type)
                )
        );
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [changes]);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const open = Boolean(anchorEl);
    const id = open ? "simple-popover" : undefined;
    const columns = [
        { label: "App", key: "app" },
        { label: "Zone", key: "zone" },
        { label: "Access", key: "type" },
        { label: "Entity Type", key: "userType" },
        { label: "User/Group", key: "person" },
        { label: "Access Type", key: "accessType" },
        { label: "Action", key: "action" },
    ];

    return (
        <div>
            <Badge badgeContent={changes.length} color="secondary">
                <Button disabled={!changes.length} variant="contained" color="primary" onClick={handleClick}>
                    REVIEW
                </Button>
            </Badge>
            <Popover
                id={id}
                open={open}
                anchorEl={anchorEl}
                onClose={handleClose}
                anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "center",
                }}
                transformOrigin={{
                    vertical: "top",
                    horizontal: "center",
                }}
            >
                <div className="p-3">
                    <h5> Pending Changes </h5>
                </div>
                <div className="px-3 pb-3">
                    <FTTable columns={columns} rows={rows}></FTTable>
                </div>
                <div className="d-flex flex-row-reverse bd-highlight px-3 pb-3">
                    <div className="px-2">
                        <Button
                            onClick={() => {
                                handleClose();
                                onSave();
                            }}
                            variant="contained"
                            color="primary"
                            startIcon={<SaveIcon />}
                        >
                            Save
                        </Button>
                    </div>
                    <div className="px-2">
                        <Button variant="contained" onClick={handleClose}>
                            Cancel
                        </Button>
                    </div>
                </div>
            </Popover>
        </div>
    );
}
