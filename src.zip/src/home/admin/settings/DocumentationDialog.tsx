import React, { useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import Typography from "@mui/material/Typography";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";

import RichTextEditor from "common/RichTextEditor";

const status = ["Draft", "Active", "Inactive"];

export default function DocumentationDialog({ classes, open, setOpen, onAdd, metaDataProps }) {
    const docs = metaDataProps?.documentation || {};
    const doc = metaDataProps?.orignalDoc || {};
    const [docum, setDocum] = useState<any>({
        status: docs?.status || status?.[0],
        search_texts: docs?.search_texts || [],
        description: docs?.description || "",
    });

    function updateDocState(key, value) {
        if (key === "search_texts") {
            value = value.split(",");
        }
        setDocum({ ...docum, [key]: value });
    }

    const handleRadioChange = (event) => {
        updateDocState("status", event?.target?.value);
    };

    const transformTitle = (_idStr) => {
        if (_idStr && typeof _idStr === "string") {
            const words = _idStr.split("_");
            return words
                .map((word) => {
                    return (word[0] || "")?.toUpperCase() + word?.substring(1);
                })
                .join(" ");
        }
        return _idStr;
    };

    return (
        <Dialog open={open} onClose={() => setOpen(false)} maxWidth="lg" aria-labelledby="dialog">
            <DialogTitle id="responsive-dialog-title">{transformTitle(doc?._id)} Documentation</DialogTitle>
            <DialogContent>
                <DialogContentText>
                    <div className={classes.inlineFC}>
                        <Typography className={classes.formLabel} style={{ width: "auto" }} color="textPrimary">
                            Status
                        </Typography>
                        <FormControl component="fieldset" style={{ paddingLeft: "10px" }}>
                            <RadioGroup
                                row
                                aria-label="status"
                                name="status"
                                value={docum?.status}
                                onChange={handleRadioChange}
                            >
                                {status.map((s) => (
                                    <FormControlLabel key={s} value={s} control={<Radio color="primary" />} label={s} />
                                ))}
                            </RadioGroup>
                        </FormControl>
                    </div>
                    <div className={classes.formControl} style={{ display: "flex" }}>
                        <Typography className={classes.formLabel} style={{ width: "10%" }} color="textPrimary">
                            Search Text
                        </Typography>
                        <TextField
                            size="small"
                            style={{ width: "80%", paddingLeft: "10px" }}
                            value={docum?.search_texts || ""}
                            variant="standard"
                            onChange={(event) => updateDocState("search_texts", event.target.value)}
                        />
                    </div>
                    <div className={classes.formControl}>
                        <Typography className={classes.formLabel} color="textPrimary">
                            {" "}
                            Description{" "}
                        </Typography>
                        <RichTextEditor
                            html={docum?.description}
                            onChange={(text) => updateDocState("description", text)}
                        />
                    </div>
                </DialogContentText>
            </DialogContent>
            <DialogActions>
                <Button
                    style={{ textTransform: "capitalize" }}
                    variant="contained"
                    onClick={() => setOpen(false)}
                    color="secondary"
                >
                    {" "}
                    Close{" "}
                </Button>
                <Button
                    style={{ textTransform: "capitalize" }}
                    variant="contained"
                    onClick={() => {
                        setOpen(false);
                        onAdd(docum);
                    }}
                    color="primary"
                >
                    {" "}
                    Update{" "}
                </Button>
            </DialogActions>
        </Dialog>
    );
}
