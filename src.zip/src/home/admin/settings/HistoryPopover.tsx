import React, { useEffect } from "react";
import Popover from "@mui/material/Popover";
import Button from "@mui/material/Button";
import { Chip, Link, Radio } from "@mui/material";
import SaveIcon from "@mui/icons-material/Save";
import FTTable from "common/FTTable";
import moment from "moment";

export default function HistoryPopover({ history, onSelect, activeVersion, onDiff }) {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const [rows, setRows] = React.useState([]);
    const [radio, setRadio] = React.useState("");
    const fixTime = (ts) => moment.utc(ts).local().format("YYYY-MM-DD HH:mm:ss");
    const isActive = (id, i) => {
        if (activeVersion) {
            return activeVersion.rec_id == id;
        }
        return i == 0;
    };

    const styleFunc = (row) => {
        return row.active ? { backgroundColor: "#dddddd" } : {};
    };

    useEffect(() => {
        setRows(
            history.map((x, i) => {
                const active = isActive(x.rec_id, i);
                return {
                    active,
                    timestamp: active ? (
                        fixTime(x.timestamp)
                    ) : (
                        <Link
                            component="button"
                            variant="body2"
                            onClick={() => {
                                onSelect(x);
                            }}
                        >
                            {fixTime(x.timestamp)}
                        </Link>
                    ),
                    author: x.author || x.user,
                    comment: x.archived ? (
                        x.comment
                    ) : (
                        <>
                            {" "}
                            {x.comment} <Chip label="Latest" color="primary" size="small" />{" "}
                        </>
                    ),
                    diff: (
                        <Radio
                            checked={radio == x.rec_id}
                            disabled={active}
                            onChange={() => setRadio(x.rec_id)}
                            color="primary"
                            size="small"
                        />
                    ),
                };
            })
        );
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [history, activeVersion, radio]);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const open = Boolean(anchorEl);
    const id = open ? "simple-popover" : undefined;
    const columns = [
        { label: "Time", key: "timestamp" },
        { label: "Author", key: "author" },
        { label: "Comment", key: "comment" },
        { label: "Diff", key: "diff" },
    ];

    return (
        <div>
            <Button
                variant="contained"
                color="primary"
                size="small"
                onClick={handleClick}
                disabled={history.length < 1}
            >
                History
            </Button>
            <Popover
                id={id}
                open={open}
                anchorEl={anchorEl}
                onClose={handleClose}
                anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "center",
                }}
                transformOrigin={{
                    vertical: "top",
                    horizontal: "center",
                }}
            >
                <div className="p-3">
                    <h5> File Edit History </h5>
                </div>
                <div className="px-3 pb-3" style={{ maxHeight: "calc(100vh - 300px)", overflowY: "auto" }}>
                    <FTTable columns={columns} rows={rows} rowStyle={styleFunc}></FTTable>
                </div>
                <div className="d-flex flex-row-reverse bd-highlight px-3 pb-3">
                    <div className="px-2">
                        <Button
                            onClick={() => {
                                handleClose();
                                onDiff(radio);
                            }}
                            variant="contained"
                            color="primary"
                            startIcon={<SaveIcon />}
                        >
                            Diff
                        </Button>
                    </div>
                    <div className="px-2">
                        <Button variant="contained" onClick={handleClose}>
                            Close
                        </Button>
                    </div>
                </div>
            </Popover>
        </div>
    );
}
