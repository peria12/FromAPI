import React, { useState } from "react";
import List from "@mui/material/List";
import ListSubheader from "@mui/material/ListSubheader";
import ListItem from "@mui/material/ListItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Collapse from "@mui/material/Collapse";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import LibraryBooksOutlinedIcon from "@mui/icons-material/LibraryBooksOutlined";
import AddIcon from "@mui/icons-material/Add";
import TextField from "@mui/material/TextField";
import * as stableStringify from "json-stable-stringify";

import ConfirmDialog from "common/ConfirmDialog";
import Access from "utils/access";
import { AddIconButton, SaveIconButton, DeleteIconButton } from "common/FTButtons";

const stringify = (value) => {
    return stableStringify({ ...value, __meta: undefined, __doc: undefined }, { space: " " });
};

const jsonStringify = (value) => {
    return JSON.stringify({ ...value, __meta: undefined, __doc: undefined });
};

export default function CollectionList({
    classes,
    adminSettings,
    setActiveItem,
    activeItem,
    setAdminSettings,
    setIsNewDoc,
    settingOrg,
    setValue,
    deleteCollection,
    collectionName,
    setCollectionName,
    setUpdatedValue,
    setVersion,
    setMetaDataProps,
    searchText,
}) {
    const [open, setOpen] = useState({});
    const [isAddNewEnabled, setIsAddNewEnabled] = useState(false);
    const [newEntry, setNewEntry] = useState<any>({});
    const [confirmOpen, setConfirmOpen] = useState(false);

    const handleCollapse = (id: string) => setOpen({ ...open, [id]: !open[id] });

    const handleTextChange = (e: any) => {
        setIsNewDoc(false);
        const value = e.target.value;
        setNewEntry({ ...newEntry, name: value, documents: [] });
    };

    const clear = () => {
        setIsAddNewEnabled(false);
        setNewEntry({});
    };

    const addNewCollection = () => {
        setAdminSettings([newEntry, ...adminSettings]);
        clear();
    };

    const handleSettings = (name: string, value: any) => {
        setCollectionName(name);
        const documentation = value?.__doc || {};
        if (value?._id && !findDoc(name, value?._id)) {
            setIsNewDoc(false);
        } else {
            setIsNewDoc(true);
        }
        setActiveItem(value?._id);
        setValue(jsonStringify(value));
        setUpdatedValue(stringify(value));
        setMetaDataProps({ orignalDoc: value, documentation: documentation });
        if (value) {
            setVersion({ ...value.__meta, rec_id: value._id });
        } else {
            setVersion(null);
        }
    };

    const addNewDoc = (e: any, name, index: number) => {
        e.stopPropagation();
        const documents = adminSettings[index]?.documents || [];
        const addedDoc = documents.find((d: any) => d._id == "");
        if (!addedDoc) {
            const newDoc = { _id: "" };
            const updatedList = adminSettings.map((item: any, i: any) => {
                if (index == i) {
                    const docs = item?.documents || [];
                    return { ...item, documents: [newDoc, ...docs] };
                }
                return item;
            });
            setAdminSettings(updatedList);
            handleSettings(name, newDoc);
        } else {
            handleSettings(name, addedDoc);
        }
        setIsNewDoc(true);
        setOpen({ ...open, [name]: true });
    };

    const deleteNewDoc = (e: any, index: number, doc_index: number) => {
        e.stopPropagation();
        const updatedList = adminSettings.map((item: any, i: any) => {
            if (index == i) {
                return { ...item, documents: item.documents.filter((d: any, i) => i != doc_index) };
            }
            return item;
        });
        setAdminSettings(updatedList);
        handleSettings("", {});
        setIsNewDoc(false);
    };

    const findDoc = (name: string, id: string) => {
        const col = settingOrg.find((s: any) => s.name == name);
        if (col) {
            const doc = col.documents?.find((d: any) => d._id == id);
            if (doc) {
                return false;
            }
        }
        return true;
    };

    const handleAddId = (e: any, index: number, i: number) => {
        const settings = [...adminSettings];
        const new_doc = {
            ...settings[index]["documents"][i],
            _id: e.target.value,
        };
        settings[index]["documents"][i] = new_doc;
        setValue(stringify(new_doc));
        setUpdatedValue(stringify(new_doc));
        setAdminSettings(settings);
    };
    const deleteHandler = (e: any, name: string) => {
        e.stopPropagation();
        setConfirmOpen(true);
        setCollectionName(name);
    };

    const filterFn = (doc) => {
        if (searchText && searchText.length) {
            const label = doc.name || doc.title || doc._id || "";
            return label.toString().toLowerCase().search(searchText) >= 0;
        }
        return true;
    };

    adminSettings.forEach((entry) => {
        const getName = (x) => (x.name || x.title || x._id || "").toString();
        entry?.documents?.sort((a, b) => getName(a).localeCompare(getName(b)));
        entry.filteredDocs = entry?.documents?.filter(filterFn);
    });

    const visibleSections = adminSettings.filter((x) => {
        if (searchText && searchText.length) {
            return x.filteredDocs.length;
        }
        return true;
    });
    const openBySearch = (name) => {
        return visibleSections.length == 1 && visibleSections[0].name == name;
    };

    return (
        <>
            <div className={classes.baseContainer}>
                <List
                    component="nav"
                    aria-labelledby="nested-list-subheader"
                    subheader={
                        <ListSubheader component="div" id="nested-list-subheader" disableGutters={true}>
                            <div className={classes.subheader}>
                                <div className={classes.displayFlex}>
                                    <span> Collections</span>
                                    {Access.isSuper && (
                                        <span className={classes.marginLeftAuto}>
                                            <AddIconButton handler={() => setIsAddNewEnabled(true)} />
                                        </span>
                                    )}
                                </div>
                                {isAddNewEnabled && (
                                    <div className={classes.displayFlex}>
                                        <div>
                                            <TextField
                                                id="add-new"
                                                name="newEntry"
                                                label="Add new collection"
                                                multiline
                                                InputProps={{ className: classes.inputBase }}
                                                value={newEntry.name || ""}
                                                onClick={(e) => e.stopPropagation()}
                                                onChange={(event) => handleTextChange(event)}
                                                InputLabelProps={{ className: classes.labelBase }}
                                            />
                                        </div>
                                        <div className={classes.marginLeftAuto}>
                                            <SaveIconButton handler={addNewCollection} />
                                            <DeleteIconButton handler={() => clear()} />
                                        </div>
                                    </div>
                                )}
                            </div>
                        </ListSubheader>
                    }
                    className={classes.list}
                >
                    {visibleSections?.map((entry: any, index: number) => {
                        const hasChildren = entry?.documents && entry?.documents.length > 0;
                        const name = entry.name;
                        return (
                            <React.Fragment key={name}>
                                <ListItem button onClick={() => handleCollapse(name)}>
                                    <ListItemIcon className={classes.listItemIcon}>
                                        <LibraryBooksOutlinedIcon color="action" fontSize="small" />
                                    </ListItemIcon>
                                    <ListItemText
                                        primary={name}
                                        primaryTypographyProps={{ className: classes.primaryFont }}
                                    />
                                    {!hasChildren && (
                                        <React.Fragment key={name}>
                                            <DeleteIconButton handler={(e) => deleteHandler(e, name)} />
                                            <ConfirmDialog
                                                title={`Delete '${collectionName}'?`}
                                                open={confirmOpen}
                                                setOpen={setConfirmOpen}
                                                onConfirm={deleteCollection}
                                            >
                                                Are you sure you want to delete this collection?
                                            </ConfirmDialog>
                                        </React.Fragment>
                                    )}
                                    {open[name] ? <ExpandLess /> : <ExpandMore />}
                                </ListItem>

                                <Collapse in={open[name] || openBySearch(name)} timeout="auto" unmountOnExit>
                                    <List component="div" disablePadding>
                                        <ListItem
                                            button
                                            className={classes.nested}
                                            style={{ background: "#e0f7fa" }}
                                            onClick={(e) => addNewDoc(e, name, index)}
                                        >
                                            <ListItemIcon className={classes.listItemIcon}>
                                                <AddIcon color="action" fontSize="small" />
                                            </ListItemIcon>
                                            <ListItemText
                                                secondary="Add new doc"
                                                secondaryTypographyProps={{ className: classes.secondaryFont }}
                                            />
                                        </ListItem>
                                        {entry.filteredDocs.map((doc: any, i: number) => {
                                            const label = doc.name || doc.title || doc._id;
                                            const isNewRecord = !doc._id || (doc._id && findDoc(name, doc._id));
                                            return (
                                                <ListItem
                                                    key={i}
                                                    button
                                                    className={[
                                                        classes.nested,
                                                        doc._id === activeItem ? classes.activeListItem : "",
                                                    ].join(" ")}
                                                    onClick={() => handleSettings(name, doc)}
                                                >
                                                    <ListItemIcon className={classes.listItemIcon}>
                                                        <DescriptionOutlinedIcon color="action" fontSize="small" />
                                                    </ListItemIcon>
                                                    {isNewRecord ? (
                                                        <>
                                                            <TextField
                                                                sx={{
                                                                    "& legend": { display: "none" },
                                                                    "& fieldset": { top: 0 },
                                                                }}
                                                                name={doc._id + "-field"}
                                                                InputProps={{ className: classes.inputBase }}
                                                                value={doc._id || ""}
                                                                onChange={(e) => {
                                                                    handleAddId(e, index, i);
                                                                }}
                                                            />
                                                            <DeleteIconButton
                                                                handler={(e) => deleteNewDoc(e, index, i)}
                                                            />
                                                        </>
                                                    ) : (
                                                        <ListItemText
                                                            secondary={label}
                                                            secondaryTypographyProps={{
                                                                className: classes.secondaryFont,
                                                            }}
                                                        />
                                                    )}
                                                </ListItem>
                                            );
                                        })}
                                    </List>
                                </Collapse>
                            </React.Fragment>
                        );
                    })}
                </List>
            </div>
        </>
    );
}
