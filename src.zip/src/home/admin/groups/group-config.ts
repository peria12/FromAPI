export const defaultFilter = { column: "", operator: "", value: "" };

export const defaultGrpInfo = { masterData: [], groups: [], isLoading: false };

export const tableColumns = [
    { label: "Column", key: "column" },
    { label: "Operator", key: "operator" },
    { label: "Value", key: "value" },
];

export const defaultFormData = {
    formType: "create",
    title: "",
    group_type: "Series",
    is_active: true,
    is_advance: false,
    is_not: false
};
export const options = [
    { value: "Series", key: "Series" },
    { value: "Aggregate", key: "Aggregate" },
    { value: "Monthly Rebalance Monitor", key: "Monthly Rebalance Monitor" },
];
