import * as React from "react";
import { useLocation } from "react-router-dom";
import { Dashboard } from "./Dashboard";
import { useEffect } from "react";
import { ClickAwayListener, Paper, Popper } from "@mui/material";

function AllApps({ apps }) {
    return (
        <div style={{ width: "1250px", height: "100%" }}>
            <Dashboard apps={apps} compact={true}></Dashboard>
        </div>
    );
}

function NavigateButton({ onClick }) {
    return (
        <div className="navigate_apps" onClick={onClick}>
            <div className="navigate_apps_frame">
                <span className="navigate_all_apps">Navigate All Apps</span>

                <svg
                    width="8.15625px"
                    height="8.48828125px"
                    viewBox="0 0 9 9"
                    preserveAspectRatio="none"
                    fill="rgba(196.00000351667404, 196.00000351667404, 196.00000351667404, 1.0)"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <path
                        d="M0 0H8.64899L4.32449 8.99999L0 0Z"
                        fill="rgba(196.00000351667404, 196.00000351667404, 196.00000351667404, 1.0)"
                    />
                </svg>
            </div>
            <div className="navigate_apps_line"></div>
        </div>
    );
}

export default function HomePopover({ apps }) {
    const [anchorEl, setAnchorEl] = React.useState<HTMLButtonElement | null>(null);
    const [keepMounted, setKeepMounted] = React.useState(false);
    const location = useLocation();

    useEffect(() => {
        handleClose();
    }, [location.pathname]);

    const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
        setAnchorEl(anchorEl ? null : event.currentTarget);
        setKeepMounted(true);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const open = Boolean(anchorEl);
    const id = open ? "home-popover" : undefined;
    const MyPopper: any = Popper;

    return (
        <ClickAwayListener onClickAway={handleClose}>
            <div>
                <NavigateButton onClick={handleClick}></NavigateButton>
                <MyPopper id={id} open={open} anchorEl={anchorEl} style={{ zIndex: 10000 }} keepMounted={keepMounted}>
                    <Paper>
                        <AllApps apps={apps}></AllApps>
                    </Paper>
                </MyPopper>
            </div>
        </ClickAwayListener>
    );
}
