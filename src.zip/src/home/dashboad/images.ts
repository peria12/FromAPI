import aaDaa from "assets/screenshots/aa-daa.png";
import aaSaa from "assets/screenshots/aa-saa.png";
import aaStyleViews from "assets/screenshots/aa-style-views.png";
import adminAcl from "assets/screenshots/ad-acl.png";
import adminSettings from "assets/screenshots/ad-settings.png";
import adminGroups from "assets/screenshots/ad-groups.png";
import alertsInbox from "assets/screenshots/alerts-inbox.png";
import alertsAnnouncements from "assets/screenshots/alerts-announcements.png";
import alertsSubscriptions from "assets/screenshots/alerts-subscriptions.png";
import entityMasterEm from "assets/screenshots/entity-master-em.png";
import entityMasterOperations from "assets/screenshots/entity-master-operations.png";
import goeActuarials from "assets/screenshots/goe-actuarials.png";
import goeClientSettings from "assets/screenshots/goe-client-settings.png";
import goePortfolios from "assets/screenshots/goe-portfolios.png";
import goeCapabilitiesE2e from "assets/screenshots/goe-capabilities.png";
import goeArc from "assets/screenshots/goe-arc.png";
import goeCustomApi from "assets/screenshots/goe-custom-api.png";
import dalFields from "assets/screenshots/dal-fields.png";
import portfoliosSummary from "assets/screenshots/portfolios-summary.png";
import portfoliosHoldings from "assets/screenshots/portfolios-holdings.png";
import esgBindingElements from "assets/screenshots/esg-binding-elements.png";
import esgFundOfFundsLevel from "assets/screenshots/esg-fund-of-funds-level.png";
import esgMacroLevel from "assets/screenshots/esg-macro-level.png";
import esgPortfolioLevel from "assets/screenshots/esg-portfolio-level.png";
import esgFundLevel from "assets/screenshots/esg-fund-level.png";
import esgSecurityLevel from "assets/screenshots/esg-security-level.png";
import modelPortfoliosFileTransforms from "assets/screenshots/model-portfolios-file-transforms.png";
import portfoliosPowerBIIncomeFund from "assets/screenshots/portfolios-powerbi-income-fund.png";
import portfoliosFranklinIncomeFunds from "assets/screenshots/portfolios-franklin-income-funds.png";
import portfoliosAccountPositions from "assets/screenshots/portfolios-account-positions.png";
import portfoliosFtisRiskDashboard from "assets/screenshots/portfolios-ftis-risk-dashboard.png";
import portfoliosAnalysis from "assets/screenshots/portfolio-analysis.png";

const map = {
    aa: {
        saa: { i: aaSaa, w: 500, h: 281 },
        daa: { i: aaDaa, w: 500, h: 281 },
        style_views: { i: aaStyleViews, w: 734, h: 462 },
    },
    admin: {
        acl: { i: adminAcl, w: 500, h: 281 },
        settings: { i: adminSettings, w: 500, h: 281 },
        groups: { i: adminGroups, w: 500, h: 281 },
    },
    alerts: {
        inbox: { i: alertsInbox, w: 500, h: 281 },
        announcements: { i: alertsAnnouncements, w: 500, h: 281 },
        subscriptions: { i: alertsSubscriptions, w: 500, h: 281 },
    },
    "entity-master": {
        em: { i: entityMasterEm, w: 500, h: 281 },
        operations: { i: entityMasterOperations, w: 500, h: 281 },
    },
    esg: {
        security_level: { i: esgSecurityLevel, w: 500, h: 281 },
        macro_level: { i: esgMacroLevel, w: 500, h: 281 },
        portfolio_level: { i: esgPortfolioLevel, w: 500, h: 281 },
        fund_level: { i: esgFundLevel, w: 500, h: 281 },
        fund_of_funds_level: { i: esgFundOfFundsLevel, w: 500, h: 281 },
        binding_elements: { i: esgBindingElements, w: 500, h: 281 },
    },
    goe: {
        actuarials: { i: goeActuarials, w: 500, h: 281 },
        "client-settings": { i: goeClientSettings, w: 500, h: 281 },
        portfolios: { i: goePortfolios, w: 500, h: 281 },
        arc: { i: goeArc, w: 500, h: 281 },
        "custom-api": { i: goeCustomApi, w: 500, h: 281 },
    },
    "goe-capabilities": {
        goee2e: { i: goeCapabilitiesE2e, w: 500, h: 281 },
    },
    dal: { fields: { i: dalFields, w: 500, h: 281 } },
    portfolios: {
        summary: { i: portfoliosSummary, w: 500, h: 281 },
        holdings: { i: portfoliosHoldings, w: 500, h: 281 },
        ftis_risk_dashboard: { i: portfoliosFtisRiskDashboard, w: 500, h: 281 },
        powerbi_income_fund: { i: portfoliosPowerBIIncomeFund, w: 1060, h: 548 },
        powerbi_franklin_income_funds: { i: portfoliosFranklinIncomeFunds, w: 647, h: 402 },
        powerbi_account_positions: { i: portfoliosAccountPositions, w: 646, h: 395 },
    },
    model_portfolios: {
        file_transforms: { i: modelPortfoliosFileTransforms, w: 500, h: 281 },
        // portfolio_management: {i: modelPortfoliosFileTransforms, w: 500, h: 281}
    },
    "research-tool": {
        portfolio_analysis: { i: portfoliosAnalysis, w: 500, h: 281 },
    },
};

export function getDefaultScreenshot(app, zone) {
    const zoneMap = map[app];
    if (zoneMap) {
        return zoneMap[zone];
    }
    return undefined;
}
