import React from "react";

import { Link } from "react-router-dom";
import { getLink } from "utils/helpers";
import Settings from "utils/settings";
import { getDefaultScreenshot } from "./images";
import { AppContext } from "utils/context";
import Loader from "common/Loader";
import Access from "utils/access";

const getImage = (app_s, app, zone) => {
    if (app_s) {
        const zone_s = app_s[zone];
        if (zone_s && zone_s.url) {
            return zone_s.url;
        }
    }

    // console.log("DID NOT GOT CUSTOM SCREENSHOT FOR ", app, zone, getDefaultScreenshot(app, zone)?.i);
    return (
        getDefaultScreenshot(app, zone)?.i ||
        "https://anima-uploads.s3.amazonaws.com/projects/623b2c507af52e429bf57823/releases/62559c308c8ec1e7431395a5/img/prtfl-opt-config-1@2x.png"
    );
};

function OtherApps({ app, zone }) {
    const screenshots = Settings.getSettings()?.app_settings?.admin?.portal?.screenshots || {};
    const app_s = screenshots[app._id];
    return (
        <>
            {app.zones
                .filter((z) => z.name != zone.name)
                .filter((z) => z.show_on_portal)
                .filter((z) => Access.hasAccessToZone(app._id, z.name, ["view"]))
                .map((z) => (
                    <Link to={getLink(app._id, z.name)} key={z.name}>
                        <div className="app-nav d-flex flex-column">
                            <span>{z.title}</span>
                            <img className="app-nav-image" src={getImage(app_s, app._id, z.name)} />
                        </div>
                    </Link>
                ))}
        </>
    );
}

/*
function TitleExtra({ app }) {
    if (app._id == "portfolios") {
        return (
            <>
                <input className="app-nosubmit" type="search" placeholder="FCF-Income Fund" />
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    aria-hidden="true"
                    role="img"
                    width="3em"
                    height="3em"
                    preserveAspectRatio="xMidYMid meet"
                    viewBox="0 0 16 16"
                >
                    <g fill="grey">
                        <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM2 2a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H2z" />
                        <path d="M2.5 4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5H3a.5.5 0 0 1-.5-.5V4zM11 7.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-5 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z" />
                    </g>
                </svg>
                <span className="app-date">Mon June 20 2022</span>

                <div className="app-dropdown">
                    <button className="app-dropbtn">Group By</button>
                    <div className="app-dropdown-content">
                        <a href="#">Link 1</a>
                        <a href="#">Link 2</a>
                        <a href="#">Link 3</a>
                    </div>
                </div>

                <div className="app-dropdown">
                    <button className="app-dropbtn">Group By</button>
                    <div className="app-dropdown-content">
                        <a href="#">Link 1</a>
                        <a href="#">Link 2</a>
                        <a href="#">Link 3</a>
                    </div>
                </div>
            </>
        );
    }
    return <></>;
}
*/

export default function AppCover(props) {
    const { app, zone } = React.useContext(AppContext);

    return (
        <div
            className={`app-wrapper ${props.className}`}
            style={{ backgroundColor: app.color1 || "#A5A5A5" }}
            id="app_cover_boundary"
        >
            <div className="app-tab_holder" id="app_cover_tab">
                <div className="app-left-tab">
                    <div className="app-h1">{app.title}</div>
                    <div className="app-bottom-bar1"></div>
                </div>
                <div className="app-slant1"></div>

                <div className="app-middle-tab">
                    <span className="app-h2">{zone.title}</span>
                    {props.header || <></>}
                </div>

                <div className="app-slant2"></div>

                <div className="app-right-tab">
                    <div className="app-top-nav">
                        <OtherApps zone={zone} app={app}></OtherApps>
                    </div>

                    <div className="app-bottom-bar2"></div>
                </div>
            </div>
            <div className="app-content">{props.loading ? <Loader /> : props.children}</div>
        </div>
    );
}
