import React from "react";
import { Theme } from "@mui/material/styles";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import MergeTypeSharpIcon from "@mui/icons-material/MergeTypeSharp";
import SaveIcon from "@mui/icons-material/Save";
import AddIcon from "@mui/icons-material/Add";
import ClearIcon from "@mui/icons-material/Clear";

import SearchBox from "common/SearchBox";

const useToolbarStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            paddingLeft: theme.spacing(1),
            paddingRight: theme.spacing(0),
        },
        title: {
            flex: "1 1 100%",
        },
        iconBtn: {
            padding: theme.spacing(1.5),
        },
        btn: {
            textTransform: "capitalize",
            marginLeft: 8,
        },
    })
);

const IconBtn = ({ classes, handler, startIcon, label, color }) => {
    return (
        <Button
            onClick={handler}
            variant="contained"
            size="small"
            color={color}
            className={classes.btn}
            startIcon={startIcon}
        >
            {label}
        </Button>
    );
};

export default function TableToolbar({
    numSelected,
    handleMerge,
    handleSave,
    mergedRows,
    handleAddEntity,
    isNewRowEnabled,
    setSearchText,
    handleClear,
    handleUpdate,
}) {
    const classes = useToolbarStyles();

    const SaveButton = () => (
        <IconBtn classes={classes} handler={handleSave} startIcon={<SaveIcon />} label="Save" color="primary" />
    );

    const ClearButton = () => (
        <IconBtn classes={classes} handler={handleClear} startIcon={<ClearIcon />} label={"Cancel"} color="default" />
    );
    const UpdateButton = () => (
        <IconBtn classes={classes} handler={handleUpdate} startIcon={<SaveIcon />} label="Update" color="primary" />
    );

    return (
        <div className="d-flex">
            <div className="p-2 mt-1 flex-grow-1">
                {numSelected > 0 ? (
                    <Typography className={classes.title} color="inherit" variant="subtitle1" component="div">
                        {numSelected} selected{" "}
                    </Typography>
                ) : (
                    <></>
                )}
            </div>
            <div className="py-2 mt-1">
                {numSelected === 1 && <UpdateButton />}
                {numSelected > 1 && !mergedRows.length && (
                    <>
                        <ClearButton />
                        <IconBtn
                            classes={classes}
                            handler={handleMerge}
                            startIcon={<MergeTypeSharpIcon />}
                            label="Merge"
                            color="primary"
                        />
                        <UpdateButton />
                    </>
                )}
                {mergedRows.length > 0 && (
                    <>
                        <ClearButton />
                        <SaveButton />
                    </>
                )}

                {!numSelected && (
                    <div className={classes.title}>
                        {!isNewRowEnabled && (
                            <IconBtn
                                color="primary"
                                classes={classes}
                                handler={handleAddEntity}
                                startIcon={<AddIcon />}
                                label="Add"
                            />
                        )}
                        {isNewRowEnabled && (
                            <>
                                <ClearButton />
                                <SaveButton />
                            </>
                        )}
                    </div>
                )}
            </div>
            <div className="ps-2 py-2">
                <SearchBox setSearchText={setSearchText} placeholder={"Search..."} />
            </div>
        </div>
    );
}
