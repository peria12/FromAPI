import React, { useState, useEffect } from "react";
import makeStyles from "@mui/styles/makeStyles";
import {
    Box,
    Collapse,
    IconButton,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Grid,
    TableSortLabel,
    Button,
    Chip,
    List,
    ListItem,
    ListItemText,
    Tooltip,
} from "@mui/material";
import createStyles from "@mui/styles/createStyles";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import Api from "utils/api";
import { getFilterQuery, useScreenshot } from "utils/helpers";
import Loader from "common/Loader";
import TableFilterForm from "common/TableFilterForm";
import SearchBox from "common/SearchBox";
import FilterMenu from "../../common/FilterMenu";
import { errorHandler } from "utils/error-handler";
import Typography from "@mui/material/Typography";
import LoadingButton from "@mui/lab/LoadingButton";
import { textOperators, numericOperators } from "config/form-data";
import AppCover from "home/dashboad/AppCover";

const useRowStyles = makeStyles((theme: any) =>
    createStyles({
        root: {
            "& > *": {
                borderBottom: "unset",
                cursor: "pointer",
            },
        },
        tableHeader: {
            fontWeight: "bold",
        },
        right: {
            marginLeft: "auto",
        },
        visuallyHidden: {
            border: 0,
            clip: "rect(0 0 0 0)",
            height: 1,
            margin: -1,
            overflow: "hidden",
            padding: 0,
            position: "absolute",
            top: 20,
            width: 1,
        },
        chip: {
            margin: theme.spacing(0.3),
        },
        filterBtn: {
            margin: theme.spacing(1),
            textTransform: "capitalize",
        },
        filterBase: {
            display: "flex",
            alignItems: "center",
        },
        notes: {
            paddingTop: "12px",
        },
        loadingBtnBase: {
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
        },
        loadingBtn: {
            textTransform: "capitalize",
            width: "100%",
        },
        childTableCell: {
            fontSize: "0.65rem",
            lineHeight: "1.12rem",
            padding: "3px 8px",
        },
        shapeCircle: {
            borderRadius: "50%",
            background: "#7ec07e",
            width: "15px",
            height: "15px",
            display: "inline-block",
            marginRight: "5px",
        },
    })
);

const initialMousePositions = {
    mouseX: null,
    mouseY: null,
};

function displayLargeStr(value, maxStrLength = 20) {
    let updatedStr = value;
    if (value && value.length > maxStrLength) {
        updatedStr = value.substring(0, 20) + "...";
        return (
            <Tooltip title={value}>
                <span>{updatedStr}</span>
            </Tooltip>
        );
    }
    return updatedStr;
}

function getNotes(notes: string) {
    return notes?.split("|+|").reverse();
}

function Row({ row, index, fieldsInfo, handleClick }) {
    const [open, setOpen] = useState(false);
    const [entityList, setEntityList] = useState<any>([]);
    const [entityHeader, setEntityHeader] = useState<any>([]);
    const [childTableLoader, setChildTableLoader] = useState(false);
    const [isActive, setIsActive] = useState(false);
    const classes = useRowStyles();
    const { sortedFields, filterable, childTableFields } = fieldsInfo;
    function getStripedStyle(index: number): any {
        return { background: index % 2 ? "#fafafa" : "white" };
    }

    function onRowClick() {
        setChildTableLoader(true);
        Api.getEntityInfo(row.entity_id)
            .then((entityInfoResponse: any) => {
                setChildTableLoader(false);
                setEntityList(entityInfoResponse.entities);
                setIsActive(entityInfoResponse.entities?.some((ele) => !ele.end_date));
                const columnsWithValues = childTableFields?.filter((col) =>
                    entityInfoResponse?.entities?.some((entity) => entity[col])
                );
                setEntityHeader(columnsWithValues);
            })
            .catch((err) => {
                setChildTableLoader(false);
                console.log(err);
            });
        setOpen(!open);
    }
    const lastRecord = entityList?.[entityList?.length - 1];
    return (
        <React.Fragment>
            <tr
                onClick={onRowClick}
                className={classes.root + " " + "custom-tr-border"}
                style={{ ...getStripedStyle(index) }}
            >
                {sortedFields.map((field: any) => (
                    <td
                        key={field}
                        onContextMenu={filterable[field] ? (event) => handleClick(event, field, row[field]) : undefined}
                        style={{ cursor: filterable[field] ? "context-menu" : "pointer" }}
                    >
                        {row[field]}
                    </td>
                ))}
                <td>
                    <IconButton aria-label="expand row" size="small">
                        {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
                    </IconButton>
                </td>
            </tr>
            <tr>
                <td style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={12}>
                    <Collapse
                        in={open}
                        timeout="auto"
                        unmountOnExit
                        style={{ background: index % 2 ? "white" : "#fafafa" }}
                    >
                        <Box margin={2} style={{ marginBottom: "20px" }}>
                            <Typography
                                align="left"
                                component="h1"
                                variant="subtitle1"
                                style={{ display: "flex", alignItems: "center", lineHeight: "unset" }}
                            >
                                {!childTableLoader && (
                                    <span
                                        className={classes.shapeCircle}
                                        style={!isActive ? { background: "red" } : undefined}
                                    />
                                )}
                                {row.bb_ticker ? `${row.entity_name} (${row.bb_ticker})` : row.entity_name}
                                {childTableLoader && <Loader />}
                            </Typography>
                            <Table size="small" aria-label="purchases" style={{ marginTop: "12px" }}>
                                <TableHead style={{ background: "#e0e0e0" }}>
                                    <TableRow>
                                        {fieldsInfo?.fields?.map((field: any) => {
                                            if (entityHeader.includes(field.id)) {
                                                return (
                                                    <TableCell
                                                        key={field.id}
                                                        className={classes.childTableCell}
                                                        align="left"
                                                    >
                                                        {field?.title}
                                                    </TableCell>
                                                );
                                            }
                                            return;
                                        })}
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {entityList?.map((entity: any, index: number) => {
                                        return (
                                            <TableRow key={`${entity.entity_id + index}`}>
                                                {entityHeader.map((header: any) => {
                                                    return (
                                                        <TableCell
                                                            className={classes.childTableCell}
                                                            component="th"
                                                            scope="row"
                                                            key={header}
                                                            style={
                                                                entityList.length - 1 == index
                                                                    ? { fontWeight: 600 }
                                                                    : undefined
                                                            }
                                                        >
                                                            {displayLargeStr(entity[header])}
                                                        </TableCell>
                                                    );
                                                })}
                                            </TableRow>
                                        );
                                    })}
                                </TableBody>
                            </Table>
                            {lastRecord?.notes && (
                                <div className={classes.notes}>
                                    <List dense={true}>
                                        Notes:{" "}
                                        {!isActive && (
                                            <ListItem>
                                                {" "}
                                                <ListItemText
                                                    style={{ margin: 0 }}
                                                    primary={`Security delisted on: ${lastRecord?.end_date}`}
                                                />{" "}
                                            </ListItem>
                                        )}
                                        {getNotes(lastRecord?.notes).map((note, i) => {
                                            if (note) {
                                                return (
                                                    <ListItem key={i}>
                                                        <ListItemText style={{ margin: 0 }} primary={note} />{" "}
                                                    </ListItem>
                                                );
                                            }
                                        })}
                                    </List>
                                </div>
                            )}
                        </Box>
                    </Collapse>
                </td>
            </tr>
        </React.Fragment>
    );
}

export default function EntityMaster() {
    const [fieldsInfo, setFieldsInfo] = useState<any>({
        fields: [],
        sortedFields: [],
        childTableFields: [],
        filterable: {},
    });
    const [entityInfo, setEntityInfo] = useState<any>({ entities: [], totalRecords: 0, isLoading: true });
    const [pageConfig, setPageConfig] = useState<any>({ rowsPerPage: 25 });
    const [orderBy, setOrderBy] = useState<any>({});
    const [open, setOpen] = React.useState(false);
    const filter = { column: "", operator: "", value: "", query: {}, queryStr: "" };
    const [filters, setFilters] = React.useState([filter]);
    const [appliedFilters, setAppliedFilters] = React.useState<any>([]);
    const [filterQuery, setFilterQuery] = React.useState("");
    const [searchText, setSearchText] = React.useState("");
    const [isActive] = useState(true);
    const [operators, setOperators] = React.useState(textOperators);

    const screenshot = useScreenshot();

    const classes = useRowStyles();
    const createSortHandler = (field: any) => () => {
        const order = orderBy[field] === "asc" ? "desc" : "asc";
        // setOrderBy({ ...orderBy, [field]: order });
        setOrderBy({ [field]: order });
    };

    useEffect(() => {
        Api.getEntityMasterFields()
            .then((fields: any) => {
                const ordered_fields = fields.sort((a: any, b: any) => a.view_order - b.view_order);
                const sorted_fields = ordered_fields.filter((f) => f.show_on_table).map((f) => f.id);
                const childTableFields = ordered_fields.filter((f) => f.show_on_detailed_info_view).map((f) => f.id);
                const filterable_fields = {};
                fields
                    .filter((f) => f.filterable)
                    .forEach((f) => {
                        filterable_fields[f.id] = true;
                    });
                setFieldsInfo({
                    fields: ordered_fields,
                    sortedFields: sorted_fields,
                    childTableFields: childTableFields,
                    filterable: filterable_fields,
                });
            })
            .catch((e: any) => {
                errorHandler(e);
                setFieldsInfo({ fields: [], sortedFields: [], childTableFields: [], filterable: {} });
            });
    }, []);

    const loadPage = (options: any = {}) => {
        const { newPage = null, isActiveEntitiesOnly = null, resetScrollId = false, signal } = options;

        let pageIndex: any = pageConfig?.page;
        let is_active: any = isActive;
        if (newPage != null) {
            pageIndex = newPage;
        }
        if (isActiveEntitiesOnly != null) {
            is_active = isActiveEntitiesOnly;
        }

        const params = {
            page: pageIndex,
            page_size: pageConfig?.rowsPerPage,
            is_active,
        };
        let _entityInfo = { ...entityInfo };
        if (!resetScrollId && entityInfo?.scrollId) {
            params["scroll_id"] = entityInfo?.scrollId;
            _entityInfo = { ...entityInfo, isLoadMore: true };
        } else {
            _entityInfo = { ...entityInfo, isLoading: true, entities: [] };
        }
        if (resetScrollId) {
            _entityInfo["scrollId"] = null;
        }
        if (signal) {
            params["signal"] = signal;
        }
        setEntityInfo(_entityInfo);

        if (filterQuery) {
            params["filters"] = filterQuery;
        }
        if (searchText) {
            params["search_string"] = searchText.toLowerCase();
        }
        if (Object.keys(orderBy).length) {
            params["sort_fields"] = JSON.stringify(
                Object.keys(orderBy).map((key) => (orderBy[key] === "desc" ? [key, -1] : [key, 1]))
            );
        }
        Api.getEntities(params)
            .then((res: any) => {
                if (!signal?.aborted) {
                    if (res.reason === "scroll id is expired or not found") {
                        return loadPage({ resetScrollId: true });
                    }
                    if (res.entities) {
                        const updatedEntityInfo = {
                            entities: res.entities,
                            totalRecords: res.entities?.length || 0,
                            isLoading: false,
                            scrollId: res.scroll_id,
                        };
                        if (params["scroll_id"]) {
                            updatedEntityInfo["entities"] = [...(entityInfo?.entities || []), ...res.entities];
                            updatedEntityInfo["isLoadMore"] = false;
                        }
                        setEntityInfo(updatedEntityInfo);
                    } else {
                        setEntityInfo({ entities: [], totalRecords: 0, isLoading: false, isLoadMore: false });
                    }

                    screenshot.take();
                }
            })
            .catch((e: any) => {
                errorHandler(e);
                setEntityInfo({ entities: [], totalRecords: 0, isLoading: false, isLoadMore: false });
            });
    };

    useEffect(() => {
        const controller = new AbortController();
        loadPage({ resetScrollId: true, signal: controller.signal });
        return () => controller.abort();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [pageConfig.rowsPerPage, filterQuery, searchText, orderBy]);

    const handleRemoveFilter = (index: number) => {
        const list = appliedFilters.filter((val, i) => i != index);
        setFilters(list);
        setAppliedFilters(list);
        setPageConfig({ ...pageConfig, page: 0 });
        const updatedQuery = {};
        if (list.length > 0) {
            list.forEach((f) => {
                if (!updatedQuery[f.column]) {
                    updatedQuery[f.column] = [];
                }
                updatedQuery[f.column].push(f.query);
            });
        }
        setFilterQuery(JSON.stringify(updatedQuery));
    };

    function checkEquality(a, b) {
        const entries1: any = Object.entries(a);
        const entries2: any = Object.entries(b);
        const short = entries1.length > entries2 ? entries2 : entries1;
        const long = short === entries1 ? b : a;
        return short.every(([k, v]) => long[k] === v);
    }

    const handleFilter = (updatedFilter = null) => {
        const filterQuery = {};
        const _appliedFilters: any = [];
        let filterList: any = filters;
        if (updatedFilter) {
            filterList = updatedFilter;
        }
        filterList.forEach((filter) => {
            if (filter.column && filter.operator) {
                let query = {};
                let field_title = filter.column;
                const field_info: any = fieldsInfo?.fields.find((f: any) => f.id === filter.column);
                if (field_info) {
                    field_title = field_info.title;
                }
                filter.queryStr = `${field_title} ${filter.operator} '${filter.value}'`;
                query = getFilterQuery(filter);
                if (!filterQuery[filter.column]) {
                    filterQuery[filter.column] = [];
                } else {
                    if (filterQuery[filter.column].find((prop) => checkEquality(query, prop))) {
                        return;
                    }
                }
                filterQuery[filter.column].push(query);
                filter.query = query;
                _appliedFilters.push(filter);
            }
        });
        setFilterQuery(JSON.stringify(filterQuery));
        setOpen(false);
        setAppliedFilters(_appliedFilters);
    };

    const handleOpenFilter = () => {
        if (filters.length >= 1) {
            const nonEmptyFilters = filters.filter((f) => f.column);
            if (nonEmptyFilters.length === 0) {
                setFilters([filter]);
            } else {
                setFilters(nonEmptyFilters);
            }
        } else {
            setFilters([filter]);
        }
        setOpen(true);
    };

    const rightClickHandler = ({ column, operator, value }) => {
        const updatedFilter: any = [
            ...filters,
            { column, operator, value, query: {}, queryStr: "", operators: operators },
        ];
        setFilters(updatedFilter);
        setPageConfig({ ...pageConfig, page: 0 });
        handleFilter(updatedFilter);
    };

    const [mousePositions, setMousePositions] = React.useState<any>(initialMousePositions);

    const handleLoadMore = () => {
        loadPage();
    };

    const handleClick = (event: any, column: string, value: any) => {
        event.preventDefault();
        const fieldInfo = fieldsInfo?.fields?.find((field) => field.id === column);
        if (!fieldInfo?.is_string) {
            setOperators(numericOperators);
        } else {
            setOperators(textOperators);
        }
        setMousePositions({
            mouseX: event.clientX - 2,
            mouseY: event.clientY - 4,
            column,
            value,
        });
    };

    const handleClose = ({ operator }) => {
        let { value } = mousePositions;
        const { column } = mousePositions;
        setMousePositions(initialMousePositions);
        if (!operator || !value) {
            return;
        }
        const field_info: any = fieldsInfo?.fields.find((f: any) => f.id === column);
        if (field_info && !field_info.is_string) {
            value = parseFloat(value);
        }
        rightClickHandler({ column, operator, value });
    };
    const showLoadMore = !entityInfo.isLoading && entityInfo.totalRecords == pageConfig?.rowsPerPage;

    const headerComponent = (
        <Grid container direction="row" justifyContent="flex-end" alignItems="center" style={{ paddingTop: "4px" }}>
            <Grid
                container
                direction="row"
                justifyContent="flex-end"
                alignItems="center"
                item
                xs={12}
                sm={12}
                md={12}
                lg={12}
                xl={12}
            >
                {appliedFilters.map(
                    (filter, i) =>
                        filter.queryStr && (
                            <Chip
                                label={filter.queryStr}
                                key={i}
                                className={classes.chip}
                                onDelete={() => handleRemoveFilter(i)}
                                color="primary"
                                size="small"
                                variant="outlined"
                            />
                        )
                )}
                <div className={classes.filterBase}>
                    <Button
                        variant="contained"
                        className={classes.filterBtn}
                        style={{ textTransform: "capitalize" }}
                        size="medium"
                        color="primary"
                        onClick={handleOpenFilter}
                    >
                        {" "}
                        Filter{" "}
                    </Button>
                    <TableFilterForm
                        fields={fieldsInfo?.fields}
                        open={open}
                        filters={filters}
                        setFilters={setFilters}
                        handleFilter={handleFilter}
                        handleClose={() => {
                            setFilters(appliedFilters);
                            setOpen(false);
                        }}
                    />
                    {<SearchBox setSearchText={setSearchText} />}
                </div>
            </Grid>
        </Grid>
    );

    return (
        <AppCover header={headerComponent}>
            <Paper>
                <TableContainer style={{ display: "block", height: "calc(100vh - 155px)", overflowY: "auto" }}>
                    <Table size="small" aria-label="collapsible table" stickyHeader>
                        <TableHead>
                            <TableRow>
                                {fieldsInfo?.fields.map((field: any) => {
                                    if (field.show_on_table) {
                                        if (field.sortable) {
                                            return (
                                                <TableCell
                                                    className={classes.tableHeader}
                                                    key={field.id}
                                                    align="left"
                                                    sortDirection={orderBy[field.id] || false}
                                                >
                                                    <TableSortLabel
                                                        active={orderBy[field.id] ? true : false}
                                                        direction={orderBy[field.id] || "asc"}
                                                        onClick={createSortHandler(field.id)}
                                                    >
                                                        {field.title}
                                                        {orderBy[field.id] ? (
                                                            <span className={classes.visuallyHidden}>
                                                                {orderBy[field.id] === "desc"
                                                                    ? "sorted descending"
                                                                    : "sorted ascending"}
                                                            </span>
                                                        ) : null}
                                                    </TableSortLabel>
                                                </TableCell>
                                            );
                                        } else {
                                            return (
                                                <TableCell key={field.id} className={classes.tableHeader} align="left">
                                                    {field.title}
                                                </TableCell>
                                            );
                                        }
                                    }
                                })}
                                <TableCell />
                            </TableRow>
                        </TableHead>
                        {entityInfo.isLoading ? (
                            <div style={{ position: "fixed", width: "90%", paddingTop: "12px" }}>
                                <Loader />
                            </div>
                        ) : (
                            <TableBody className="custom-tbody dense-table">
                                <FilterMenu
                                    mousePositions={mousePositions}
                                    handleClose={handleClose}
                                    operators={operators}
                                />
                                {entityInfo.entities.map((entity: any, index: number) => (
                                    <Row
                                        key={entity.entity_id}
                                        row={entity}
                                        index={index}
                                        fieldsInfo={fieldsInfo}
                                        handleClick={handleClick}
                                    />
                                ))}
                            </TableBody>
                        )}
                    </Table>
                    {showLoadMore && (
                        <div className={classes.loadingBtnBase}>
                            <LoadingButton
                                loading={entityInfo.isLoadMore}
                                loadingPosition="center"
                                variant="outlined"
                                color="primary"
                                className={classes.loadingBtn}
                                // loadingIndicator="Loading..."
                                onClick={handleLoadMore}
                            >
                                Load more
                            </LoadingButton>
                        </div>
                    )}
                </TableContainer>
            </Paper>
        </AppCover>
    );
}
