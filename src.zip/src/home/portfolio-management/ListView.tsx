import React, { useRef, useState, useEffect, useMemo, useCallback } from "react";
import { InputBase } from "@mui/material";
import { Search } from "@mui/icons-material";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-enterprise";
import { SelectionChangedEvent } from "ag-grid-community";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "./model-portfolio.css";
import Api from "utils/api";
import plusIcon from "assets/Plus.svg";

const modelColDefs = [
    { headerName: "Model Suite", field: "Model Suite", rowGroup: true, hide: true },
    { headerName: "Category", field: "Category" },
    { headerName: "Sub Category", field: "Sub-Category" },
    { headerName: "Model Name", field: "Name" },
    { headerName: "Description", field: "Description" },
];

export default function ListView({ isEditMode, addAsset, assets, rowDataForModel }) {
    const gridRefForModel = useRef<AgGridReact>(null);
    const gridRefForAsset = useRef<AgGridReact>(null);
    const [searchTextForModel, setSearchTextForModel] = useState("");
    const [searchTextForAsset, setSearchTextForAsset] = useState("");
    const [rowDataForAsset, setRowDataForAsset] = useState<any[]>();
    const [showAdding, setShowAdding] = useState(isEditMode);
    const [selectedAssets, setSelectedAssets] = useState<any[]>([]);
    const [assetColumns, setAssetColumns] = useState<any>([]);

    function resetColumns(res) {
        const formattedCols = (res.columns || []).map((col) => {
            if (col === "morningstar_category_us_assetclass_name") {
                return {
                    headerName: res.display_name_mapping[col],
                    field: col,
                    rowGroupIndex: 0,
                    hide: true,
                };
            } else if (col === "morningstar_category_name") {
                return { headerName: res.display_name_mapping[col], field: col, rowGroupIndex: 1, hide: true };
            } else if (col === "entity_id") {
                return {
                    headerName: res.display_name_mapping[col],
                    field: col,
                    checkboxSelection: (params) => {
                        return (
                            params.data &&
                            params.data.entity_id &&
                            assets &&
                            assets.findIndex((asset) => asset.entity_id === params.data.entity_id) === -1
                        );
                    },
                    maxWidth: 150,
                };
            } else {
                return { headerName: res.display_name_mapping[col], field: col, maxWidth: 150 };
            }
        });
        setAssetColumns(formattedCols);
    }

    useEffect(() => {
        Api.getAssetList().then((res) => {
            if (res) {
                const formattedData = (res.data || []).map((data) => {
                    const formattedAsset = {};
                    res?.columns?.forEach((col, i) => {
                        formattedAsset[col] = data[i];
                    });
                    return formattedAsset;
                });
                setRowDataForAsset(formattedData);
                resetColumns(res);
            }
        });
        //eslint-disable-next-line
    }, [assets]);

    useEffect(() => {
        setShowAdding(isEditMode);
    }, [isEditMode]);

    useEffect(() => {
        if (gridRefForModel && gridRefForModel.current && gridRefForModel.current.api) {
            gridRefForModel.current.api.setQuickFilter(searchTextForModel);
        }
    }, [searchTextForModel]);

    useEffect(() => {
        if (gridRefForAsset && gridRefForAsset.current && gridRefForAsset.current.api) {
            gridRefForAsset.current.api.setQuickFilter(searchTextForAsset);
        }
    }, [searchTextForAsset]);

    const autoGroupColumnDefForModel = useMemo(() => {
        return {
            headerName: "Model Suite",
            field: "Model Suite",
        };
    }, []);

    const autoGroupColumnDefForAsset = useMemo(() => {
        return {
            headerName: "Category",
            field: "category",
            minWidth: 100,
        };
    }, []);

    const changeSelectedAssets = useCallback((event: SelectionChangedEvent) => {
        const nodes = event.api.getSelectedNodes();
        const getSelected = nodes.map((item) => item.data);
        setSelectedAssets(getSelected);
    }, []);

    const getSelectedRowData = () => {
        addAsset(selectedAssets);
    };

    return (
        <div className="porfolio-management-wrapper portfolio-management-tab-container">
            <div className="portfolio-management-drag-handle" style={{ height: "20px", width: "100%" }}></div>
            <input type="radio" id="model-list-tab" name="portfolio-management-tabs" value="model" defaultChecked />
            <label className="portfolio-management-tab-label" htmlFor="model-list-tab" style={{ marginLeft: "50px" }}>
                Model List
            </label>
            <div className="porfolio-management-content-box">
                <div className="porfolio-management-search-bar">
                    <label
                        htmlFor="list-view-search-box"
                        id="search-label"
                        style={{ marginRight: "5px", alignSelf: "center" }}
                    >
                        Search
                    </label>
                    <InputBase
                        id="list-view-search-box"
                        onChange={(e: any) => setSearchTextForModel(e.target.value)}
                        sx={{ border: "solid 1px #C4C4C4", width: "50%", padding: "0 5px", height: "25px" }}
                    />
                    <div className="porfolio-management-icon-wrapper">
                        <Search color="action" />
                    </div>
                </div>
                <div className="ag-theme-alpine porfolio-management-ag">
                    <AgGridReact
                        rowData={rowDataForModel}
                        ref={gridRefForModel}
                        columnDefs={modelColDefs}
                        autoGroupColumnDef={autoGroupColumnDefForModel}
                        groupAllowUnbalanced
                    ></AgGridReact>
                </div>
            </div>

            <input type="radio" id="asset-list-tab" name="portfolio-management-tabs" value="asset" />
            <label className="portfolio-management-tab-label" htmlFor="asset-list-tab">
                Asset List
            </label>
            <div className="porfolio-management-content-box">
                <div className="porfolio-management-search-bar">
                    <label
                        htmlFor="list-view-search-box"
                        id="search-label"
                        style={{ marginRight: "5px", alignSelf: "center" }}
                    >
                        Search
                    </label>
                    <InputBase
                        id="list-view-search-box"
                        onChange={(e: any) => {
                            setSearchTextForAsset(e.target.value);
                        }}
                        sx={{ border: "solid 1px #C4C4C4", width: "50%", padding: "0 5px", height: "25px" }}
                    />
                    <div className="porfolio-management-icon-wrapper">
                        <Search color="action" />
                    </div>
                </div>
                <div className="ag-theme-alpine porfolio-management-ag">
                    <AgGridReact
                        rowData={rowDataForAsset}
                        ref={gridRefForAsset}
                        columnDefs={assetColumns}
                        autoGroupColumnDef={autoGroupColumnDefForAsset}
                        groupAllowUnbalanced
                        rowSelection="multiple"
                        suppressRowDeselection
                        suppressRowClickSelection
                        onSelectionChanged={changeSelectedAssets}
                    ></AgGridReact>
                    {showAdding && (
                        <div className="portfolio-management-add-icon" onClick={() => getSelectedRowData()}>
                            <img src={plusIcon} />
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
