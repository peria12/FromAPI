import React from "react";
import CancelOutlinedIcon from "@mui/icons-material/CancelOutlined";
import CloseIcon from "@mui/icons-material/Close";
import { FTIconButton } from "common/FTButtons";

const numberVal = (val) => {
    if (val != undefined && val != null && val !== "") {
        val = Number(val).toFixed(2);
        return isNaN(val) ? "" : Number(val);
    }
    return "";
};

function getValue(col, row) {
    const val = numberVal(row[col.id]);
    if (val != undefined && val != null && val !== "") {
        return val + "%";
    }
    return "";
}

const iconStyle = { fontSize: "1.2rem", color: "grey" };

function DeleteIcon({ row, onDelete }) {
    const isGroupedRow = row?.isGroupedRow || false;
    if (isGroupedRow) {
        return <></>;
    }
    return (
        <FTIconButton
            handler={() => onDelete(row)}
            title="Remove"
            style={{ padding: "1px" }}
            btnIcon={<CloseIcon style={iconStyle} color="primary" />}
            placement="top"
        />
    );
}

function DeleteIconHeader({ onDeleteAll }) {
    return (
        <FTIconButton
            handler={onDeleteAll}
            title="Remove All"
            style={{ padding: "1px" }}
            btnIcon={<CancelOutlinedIcon style={iconStyle} color="primary" />}
            placement="top"
        />
    );
}

const getRowCellStyle = (col) => ({
    height: "20px",
    minHeight: "20px",
    width: col.width || "50px",
    minWidth: col.minWidth || "50px",
    fontSize: "14px",
});

const getHeaderCellStyle = (col) => ({
    width: col.width || "50px",
    minWidth: col.minWidth || "50px",
    color: "#C5C5C5",
    fontStyle: "italic",
    fontWeight: "400",
    fontSize: "14px",
});

export default function ModelAssetsTable({ rows, cols, isEditable, setModelData }) {
    function onDelete(id) {
        const newAssets = rows.slice();
        const filteredAssets = newAssets.filter((asset) => asset.entity_id !== id);
        setModelData((modelData) => ({ ...modelData, assets: filteredAssets }));
    }
    function onDeleteAll() {
        setModelData((modelData) => ({ ...modelData, assets: [] }));
    }
    return (
        <table style={{ width: "100%" }}>
            <thead>
                <tr>
                    {cols?.map((col) => {
                        if (!isEditable && col.id == "delBtn") {
                            return null;
                        }
                        return (
                            <th key={col.id} style={getHeaderCellStyle(col)}>
                                <div>
                                    <span>
                                        {col.id == "delBtn" ? <DeleteIconHeader onDeleteAll={onDeleteAll} /> : col.name}
                                    </span>
                                </div>
                            </th>
                        );
                    })}
                </tr>
            </thead>
            <tbody>
                {rows?.map((row, i) => (
                    <tr key={i} style={{ color: isEditable ? "#355dd1" : "#2A2A2A" }}>
                        {cols?.map((col) => {
                            if (!isEditable && col.id == "delBtn") {
                                return null;
                            }
                            if (isEditable && col.id == "weight") {
                                return (
                                    <td key={col.id} style={getRowCellStyle(col)}>
                                        <input
                                            key={col.id}
                                            className="portfolio-management-edit-input weights-text"
                                            type="text"
                                            defaultValue={Number(row.weight || "0")}
                                            onBlur={(e) => {
                                                const newAssets: any = rows.slice();
                                                newAssets.find((asset) => asset.entity_id === row.entity_id).weight =
                                                    e.target.value;
                                                setModelData((modelData) => ({ ...modelData, assets: newAssets }));
                                            }}
                                        />
                                        %
                                    </td>
                                );
                            }
                            return (
                                <td
                                    key={col.id}
                                    style={getRowCellStyle(col)}
                                    onClick={col.id == "delBtn" ? () => onDelete(row.entity_id) : undefined}
                                >
                                    {(() => {
                                        switch (col.id) {
                                            case "delBtn":
                                                return <DeleteIcon row={row} onDelete={onDelete} />;
                                            case "weight":
                                                return getValue(col, row);
                                            default:
                                                return row[col.id];
                                        }
                                    })()}
                                </td>
                            );
                        })}
                    </tr>
                ))}
            </tbody>
        </table>
    );
}
