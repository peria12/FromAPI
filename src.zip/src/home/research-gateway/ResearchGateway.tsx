import React, { useState, useEffect } from "react";
import { Link, Switch, Route, useRouteMatch } from "react-router-dom";

import Api from "utils/api";
import { initTooltip, getIconFromFileType } from "utils/helpers";
import Modal from "common/Modal";
import { entryNotification } from "utils/events";
// import Entry from "./Entry";
import EntryForm from "./EntryForm";
import RichTextEditor from "common/RichTextEditor";
import MuiTable from "common/Table/MuiTable";
import { FileDownload } from "common/FileDownload";

export default function ResearchGateway() {
    const { path } = useRouteMatch();
    const [table, setTable] = useState({
        columns: [
            {
                _id: "name",
                title: "Name",
                is_string: true,
                view_order: 1,
                show_on_table: true,
                sortable: true,
                filterable: 1,
            },
            {
                _id: "author",
                title: "Author",
                is_string: true,
                view_order: 2,
                show_on_table: true,
                sortable: true,
                filterable: 1,
            },
            {
                _id: "status",
                title: "Status",
                is_string: true,
                view_order: 3,
                show_on_table: true,
                sortable: true,
                filterable: 1,
            },
            {
                _id: "team",
                title: "Team",
                is_string: true,
                view_order: 4,
                show_on_table: true,
                sortable: true,
                filterable: 1,
            },
            {
                _id: "asset_class",
                title: "Asset Class",
                is_string: true,
                view_order: 5,
                show_on_table: true,
                sortable: true,
                filterable: 1,
            },
            {
                _id: "sub_asset_class",
                title: "Sub Asset Class",
                is_string: true,
                view_order: 6,
                show_on_table: true,
                sortable: true,
                filterable: 1,
            },
            {
                _id: "create_date",
                title: "Created",
                is_string: true,
                view_order: 7,
                show_on_table: true,
                sortable: true,
                filterable: 1,
            },
            {
                _id: "update_date",
                title: "Updated",
                is_string: true,
                view_order: 8,
                show_on_table: true,
                sortable: true,
                filterable: 0,
            },
            {
                _id: "files",
                title: "Files",
                is_string: true,
                view_order: 9,
                show_on_table: true,
                sortable: true,
                filterable: 1,
            },
            {
                _id: "actions",
                title: "Actions",
                view_order: 10,
                show_on_table: true,
                position: "center",
            },
        ],
        data: [],
        error: "",
    });

    const [deleteRow, setDeleteRow] = useState(null as any);

    const loadEntry = (params) =>
        Api.getEntries(params)
            .then((data: any) => {
                setTable({ columns: table.columns, data: data, error: "" });
                initTooltip();
                const dataResponse = {
                    records: data,
                    total_records: Array.isArray(data) ? data.length : 0,
                };
                return dataResponse;
            })
            .catch(() => {
                setTable({ columns: table.columns, data: [], error: "Failed to fetch data..." });
            });

    const MuiFieldsTableData = () => {
        return Promise.resolve(table.columns);
    };

    const toolbarConfig = {
        queryFilter: true,
        searchBar: true,
        columnHideShow: true,
    };

    useEffect(() => {
        loadEntry({});
        entryNotification.subscribe(loadEntry);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [path]);

    const confirmDelete = () => {
        Api.deleteEntry(deleteRow._id).then(loadEntry);
        setDeleteRow(null);
    };

    function fileMenu({ props }) {
        return (
            <div className="accordion-header">
                {props?.row.attachments?.map((file) => (
                    <span
                        key={file.file_id}
                        data-bs-toggle="tooltip"
                        data-bs-placement="bottom"
                        title={file.file_name}
                        className="me-1"
                    >
                        <FileDownload file_id={file.file_id}>
                            <i className={getIconFromFileType(file.file_type)}></i>
                        </FileDownload>
                    </span>
                ))}
            </div>
        );
    }

    function actionMenu({ props }) {
        return (
            <div className="accordion-header">
                <Link to={`${path}/${props?.row._id}`}>
                    <i className="fas fa-edit mx-1"></i>
                </Link>
                <i
                    className="fas fa-trash-alt mx-1 text-danger"
                    style={{ cursor: "pointer" }}
                    onClick={() => setDeleteRow(props?.row)}
                ></i>
                &nbsp;
            </div>
        );
    }

    const html = "<p> Sample rich text</p>";
    const styleCellHandler = (row: any) => row?.event_read === false;

    return (
        <div className="mx-4 my-2">
            <div>
                <MuiTable
                    meta={{ striped: true }}
                    appInfo={{
                        appId: "M-Uip",
                    }}
                    tableDataApi={loadEntry}
                    fieldsApi={MuiFieldsTableData}
                    toolbarConfig={toolbarConfig}
                    rowConfig={{
                        customizeCell: {
                            actions: actionMenu,
                            files: fileMenu,
                        },
                        styleCell: {
                            style: {
                                fontWeight: "bold",
                            },
                            handler: styleCellHandler,
                        },
                    }}
                />
            </div>
            <Switch>
                {/* <Route path={`${path}/:id`} component={Entry} /> */}
                <Route path={`${path}/:id`} component={EntryForm} />
            </Switch>
            {deleteRow ? (
                <Modal title="Confirm" buttonText="Delete" onOk={confirmDelete} onClose={() => setDeleteRow(null)}>
                    Do you really want to delete <b>{deleteRow?.name}</b>?
                </Modal>
            ) : (
                ""
            )}

            <RichTextEditor html={html} onChange={(html) => console.log(html)}></RichTextEditor>
        </div>
    );
}
