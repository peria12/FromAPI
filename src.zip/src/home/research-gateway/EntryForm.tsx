import React, { useEffect, useState } from "react";
import makeStyles from "@mui/styles/makeStyles";
import { Button, Typography } from "@mui/material";
import { useForm } from "react-hook-form";

import Breadcrumbs from "@mui/material/Breadcrumbs";
import { Link, useParams } from "react-router-dom";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import Grid from "@mui/material/Grid";
import { MuiForm } from "common/mui-form/MuiForm";
import Api from "utils/api";

const useRowStyles = makeStyles({
    base: {
        background: "white",
        height: "calc(100vh - 20px)",
    },
    breadcrumbsText: {
        color: "#337ab7",
        fontSize: "30px",
    },
    currentTab: {
        fontSize: "20px",
    },
});

export default function EntryForm() {
    const params = useParams();
    const [fields, setFields] = useState(null as any);
    const [entry, setEntry] = useState(null as any);
    const [people, setPeople] = useState<any[]>([]);
    const methods = useForm(entry || {});
    const { handleSubmit, reset } = methods;
    const customFields = {};

    useEffect(() => {
        if (!fields) {
            Api.getFields().then((fields) => {
                const ordered_fields = fields.sort((a: any, b: any) => a.display_order - b.display_order);
                setFields(ordered_fields);
            });
        }
        if (!entry) {
            if (params.id != "new") {
                Api.getEntry(params.id).then((entryInfo) => {
                    setEntry(entryInfo);
                    reset(entryInfo);
                });
            } else {
                setEntry({});
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [entry, fields, params.id]);

    const onChange = (value, key) => {
        customFields[key] = value;
    };

    const onSubmit = (data: any) => {
        const updatedEntry = { ...data, ...customFields };
        saveChanges(updatedEntry);
    };

    const saveChanges = (entry) => {
        if (params.id != "new") {
            Api.updateEntry(params.id, entry).then((res) => {
                console.log("updateEntry", res);
            });
        } else {
            Api.createEntry(entry).then((resp) => {
                console.log("createEntry", resp);
            });
        }
    };

    const handleAdd = (_, person) => {
        if (person) {
            if (!people.find((p: any) => p.id == person.id)) {
                const newPeople = [...people, person].sort((a, b) => a.label.localeCompare(b.label));
                setPeople(newPeople);
            }
        }
    };

    const mapUser = (obj) => ({ id: obj.id, label: obj.displayName, mail: obj.mail, givenName: obj.givenName });

    const provider = (query) => {
        if (!query) return Promise.resolve([[], 0]);

        return Api.searchUsers(query)
            .then((results: any) => [results.value.map(mapUser), results.value.length])
            .catch((e) => console.log(e));
    };

    const classes = useRowStyles();

    return (
        <div className={classes.base}>
            <div className="px-4" style={{ background: "white" }}>
                <Breadcrumbs separator={<NavigateNextIcon />} aria-label="breadcrumb">
                    <Link color="inherit" to="/research-gateway" className={classes.breadcrumbsText}>
                        {" "}
                        Research Gateway{" "}
                    </Link>
                    <Typography color="textPrimary" className={classes.currentTab}>
                        New Entry
                    </Typography>
                </Breadcrumbs>
                <hr />
                <Grid
                    className="pt-3"
                    container
                    direction="row"
                    justifyContent="flex-start"
                    alignItems="center"
                    spacing={4}
                >
                    {fields?.map((field: any, index: number) => {
                        return (
                            <Grid
                                key={field.id + "_" + index}
                                container
                                item
                                xs={field.colWidth}
                                sm={field.colWidth}
                                md={field.colWidth}
                                lg={field.colWidth}
                                xl={field.colWidth}
                            >
                                <MuiForm
                                    field={field}
                                    value={entry?.[field?.id] || ""}
                                    methods={methods}
                                    onChange={(value) => onChange(value, field?.id)}
                                    handleAdd={handleAdd}
                                    provider={provider}
                                />
                            </Grid>
                        );
                    })}
                </Grid>
                <Grid className="pt-2 pb-3" container direction="row" justifyContent="flex-end" alignItems="center">
                    <Button onClick={handleSubmit(onSubmit)} color="primary" variant={"contained"}>
                        {" "}
                        Submit{" "}
                    </Button>
                </Grid>
            </div>

            {/* <div>
                <FormInputRadio name={"radioValue"} control={control} label={"Radio Input"} options={[{ label: "Radio Option 1", value: "1", }, { label: "Radio Option 2", value: "2", },]} />
                <FormInputMultiCheckbox control={control} setValue={setValue} name={"checkboxValue"} label={"Checkbox Input"} options={[{ label: "Checkbox Option 1", value: "1", }, { label: "Checkbox Option 2", value: "2", },]} />
                <Button onClick={handleSubmit(onSubmit)} variant={"contained"}> Submit </Button>
                <Button onClick={() => reset()} variant={"outlined"}> Reset </Button>
            </div> */}
        </div>
    );
}
