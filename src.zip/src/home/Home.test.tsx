import { act, render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter as Router } from "react-router-dom";
import Home from "./Home";
import axios from "axios";

jest.mock("axios");
const mockedAxios = axios as jest.Mocked<typeof axios>;

test("renders home", async () => {
    mockedAxios.get.mockImplementation(async (url) => {
        if (url == "/api/admin/apps") {
            return {
                data: {
                    apps: [
                        {
                            _id: "entity-master",
                            title: "Entity Master",
                            title_html: "Entity<BR>Master",
                            view_order: 1,
                            show_on_portal: true,
                        },
                        {
                            _id: "research-gateway",
                            title: "Research Gateway",
                            title_html: "Research<BR>Gateway",
                            view_order: 2,
                            show_on_portal: true,
                        },
                    ],
                },
            };
        } else if (url == "/api/research-gateway/entries") {
            return { entries: [] };
        }
        return {};
    });

    act(() => {
        render(
            <Router initialentries={["/entity-master"]} initialIndex={0}>
                <Home />
            </Router>
        );
    });

    await waitFor(() => {
        const textElements = screen.getAllByText(/Research/);
        expect(textElements.length).toBe(1);
    });
});
