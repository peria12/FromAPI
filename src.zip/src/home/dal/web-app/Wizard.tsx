import React, { useState, useContext } from "react";
import { Box, Button, Card, CardContent, Step, StepLabel, Stepper, Typography } from "@mui/material";
import { useHistory } from "react-router-dom";
import EntitiesContainer from "./tabs/EntitiesTabs/EntitiesContainer";
import FieldsContainer from "./tabs/FieldsTabs/FieldsContainer";
import { BuildJsonContext } from "./contexts/BuildJsonContext";

const steps = ["Fields", "Entities", "Dates"];

export default function DALPlugin() {
    const history = useHistory();
    const [activeStep, setActiveStep] = useState<number>(0);
    const {
        manageEntityScreenJson,
        selectedEntityData,
        savedEntityData,
        manageFieldsScreenJson,
        selectedFieldsData,
        savedFieldsData,
    } = useContext(BuildJsonContext);

    const saveEntitiesData = () => {
        manageEntityScreenJson?.({ type: "saveEntityData", payload: selectedEntityData });
        if (selectedEntityData.length !== 0)
            manageEntityScreenJson?.({ type: "updateEntitiesJson", payload: selectedEntityData });
    };
    const resetEntitiesData = () => {
        manageEntityScreenJson?.({ type: "resetEntityData" });
        manageEntityScreenJson?.({ type: "updateSearchEntity", payload: savedEntityData });
    };
    const saveFieldsData = () => {
        manageFieldsScreenJson?.({ type: "saveFieldsData", payload: selectedFieldsData });
        if (selectedFieldsData.length !== 0)
            manageFieldsScreenJson?.({ type: "updateFieldsJson", payload: selectedFieldsData });
    };
    const resetFieldsData = () => {
        manageFieldsScreenJson?.({ type: "resetFieldsData" });
        manageFieldsScreenJson?.({ type: "updateFieldsData", payload: savedFieldsData });
    };

    const handleNext = () => {
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
        if (steps[activeStep] === "Entities") {
            saveEntitiesData();
        }
        if (steps[activeStep] === "Fields") {
            saveFieldsData();
        }
    };

    const handleBack = () => {
        setActiveStep((prevActiveStep) => prevActiveStep - 1);
    };

    const handleCancel = () => {
        history.push("/dal/webui");
        if (steps[activeStep] === "Entities") {
            resetEntitiesData();
        }
        if (steps[activeStep] === "Fields") {
            resetFieldsData();
        }
    };

    return (
        <Box sx={{ width: "80%", margin: "80px auto 80px auto" }}>
            <Stepper activeStep={activeStep} alternativeLabel>
                {steps.map((label) => {
                    const stepProps = {};
                    const labelProps = {};

                    return (
                        <Step key={label} {...stepProps}>
                            <StepLabel {...labelProps}>{label}</StepLabel>
                        </Step>
                    );
                })}
            </Stepper>
            {activeStep === steps.length ? (
                <>
                    <Card sx={{ minWidth: 275, minHeight: 300, margin: 2 }}>
                        <CardContent>
                            <Typography variant="body2">Fetching data...</Typography>
                            <Box sx={{ display: "flex", flexDirection: "row", pt: 2 }}>
                                <Box sx={{ flex: "1 1 auto" }} />
                                {/* <Button onClick={handleReset}>Reset</Button> */}
                            </Box>
                        </CardContent>
                    </Card>
                </>
            ) : (
                <>
                    <Typography component="div" sx={{ my: 2 }}>
                        <Card sx={{ width: "100%", minHeight: 420 }}>
                            {activeStep === 0 && <FieldsContainer />}
                            {activeStep === 1 && <EntitiesContainer />}
                            {activeStep === 2 && (
                                <div>
                                    <p>Dates Containter</p>
                                </div>
                            )}
                        </Card>
                    </Typography>
                    <Box sx={{ display: "flex", flexDirection: "row", pt: 2 }}>
                        <Button color="primary" variant="outlined" onClick={handleCancel}>
                            Cancel
                        </Button>
                        <Box sx={{ flex: "1 1 auto" }} />
                        {activeStep !== 0 && (
                            <Button color="secondary" variant="outlined" onClick={handleBack} sx={{ mr: 1 }}>
                                Previous
                            </Button>
                        )}
                        {activeStep === steps.length - 1 ? (
                            <Button variant="contained" color="primary">
                                Fetch Data
                            </Button>
                        ) : (
                            <Button variant="contained" color="primary" onClick={handleNext}>
                                Next
                            </Button>
                        )}
                    </Box>
                </>
            )}
        </Box>
    );
}
