import React from "react";
import { Switch, Route } from "react-router-dom";

import { BuildJsonContextProvider } from "./contexts/BuildJsonContext";
import AppCover from "../../dashboad/AppCover";
import WebUI from "./WebUI";
import "./dalwebui.scss";

export default function WebApp() {
    return (
        <AppCover className="dal-web">
            <BuildJsonContextProvider>
                <Switch>
                    <Route path="/dal/webui">
                        <WebUI />
                    </Route>
                </Switch>
            </BuildJsonContextProvider>
        </AppCover>
    );
}
