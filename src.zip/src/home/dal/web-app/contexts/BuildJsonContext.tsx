import React, { createContext, useState, useMemo } from "react";

export interface BuildJsonComponentContext {
    buildJsonValue?: any;
    setBuildJsonValue?: (buildJsonValue: any) => void;

    isFromDalPlugin?: boolean;
    setIsFromDalPlugin?: (name: boolean) => void;

    selectedFieldsData?: any;
    setSelectedFieldsData?: (selectedFieldsData: any) => void;

    savedFieldsData?: any;
    setSavedFieldsData?: (savedFieldsData: any) => void;

    selectedSubFieldsData?: any;
    setSelectedSubFieldsData?: (selectedSubFieldsData: any) => void;

    savedSubFieldsData?: any;
    setSavedSubFieldsData?: (savedSubFieldsData: any) => void;

    selectedFilterData?: any;
    setSelectedFilterData?: ((selectedFilterData: any) => void | undefined) | undefined;

    savedFilterData?: any;
    setSavedFilterData?: (savedFilterData: any) => void;

    manageFieldsScreenJson?: ((action: any) => void | undefined) | undefined;

    selectedEntityData?: any;
    setSelectedEntityData?: (selectedEntityData: any) => void;

    savedEntityData?: any;
    setSavedEntityData?: (savedEntityData: any) => void;

    manageEntityScreenJson?: ((action: any) => void | undefined) | undefined;
}
const initialContext = {
    buildJsonValue: {},
    isFromDalPlugin: false,
    selectedFieldsData: [],
    savedFieldsData: [],
    selectedEntityData: [],
    savedEntityData: [],
    selectedSubFieldsData: [],
    savedSubFieldsData: [],
    selectedFilterData: [],
    savedFilterData: [],
};

export const BuildJsonContext = createContext<BuildJsonComponentContext>(initialContext);

export const BuildJsonContextProvider = (props: any) => {
    const [buildJsonValue, setBuildJsonValue] = useState<any>(props.buildJsonValue || initialContext.buildJsonValue);

    const [isFromDalPlugin, setIsFromDalPlugin] = useState<boolean>(
        props.isFromDalPlugin || initialContext.isFromDalPlugin
    );
    const [selectedFieldsData, setSelectedFieldsData] = useState<any>(
        props.selectedFieldsData || initialContext.selectedFieldsData
    );
    const [savedFieldsData, setSavedFieldsData] = useState<any>(
        props.savedFieldsData || initialContext.savedFieldsData
    );
    const [selectedFilterData, setSelectedFilterData] = useState<any>(
        props.selectedFilterData || initialContext.selectedFilterData
    );
    const [savedFilterData, setSavedFilterData] = useState<any>(
        props.savedFilterData || initialContext.savedFilterData
    );
    const [selectedSubFieldsData, setSelectedSubFieldsData] = useState<any>(
        props.selectedSubFieldsData || initialContext.selectedSubFieldsData
    );
    const [savedSubFieldsData, setSavedSubFieldsData] = useState<any>(
        props.savedSubFieldsData || initialContext.savedSubFieldsData
    );
    const [selectedEntityData, setSelectedEntityData] = useState<any>(
        props.selectedEntityData || initialContext.selectedEntityData
    );

    const [savedEntityData, setSavedEntityData] = useState<any>(
        props.savedEntityData || initialContext.savedEntityData
    );
    const manageEntityScreenJson = (action) => {
        if (action.type === "addSearchEntity") {
            if (Array.isArray(action.payload)) {
                setSelectedEntityData((current) => [...current, ...action.payload]);
            } else {
                setSelectedEntityData((current) => [...current, action.payload]);
            }
        }
        if (action.type === "saveEntityData") {
            setSavedEntityData(action.payload);
        }
        if (action.type === "resetEntityData") {
            setSelectedEntityData([]);
        }
        if (action.type === "updateSearchEntity") {
            setSelectedEntityData(action.payload);
        }
        if (action.type === "removeSearchEntity") {
            setSelectedEntityData((current) =>
                current.filter((entity) => {
                    return entity !== action.payload;
                })
            );
        }
        if (action.type === "updateEntitiesJson") {
            setBuildJsonValue((current) => {
                return { ...current, entities: action.payload };
            });
        }
    };
    const manageFieldsScreenJson = (action) => {
        if (action.type === "addFields") {
            setSelectedFieldsData((current) => [...current, action.payload]);
        }
        if (action.type === "removeField") {
            setSelectedFieldsData((current) =>
                current.filter((field) => {
                    return field.id !== action.payload;
                })
            );
        }
        if (action.type === "saveFieldsData") {
            setSavedFieldsData(action.payload);
        }
        if (action.type === "updateFieldsData") {
            setSelectedFieldsData(action.payload);
        }
        if (action.type === "resetFieldsData") {
            setSelectedFieldsData([]);
        }
        if (action.type === "addSubField") {
            setSelectedSubFieldsData((current) => [...current, action.payload]);
        }
        if (action.type === "saveSubFieldsData") {
            setSavedSubFieldsData(action.payload);
        }
        if (action.type === "removeSubField") {
            setSelectedSubFieldsData((current) =>
                current.filter((subfield) => {
                    return subfield.id !== action.payload;
                })
            );
        }
        if (action.type === "addFilters") {
            setSelectedFilterData((current) => [
                ...current.filter((x) => x.filterObj.parameterID !== action.payload.filterObj.parameterID),
                action.payload,
            ]);
        }
        if (action.type === "saveFiltersData") {
            setSavedFilterData(action.payload);
        }
        if (action.type === "updateFieldsJson") {
            setBuildJsonValue((current) => {
                return { ...current, fields: action.payload };
            });
        }
    };
    const providerValue = useMemo(
        () => ({
            buildJsonValue,
            setBuildJsonValue,
            isFromDalPlugin,
            setIsFromDalPlugin,
            selectedEntityData,
            savedEntityData,
            manageEntityScreenJson,
            selectedFieldsData,
            savedFieldsData,
            manageFieldsScreenJson,
            selectedSubFieldsData,
            savedSubFieldsData,
            selectedFilterData,
            savedFilterData,
            setSelectedFilterData,
        }),
        [
            buildJsonValue,
            isFromDalPlugin,
            selectedEntityData,
            savedEntityData,
            selectedFieldsData,
            savedFieldsData,
            selectedSubFieldsData,
            savedSubFieldsData,
            selectedFilterData,
            savedFilterData,
        ]
    );

    return <BuildJsonContext.Provider value={providerValue}>{props.children}</BuildJsonContext.Provider>;
};
