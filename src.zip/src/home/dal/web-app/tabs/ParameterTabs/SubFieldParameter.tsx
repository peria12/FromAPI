import React, { useState, useRef, useMemo, useContext } from "react";
import DeleteIcon from "@mui/icons-material/Delete";
import Button from "@mui/material/Button";
import InputBase from "@mui/material/InputBase";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";

import { BuildJsonContext } from "../../contexts/BuildJsonContext";

const inlineFormStyles = {
    display: "flex",
    gap: "8px",
};

const SubFieldParameter = ({ selectedField, selectedNestedField }) => {
    const [subField, setSubField] = useState("");
    const [error, setError] = useState(false);
    const gridRef = useRef<any>(null);
    const { manageFieldsScreenJson, selectedSubFieldsData } = useContext(BuildJsonContext);
    const gridStyle = useMemo(() => ({ marginTop: "20px", height: "240px", width: "100%" }), []);
    const defaultColDef = useMemo(() => {
        return {
            enableValue: true,
            width: 100,
            resizable: true,
            flex: 1,
            minWidth: 100,
            suppressMenu: true,
        };
    }, []);

    const columns = [
        { field: "subFieldValue", headerName: "Subfield", flex: 1, editable: false, sortable: false },
        {
            field: "action",
            headerName: "Action",
            cellRenderer: DeleteIcon,
        },
    ];

    const handleSubfield = () => {
        const isPresent = selectedSubFieldsData.some((item) => item.subFieldValue === subField);
        if (!isPresent) {
            setError(false);
            manageFieldsScreenJson?.({
                type: "addSubField",
                payload: {
                    id: subField,
                    subFieldValue: subField,
                    subFieldName: "sub_fields",
                    fieldName: selectedField,
                    nestedKey: selectedNestedField || selectedField,
                    isArray: true,
                },
            });
            setSubField("");
        } else {
            setError(true);
        }
    };

    const onCellClicked = (params) => {
        if (params.column.colId === "action") {
            console.log(params.data);
            manageFieldsScreenJson?.({ type: "removeSubField", payload: params.data.id });
        }
    };

    return (
        <>
            <div style={inlineFormStyles}>
                <Typography sx={{ color: "#8E8D8D", fontSize: "15px", display: "flex", alignItems: "center" }}>
                    Sub field
                </Typography>
                <Paper component="div" className="dalSearchInput">
                    <InputBase
                        sx={{ ml: 1, flex: 1 }}
                        placeholder=""
                        inputProps={{ "aria-label": "Add Sub Fields" }}
                        value={subField}
                        onChange={(e) => setSubField(e.target.value)}
                    />
                </Paper>
                <Button color="secondary" variant="outlined" onClick={() => handleSubfield()}>
                    Add Subfield
                </Button>
                {error && <small className="error">SubField already added</small>}
            </div>
            <div style={gridStyle} className="ag-theme-balham">
                <AgGridReact
                    ref={gridRef}
                    rowData={selectedSubFieldsData}
                    columnDefs={columns}
                    defaultColDef={defaultColDef}
                    rowSelection={"single"}
                    onCellClicked={onCellClicked}
                />
            </div>
        </>
    );
};

export default SubFieldParameter;
