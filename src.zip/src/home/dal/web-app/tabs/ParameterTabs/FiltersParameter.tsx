import Button from "@mui/material/Button";
import InputBase from "@mui/material/InputBase";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import React, { useEffect, useState, useRef, useContext, useCallback } from "react";
import TableComponent from "../../components/TableComponent";
import DeleteIcon from "@mui/icons-material/Delete";

import { BuildJsonContext } from "../../contexts/BuildJsonContext";

const FiltersParameter = ({ selectedField }) => {
    const [filterIDType, setFilterIDType] = useState<string>("");
    const [filterInputId, setFilterInputId] = useState<string>("");
    const [filterIds, setFilterIds] = useState<any>([]);
    const gridRef = useRef<any>(null);
    const { selectedFilterData, setSelectedFilterData } = useContext(BuildJsonContext);
    const componentDidMount = useRef(false);
    useEffect(() => {
        if (!componentDidMount.current) {
            componentDidMount.current = true;
            const getFiltersByField = () => {
                const filterVal = selectedFilterData.filter((item) => item?.filterObj?.selectedField === selectedField);
                if (filterVal.length !== 0) {
                    setFilterIds(filterVal[0].filterObj.filter.ids);
                    setFilterIDType(filterVal[0].filterObj.filter.id_type);
                }
            };
            getFiltersByField();
        }
    }, [selectedFilterData, selectedField]);

    const handleAddFilterID = (event) => {
        const { name, value } = event.target;
        if (name === "filterIDType") {
            setFilterIDType(value);
        }
        if (name === "filterID") {
            setFilterInputId(value);
        }
    };
    const addFiltersCallback = useCallback(() => {
        if (setSelectedFilterData)
            setSelectedFilterData((current) => [
                ...current.filter((x) => x.filterObj.selectedField !== selectedField),
                { filterObj: { selectedField: selectedField, filter: { id_type: filterIDType, ids: [filterIds] } } },
            ]);
    }, [filterIds, filterIDType, selectedField, setSelectedFilterData]);
    useEffect(() => {
        addFiltersCallback();
    }, [addFiltersCallback]);
    const submitAddFilterId = () => {
        setFilterIds((ids) => [...ids, filterInputId]);
    };

    const columns = [
        { field: "filterID", headerName: "Filter IDs", flex: 1, editable: false, sortable: false },
        {
            field: "action",
            headerName: "Action",
            cellRenderer: DeleteIcon,
        },
    ];
    let formatFilter: any = [];
    function formatFilterData() {
        filterIds.forEach((itemid) => {
            formatFilter = [...formatFilter, { id: itemid, filterID: itemid }];
        });
        return formatFilter;
    }
    const onCellClicked = (params) => {
        if (params.column.colId === "action") {
            setFilterIds((oldValues) => {
                return oldValues.filter((item) => item !== params.data.id);
            });
        }
    };
    return (
        <>
            <div className="filtersTab">
                <Typography>ID Type</Typography>
                <Paper component="div" className="dalSearchInput">
                    <InputBase
                        sx={{ ml: 1, flex: 1 }}
                        name="filterIDType"
                        value={filterIDType}
                        onChange={handleAddFilterID}
                        inputProps={{ "aria-label": "Id Type" }}
                    />
                </Paper>
                <Typography>ID</Typography>
                <Paper component="div" className="dalSearchInput">
                    <InputBase
                        sx={{ ml: 1, flex: 1 }}
                        onChange={handleAddFilterID}
                        name="filterID"
                        inputProps={{ "aria-label": "Id" }}
                    />
                </Paper>
                <Button color="secondary" variant="outlined" onClick={submitAddFilterId}>
                    Add Filter Id
                </Button>
            </div>
            <TableComponent
                gridRef={gridRef}
                rowData={formatFilterData()}
                columnData={columns}
                onCellClicked={onCellClicked}
            />
        </>
    );
};
export default FiltersParameter;
