import React, { useState } from "react";
import PropTypes from "prop-types";
import Button from "@mui/material/Button";
import SubFieldParameter from "./SubFieldParameter";
import FiltersParameter from "./FiltersParameter";
import { CardContent, Tabs, Tab, Box } from "@mui/material";

function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ padding: "24px 0" }}>
                    <Box>{children}</Box>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        "aria-controls": `simple-tabpanel-${index}`,
    };
}

export default function ParametersContainer({
    selectedField,
    handleSubFieldModal,
    selectedNestedField,
}: {
    selectedField: any;
    handleSubFieldModal: any;
    selectedNestedField: any;
}) {
    const [value, setValue] = useState(0);
    const [, setIsOpen] = useState(false);
    //const [saveParams, setSaveParams] = useState(false);
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    // useEffect(() => {
    //     if (saveParams) handleSubFieldModal(false);
    // }, [saveParams]);

    const handleSaveParameters = () => {
        // setSaveParams(true)
    };
    const handleCancel = () => {
        handleSubFieldModal(false);
    };
    return (
        <CardContent className="DalWebTab">
            <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                <Tabs
                    TabIndicatorProps={{ style: { background: "none" } }}
                    value={value}
                    onChange={handleChange}
                    aria-label="basic tabs example"
                >
                    <Tab label="Subfield" {...a11yProps(0)} />
                    <Tab label="Filters" {...a11yProps(1)} />
                    <Tab label="Others" {...a11yProps(2)} />
                </Tabs>
            </Box>
            <TabPanel value={value} index={0}>
                <SubFieldParameter selectedField={selectedField} selectedNestedField={selectedNestedField} />
            </TabPanel>
            <TabPanel value={value} index={1}>
                <FiltersParameter selectedField={selectedField} />
            </TabPanel>
            {/* <TabPanel value={value} index={2}>
        <OthersParameters parameterID={selectedField} selectedNestedField={selectedNestedField}/>
      </TabPanel> */}
            <div className="flex-container">
                <Button color="error" variant="outlined" onClick={() => handleCancel()}>
                    Cancel
                </Button>
                <Button color="secondary" variant="outlined" onClick={() => setIsOpen(true)}>
                    Add Fields
                </Button>
                <Button variant="contained" color="primary" onClick={() => handleSaveParameters()}>
                    Save Parameters
                </Button>
            </div>

            {/* <CustomModal
        showModal={isOpen}
        bodyComponent={<NestedSubFieldContainer handleNestedSubFieldModal={handleNestedSubFieldModal} selectedField={selectedField}/>}
        className={'Modal nestedfields'}
      /> */}
        </CardContent>
    );
}
