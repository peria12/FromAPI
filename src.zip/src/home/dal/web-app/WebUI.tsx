import React, { useEffect, useState, useContext } from "react";
import { useHistory, Switch, Route, useRouteMatch } from "react-router-dom";
import { Container, Button, Backdrop, Box, CircularProgress } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import Wizard from "./Wizard";

import { BuildJsonContext } from "./contexts/BuildJsonContext";

declare global {
    interface Window {
        chrome: {
            webview: {
                postMessage: (message: any) => void;
            };
        };
    }
}
export default function DALFields() {
    const {
        push,
        location: { pathname },
    } = useHistory();

    const isFromExcel = window.navigator.userAgent.toLowerCase().includes("dalplugin");

    const { path } = useRouteMatch();

    const [loading, setLoading] = useState<boolean>(false);
    const [inputText, setInputText] = useState<any>("");
    const [error, setError] = useState<boolean>(false);
    const [errorMsg, setErrorMsg] = useState<string>("");

    const { buildJsonValue, isFromDalPlugin, setIsFromDalPlugin } = useContext(BuildJsonContext);
    const textArea = {
        "& textarea": {
            boxSizing: "border-box",
            width: "100%",
            margin: "20px 0px",
            padding: "10px",
            fontSize: "16px",
            background: "#FFFFFF 0% 0% no-repeat padding-box",
            boxShadow: "0.45px 2px 10px #7777771A",
            border: "1px solid #000",
            borderRadius: "6px",
            outline: "none",
            resize: "none",
        },
    };
    useEffect(() => {
        if (isFromExcel) {
            setIsFromDalPlugin?.(true);
            const Header = document.querySelector("#title-bar")?.classList as DOMTokenList;
            Header.add("hideHeader");
            const AppNav = document.querySelector(".app-top-nav")?.classList as DOMTokenList;
            AppNav.add("hideAppNav");
        }
    }, [isFromExcel, setIsFromDalPlugin]);

    const isJsonString = (json) => {
        let isValid = false;
        const printError = function (error, explicit) {
            setErrorMsg(`[${explicit ? "EXPLICIT" : "INEXPLICIT"}] ${error.name}: ${error.message}`);
        };
        try {
            if (JSON.parse(json)) {
                setError(false);
                //dispatch(createJson(JSON.parse(json)))
                //local storage setJsonCreator(JSON.parse(json));
            }
            isValid = true;
        } catch (e) {
            setError(true);
            if (e instanceof SyntaxError) {
                printError(e, true);
            } else {
                printError(e, false);
            }
        }
        return isValid;
    };
    useEffect(() => {
        setInputText(JSON.stringify(buildJsonValue, null, 4));
    }, [buildJsonValue]);

    const handleOnChange = (e) => {
        setInputText(e.target.value);
    };

    const handleClearInput = () => {
        setError(false);
        setErrorMsg("");
        setInputText("{}");
        // dispatch(resetFieldForm())
        // dispatch(resetEntitiesForm())
        // dispatch(resetDatesForm())
        // clear local storage
    };

    const handleWizardClick = () => {
        if (isJsonString(inputText)) {
            if (isFromDalPlugin) push(`${path}/wizard`);
            else push(`${path}/wizard`);
        }
    };

    const handleOpen = () => {
        if (isFromDalPlugin) {
            setLoading(true);
            // handleExcelFetch()
        } else {
            // setLoading(true)
            // navigate('/reportstable', { replace: true });
        }
    };

    return (
        <>
            {pathname === "/dal/webui" && (
                <Container maxWidth="lg" style={{ marginTop: 60 }}>
                    <div className="d-flex justify-content-end">
                        <Button color="error" variant="outlined" startIcon={<DeleteIcon />} onClick={handleClearInput}>
                            Clear
                        </Button>
                    </div>
                    <Box sx={textArea}>
                        <textarea rows={14} value={inputText} onChange={handleOnChange} />
                        <small className="error">{error && errorMsg}</small>
                    </Box>
                    <div className="d-flex justify-content-between">
                        <div>
                            <Button
                                color="secondary"
                                variant="outlined"
                                className="closebtn"
                                onClick={() => {
                                    if (isFromDalPlugin) window.chrome.webview.postMessage("CancelButtonClicked");
                                }}
                            >
                                Cancel
                            </Button>
                        </div>
                        <div className={"d-flex flex-row"}>
                            <Button
                                color="primary"
                                variant="contained"
                                style={{ marginRight: 15 }}
                                onClick={handleWizardClick}
                            >
                                Wizard
                            </Button>
                            <div>
                                <Button color="secondary" variant="outlined" onClick={handleOpen}>
                                    Fetch Data
                                </Button>
                                <Backdrop
                                    sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                                    open={loading}
                                >
                                    <CircularProgress />
                                </Backdrop>
                            </div>
                        </div>
                    </div>
                </Container>
            )}
            <Switch>
                <Route path={`${path}/Wizard`} component={Wizard} />
            </Switch>
        </>
    );
}
