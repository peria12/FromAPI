import React, { useMemo } from "react";

import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";

const TableComponent = ({ gridRef, rowData, columnData, onCellClicked }) => {
    const gridStyle = useMemo(() => ({ marginTop: "20px", height: "240px", width: "100%" }), []);
    const defaultColDef = useMemo(() => {
        return {
            enableValue: true,
            width: 100,
            resizable: true,
            flex: 1,
            minWidth: 100,
            suppressMenu: true,
        };
    }, []);

    return (
        <div style={gridStyle} className="ag-theme-balham">
            <AgGridReact
                ref={gridRef}
                rowData={rowData}
                columnDefs={columnData}
                defaultColDef={defaultColDef}
                rowSelection={"single"}
                onCellClicked={onCellClicked}
            />
        </div>
    );
};

export default TableComponent;
