import React, { useState, useEffect } from "react";
import { Button, CardContent, IconButton } from "@mui/material";
import Paper from "@mui/material/Paper";
import SearchInput from "../../../../common/SearchInput";
import ManageSearchSharpIcon from "@mui/icons-material/ManageSearchSharp";
import FieldsListDialog from "../tabs/FieldsTabs/FieldsListDialog";
import Api from "../../../../utils/api";

const AddFieldComponent = ({ setSearchFieldValue, searchFieldValue, handleAddField, tableComponent }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [dalFieldsList, setDalFieldsList] = useState<any>({ arr: [], obj: [] });
    const handleFieldList = () => {
        setIsOpen(true);
    };
    const handleClose = () => {
        setIsOpen(false);
    };
    useEffect(() => {
        Api.getDALFields()
            .then((data) => {
                const arr = Object.keys(data.dal).sort();
                const obj = arr.map((item) => {
                    return { id: item, label: item };
                });
                setDalFieldsList({ arr, obj });
            })
            .catch((e) => {
                console.log(e);
            });
    }, []);

    return (
        <CardContent>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: "20px" }}>
                <Paper
                    component="form"
                    sx={{
                        display: "flex",
                        alignItems: "center",
                        width: 300,
                        border: "1px solid #8E8E8E",
                        position: "relative",
                    }}
                >
                    <SearchInput
                        onChange={(_, v) => setSearchFieldValue(v)}
                        options={dalFieldsList.obj}
                        value={searchFieldValue}
                        placeholder="Search fields"
                        popperWidth="300px"
                        searchIcon={true}
                        disableUnderline={true}
                    />
                </Paper>
                <Button variant="contained" color="primary" onClick={handleAddField}>
                    Add Fields
                </Button>

                <IconButton
                    color="primary"
                    aria-label="search"
                    onClick={handleFieldList}
                    sx={{
                        borderRadius: "5px",
                        backgroundColor: "#9c27b0",
                        "&:hover": {
                            backgroundColor: "#9c27b0",
                        },
                    }}
                >
                    <ManageSearchSharpIcon sx={{ color: "#FFFFFF" }} />
                </IconButton>
                <FieldsListDialog open={isOpen} onClose={handleClose} fieldsName={dalFieldsList.arr} />
            </div>
            {tableComponent}
        </CardContent>
    );
};

export default AddFieldComponent;
