import { Checkbox, Paper, Table, TableBody, TableContainer, TableHead, TableRow, Typography } from "@mui/material";
import SearchBox from "common/SearchBox";
import AppCover from "home/dashboad/AppCover";
import React, { useEffect, useState } from "react";
import Access from "utils/access";
import Api from "utils/api";
import { useScreenshot } from "utils/helpers";

const noDataMessage = (
    <Typography align="center" component="h6" variant="subtitle1">
        No records found
    </Typography>
);

const getStripedStyle = (index) => ({ background: index % 2 ? "white" : "#fafafa" });

export default function AlertSubscriptions() {
    const subTypes = [
        { id: "email", title: "Email" },
        { id: "teams", title: "Teams" },
        { id: "portal", title: "Portal" },
    ];
    const [alertDefs, setAlertDefs] = useState<any>([]);
    const [alertSubs, setAlertSubs] = useState<any>([]);
    const [searchText, setSearchText] = useState("");

    const screenshot = useScreenshot();

    useEffect(() => {
        Promise.all([Api.getAlertDefs(), Api.getAlertSubscriptions(Access.userInfo.uuid)]).then(([al, subs]) => {
            setAlertDefs(al);
            setAlertSubs(subs || []);
            screenshot.take();
        });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    function updateSubData(id, type, status) {
        const list = [...alertSubs];
        let index = list.findIndex((ele) => ele.def_id === id);
        if (index == -1) {
            index = list.length;
            list[index] = { def_id: id, modes: [] };
        }
        let curModes = list[index]["modes"] || [];
        if (!curModes.includes(type) && status) {
            curModes.push(type);
        } else if (!status && curModes.includes(type)) {
            curModes = curModes.filter((ele) => ele != type);
        }
        list[index]["modes"] = curModes;
        setAlertSubs(list);
    }

    function Row({ index, alert }) {
        const handleCheckbox = (type, checked) => {
            const userId = Access.userInfo.uuid;
            if (checked) {
                Api.subscribeToAlert(alert._id, type.id, userId).then(() => {
                    updateSubData(alert._id, type.id, true);
                });
            } else {
                Api.unSubscribeToAlert(alert._id, type.id, userId).then(() => {
                    updateSubData(alert._id, type.id, false);
                });
            }
        };
        const isChecked = (type) => {
            const sub = alertSubs.find((x) => x.def_id == alert._id);
            return sub ? sub.modes.includes(type.id) || false : false;
        };

        return (
            <tr style={{ ...getStripedStyle(index) }}>
                <td align="left">
                    <div className="p-2"> {alert.name} </div>
                </td>
                {subTypes.map((type, i) => (
                    <td key={i} align="left">
                        <Checkbox
                            onChange={(event) => handleCheckbox(type, event.target.checked)}
                            checked={isChecked(type)}
                            size={"small"}
                            tabIndex={-1}
                            color="primary"
                            disableRipple
                            inputProps={{ "aria-labelledby": `list-item-${type}-label` }}
                        />
                    </td>
                ))}
            </tr>
        );
    }

    const filterDefs = (def) => {
        const words = searchText.split(" ").filter((x) => x.length);
        const nameLower = def.name.toLowerCase();
        return words.every((word) => nameLower.includes(word.toLowerCase()));
    };

    return (
        <AppCover header={<SearchBox setSearchText={setSearchText} placeholder="Search" />}>
            <TableContainer component={Paper}>
                <Table aria-label="application permission table">
                    <TableHead>
                        <TableRow className="fw-bold">
                            <td align="left" className="ps-2"></td>
                            {subTypes.map((type: any, i) => (
                                <td className="fw-bold py-3" key={i} align="left">
                                    {type.title}
                                </td>
                            ))}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {alertDefs.length ? (
                            alertDefs.filter(filterDefs).map((alert, i) => <Row index={i} key={i} alert={alert} />)
                        ) : (
                            <TableRow>
                                <td>{noDataMessage}</td>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </TableContainer>
        </AppCover>
    );
}
