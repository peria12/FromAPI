import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import Button from "@mui/material/Button";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";

import DOMPurify from "dompurify";
import MuiTable from "common/Table/MuiTable";
import Api from "utils/api";
import { useScreenshot } from "utils/helpers";
import { alertClearedNotification } from "utils/events";
import AppCover from "home/dashboad/AppCover";

const appInfo = { appId: "admin", subAppId: "alert" };
const meta = { nested: false, striped: true, dense: true, resizable: false, ordering: false };
const toolbarConfig = {
    queryFilter: true,
    searchBar: true,
    columnHideShow: true,
    CustomFilter: CheckBoxFilter,
};

const useStyles = makeStyles(() =>
    createStyles({
        btn: {
            textTransform: "capitalize",
            marginLeft: 8,
            margin: 2,
        },
        checkBox: {
            marginRight: "auto",
        },
    })
);

function getSubject({ props }) {
    const { row } = props;
    return (
        <div
            dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(row?.Subject || ""),
            }}
        />
    );
}

const alert_fields = [
    {
        _id: "Severity",
        title: "Severity",
        is_string: true,
        view_order: 1,
        show_on_table: true,
        sortable: true,
        filterable: 1,
    },
    {
        _id: "region",
        title: "Region",
        is_string: true,
        view_order: 2,
        show_on_table: true,
        sortable: true,
        filterable: 1,
    },
    {
        _id: "Source",
        title: "Source",
        is_string: true,
        view_order: 3,
        show_on_table: true,
        sortable: true,
        filterable: 1,
    },
    {
        _id: "Subject",
        title: "Subject",
        is_string: true,
        view_order: 4,
        show_on_table: true,
        sortable: true,
        filterable: 1,
    },
    {
        _id: "created_on",
        title: "Date",
        is_string: true,
        view_order: 5,
        show_on_table: true,
        sortable: true,
        filterable: 1,
    },
    {
        _id: "def_id",
        title: "Def Id",
        is_string: true,
        view_order: 6,
        show_on_table: true,
        sortable: true,
        filterable: 0,
    },
    {
        _id: "event_read",
        title: "Event Read",
        is_string: true,
        view_order: 7,
        show_on_table: false,
        sortable: true,
        filterable: 1,
    },
    {
        _id: "primary_action_button",
        title: "Action",
        view_order: 8,
        show_on_table: true,
        position: "center",
    },
];

const getAlertFields = () => Promise.resolve(alert_fields);

function CheckBoxFilter({ props }) {
    const [status, setStatus] = React.useState<any>(false);
    const classes = useStyles();
    const { queryParams, setQueryParams } = props;

    const handleChange = (event: any) => {
        setStatus(event.target.checked);

        let newParams = { ...queryParams };
        if (!event.target.checked) {
            delete newParams.event_read;
        } else {
            newParams = {
                ...queryParams,
                filters: { ...queryParams.filters, event_read: { $eq: false } },
            };
        }
        setQueryParams(newParams);
    };

    return (
        <div className={classes.checkBox}>
            <FormControlLabel
                control={<Checkbox checked={status} onChange={handleChange} name="isRead" color="primary" />}
                label="Unread Alerts"
            />
        </div>
    );
}

function ActionButtons({ props }) {
    const classes = useStyles();
    const { row, setTableData } = props;

    function handler(action: string) {
        if (!row._id) {
            console.log("No alert id not found");
        }
        if (action === "clear" && row._id) {
            Api.clearAlert(row._id, {}).then(() => {
                setTableData((tableData) => {
                    const rows = [...tableData.rows];
                    const index = rows.findIndex((r) => r._id == row._id);
                    if (index != -1) {
                        const info = rows[index];
                        info.event_read = true;
                        rows[index] = info;
                        return { ...tableData, rows: rows };
                    }
                    return tableData;
                });
                alertClearedNotification.next();
            });
        } else {
            console.log("Action not supported!");
        }
    }

    return (
        <div>
            <Button
                onClick={() => handler("ack")}
                variant="contained"
                size="small"
                color="primary"
                className={classes.btn}
            >
                Acknowledge
            </Button>
            <Button
                onClick={() => handler("action-needed")}
                variant="contained"
                size="small"
                color="secondary"
                className={classes.btn}
            >
                Action Needed
            </Button>
            <Button onClick={() => handler("clear")} variant="contained" size="small" className={classes.btn}>
                Clear
            </Button>
        </div>
    );
}

const styleCellHandler = (row: any) => row?.event_read === false;

export default function Alerts() {
    const screenshot = useScreenshot();

    const getTableData = (params: any) =>
        Api.getAlerts(params).then((resp: any) => {
            setTimeout(() => {
                screenshot.take();
            }, 200);
            return {
                records: resp?.events,
                total_records: resp?.total_records,
            };
        });

    return (
        <AppCover>
            <MuiTable
                appInfo={appInfo}
                meta={meta}
                fieldsApi={getAlertFields}
                tableDataApi={getTableData}
                toolbarConfig={toolbarConfig}
                rowConfig={{
                    customizeCell: {
                        primary_action_button: ActionButtons,
                        Subject: getSubject,
                    },
                    styleCell: {
                        style: {
                            fontWeight: "bold",
                        },
                        handler: styleCellHandler,
                    },
                }}
                // nestedTableConfig={{
                //     type: "Card",
                //     titleProp: "body",
                // }}
                defaultOrderBy={{
                    created_on: "desc",
                }}
            />
        </AppCover>
    );
}
