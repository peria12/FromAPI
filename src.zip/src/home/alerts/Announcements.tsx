import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useHistory } from "react-router-dom";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import Button from "@mui/material/Button";
import { MuiFormLine } from "common/mui-form/MuiForm";
import GoeForm from "home/goe/common/GoeForm";
import CheckboxGrid from "./CheckboxGrid";
import Api from "utils/api";
import FTSnackBar from "common/FTSnackBar";
import { useScreenshot } from "utils/helpers";
import AppCover from "home/dashboad/AppCover";

const useStyles = makeStyles(() =>
    createStyles({
        base: {
            width: "100%",
            background: "#fff",
            padding: "40px",
        },
        container: {
            width: "100%",
            padding: "0 30px",
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
        },
        btn: {
            textTransform: "capitalize",
            marginLeft: 8,
            margin: 2,
        },
        checkBox: {
            marginRight: "auto",
        },
    })
);

export default function Announcements({ apps }) {
    const classes = useStyles();
    const history = useHistory();
    const methods = useForm<any>({ mode: "onChange", defaultValues: {} });
    const [message, setMessage] = React.useState({ type: "", text: "", open: false });
    const appList = apps.map(({ _id, title }: any) => ({ key: _id, value: title }));
    const screenshot = useScreenshot();

    const formFields = [
        {
            label: "Subject",
            name: "subject",
            type: "text",
            required: true,
        },
        {
            label: "Apps",
            name: "apps",
            type: "checkbox-grid",
            options: appList,
            required: true,
            displayOrder: "column",
            levels: [
                { key: "info", value: "Info" },
                { key: "s1", value: "S1" },
                { key: "s2", value: "S2" },
            ],
        },
        {
            label: "Description",
            name: "body",
            type: "rich-text",
        },
        {
            label: "Attachments",
            name: "file",
            type: "files",
        },
    ];
    function handleSubmit() {
        methods.handleSubmit(
            (data) => {
                const apps = data?.apps?.length || 0;
                if (apps === 0) {
                    setMessage({ type: "error", text: "Apps required", open: true });
                    return;
                }
                Api.createAnnouncements(data).then(() => {
                    setMessage({
                        type: "success",
                        text: "Announcement created!",
                        open: true,
                    });
                    setTimeout(() => {
                        history.push("/admin/alerts");
                    }, 600);
                });
            },
            (err) => console.log("ERR", err)
        )();
    }

    useEffect(() => {
        screenshot.take();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <AppCover>
            <div className={classes.base}>
                <FTSnackBar snack={message} />
                <div className={classes.container}>
                    {formFields.map((field: any, index: number) => {
                        if (field?.type === "checkbox-grid") {
                            return (
                                <GoeForm key={index} label={field.label}>
                                    <CheckboxGrid
                                        key={field.name + index}
                                        field={field}
                                        methods={methods}
                                        options={appList}
                                    />
                                </GoeForm>
                            );
                        }
                        return <MuiFormLine key={field.name + index} field={field} methods={methods} />;
                    })}
                    <div style={{ marginLeft: "auto", width: "50%" }}>
                        <Button onClick={handleSubmit} variant="contained" color="primary" className={classes.btn}>
                            Save
                        </Button>
                    </div>
                </div>
            </div>
        </AppCover>
    );
}
