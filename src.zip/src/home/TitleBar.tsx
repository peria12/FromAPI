import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import logo from "assets/franklin-logo.webp";
import Api from "utils/api";
import Access from "utils/access";
import HomePopover from "./dashboad/HomePopover";
import FTSnackBar from "common/FTSnackBar";
import { alertClearedNotification, homePageResetNotification } from "utils/events";
import errorNotification from "utils/api-error";
import { Badge, Tooltip } from "@mui/material";

import PeopleDashBoardLight from "assets/ft-icons/PeopleDashboardLight.svg";
import PeopleDashBoardFull from "assets/ft-icons/PeopleDashboardFull.svg";
import AppLogDashBoardLight from "assets/ft-icons/AppLogDashboardLight.svg";
import AppLogDashBoardFull from "assets/ft-icons/AppLogDashboardFull.svg";
import DownloadPyFull from "assets/ft-icons/DownloadPyFull.svg";
import DownloadPyLight from "assets/ft-icons/DownloadPhLight.svg";
import EmailFull from "assets/ft-icons/send_email.svg";
import EmailLight from "assets/ft-icons/send_email_gs.svg";
import HomeFull from "assets/ft-icons/HomeFull.svg";
import HomeLight from "assets/ft-icons/HomeLight.svg";
import LogoutFull from "assets/ft-icons/LogoutFull.svg";
import LogoutLight from "assets/ft-icons/LogoutLight.svg";
import ResetFull from "assets/ft-icons/ResetFull.svg";
import ResetLight from "assets/ft-icons/ResetLight.svg";
import ConfirmDialog from "common/ConfirmDialog";
import Settings from "utils/settings";
import { getRandomMosaiqLogo } from "../utils/helpers";

const Photo = ({ img }) => <img style={{ borderRadius: "50%", height: "32px", width: "32px" }} src={img} />;

/*
function SearchAllApps() {
    return (
        <div className="title_bar_search">
            <div className="title_bar_search_inner">
                <span className="title_bar_search_text">Search All Apps</span>

                <svg
                    width="15.296875px"
                    height="15.9150390625px"
                    viewBox="0 0 16 16"
                    preserveAspectRatio="none"
                    fill="rgba(196.00000351667404, 196.00000351667404, 196.00000351667404, 1.0)"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <path
                        d="M15.2062 13.7147L12.5348 10.9505C13.254 9.88731 13.665 8.50521 13.665 7.12311C13.665 3.08314 10.5827 0 6.88387 0C2.97959 0 0 3.18945 0 7.12311C0 11.0568 3.08233 14.2462 6.88387 14.2462C8.21954 14.2462 9.45248 13.821 10.5827 13.0768L13.254 15.841C13.4595 16.0536 13.7677 16.0536 13.9732 15.841L15.3089 14.4589C15.4116 14.2462 15.4116 13.9273 15.2062 13.7147ZM6.78112 12.2262C4.10977 12.2262 1.95214 9.99362 1.95214 7.22943C1.95214 4.46524 4.00703 2.1263 6.78112 2.1263C9.55522 2.1263 11.6101 4.35892 11.6101 7.22943C11.6101 10.0999 9.45248 12.2262 6.78112 12.2262Z"
                        fill="rgba(196.00000351667404, 196.00000351667404, 196.00000351667404, 1.0)"
                    />
                </svg>
            </div>

            <div className="title_bar_search_line"></div>
        </div>
    );
}
*/

function RightSide({ path }) {
    const [img, setImg] = useState<any>(null);
    const [hasError, setHasError] = React.useState(false);
    const [errorInfo, setErrorInfo] = useState<any>({ type: "", text: "", open: false });
    const [alertCount, setAlertCount] = useState(0);
    const [links, setLinks] = useState<any>(null);
    const [confirmOpen, setConfirmOpen] = useState(false);

    const userInfo = Access.userInfo || {};
    const userFullName = userInfo.name || userInfo?.["first-name"] || userInfo?.first_name;

    const userNameArr = userFullName?.split(",");
    const firstChar = userNameArr?.pop()?.trim()?.charAt(0);
    const secChar = userNameArr?.pop()?.trim()?.charAt(0);

    const errorHandler = () => setImg(null);

    function loadAlertsCount(showPopup = false) {
        Api.getAlertsCount().then((alert_events) => {
            const alert_count = alert_events ? alert_events["total_records"] || 0 : 0;
            if (alert_count) {
                setAlertCount(alert_count);
                if (showPopup) {
                    errorNotification.next({
                        type: "warning",
                        text: `${alert_count} Alerts since last login`,
                        open: true,
                    });
                }
            }
        });
    }

    useEffect(() => {
        Api.getMyPhoto(errorHandler).then((data) => {
            if (data) {
                setImg(URL.createObjectURL(new Blob([data], { type: "image/jpeg" })));
            }
        });

        loadAlertsCount(true);

        const alertSub = alertClearedNotification.subscribe(() => {
            loadAlertsCount(false);
        });

        const errMessage = errorNotification.subscribe((errInfo: any) => {
            setErrorInfo(errInfo);
            if (errInfo.type) {
                setHasError(true);
            }
        });

        setInterval(loadAlertsCount, 300000);

        Api.getZoneSettings("admin", "portal").then((data) => {
            setLinks(data?.config?.titleLinks);
        });

        return () => {
            errMessage.unsubscribe();
            setErrorInfo({ type: "", text: "", open: false });
            setHasError(false);
            alertSub.unsubscribe();
        };
    }, []);

    const AlertCountBadge = () => (
        <Badge
            badgeContent={alertCount}
            overlap="circular"
            anchorOrigin={{
                vertical: "top",
                horizontal: "left",
            }}
            max={5000}
            color="secondary"
        >
            <div>
                {img ? (
                    <Photo img={img} />
                ) : (
                    <div className="title_bar_sub_img">{firstChar + (secChar ? secChar : "")}</div>
                )}
            </div>
        </Badge>
    );

    const onClose = () => {
        setErrorInfo({ type: "", text: "", open: false });
        setHasError(false);
    };

    const resetHomePage = () => {
        Settings.updateSettings("admin", "portal", "layout", []);
        homePageResetNotification.next();
    };

    const handleMouseEnterAndLeaveForTitleIcons = (elementId: string, action: string) => {
        const iconElement = document.getElementById(elementId) as HTMLImageElement | null;
        if (iconElement) {
            switch (elementId) {
                case "user-dashboard": {
                    if (action === "enter") iconElement.src = PeopleDashBoardFull;
                    else iconElement.src = PeopleDashBoardLight;
                    break;
                }
                case "download-py": {
                    if (action === "enter") iconElement.src = DownloadPyFull;
                    else iconElement.src = DownloadPyLight;
                    break;
                }
                case "app-log-dashboard": {
                    if (action === "enter") iconElement.src = AppLogDashBoardFull;
                    else iconElement.src = AppLogDashBoardLight;
                    break;
                }
                case "home": {
                    if (action === "enter") iconElement.src = HomeFull;
                    else iconElement.src = HomeLight;
                    break;
                }
                case "reset": {
                    if (action === "enter") iconElement.src = ResetFull;
                    else iconElement.src = ResetLight;
                    break;
                }
                case "logout": {
                    if (action === "enter") iconElement.src = LogoutFull;
                    else iconElement.src = LogoutLight;
                    break;
                }
                case "email": {
                    if (action === "enter") iconElement.src = EmailFull;
                    else iconElement.src = EmailLight;
                    break;
                }
                default:
                    null;
            }
        }
    };

    return (
        <>
            {hasError && <FTSnackBar snack={errorInfo} onClose={onClose} />}
            <div className="mx-1 cursor" />
            <div className="title_bar_button">
                <Tooltip title="Email Mosaiq Support" placement="top">
                    <a href="mailto:mosaiq-support@franklintempleton.com" target="_blank" rel="noreferrer">
                        <img
                            src={EmailLight}
                            alt="email"
                            className="title-icon"
                            id="email"
                            onMouseEnter={() => handleMouseEnterAndLeaveForTitleIcons("email", "enter")}
                            onMouseLeave={() => handleMouseEnterAndLeaveForTitleIcons("email", "leave")}
                        />
                    </a>
                </Tooltip>
            </div>

            <div className="mx-1 cursor" />
            <div className="title_bar_button">
                <Tooltip title="Download DAL Package" placement="top">
                    <a href={links?.dalPackage} target="_blank" rel="noreferrer" download>
                        <img
                            src={DownloadPyLight}
                            alt="download py"
                            className="title-icon"
                            id="download-py"
                            onMouseEnter={() => handleMouseEnterAndLeaveForTitleIcons("download-py", "enter")}
                            onMouseLeave={() => handleMouseEnterAndLeaveForTitleIcons("download-py", "leave")}
                        />
                    </a>
                </Tooltip>
            </div>

            <div className="mx-1" />
            <div className="title_bar_button">
                <Tooltip title="Usage Dashboard" placement="top">
                    <a href={links?.userDashboard} target="_blank" rel="noreferrer">
                        <img
                            src={PeopleDashBoardLight}
                            alt="user dashboard"
                            className="title-icon"
                            id="user-dashboard"
                            onMouseEnter={() => handleMouseEnterAndLeaveForTitleIcons("user-dashboard", "enter")}
                            onMouseLeave={() => handleMouseEnterAndLeaveForTitleIcons("user-dashboard", "leave")}
                        />
                    </a>
                </Tooltip>
            </div>
            <div className="mx-1" />
            <div className="title_bar_button">
                <Tooltip title="Application Logs Dashboard" placement="top">
                    <a href={links?.appLogsDashboard} target="_blank" rel="noreferrer">
                        <img
                            src={AppLogDashBoardLight}
                            alt="app logs dashboard"
                            className="title-icon"
                            id="app-log-dashboard"
                            onMouseEnter={() => handleMouseEnterAndLeaveForTitleIcons("app-log-dashboard", "enter")}
                            onMouseLeave={() => handleMouseEnterAndLeaveForTitleIcons("app-log-dashboard", "leave")}
                        />
                    </a>
                </Tooltip>
            </div>
            <div className="mx-3" />
            {path == "/" ? (
                <div className="title_bar_button">
                    <ConfirmDialog
                        title={"Confirm Reset"}
                        open={confirmOpen}
                        setOpen={setConfirmOpen}
                        onConfirm={resetHomePage}
                    >
                        Are you sure you want to reset the home page?
                    </ConfirmDialog>
                    <Tooltip title="Reset Home Page" placement="top">
                        <img
                            className="title-icon pointer"
                            src={ResetLight}
                            alt="reset home"
                            id="reset"
                            onMouseEnter={() => handleMouseEnterAndLeaveForTitleIcons("reset", "enter")}
                            onMouseLeave={() => handleMouseEnterAndLeaveForTitleIcons("reset", "leave")}
                            onClick={() => setConfirmOpen(true)}
                        />
                    </Tooltip>
                </div>
            ) : (
                <></>
            )}

            <div className="title_bar_button">
                <Tooltip title="Home" placement="top">
                    <Link to="/">
                        <img
                            src={HomeLight}
                            alt="home"
                            className="title-icon"
                            id="home"
                            onMouseEnter={() => handleMouseEnterAndLeaveForTitleIcons("home", "enter")}
                            onMouseLeave={() => handleMouseEnterAndLeaveForTitleIcons("home", "leave")}
                        />
                    </Link>
                </Tooltip>
            </div>
            <div className="mx-2" />
            <div className="title_right_side">
                {alertCount > 0 ? (
                    <Link to={"/alerts/inbox"}>
                        <AlertCountBadge />{" "}
                    </Link>
                ) : (
                    <AlertCountBadge />
                )}

                <span className="title_user_name">{userFullName}</span>
            </div>

            <div className="title_bar_button">
                <Tooltip title="Logout" placement="top">
                    <button className="ft-logout-btn">Logout</button>
                </Tooltip>
            </div>
        </>
    );
}

export default function TitleBar({ apps, path }) {
    const [build, setBuild] = useState({ version: "", env: "" });
    const [initialMosaiqLogo, setInitialMosaiqLogo] = useState("");
    const isLocalEnv = useMemo(() => process.env?.NODE_ENV?.toLowerCase() === "development", []);

    useEffect(() => {
        const initialLogo = getRandomMosaiqLogo();
        if (initialLogo) setInitialMosaiqLogo(initialLogo);
    }, []);

    const handleOnHoverLogo = () => {
        const appLogoElement = document.getElementById("appLogo") as HTMLImageElement | null;
        if (appLogoElement) {
            appLogoElement.src = initialMosaiqLogo;
        }
    };

    useEffect(() => {
        Api.getSystemInfo().then((info) => {
            if (info.env != "prod") {
                setBuild({
                    version: `[v${info.version}]`,
                    env: info.env,
                });
            }
        });
    }, []);

    const getBackgroundColor = () => {
        if (isLocalEnv) return "red";
        if (build.env == "dev" || build.env == "dev2") return "orange";
        if (build.env == "test") return "blue";
        if (build.env == "uat") return "green";
        else return "";
    };

    return (
        <div id="title-bar" className="d-flex justify-content-between title_bar">
            <div className="title_logo">
                <Link to={"/"}>
                    <img className="title_logo_img" width="124.0px" height="24.0px" src={logo} />
                    {(build.env || isLocalEnv) && (
                        <div className="ribbonWrapper">
                            <div style={{ backgroundColor: getBackgroundColor() }} className="ribbon">
                                {isLocalEnv ? "local" : build.env}
                            </div>
                        </div>
                    )}
                </Link>

                <img
                    id="appLogo"
                    onMouseEnter={() => handleOnHoverLogo()}
                    src={initialMosaiqLogo}
                    alt="app logo"
                    className="title-logo"
                />
            </div>

            <div className="title_bar_middle">
                <div className={"d-flex flex-row" + (path == "/" ? " d-none" : "")}>
                    <HomePopover apps={apps}></HomePopover>
                </div>
            </div>

            <div className="user-login d-flex flex-row">
                <RightSide path={path} />
            </div>
        </div>
    );
}
