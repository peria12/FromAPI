import React, { useState, useEffect } from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import Api from "utils/api";
import { errorHandler } from "utils/error-handler";
import Loader from "common/Loader";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import { FormFile } from "common/forms/FormFile";
import { defaultReportInfo } from "./SAAConfig";
import { get, convertToMap, useScreenshot } from "utils/helpers";

import ReportBuilder from "./ReportBuilder";
import errorNotification from "utils/api-error";
import FTDatePicker from "common/FTDatePicker";
import moment from "moment";
import AppCover from "home/dashboad/AppCover";

const useStyles = makeStyles(() =>
    createStyles({
        base: {
            width: "100%",
        },
        container: {
            width: "100%",
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
        },
        reportContainer: {
            display: "flex",
            justifyContent: "flex-start",
            flexDirection: "row",
            width: "100%",
            flexWrap: "wrap",
        },
        filter: {
            display: "flex",
            justifyContent: "center",
            flexDirection: "row",
            width: "100%",
        },
        tab: {
            textTransform: "capitalize",
            fontSize: "1.15rem",
        },
        selectFilePanel: {
            width: "80%",
            paddingTop: "20px",
        },
        reportPanel: {
            width: "100%",
            paddingTop: "16px",
            paddingLeft: "18px",
        },
        btn: {
            textTransform: "capitalize",
        },

        fileBtn: {
            color: "#00a0dc",
            cursor: "pointer",
        },
        fileNameText: {
            borderBottom: "1px solid #00a0dc",
        },
        iconBtn: {
            fontSize: "1.5rem",
            color: "#00a0dc",
        },
        downloadBtn: {
            display: "inline-flex",
            alignItems: "center",
            textDecoration: "auto",
            cursor: "pointer",
            paddingRight: "15px",
        },
    })
);

const InputTypes = ["input-table", "text", "number", "field-group"];

function ReportHeader({ reportInfo, reports }) {
    return (
        <div style={{ marginTop: "18px", width: "30%" }}>
            {reports &&
                reportInfo?.map((ele: any) => (
                    <div key={ele.key} style={{ display: "flex", paddingTop: "4px", width: "100%" }}>
                        <div style={{ width: "30%" }}>{ele?.title}</div>
                        <div style={{ width: "70%" }}>{reports[ele?.key]}</div>
                    </div>
                ))}
        </div>
    );
}

export default function AAReports({ app, type }) {
    const classes = useStyles();
    const [tabs, setTabs] = useState<any>([]);
    const [reportInfo, setReportInfo] = useState<any>({ ...defaultReportInfo });
    const [currTabInfo, setCurrTabInfo] = useState<any>({});
    const [filterValues, setFilterValues] = useState<any>({});
    const [templateConfig, setTemplateConfig] = useState<any>({});
    const [useAllValues, setUseAllValues] = useState<any>(false);
    const [date, setDate] = useState<any>(null);
    const [dateInfo, setDateInfo] = useState<any>({ availableDates: [] });
    const [fileList, setFileList] = useState<any>([]);

    const screenshot = useScreenshot();

    useEffect(() => {
        Api.getZoneSettings(app, type)
            .then((response: any) => {
                const ui_template = response?.ui_template;
                const tabs = ui_template?.tabs || [];
                if (!ui_template) {
                    const errorInfo = {
                        type: "error",
                        text: `Unable to fetch ${type?.toUpperCase()} settings`,
                        open: true,
                    };
                    errorNotification.next(errorInfo);
                } else if (tabs.length) {
                    setTabs(tabs);
                    const firstTab = tabs[0];
                    if (firstTab?.isDefault) {
                        setUseAllValues(firstTab?.useAllValues || false);
                    }
                    setCurrTabInfo({ ...firstTab });
                } else if (ui_template?.elements?.length > 0) {
                    setTemplateConfig(ui_template);
                }

                screenshot.take();
            })
            .catch((err: any) => {
                console.log(err);
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [type, app]);

    const getFormatedDate = (dateInput) => moment(dateInput).format("YYYY-MM-DD");

    useEffect(() => {
        setTabs([]);
        setCurrTabInfo({});
        setReportInfo((reportInfo) => ({ ...reportInfo, isLoading: false, reports: {} }));
        setTemplateConfig({});
    }, [type, app]);

    function apiHandler() {
        const curDate = moment(new Date()).format("YYYY-MM-DD");
        setDate(curDate);
        setDateInfo({ ...dateInfo, maxDate: curDate });
    }

    useEffect(() => {
        if (type == "ftis_risk_dashboard") {
            Api.getLatestAvailableDate({ all_available_dates: true })
                .then((response: any) => {
                    if (response?.dates?.length > 0) {
                        const availableDates = response?.dates;
                        const latestDate = availableDates[availableDates.length - 1];
                        const date = getFormatedDate(latestDate);
                        setDate(date);
                        setDateInfo({
                            availableDates: availableDates,
                            minDate: availableDates[0],
                            maxDate: date,
                        });
                    } else {
                        apiHandler();
                    }
                })
                .catch((err) => {
                    console.log(err);
                    apiHandler();
                });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [type]);

    useEffect(() => {
        let apiCall: any = null;
        let reportsAccessKey: any = null;
        if (type === "daa") {
            apiCall = Api.getDAAReports();
        } else if (type == "ftis_risk_dashboard") {
            if (!date) {
                return;
            }
            setReportInfo({ ...reportInfo, isLoading: true });
            apiCall = Api.getISRCPolicyPortfolioInfo({ date: moment(date).format("YYYY-MM-DD") });
            reportsAccessKey = "sections";
        }
        if (apiCall) {
            apiCall
                .then((response: any) => {
                    if (response) {
                        if (response?.error) {
                            errorNotification.next({ type: "error", text: response?.error || "failed", open: true });
                            if (reportsAccessKey) {
                                setReportInfo({ isLoading: false, reports: {} });
                            } else {
                                setReportInfo((reportInfo) => ({ ...reportInfo, isLoading: false }));
                            }
                        } else {
                            setReportInfo((reportInfo) => ({
                                ...reportInfo,
                                isLoading: false,
                                master: { ...response },
                                reports: reportsAccessKey ? response?.[reportsAccessKey] : response,
                            }));
                        }
                    } else {
                        errorNotification.next({ type: "error", text: "Failed to process", open: true });
                        setReportInfo((reportInfo) => ({ ...reportInfo, isLoading: false }));
                    }

                    screenshot.take();
                })
                .catch((e: any) => {
                    errorHandler(e);
                    errorNotification.next({ type: "error", text: "Error...", open: true });
                    setReportInfo((reportInfo) => ({ ...reportInfo, isLoading: false }));
                });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [type, app, date]);

    useEffect(() => {
        if (reportInfo?.reports) {
            const reportFilters = currTabInfo?.elements?.filter((ele) => InputTypes.includes(ele.type));
            const currTabFilters = {};
            reportFilters?.forEach((ele) => {
                if (ele?.id) {
                    const key = ele.accessKey || ele?.id;
                    currTabFilters[ele?.id] = get(reportInfo?.reports, key, null);
                }
            });
            setFilterValues((values) => ({
                ...values,
                [currTabInfo?.id]: { ...values?.[currTabInfo?.id], ...currTabFilters },
            }));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [currTabInfo]);

    const handleChange = (event, newValue) => {
        const tabInfo: any = tabs.find((tab) => tab.id == newValue) || {};
        setCurrTabInfo({ ...tabInfo });
    };

    const isTabDisabled = (index) => {
        if (reportInfo?.isReportGenerated) {
            return false;
        } else if (index !== currTabInfo.id) {
            return true;
        }
        return false;
    };

    const toNumber = (value) => {
        if (value != null && !isNaN(value)) {
            return parseFloat(value);
        }
        return null;
    };

    function validateFilterInput(inputs, fieldConfig) {
        if (Array.isArray(inputs)) {
            inputs.forEach((input) => {
                Object.keys(input).map((key) => {
                    if (fieldConfig[key].type === "number") {
                        input[key] = toNumber(input[key]);
                    }
                });
            });
        } else if (inputs && typeof inputs === "object") {
            Object.keys(inputs).map((key) => {
                if (fieldConfig[key].type === "number") {
                    inputs[key] = toNumber(inputs[key]);
                }
            });
        }
        return inputs;
    }

    function dateChangeHandler(value) {
        setDate(getFormatedDate(value));
    }

    function getReportIds() {
        const ids: any = [];
        currTabInfo?.elements?.forEach((config: any) => {
            switch (config?.type) {
                case "table":
                    ids.push(config?.id);
                    return;
                case "button-groups": {
                    const keys = config?.buttons?.map((ele) => ele.accessKey);
                    ids.push(...keys);
                    return;
                }
            }
        });
        return ids;
    }

    const transformInputs = (key, filters) => {
        const eleInfo = currTabInfo?.elements.find((ele: any) => ele.id == key) || {};
        switch (eleInfo?.type) {
            case "field-group":
                return validateFilterInput(filters[key], convertToMap(eleInfo.fields, "id"));
            case "number":
                return toNumber(filters[key]);
            case "input-table":
                return validateFilterInput(filters[key], convertToMap(eleInfo.rows, "id"));
            default:
                return filters[key];
        }
    };

    function isDateDisable(dateStr) {
        const date = getFormatedDate(dateStr);
        return !dateInfo?.availableDates.includes(date);
    }

    const applyFilters = () => {
        const filters = filterValues?.[currTabInfo?.id];
        const body = {};
        if (filters) {
            Object.keys(filters).forEach((key) => {
                body[key] = transformInputs(key, filters);
            });
        }
        const dataReports = {};
        getReportIds()?.forEach((id) => {
            dataReports[id] = {};
        });
        setReportInfo({ ...reportInfo, btnLoading: true, reports: { ...reportInfo?.reports, ...dataReports } });

        Api.runSAAReports(currTabInfo.api, reportInfo?.reports?.request_id, body)
            .then((_reports: any) => {
                if (_reports) {
                    if (_reports?.error) {
                        return onResponse(_reports?.error);
                    }
                    setReportInfo({
                        ...reportInfo,
                        btnLoading: false,
                        reports: { ...reportInfo.reports, ..._reports },
                    });
                    return;
                }
                return onResponse("Failed to process..");
            })
            .catch((e: any) => {
                errorHandler(e);
                return onResponse();
            });
    };

    function onResponse(message = "Error...") {
        errorNotification.next({ type: "error", text: message, open: true });
        setReportInfo({ ...reportInfo, btnLoading: false });
    }

    function handleFileChange(fileData) {
        setFileList(fileData);
        setReportInfo({
            ...reportInfo,
            isLoading: false,
            isReportGenerated: false,
            reports: {},
        });
        if (fileData?.length === 0) {
            return;
        }
        if (fileData?.length > 2) {
            const errorInfo = {
                type: "error",
                text: `Maximum 2 files can be uploaded !`,
                open: true,
            };
            errorNotification.next(errorInfo);
            return;
        }
        setReportInfo({
            ...reportInfo,
            isLoading: true,
            // isReportGenerated: false
        });
        // setMessage({ type: "info", text: "Processing...", open: true });
        Api.getSAAReports({ attachments: fileData, use_all_values: useAllValues })
            .then((response: any) => {
                if (response) {
                    if (response?.error) {
                        errorNotification.next({ type: "error", text: response?.error || "failed", open: true });
                        setReportInfo({ ...reportInfo, isLoading: false, reports: {}, isReportGenerated: false });
                    } else {
                        setReportInfo({ ...reportInfo, isLoading: false, isReportGenerated: true, reports: response });
                    }
                } else {
                    errorNotification.next({ type: "error", text: "Failed to process", open: true });
                    setReportInfo({ ...reportInfo, isLoading: false, isReportGenerated: false });
                }
            })
            .catch((e: any) => {
                errorHandler(e);
                errorNotification.next({ type: "error", text: "Error...", open: true });
                setReportInfo({ ...reportInfo, isLoading: false, isReportGenerated: false });
            });
    }

    let elements: any = [];
    if (currTabInfo?.elements?.length > 0) {
        elements = currTabInfo?.elements;
    } else if (templateConfig?.elements?.length > 0) {
        elements = templateConfig?.elements;
    }

    const headerComponent = (
        <>
            {type == "ftis_risk_dashboard" && date && (
                <div className="date-picker-alignment" style={{ marginTop: "8px" }}>
                    <FTDatePicker
                        label=""
                        style={{ width: "155px", height: "40px" }}
                        dateStr={date}
                        handleDateChange={dateChangeHandler}
                        minDate={dateInfo?.minDate}
                        maxDate={dateInfo?.maxDate}
                        shouldDisableDate={isDateDisable}
                    />
                </div>
            )}
        </>
    );

    return (
        <AppCover header={headerComponent}>
            <div className={classes.container}>
                {templateConfig?.title && (
                    <Typography style={{ padding: "7px 0px 5px" }} align="left" component="h6" variant="h6">
                        {templateConfig?.title}
                    </Typography>
                )}
                {tabs?.length > 0 && (
                    <Paper square>
                        <Tabs
                            value={currTabInfo.id}
                            indicatorColor="primary"
                            textColor="primary"
                            onChange={handleChange}
                        >
                            {tabs?.map((tab: any, index: number) => (
                                <Tab
                                    className={classes.tab}
                                    key={tab.id}
                                    value={tab.id}
                                    label={tab.label}
                                    disabled={isTabDisabled(index)}
                                />
                            ))}
                        </Tabs>
                    </Paper>
                )}
                <>
                    <div className={classes.reportContainer}>
                        {currTabInfo?.isDefault && (
                            <div className={classes.selectFilePanel}>
                                <FormFile
                                    title={"Drag and Drop or Select File (Only *.csv files will be accepted)"}
                                    value={[]}
                                    onChange={handleFileChange}
                                    multiple={true}
                                    showFileName={true}
                                    height={"100px"}
                                    accept={".csv"}
                                    fileListValue={fileList}
                                />
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            checked={useAllValues}
                                            sx={{ "& .MuiSvgIcon-root": { fontSize: 28 } }}
                                            onChange={(e) => setUseAllValues(e.target.checked)}
                                            name="isRead"
                                            color="primary"
                                        />
                                    }
                                    label="Use All Values"
                                />
                            </div>
                        )}
                    </div>

                    {reportInfo?.isLoading && <Loader />}
                    {templateConfig?.reportInfo && !reportInfo?.isLoading && (
                        <ReportHeader reportInfo={templateConfig?.reportInfo} reports={reportInfo?.master} />
                    )}
                    <div className={classes.reportContainer}>
                        {elements?.map((config: any) => (
                            <>
                                {config?.gridType == "row" ? (
                                    <div key={config.id} style={{ width: "100%" }}>
                                        <div className={classes.reportPanel} style={{ width: config?.width }}>
                                            <ReportBuilder
                                                key={config.id}
                                                config={config}
                                                classes={classes}
                                                handler={applyFilters}
                                                reportInfo={reportInfo}
                                                currTabInfo={currTabInfo}
                                                filterValues={filterValues}
                                                setFilterValues={setFilterValues}
                                                InputTypes={InputTypes}
                                                reportType={type}
                                            />
                                        </div>
                                    </div>
                                ) : (
                                    <div
                                        key={config.id}
                                        className={classes.reportPanel}
                                        style={{ width: config?.width }}
                                    >
                                        <ReportBuilder
                                            key={config.id}
                                            config={config}
                                            classes={classes}
                                            handler={applyFilters}
                                            reportInfo={reportInfo}
                                            currTabInfo={currTabInfo}
                                            filterValues={filterValues}
                                            setFilterValues={setFilterValues}
                                            InputTypes={InputTypes}
                                            reportType={type}
                                        />
                                    </div>
                                )}
                            </>
                        ))}
                    </div>
                </>
            </div>
        </AppCover>
    );
}
