import React, { useState, useEffect } from "react";
import { groupBy, roundNumber } from "utils/helpers";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-enterprise";
import EfficientFrontier from "./EfficientFrontier";
import AssetAllocationWeights from "./AssetAllocationWeights";
import { p_columns, tb3_rows } from "../../utils/aa-cfg";
import { percentPostfix } from "../../utils/aa-helper";

function groupRows(rows, restructuredData, grpBy = "asset_type") {
    const groupData = groupBy(rows, grpBy);
    let results: any = [];
    const totalValues = Object.fromEntries(p_columns.map((col) => [col.value, 0]));
    Object.keys(groupData).forEach((type) => {
        if (groupData[type]) {
            const value = groupData[type];
            const aggFields: any = Object.fromEntries(
                p_columns.map((col) => [
                    col.value,
                    groupData[type].reduce(
                        (da, dc) => da + (col.value === "bm" ? dc[col.value] || 0 : dc[col.value]),
                        0
                    ),
                ])
            );
            p_columns.forEach((col) => {
                totalValues[col.value] = totalValues[col.value] + aggFields[col.value];
            });
            let className = "";
            if (type === "Equity") {
                className = "saa-texthead-blue";
            }
            if (type === "Fixed Income") {
                className = "saa-texthead-red";
            }
            if (type === "Alternatives") {
                className = "saa-texthead-purple";
            }
            if (type === "Cash") {
                className = "saa-texthead-green";
            }
            results = [
                ...results,
                {
                    asset_name: type,
                    ...Object.fromEntries(
                        Object.entries(aggFields).map(([key, val]) => [
                            key,
                            typeof val === "number" ? roundNumber(val) : val,
                        ])
                    ),
                    className: "table-text-grey" + " " + className,
                    isGroupedRow: true,
                },
                {
                    asset_name: "Contribution to Risk",
                    className: "table-text-grey",
                    isGroupedRow: true,
                    ...Object.fromEntries(
                        Object.entries(restructuredData).map(([key, val]: any) => [
                            key === "p" ? key : "p" + val.frontier_point,
                            val?.contribution_to_risk?.[type] ? roundNumber(val?.contribution_to_risk?.[type]) : "",
                        ])
                    ),
                },
                ...value.map((asset) =>
                    Object.fromEntries(
                        Object.entries(asset).map(([key, val]) => [
                            key,
                            typeof val === "number" ? roundNumber(val) : val,
                        ])
                    )
                ),
            ];
        }
    });
    results.push({
        ...Object.fromEntries(
            Object.entries(totalValues).map(([key, val]) => [key, typeof val === "number" ? roundNumber(val) : val])
        ),
        className: "table-text-grey",
        isGroupedRow: true,
    });
    results.forEach((row, idx) => (row.key = idx));
    return results;
}

function restructureData(data) {
    const restructuredData: any = {};
    Object.keys(data).map((key) => {
        if (key === "final_objective") {
            restructuredData.p = data?.[key] ?? "";
        } else if (key === "frontier_points") {
            data[key]?.forEach((obj) => (restructuredData[obj.frontier_point] = obj));
        }
    });
    return restructuredData;
}

function formatDataForOptimalTable(restructuredData, benchmark) {
    const assetStrToValuesObj = {};
    const benchmarkMap = new Map();
    benchmark?.forEach((asset) => {
        benchmarkMap.set(
            [asset.asset_type || "", asset.category || "", asset.sub_category || "", asset.asset || ""].toString(),
            Number(asset.weight) || 0
        );
    });
    Object.keys(restructuredData).map((key) => {
        const assetsArr = restructuredData?.[key]?.solution || [];
        assetsArr.map((asset) => {
            const assetStr = asset?.asset?.toString();
            if (!Object.hasOwn(assetStrToValuesObj, assetStr)) {
                assetStrToValuesObj[assetStr] = {};
                assetStrToValuesObj[assetStr].asset_type = asset?.asset?.[0] || "";
                assetStrToValuesObj[assetStr].category = asset?.asset?.[1] || "";
                assetStrToValuesObj[assetStr].sub_category = asset?.asset?.[2] || "";
                assetStrToValuesObj[assetStr].asset_name = asset?.asset?.[3] || "";
            }
            const valueKey = key === "p" ? "p" : "p" + key;
            assetStrToValuesObj[assetStr][valueKey] = asset?.holding;
            assetStrToValuesObj[assetStr].bm = benchmarkMap.get(assetStr);
        });
    });
    return Object.values(assetStrToValuesObj);
}

function formatDataPart2(restructuredData) {
    const formattedPart2: any = {
        expected_return: {},
        total_risk: {},
        "5_pcnt_VaR": {},
        "5_pcnt_CVaR": {},
        sharpe_ratio: {},
        tracking_error: {},
        portfolio_predicted_beta: {},
        up_capture: {},
        down_capture: {},
    };
    Object.keys(restructuredData).map((key) => {
        const valueKey = key === "p" ? "p" : "p" + key;
        if (key === "p") {
            formattedPart2.expected_return.bm = roundNumber(restructuredData[key].benchmark_expected_return) || "";
            formattedPart2.total_risk.bm = roundNumber(restructuredData[key].total_benchmark_risk) || "";
            formattedPart2["5_pcnt_VaR"].bm = roundNumber(restructuredData[key]["benchmark_5_pcnt_VaR"]) || "";
            formattedPart2["5_pcnt_CVaR"].bm = roundNumber(restructuredData[key]["benchmark_5_pcnt_CVaR"]) || "";
            formattedPart2.sharpe_ratio.bm = roundNumber(restructuredData[key].benchmark_sharpe_ratio) || "";
        }
        formattedPart2.expected_return[valueKey] = roundNumber(restructuredData[key].expected_return) || "";
        formattedPart2.total_risk[valueKey] = roundNumber(restructuredData[key].total_risk) || "";
        formattedPart2["5_pcnt_VaR"][valueKey] = roundNumber(restructuredData[key]["5_pcnt_VaR"]) || "";
        formattedPart2["5_pcnt_CVaR"][valueKey] = roundNumber(restructuredData[key]["5_pcnt_CVaR"]) || "";
        formattedPart2.sharpe_ratio[valueKey] = roundNumber(restructuredData[key].sharpe_ratio) || "";
        formattedPart2.tracking_error[valueKey] = roundNumber(restructuredData[key].tracking_error) || "";
        formattedPart2.portfolio_predicted_beta[valueKey] =
            roundNumber(restructuredData[key].portfolio_predicted_beta) || "";
        formattedPart2.up_capture[valueKey] = roundNumber(restructuredData[key].up_capture) || "";
        formattedPart2.down_capture[valueKey] = roundNumber(restructuredData[key].down_capture) || "";
    });
    return formattedPart2;
}

export default function OptimalPortfolio({ data, editOrSelectSolution }) {
    const [groupedRows, setGroupedRows] = useState<any>([]);
    const [dataPart2, setDataPart2] = useState<any>({});
    const [onHoverCol, setOnHoverCol] = useState<any>(null);
    const frontierPoints = data?.data?.frontier_points?.map((obj) => "p" + obj.frontier_point) || [];

    useEffect(() => {
        const restructuredData = restructureData(data?.data);
        const formattedData = formatDataForOptimalTable(restructuredData, data?.benchmark);
        const formattedDataPart2 = formatDataPart2(restructuredData);
        setGroupedRows(groupRows(formattedData, restructuredData));
        setDataPart2(formattedDataPart2);
    }, [data]);

    function changePColumn(col) {
        setGroupedRows((groupedRows) =>
            groupedRows.map((row) => ({
                ...row,
                p: row[col],
            }))
        );
        setDataPart2((data) => {
            const newData = {};
            for (const key in data) {
                newData[key] = {
                    ...data[key],
                    p: data[key][col],
                };
            }
            return newData;
        });
        const selectedSolution = Object.values(data?.data?.frontier_points)?.find(
            (solution: any) => solution?.frontier_point === Number(col.slice(1))
        );
        editOrSelectSolution(selectedSolution);
    }

    return (
        <div id="output" className="opt-container" style={{ height: "100%" }}>
            <div className="w-content">
                <div className="left-panel">
                    <div className="table-container" style={{ flexDirection: "column", height: "calc(100% - 30px)" }}>
                        <div className="saa-tb1" style={{ display: "flex" }}>
                            <div className="first-group-table" style={{ marginTop: "42px" }}>
                                <table>
                                    <thead>
                                        <tr>
                                            <th>
                                                <div>
                                                    <span>Category</span>
                                                </div>
                                            </th>
                                            <th>
                                                <div>
                                                    <span>Sub Category</span>
                                                </div>
                                            </th>
                                            <th>
                                                <div>
                                                    <span>Asset Name</span>
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {groupedRows.map((row) => (
                                            <tr key={row.key} className={row.className}>
                                                <td>{row.category}&nbsp;</td>
                                                <td>{row.sub_category}&nbsp;</td>
                                                <td>{row.asset_name}&nbsp;</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                            {p_columns.map((col, idx) => (
                                <div key={idx}>
                                    {col.hoverEffect && (
                                        <div
                                            className="top-button"
                                            onMouseEnter={() => col.hoverEffect && setOnHoverCol(col.value)}
                                            onMouseLeave={() => col.hoverEffect && setOnHoverCol(null)}
                                            onClick={() => col.hoverEffect && changePColumn(col.value)}
                                            style={
                                                Object.keys(data?.data).length !== 0 &&
                                                frontierPoints.includes(col.value) &&
                                                onHoverCol === col.value
                                                    ? { visibility: "visible", cursor: "pointer", color: "black" }
                                                    : {}
                                            }
                                        >
                                            Make P*
                                        </div>
                                    )}
                                    <div
                                        className={col.class}
                                        onMouseEnter={() => col.hoverEffect && setOnHoverCol(col.value)}
                                        onMouseLeave={() => col.hoverEffect && setOnHoverCol(null)}
                                        onClick={() =>
                                            col.hoverEffect &&
                                            Object.keys(data?.data).length !== 0 &&
                                            frontierPoints.includes(col.value) &&
                                            changePColumn(col.value)
                                        }
                                        style={
                                            col.hoverEffect &&
                                            onHoverCol === col.value &&
                                            Object.keys(data?.data).length !== 0 &&
                                            frontierPoints.includes(col.value)
                                                ? { borderColor: "rgba(140, 140, 140, 1)", cursor: "pointer" }
                                                : {}
                                        }
                                    >
                                        <table>
                                            <thead>
                                                <tr>
                                                    <th>
                                                        <div>
                                                            <span>{col.label}</span>
                                                        </div>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {groupedRows.map((row) => (
                                                    <tr
                                                        key={row.key}
                                                        className={row.isGroupedRow ? "table-text-sum-num" : ""}
                                                    >
                                                        <td>{percentPostfix(row[col.value])}&nbsp;</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className="saa-tb3">
                            <div style={{ display: "flex" }}>
                                <div className="first-group-table" style={{ marginTop: 0 }}>
                                    <table>
                                        <tbody>
                                            {tb3_rows.map((row) => (
                                                <tr key={row.value}>
                                                    <td></td>
                                                    <td></td>
                                                    <td>{row.label}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                                {p_columns.map((col, idx) => (
                                    <div
                                        key={idx}
                                        className={col.class}
                                        onMouseEnter={() => col.hoverEffect && setOnHoverCol(col.value)}
                                        onMouseLeave={() => col.hoverEffect && setOnHoverCol(null)}
                                        onClick={() =>
                                            col.hoverEffect &&
                                            Object.keys(data?.data).length !== 0 &&
                                            frontierPoints.includes(col.value) &&
                                            changePColumn(col.value)
                                        }
                                        style={
                                            col.hoverEffect &&
                                            onHoverCol === col.value &&
                                            Object.keys(data?.data).length !== 0 &&
                                            frontierPoints.includes(col.value)
                                                ? {
                                                      borderColor: "rgba(140, 140, 140, 1)",
                                                      marginTop: "5px",
                                                      cursor: "pointer",
                                                  }
                                                : { marginTop: "5px" }
                                        }
                                    >
                                        <table>
                                            <tbody>
                                                {tb3_rows.map((row) => (
                                                    <tr key={row.value}>
                                                        <td>{dataPart2[row.value]?.[col.value]}&nbsp;</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
                <div className="right-panel">
                    <div style={{ minWidth: "800px", width: "100%", overflow: "scroll" }}>
                        <EfficientFrontier data={data?.data} selected={onHoverCol} />
                        <AssetAllocationWeights data={data?.data} />
                    </div>
                </div>
            </div>
        </div>
    );
}
