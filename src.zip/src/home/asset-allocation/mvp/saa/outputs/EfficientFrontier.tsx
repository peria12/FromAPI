import React from "react";
import Paper from "@mui/material/Paper";
import { HChart } from "common/HChart";
import { numberVal } from "../../utils/aa-helper";

function getOptions(data, selected) {
    const frontier_points = data?.frontier_points || [];
    const final_objective = data?.final_objective || [];
    if (!data?.frontier_points) {
        return { title: { text: "" } };
    }
    let maxSharp: any = null;
    const defMarker = { enabled: true, radius: 4, lineWidth: 2, symbol: "circle" };

    const seriesData: any = [
        {
            // stacking: "normal",
            showInLegend: false,
            marker: { ...defMarker, fillColor: "#FFF", lineColor: "#B29DF3" },
            data: frontier_points?.map((e) => {
                const info: any = {
                    x: numberVal(e.total_risk),
                    y: numberVal(e?.expected_return),
                    name: "P" + e?.frontier_point,
                };
                if (e.max_sharpe_ratio_ind) {
                    maxSharp = e;
                }
                if (selected) {
                    // const pfIndex = selected?.split("p")?.[1] - 1;
                    // if (i == pfIndex) {
                    //     info.marker = { ...defMarker, fillColor: "#FFF", lineColor: "#000" }
                    // }
                }
                return info;
            }),
        },
        {
            name: "P",
            showInLegend: false,
            marker: {
                ...defMarker,
                fillColor: "#FFF",
                lineColor: "#7C7C7C",
            },
            dataLabels: {
                enabled: true,
                align: "left",
                format: '<span style="color:#7C7C7C">{point.name}</span>',
            },
            data: [
                {
                    name: "P*",
                    x: numberVal(final_objective?.total_risk),
                    y: numberVal(final_objective?.expected_return),
                },
            ],
        },
        {
            name: "BM",
            showInLegend: false,
            pointStart: 0,
            dataLabels: {
                align: "left",
                enabled: true,
                format: '<span style="color:#FE9467">{point.name}</span>',
            },
            marker: {
                ...defMarker,
                fillColor: "#FFF",
                lineColor: "#FE9467",
            },
            data: [
                {
                    name: "BM*",
                    x: numberVal(final_objective?.total_benchmark_risk),
                    y: numberVal(final_objective?.benchmark_expected_return),
                },
            ],
        },
    ];
    if (maxSharp) {
        const ret = maxSharp?.expected_return;
        seriesData.push({
            name: "Max Sharpe",
            showInLegend: false,
            pointStart: 0,
            dataLabels: {
                enabled: true,
                align: "left",
                format: '<span style="color:#834159;">{point.name}</span>',
            },
            marker: {
                ...defMarker,
                fillColor: "#FFF",
                lineColor: "#834159",
            },
            data: [
                {
                    name: "Max Sharpe",
                    x: numberVal(maxSharp?.total_risk),
                    y: numberVal(ret),
                },
            ],
        });
    }

    return {
        chart: { type: "line" },
        title: { text: "" },
        xAxis: {
            type: "linear",
            allowDecimals: true,
            tickAmount: 11,
            title: { text: "Expected Risk %" },
            labels: {
                overflow: "justify",
                format: "<b>{value}%</b>",
            },
        },
        yAxis: {
            gridLineWidth: 0,
            // type: "logarithmic",
            title: { text: "Expected Return %" },
            labels: { overflow: "justify", format: "<b>{value}%</b>" },
        },
        tooltip: {
            headerFormat: "<b>{series.name}</b><br />",
            pointFormat: "x = {point.x}, y = {point.y}",
        },
        plotOptions: {
            series: {
                pointStart: 0,
            },

            line: {
                dataLabels: {
                    enabled: true,
                    align: "right",
                    // allowOverlap: true,
                    format: '<span style="color:#B29DF3">{point.name}</span>',
                    style: { fontWeight: 400 },
                },
                color: "#B29DF3",
                enableMouseTracking: false,
            },
        },
        series: seriesData,
    };
}

export default function EfficientFrontier({ data, selected = "p1" }) {
    const options: any = React.useMemo(
        () => getOptions(data, selected),
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [data]
    );
    return (
        <Paper
            className="saa-outputs"
            square
            elevation={5}
            style={{ width: "100%", overflow: "scroll", padding: "0px 8px" }}
        >
            <div className="saa-drag card-header w-100" style={{ textAlign: "left", marginBottom: 7 }}>
                {" "}
                Efficient Frontier{" "}
            </div>
            <HChart
                option={options}
                style={{ height: "100%", width: "100%", display: "flex", alignItems: "center", overflow: "hidden" }}
            />
        </Paper>
    );
}
