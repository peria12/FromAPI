import React, { useState, useEffect } from "react";
import { groupBy, downloadFileData, base64ToArrayBuffer, roundNumber } from "utils/helpers";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-enterprise";
import { AdornedButton } from "common/FTButtons";
import WeightsAndDeltas from "./WeightsAndDeltas";
import Api from "utils/api";
import errorNotification from "utils/api-error";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Checkbox from "@mui/material/Checkbox";
import DragIndicatorIcon from "@mui/icons-material/DragIndicator";
import { percentPostfix } from "../../utils/aa-helper";

const pdfStyle = `

        #output {
            height: 100%;
            width: 100%;
            top:20;
            left:20;
            right:20;
            bottom:20;
            overflow: visible;
        }
        #output .table-container {
            overflow: visible;
            height: auto;
        }
        table {
            font-size: small;
        }
        #output .left-panel {
            border-right: none;
            width: 100%;
        }
        #output .w-content {
            display: block;
            height: 100%;
        }
        #output .saa-input input[type=text] {
            border: none;
            width: 30px;
            height: unset;
            padding: 0px;
            font-size: small;
        }
        #output .table-container {
            overflow: visible;
        }
        #output .right-panel {
            width: 100%;
        }
        #output .right-panel > div {
            overflow: visible !important;
            display: flex;  
        }
        #output .weights-deltas-grid {
            width: 50%;
        }
        #output .abs-rel-grid {
            width: 50%;
            border:none;
        }
        #output .saa-column-table .content .text-cell td {
            min-width: 120px;
        }
        #output .header {
            padding: 8px 12px;
            margin: 0px;
            font-family: Roboto, Helvetica, Arial, sans-serif;
            font-weight: 500;
            font-size: 1.5rem;
            line-height: 1.6;
            letter-spacing: 0.0075em;
        }
        #output .sub-header {
            padding: 15px 0px 2px 12px;
            font-family: Roboto Condensed;
            font-weight: 500;
            font-size: 1.3rem;
            color: #626262;
        }

        #output .ft-saa-cwt {
            min-width: 158px;
        }
        #output .saa-column-table .content .numeric-cell td{
            padding: 2px;
        }
        #output .table-container th {
            font-size: 12px;
        }
        #output .table-container th > div > span {
            left: unset;
            right: 1px;
        }
    `
    .split("\n")
    .join("");

function formatDataForOutputTable(outputData) {
    const { data, benchmark, modelAssets } = outputData;
    const formattedData: any = [];
    const assetsArr = data?.final_objective?.solution;
    if (!assetsArr) {
        return [];
    }
    const benchmarkMap = new Map();
    benchmark?.forEach((asset) => {
        benchmarkMap.set(
            [asset.asset_type || "", asset.category || "", asset.sub_category || "", asset.asset || ""].toString(),
            Number(asset.weight) || 0
        );
    });
    const modelAssetsSet = new Set();
    modelAssets?.forEach((asset) => {
        modelAssetsSet.add([asset.asset_type, asset.category, asset.sub_category, asset.asset].toString());
    });
    const previousSolutionMap = new Map();
    data?.prev_final_objective?.solution?.length &&
        data?.prev_final_objective?.solution?.forEach((asset) => {
            previousSolutionMap.set([asset.asset].toString(), asset.holding);
        });
    const totalPercentage = {};
    assetsArr?.map((asset) => {
        if (asset.asset[0] && !Object.hasOwn(totalPercentage, asset.asset[0])) {
            totalPercentage[asset.asset[0]] = 0;
            totalPercentage["benmark_" + asset.asset[0]] = 0;
            totalPercentage["prev_" + asset.asset[0]] = 0;
        }
        totalPercentage[asset.asset[0]] += asset.holding || 0;
        totalPercentage["benmark_" + asset.asset[0]] += benchmarkMap.get(asset.asset.toString()) ?? 0;
        totalPercentage["prev_" + asset.asset[0]] += previousSolutionMap.get(asset.asset.toString()) ?? 0;
    });

    assetsArr?.map((asset, idx) => {
        const current_asset = totalPercentage[asset.asset[0]]
            ? ((asset.holding || 0) / totalPercentage[asset.asset[0]]) * 100
            : 0;
        const benchmark_asset = totalPercentage["benmark_" + asset.asset[0]]
            ? ((benchmarkMap.get(asset.asset.toString()) ?? 0) / totalPercentage["benmark_" + asset.asset[0]]) * 100
            : 0;
        const prev_asset: any = totalPercentage["prev_" + asset.asset[0]]
            ? ((previousSolutionMap.get(asset.asset.toString()) ?? 0) / totalPercentage["prev_" + asset.asset[0]]) * 100
            : "";
        formattedData.push({
            id: idx,
            asset_class: asset.asset[0] || "",
            asset_type: asset.asset[0] || "",
            category: asset.asset[1] || "",
            sub_category: asset.asset[2] || "",
            asset_name: asset.asset[3] || "",
            current_portfolio: asset.holding || 0,
            current_asset,
            benchmark_portfolio: benchmarkMap.get(asset.asset.toString()) ?? 0,
            benchmark_asset,
            benchmark_delta_portfolio: modelAssetsSet.has(asset.asset.toString())
                ? asset.holding - (benchmarkMap.get(asset.asset.toString()) ?? 0)
                : "",
            benchmark_delta_asset: modelAssetsSet.has(asset.asset.toString()) ? current_asset - benchmark_asset : "",
            prev_delta_portfolio: previousSolutionMap.get(asset.asset.toString())
                ? asset.holding - (previousSolutionMap.get(asset.asset.toString()) ?? 0)
                : "",
            prev_delta_asset:
                previousSolutionMap.get(asset.asset.toString()) && typeof prev_asset === "number"
                    ? current_asset - prev_asset
                    : "",
            prev_portfolio: previousSolutionMap.get(asset.asset.toString()) ?? "",
            prev_asset,
        });
    });
    return formattedData;
}
function groupRows(rows, contribution_to_risk = {}, grpBy = "asset_type") {
    const groupData = groupBy(rows, grpBy);
    let results: any = [];
    const totalValues = {
        current_portfolio: 0,
        benchmark_portfolio: 0,
        prev_portfolio: 0,
    };

    Object.keys(groupData).forEach((type) => {
        if (groupData[type]) {
            const current_portfolio = groupData[type].reduce((da, dc) => da + Number(dc.current_portfolio) || 0, 0);
            const benchmark_portfolio = groupData[type].reduce((da, dc) => da + dc.benchmark_portfolio || 0, 0);
            const prev_portfolio = groupData[type].reduce((da, dc) => da + dc.prev_portfolio || 0, 0);
            totalValues.current_portfolio += current_portfolio;
            totalValues.benchmark_portfolio += benchmark_portfolio;
            totalValues.prev_portfolio += prev_portfolio;
        }
    });

    Object.keys(groupData).forEach((type) => {
        if (groupData[type]) {
            const value = groupData[type];
            const current_portfolio = groupData[type].reduce((da, dc) => da + Number(dc.current_portfolio) || 0, 0);
            const current_asset = totalValues.current_portfolio
                ? (current_portfolio / totalValues.current_portfolio) * 100
                : 0;
            const benchmark_portfolio = groupData[type].reduce((da, dc) => da + dc.benchmark_portfolio || 0, 0);
            const benchmark_asset = totalValues.benchmark_portfolio
                ? (benchmark_portfolio / totalValues.benchmark_portfolio) * 100
                : 0;
            const prev_portfolio = groupData[type].reduce((da, dc) => da + dc.prev_portfolio || 0, 0);
            const prev_asset: any = totalValues.prev_portfolio
                ? (prev_portfolio / totalValues.prev_portfolio) * 100
                : "";
            const aggFields: any = {
                current_portfolio,
                current_asset,
                benchmark_delta_portfolio: (current_portfolio ?? 0) - (benchmark_portfolio ?? 0),
                benchmark_delta_asset: current_asset - benchmark_asset,
                prev_delta_portfolio: typeof prev_portfolio === "number" ? current_portfolio - prev_portfolio : "",
                prev_delta_asset: typeof prev_asset === "number" ? current_asset - prev_asset : "",
                benchmark_portfolio,
                benchmark_asset,
                prev_portfolio,
                prev_asset,
            };
            let className = "";
            if (type === "Equity") {
                className = "saa-texthead-blue";
            }
            if (type === "Fixed Income") {
                className = "saa-texthead-red";
            }
            if (type === "Alternatives") {
                className = "saa-texthead-purple";
            }
            if (type === "Cash") {
                className = "saa-texthead-green";
            }
            results = [
                ...results,
                {
                    asset_name: type,
                    ...Object.fromEntries(
                        Object.entries(aggFields).map(([key, val]) => [
                            key,
                            typeof val === "number" ? roundNumber(val) : val,
                        ])
                    ),
                    className: "table-text-grey" + " " + className,
                    isGroupedRow: true,
                },
                {
                    asset_name: "Contribution to Risk",
                    className: "table-text-grey",
                    current_portfolio: contribution_to_risk[type] ? roundNumber(contribution_to_risk[type]) : "",
                    isGroupedRow: true,
                },
                ...value.map((asset) =>
                    Object.fromEntries(
                        Object.entries(asset).map(([key, val]) => [
                            key,
                            typeof val === "number" ? roundNumber(val) : val,
                        ])
                    )
                ),
            ];
        }
    });
    results.push({
        ...Object.fromEntries(
            Object.entries(totalValues).map(([key, val]) => [key, typeof val === "number" ? roundNumber(val) : val])
        ),
        className: "table-text-grey",
        isGroupedRow: true,
    });
    results.forEach((row, idx) => (row.key = idx));
    return { results, totalCurrent: totalValues.current_portfolio };
}

const expSections = [
    { id: "ast-table", name: "SAA Final Portfolio Detail", order: 1, type: "Data Table" },
    { id: "weights_delta", name: "Visual SAA vs. Benchmark Comparison", order: 2, type: "Chart" },
    { id: "abs_rel", name: "SAA vs. Benchmark Statistics", order: 3, type: "Chart" },
];

const defaultSelected = expSections?.reduce((res, item) => {
    res[item.id] = true;
    return res;
}, {});

export default function Output({ data, editOrSelectSolution, editSolutionWithoutSave }) {
    const [tableData, setTableData] = useState<any>([]);
    const [groupedRows, setGroupedRows] = useState<any>([]);
    const [openExpDialog, setOpenExpDialog] = useState(false);
    const [saveStatus, setSaveStatus] = useState({ loading: false, disabled: false });

    useEffect(() => {
        const formattedData = formatDataForOutputTable(data);
        setTableData(formattedData);
        const { results, totalCurrent } = groupRows(formattedData, data?.data?.final_objective?.contribution_to_risk);
        if (roundNumber(totalCurrent) !== 100) {
            setSaveStatus((saveStatus) => ({ ...saveStatus, disabled: true }));
        } else {
            setSaveStatus((saveStatus) => ({ ...saveStatus, disabled: false }));
        }
        setGroupedRows(results);
    }, [data]);

    function ExportDialog() {
        const [loaders, setLoaders] = useState<any>({});
        const [sections, setSections] = useState<any>([...expSections]);
        const [selected, setSelected] = useState({ ...defaultSelected });
        const [dragId, setDragId] = useState();
        const [dragging, setDragging] = useState(false);

        const handleToggle = (id) => () => {
            setSelected((s) => ({ ...s, [id]: !s[id] }));
        };

        const handleDrag = (ev) => {
            setDragId(ev.currentTarget.id);
            setDragging(true);
        };

        const handleDrop = (ev) => {
            try {
                setDragging(false);
                const records = [...(sections || [])];
                const dragBox = records.find((box) => box.id === dragId);
                const dropBox = records.find((box) => box.id === ev.currentTarget.id);
                const dragBoxOrder = dragBox.order;
                const dropBoxOrder = dropBox.order;
                const newBoxState = records.map((box) => {
                    if (box.id === dragId) {
                        box.order = dropBoxOrder;
                    }
                    if (box.id === ev.currentTarget.id) {
                        box.order = dragBoxOrder;
                    }
                    return box;
                });
                setSections(newBoxState);
            } catch (err) {
                console.log(err);
            }
        };

        function onClose() {
            setOpenExpDialog(false);
        }

        function drawColSection(rowDiv, section, cloneEle) {
            const div = document.createElement("div");
            div.setAttribute("style", `width:50%;`);
            div.appendChild(draw_header(section.name, "H2"));
            const secDiv = cloneEle.querySelector("#" + section.id);
            secDiv.setAttribute("style", `width:100%;`);
            div.appendChild(secDiv);
            rowDiv.appendChild(div);
            return rowDiv;
        }

        function exportReport(sections, selected) {
            setLoaders((l) => ({ ...l, export: true }));
            const serializer = new XMLSerializer();
            const ele: any = document.getElementById("output-report");
            const cloneEle: any = ele.cloneNode(true);
            const wrapper = document.createElement("div");
            wrapper.setAttribute("id", "output");
            wrapper.appendChild(draw_header("SAA Outputs"));
            const expSections = sections.filter((s) => selected[s.id]);
            let inline = false;
            if (selected["weights_delta"] && selected["abs_rel"]) {
                const idx1 = expSections.find((s) => s.id == "weights_delta")?.order;
                const idx2 = expSections.find((s) => s.id == "abs_rel")?.order;
                const diff = Math.abs(idx1 - idx2);
                if (diff == 1) {
                    inline = true;
                }
            }
            if (!inline) {
                expSections.forEach((section) => {
                    wrapper.appendChild(draw_header(section.name, "H2"));
                    const secElement = cloneEle.querySelector("#" + section.id);
                    wrapper.appendChild(secElement);
                });
            } else {
                for (let i = 0; i < expSections?.length; i++) {
                    const section = expSections[i];
                    if (["weights_delta", "abs_rel"].includes(section.id)) {
                        let rowDiv = document.createElement("div");
                        rowDiv.setAttribute("style", `display:flex; width:100%;`);
                        rowDiv = drawColSection(rowDiv, section, cloneEle);
                        i++;
                        rowDiv = drawColSection(rowDiv, expSections[i], cloneEle);
                        wrapper.appendChild(rowDiv);
                    } else {
                        wrapper.appendChild(draw_header(section.name, "H2"));
                        const secElement = cloneEle.querySelector("#" + section.id);
                        wrapper.appendChild(secElement);
                    }
                }
            }
            const htmlStr = serializer.serializeToString(wrapper);
            let strCss = Array.from(document.styleSheets)
                .flatMap((s) => Array.from(s.cssRules).map((x) => x.cssText))
                .join(" ");

            strCss = `<style>
                ${strCss}
                ${pdfStyle}
            </style>`;

            const html = htmlStr.concat(strCss);
            const errorInfo = {
                type: "error",
                text: `Failed to export the report`,
                open: true,
            };
            console.log(html);

            Api.exportPDF({ html, id: "SAA-Output" })
                .then((response: any) => {
                    if (response?.pdf) {
                        downloadFileData(base64ToArrayBuffer(response.pdf), "saa-output.pdf");
                        onClose();
                    } else {
                        errorNotification.next(errorInfo);
                    }
                    setLoaders((l) => ({ ...l, export: false }));
                })
                .catch((err: any) => {
                    console.error(err);
                    errorNotification.next(errorInfo);
                    setLoaders((l) => ({ ...l, export: false }));
                });
        }

        return (
            <Dialog open={openExpDialog} onClose={onClose} maxWidth="sm" fullWidth>
                <DialogTitle style={{ paddingBottom: 8, fontFamily: "Roboto" }}>Customize Report View</DialogTitle>
                <DialogContent>
                    <List sx={{ width: "100%", bgcolor: "background.paper" }}>
                        {sections
                            ?.sort((a, b) => a.order - b.order)
                            ?.map((sec) => {
                                const id = sec.id;
                                const labelId = `checkbox-list-label-${id}`;
                                return (
                                    <ListItem
                                        key={id}
                                        disablePadding
                                        id={id}
                                        draggable={true}
                                        onDragOver={(e) => e.preventDefault()}
                                        onDragStart={handleDrag}
                                        onDrop={handleDrop}
                                        style={{ opacity: dragging ? 0.5 : 1 }}
                                        secondaryAction={
                                            <Checkbox
                                                edge="start"
                                                checked={selected[id]}
                                                tabIndex={-1}
                                                disableRipple
                                                onClick={handleToggle(id)}
                                                inputProps={{ "aria-labelledby": labelId }}
                                            />
                                        }
                                    >
                                        <ListItemButton dense style={{ paddingLeft: "8px" }}>
                                            <ListItemIcon style={{ alignItems: "center" }}>
                                                <DragIndicatorIcon />
                                            </ListItemIcon>
                                            <ListItemText
                                                primaryTypographyProps={{
                                                    style: {
                                                        fontFamily: "Roboto",
                                                        fontSize: "1.2rem",
                                                    },
                                                }}
                                                secondaryTypographyProps={{
                                                    style: {
                                                        fontFamily: "Roboto Condensed",
                                                        fontSize: "1.1rem",
                                                    },
                                                }}
                                                id={labelId}
                                                primary={sec.name}
                                                secondary={sec.type}
                                            />
                                        </ListItemButton>
                                    </ListItem>
                                );
                            })}
                    </List>
                </DialogContent>
                <DialogActions>
                    <AdornedButton
                        style={{ textTransform: "capitalize" }}
                        variant="contained"
                        onClick={() => setOpenExpDialog(false)}
                        color="secondary"
                        size="small"
                    >
                        Close
                    </AdornedButton>
                    <AdornedButton
                        style={{ textTransform: "capitalize" }}
                        variant="contained"
                        onClick={(e) => {
                            e.preventDefault();
                            exportReport(sections, selected);
                        }}
                        color="primary"
                        size="small"
                        loading={loaders?.export}
                    >
                        Export
                    </AdornedButton>
                </DialogActions>
            </Dialog>
        );
    }

    // function pageBreakEle() {
    //     const div = document.createElement("div");
    //     div.setAttribute("style", "page-break-before: always");
    //     return div
    // }

    function draw_header(title, level = "H1") {
        const header = document.createElement("div");
        const className = level == "H2" ? "sub-header" : "header";
        header.setAttribute("class", className);
        header.appendChild(document.createTextNode(title));
        return header;
    }
    const hasReportData = data && Object.keys(data?.data)?.length > 0;

    return (
        <div id="output" className="opt-container" style={{ height: "100%" }}>
            <div id="output-report" className="w-content">
                <ExportDialog />
                <div className="left-panel">
                    <div id="ast-table" className="table-container saa-tb1">
                        <div className="first-group-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <div>
                                                <span>Class</span>
                                            </div>
                                        </th>
                                        <th>
                                            <div>
                                                <span>Category</span>
                                            </div>
                                        </th>
                                        <th>
                                            <div>
                                                <span>Sub Category</span>
                                            </div>
                                        </th>
                                        <th>
                                            <div>
                                                <span>Asset Name</span>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {groupedRows?.map((row) => (
                                        <tr key={row.key} className={row.className}>
                                            <td>{row.asset_class}&nbsp;</td>
                                            <td>{row.category}&nbsp;</td>
                                            <td>{row.sub_category}&nbsp;</td>
                                            <td>{row.asset_name}&nbsp;</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        <div className="ft-saa-cwt">
                            <div className="saa-2">
                                <div className="saa-cwt">
                                    <div className="saa-h4">Current Weights</div>
                                </div>
                            </div>
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <div>
                                                <span>% Portfolio</span>
                                            </div>
                                        </th>
                                        <th>
                                            <div>
                                                <span>% Asset Cl.</span>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {groupedRows.map((row) => {
                                        if (!row.isGroupedRow) {
                                            return (
                                                <tr key={row.key}>
                                                    <td className="saa-input">
                                                        <input
                                                            type="text"
                                                            value={row.current_portfolio}
                                                            onChange={(e) => {
                                                                const newRows = [...tableData];
                                                                newRows[row.id].current_portfolio = e.target.value || 0;
                                                                setTableData(() => {
                                                                    return newRows;
                                                                });
                                                                const { results, totalCurrent } = groupRows(newRows);
                                                                if (roundNumber(totalCurrent) !== 100) {
                                                                    setSaveStatus((saveStatus) => ({
                                                                        ...saveStatus,
                                                                        disabled: true,
                                                                    }));
                                                                } else {
                                                                    setSaveStatus((saveStatus) => ({
                                                                        ...saveStatus,
                                                                        disabled: false,
                                                                    }));
                                                                    const solution: any = [];
                                                                    newRows.forEach((row) => {
                                                                        solution.push({
                                                                            asset: [
                                                                                row.asset_class || "",
                                                                                row.category || "",
                                                                                row.sub_category || "",
                                                                                row.asset_name || "",
                                                                            ],
                                                                            holding: Number(row.current_portfolio),
                                                                        });
                                                                    });
                                                                    editSolutionWithoutSave({ solution });
                                                                }
                                                                setGroupedRows(() => results);
                                                            }}
                                                        />
                                                        %
                                                    </td>
                                                    <td>{percentPostfix(row.current_asset)}</td>
                                                </tr>
                                            );
                                        } else {
                                            return (
                                                <tr
                                                    key={row.key}
                                                    className={row.isGroupedRow ? "table-text-sum-num" : ""}
                                                >
                                                    <td>{percentPostfix(row.current_portfolio)}&nbsp;</td>
                                                    <td>{percentPostfix(row.current_asset)}&nbsp;</td>
                                                </tr>
                                            );
                                        }
                                    })}
                                </tbody>
                            </table>
                        </div>
                        <div className="ft-saa-pwt">
                            <div className="saa-2">
                                <div className="saa-pwt">
                                    <div className="saa-h4">Benchmark Deltas</div>
                                </div>
                            </div>
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <div>
                                                <span>% Portfolio</span>
                                            </div>
                                        </th>
                                        <th>
                                            <div>
                                                <span>% Asset Cl.</span>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {groupedRows.map((row) => {
                                        return (
                                            <tr key={row.key} className={row.isGroupedRow ? "table-text-sum-num" : ""}>
                                                <td>{percentPostfix(row.benchmark_delta_portfolio)}&nbsp;</td>
                                                <td>{percentPostfix(row.benchmark_delta_asset)}&nbsp;</td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                        <div className="ft-saa-pwt">
                            <div className="saa-2">
                                <div className="saa-pwt">
                                    <div className="saa-h4">Benchmark Weights</div>
                                </div>
                            </div>
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <div>
                                                <span>% Portfolio</span>
                                            </div>
                                        </th>
                                        <th>
                                            <div>
                                                <span>% Asset Cl.</span>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {groupedRows.map((row) => {
                                        return (
                                            <tr key={row.key} className={row.isGroupedRow ? "table-text-sum-num" : ""}>
                                                <td>{percentPostfix(row.benchmark_portfolio)}&nbsp;</td>
                                                <td>{percentPostfix(row.benchmark_asset)}&nbsp;</td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                        <div className="ft-saa-deltas">
                            <div className="saa-2">
                                <div className="saa-deltas">
                                    <div className="saa-h4">Previous Deltas</div>
                                </div>
                            </div>
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <div>
                                                <span>% Portfolio</span>
                                            </div>
                                        </th>
                                        <th>
                                            <div>
                                                <span>% Asset Cl.</span>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {groupedRows.map((row) => {
                                        return (
                                            <tr key={row.key} className={row.isGroupedRow ? "table-text-sum-num" : ""}>
                                                <td
                                                    className={
                                                        typeof row.prev_delta_portfolio !== "number"
                                                            ? ""
                                                            : row.prev_delta_portfolio >= 0
                                                            ? "green-value1"
                                                            : "red-value1"
                                                    }
                                                >
                                                    {percentPostfix(row.prev_delta_portfolio)}&nbsp;
                                                </td>
                                                <td
                                                    className={
                                                        typeof row.prev_delta_portfolio !== "number"
                                                            ? ""
                                                            : row.prev_delta_portfolio >= 0
                                                            ? "green-value1"
                                                            : "red-value1"
                                                    }
                                                >
                                                    {percentPostfix(row.prev_delta_asset)}&nbsp;
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                        <div className="ft-saa-cwt">
                            <div className="saa-2">
                                <div className="saa-cwt">
                                    <div className="saa-h4">Previous Weights</div>
                                </div>
                            </div>
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <div>
                                                <span>% Portfolio</span>
                                            </div>
                                        </th>
                                        <th>
                                            <div>
                                                <span>% Asset Cl.</span>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {groupedRows.map((row) => {
                                        return (
                                            <tr key={row.key} className={row.isGroupedRow ? "table-text-sum-num" : ""}>
                                                <td>{percentPostfix(row.prev_portfolio)}&nbsp;</td>
                                                <td>{percentPostfix(row.prev_asset)}&nbsp;</td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    {saveStatus.disabled && (
                        <span style={{ color: "red", marginLeft: "450px" }}>Total weight must be 100%</span>
                    )}
                    {hasReportData && (
                        <div id="saa-output-btn" className="d-flex w-100">
                            <div className="btn-group" style={{ width: "100%" }}>
                                <AdornedButton
                                    className="save-btn m-1"
                                    variant="outlined"
                                    size="small"
                                    onClick={() => setOpenExpDialog(true)}
                                    disabled={saveStatus.disabled}
                                >
                                    Export Report
                                </AdornedButton>
                                <AdornedButton
                                    className="save-btn"
                                    variant="outlined"
                                    size="small"
                                    onClick={async () => {
                                        setSaveStatus((saveStatus) => ({ ...saveStatus, loading: true }));
                                        const solution: any = [];
                                        tableData.forEach((row) => {
                                            solution.push({
                                                asset: [
                                                    row.asset_class || "",
                                                    row.category || "",
                                                    row.sub_category || "",
                                                    row.asset_name || "",
                                                ],
                                                holding: Number(row.current_portfolio),
                                            });
                                        });
                                        try {
                                            await editOrSelectSolution({ solution });
                                        } finally {
                                            setSaveStatus((saveStatus) => ({ ...saveStatus, loading: false }));
                                        }
                                    }}
                                    loading={saveStatus.loading}
                                    disabled={saveStatus.disabled}
                                >
                                    Save
                                </AdornedButton>
                            </div>
                        </div>
                    )}
                </div>
                <div className="right-panel">
                    <WeightsAndDeltas data={data.data} benchmark={data.benchmark} />
                </div>
            </div>
        </div>
    );
}
