import React from "react";
import { HChart } from "common/HChart";
import { groupByAggregate } from "utils/helpers";
import { numberVal } from "../../utils/aa-helper";

function getOptions(id, resp) {
    const bgColor = id == 2 ? "#F2F2F2" : "#FFFFFF";
    const defaultCfg = { chart: { backgroundColor: bgColor }, title: { text: "" } };
    let colors: any = ["#5195FC", "#FD4B7C", "#9E7BFA", "#6BC3BC"];
    let data: any = [];
    if (!resp?.length) {
        return defaultCfg;
    }
    if (id == 2) {
        colors = ["#366BBB", "#B63256", "#643AD1", "#0E7D75"];
    }
    data = resp?.map((e) => ({ name: e.asset_type, y: numberVal(e?.weight) }));
    return {
        chart: {
            type: "pie",
            backgroundColor: bgColor,
            margin: [0, 0, 0, 0],
            height: "100%",
        },
        title: null,
        tooltip: {
            enabled: true,
            pointFormat: "{series.name}: <b>{point.y:.1f}%</b>",
        },
        accessibility: {
            point: {
                valueSuffix: "%",
            },
        },
        plotOptions: {
            pie: {
                size: "100%",
                height: "100%",
                colors: colors,
                dataLabels: {
                    enabled: false,
                },
                enableMouseTracking: true,
                cursor: "pointer",
            },
            series: {
                borderWidth: 2,
                states: {
                    hover: {
                        enabled: false,
                    },
                },
            },
        },
        series: [
            {
                name: "",
                colorByPoint: true,
                data: data,
            },
        ],
    };
}

const labelColors = ["#471DB4", "#5195FC", "#6BC3BC", "#FD4B7C"];

const getData = (cfg) => cfg?.series?.[0]?.data;
const barColors = {
    "0": ["#5195FC", "#FD4B7C", "#9E7BFA", "#6BC3BC"],
    "1": ["#366BBB", "#B63256", "#643AD1", "#0E7D75"],
};

function getDeltaCfg(curWeights: any = [], benchWeights, prvWeights) {
    if (curWeights?.length <= 0) {
        return { title: { text: "" } };
    }
    const series: any = [];

    if (curWeights?.length > 0 && prvWeights?.length > 0) {
        const data = curWeights?.map((ele) => {
            const prvWgts = prvWeights?.find((e) => e.asset_type?.toLowerCase() == ele.asset_type?.toLowerCase());
            return numberVal(ele?.weight - prvWgts?.weight || 0);
        });
        series.push({ name: "Previous Delta", showInLegend: false, data: data });
    }

    if (curWeights?.length > 0 && benchWeights?.length > 0) {
        const data = curWeights?.map((ele) => {
            const bench = benchWeights?.find((e) => e.asset_type?.toLowerCase() == ele.asset_type?.toLowerCase());
            return numberVal(ele?.weight - bench?.weight || 0);
        });
        series.push({ name: "Benchmark Delta", showInLegend: false, data: data });
    }

    return {
        chart: {
            type: "bar",
            events: {
                load: function () {
                    const chart = this as any;
                    chart?.series?.forEach(function (series, index) {
                        series?.data.forEach(function (point, i) {
                            point.update({ color: barColors[index][i] }, false);
                        });
                    });
                    chart.redraw();
                },
            },
        },
        title: { text: "", useHTML: true },
        subtitle: { text: null },
        xAxis: { categories: ["", "", "", ""], visible: false },
        yAxis: {
            startOnTick: true,
            gridLineDashStyle: "Dot",
            title: { text: null },
            labels: { overflow: "justify", format: "<b>{value}%</b>" },
        },
        tooltip: {
            // valueSuffix: " millions", // pointFormat: "Population: <b>{point.y}k</b>"
        },
        colors: ["#5195FC", "#366BBB", "#FD4B7C", "#B63256", "#9E7BFA", "#643AD1", "#6BC3BC", "#0E7D75"],

        plotOptions: {
            series: {
                maxPointWidth: 10,
            },
            bar: {
                colorByPoint: true,
                series: {
                    pointWidth: 15,
                },
                cursor: "pointer",
                dataLabels: {
                    enabled: true,
                },
                groupPadding: 0.3,
                pointPadding: 0,
            },
        },
        series: series,
    };
}

function DataTable({ colInfo, rowInfo }) {
    //default: numeric and percentage
    const { header, text, className = "", colorFormatter } = colInfo;
    const { percentage = [], totalRows } = rowInfo;
    let values = colInfo?.values;
    if (!values) {
        values = new Array(totalRows).fill(null);
    }

    const getColor = (val) => {
        if (val == 0) {
            return "";
        }
        return val > 0 ? "pos-val" : "neg-val";
    };

    return (
        <div className="content">
            <div
                className={`${className} ${!text ? "numeric-cell" : "text-cell"}`}
                style={!header ? { paddingTop: "2px" } : undefined}
            >
                <table style={!header ? { marginTop: "0px" } : undefined}>
                    {header && (
                        <thead>
                            {" "}
                            <tr>
                                {" "}
                                <th>
                                    <div style={text ? { borderBottom: "none" } : undefined}>
                                        <span>{header}</span>
                                    </div>
                                </th>{" "}
                            </tr>{" "}
                        </thead>
                    )}
                    <tbody>
                        {values?.map((val, i) => {
                            if (!text && val != null) {
                                val = numberVal(val);
                            }
                            return (
                                <tr key={i}>
                                    <td
                                        className={colorFormatter ? getColor(val) : ""}
                                        style={text ? { borderBottom: "none" } : undefined}
                                    >
                                        {val}
                                        {val != null && percentage?.includes(i) && !text ? "%" : ""}
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

const isValidNumber = (v) => v !== null && v !== undefined && v !== ""

const diff = (f, s) => {
    if (isValidNumber(f) && isValidNumber(s)) {
        return f - s;
    }
    return null;
};

export default function WeightsAndDeltas({ data, benchmark }) {
    const weightChartStyle: any = { width: "70%", height: "120px", minWidth: "70%" }; // flex: 1
    const weights: any = React.useMemo(() => {
        let curWeights: any = [],
            prvWeights: any = [],
            benchWeights: any = [];
        let absolute: any = {},
            relative: any = {};
        const fo = data?.final_objective;
        const pfo = data?.prev_final_objective;
        if (Object.keys(data).length) {
            const solution = fo?.solution?.map((e) => {
                const [asset_type = "", category = "", sub_category = "", asset = ""] = e?.asset || [];
                return { asset_type, category, sub_category, asset, weight: e?.holding };
            });
            curWeights = groupByAggregate(solution, "asset_type", ["weight"]);

            const prvSolution =
                pfo?.solution?.length &&
                pfo?.solution?.map((e) => {
                    const [asset_type = "", category = "", sub_category = "", asset = ""] = e?.asset || [];
                    return { asset_type, category, sub_category, asset, weight: e?.holding };
                });
            prvWeights = groupByAggregate(prvSolution, "asset_type", ["weight"]);

            absolute = {
                current: [fo?.expected_return, fo?.total_risk, fo?.["5_pcnt_VaR"], fo?.["5_pcnt_CVaR"], fo?.sharpe_ratio],
                prv: [pfo?.expected_return, pfo?.total_risk, pfo?.["5_pcnt_VaR"], pfo?.["5_pcnt_CVaR"], pfo?.sharpe_ratio],
                bm: [
                    fo?.benchmark_expected_return,
                    fo?.total_benchmark_risk,
                    fo?.benchmark_5_pcnt_VaR,
                    fo?.benchmark_5_pcnt_CVaR,
                    fo?.benchmark_sharpe_ratio,
                ],
            };
            relative = {
                current: [fo?.tracking_error, fo?.portfolio_predicted_beta, fo?.up_capture, fo?.down_capture],
                prv: [pfo?.tracking_error, pfo?.portfolio_predicted_beta, pfo?.up_capture, pfo?.down_capture],
                bm: [null, fo?.benchmark_beta, null, null],
            };
        }

        if (benchmark?.length > 0) {
            const solution = benchmark?.map((bm) => {
                return {
                    category: bm.category || "",
                    sub_category: bm.sub_category || "",
                    asset: bm.asset || "",
                    asset_type: bm.asset_type || "",
                    weight: !isNaN(bm?.weight) ? Number(bm?.weight) : bm?.weight,
                };
            });
            benchWeights = groupByAggregate(solution, "asset_type", ["weight"]);
        }

        const absoluteData = [
            {
                id: "metrics",
                header: "Metrics",
                text: true,
                values: ["Return", "Volatility", "5% VaR", "5%CVaR", "Sharpe Ratio"],
            },
            {
                id: "current",
                header: "Current",
                values: absolute?.current,
            },
            {
                id: "bm_delta",
                header: "BM Delta",
                className: "bg-grey",
                colorFormatter: true,
                values: absolute?.current?.map((e, i) => diff(e, absolute?.bm[i])),
            },
            {
                id: "bm",
                header: "BM",
                className: "bg-grey",
                values: absolute?.bm,
            },
            {
                id: "prev_delta",
                header: "Prev Delta",
                values: absolute?.current?.map((e, i) => diff(e, absolute?.prv[i])),
                colorFormatter: true,
            },
            {
                id: "prev",
                header: "Prev",
                values: absolute?.prv,
            },
        ];

        const relativeData = [
            {
                id: "metrics",
                text: true,
                values: ["Tracking Error", "Beta", "Up Capture", "Down Capture"],
            },
            {
                id: "current",
                values: relative?.current,
            },
            {
                id: "bm_delta",
                className: "bg-grey",
                colorFormatter: true,
                values: relative?.current?.map((e, i) => diff(e, relative?.bm[i])),
            },
            {
                id: "bm",
                className: "bg-grey",
                values: relative?.bm,
            },
            {
                id: "prev_delta",
                values: relative?.current?.map((e, i) => diff(e, relative?.prv[i])),
                colorFormatter: true,
            },
            {
                id: "prev",
                values: relative?.prv,
            },
        ];

        return {
            current: getOptions(1, curWeights),
            bench: getOptions(2, benchWeights),
            previous: getOptions(3, prvWeights),
            delta: getDeltaCfg(curWeights, benchWeights, prvWeights),
            curWeights: curWeights,
            prvWeights: prvWeights,
            benchWeights: benchWeights,
            absoluteData,
            relativeData,
        };
    }, [data, benchmark]);

    return (
        <div id="weights_delta_" style={{ minWidth: "600px", width: "100%", overflow: "scroll" }}>
            <div id="weights_delta" className="weights-deltas-grid p-1 m-1">
                <div className="w-100 d-flex flex-row m-1 weights-base p-1" style={{ alignItems: "flex-start" }}>
                    <div className="pie-label-card">
                        <div className="card-header w-100" />
                        <div className="w-100 pie-label-grid">
                            {getData(weights?.current)?.map((entry, i) => (
                                <div key={i} className="pie-label" style={{ color: labelColors[i] }}>
                                    {entry.name}
                                </div>
                            ))}
                        </div>
                    </div>
                    <div className="weights-card d-flex flex-row">
                        <div className="card-header w-100">Current Weights</div>
                        <div className="pie-value-grid">
                            {getData(weights?.current)?.map((e, i) => (
                                <div key={i} className="pie-value">
                                    {e.y}%
                                </div>
                            ))}
                        </div>
                        <div style={weightChartStyle}>
                            <HChart
                                option={weights?.current}
                                style={{
                                    height: "100%",
                                    width: "100%",
                                    display: "flex",
                                    alignItems: "center",
                                    overflow: "hidden",
                                }}
                            />
                        </div>
                    </div>
                    <div className="weights-card d-flex flex-row" style={{ background: "#F2F2F2" }}>
                        <div className="card-header w-100">Benchmark Weights</div>
                        <div className="pie-value-grid">
                            {getData(weights?.bench)?.map((e, i) => (
                                <div key={i} className="pie-value">
                                    {e.y}%
                                </div>
                            ))}
                        </div>
                        <div style={weightChartStyle}>
                            <HChart
                                option={weights?.bench}
                                style={{
                                    height: "100%",
                                    width: "100%",
                                    display: "flex",
                                    alignItems: "center",
                                    overflow: "hidden",
                                }}
                            />
                        </div>
                    </div>
                    <div className="weights-card d-flex flex-row">
                        <div className="card-header w-100">Previous Weights</div>
                        <div className="pie-value-grid">
                            {getData(weights?.previous)?.map((e, i) => (
                                <div key={i} className="pie-value">
                                    {e.y}%
                                </div>
                            ))}
                        </div>
                        <div style={weightChartStyle}>
                            <HChart
                                option={weights?.previous}
                                style={{
                                    height: "100%",
                                    width: "100%",
                                    display: "flex",
                                    alignItems: "center",
                                    overflow: "hidden",
                                }}
                            />
                        </div>
                    </div>
                </div>
                <div className="delta-base  w-100 p-1">
                    <div className="report-title">Deltas </div>
                    <HChart
                        option={weights?.delta}
                        style={{
                            height: "100%",
                            width: "100%",
                            display: "flex",
                            alignItems: "center",
                            overflow: "hidden",
                        }}
                    />
                </div>
            </div>
            <div id="abs_rel" className="abs-rel-grid p-1 m-1">
                <div className="report-title">Absolute </div>
                <div className="w-100 d-flex saa-column-table">
                    {weights?.absoluteData?.map((col) => (
                        <DataTable key={col.id} colInfo={col} rowInfo={{ percentage: [0, 1, 2, 3], totalRows: 5 }} />
                    ))}
                </div>
                <div className="report-title">Relative </div>
                <div className="w-100 d-flex saa-column-table">
                    {weights?.relativeData?.map((col) => (
                        <DataTable key={col.id} colInfo={col} rowInfo={{ percentage: [0], totalRows: 4 }} />
                    ))}
                </div>
            </div>
        </div>
    );
}