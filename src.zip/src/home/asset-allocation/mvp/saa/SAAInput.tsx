import React, { useState, useMemo, useEffect } from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import { CircularProgress, Dialog, TextField, DialogContent, DialogActions } from "@mui/material";
import errorNotification from "utils/api-error";
import moment from "moment";
import { groupBy } from "utils/helpers";
import AutocompleteField from "common/AutocompleteField";
import SearchInput from "common/SearchInput";
import { FTIconButton } from "common/FTButtons";
import ModeEditIcon from "@mui/icons-material/ModeEdit";
import ShareIcon from "@mui/icons-material/Share";
import DeleteIcon from "@mui/icons-material/Delete";
import FTDatePicker from "common/FTDatePicker";
import ShareWith from "../shared/ShareWith";
import InputAdornment from "@mui/material/InputAdornment";
import "ag-grid-community/styles/ag-grid.css";
import { globalSearch } from "utils/helpers";
import Tooltip from "@mui/material/Tooltip";
import "ag-grid-enterprise";
import SearchForAsset from "../shared/SearchForAsset";
import EditModal from "../shared/EditNameDialog";
import {
    updateRowValues,
    hasAccess,
    findAssetGroup,
    getAssetId,
    compareTemplate,
    compareAssets,
    sortList,
    removeKeys,
} from "../utils/aa-helper";
import Api from "utils/api";
import { defaultFormData, squareBtnStyle } from "../utils/aa-cfg";
import ModelPortfolio from "../../../portfolio-management/ModelDetail";
import AuditTrail from "./AuditTrail";
import { AdornedButton } from "common/FTButtons";
import AssetTable from "./AssetTable";
import CopyAllIcon from "@mui/icons-material/CopyAll";
import DriveFileRenameOutlineIcon from "@mui/icons-material/DriveFileRenameOutline";

const useStyles = makeStyles(() =>
    createStyles({
        saaCard: {
            padding: "12px 6px",
        },
        btn: {
            textTransform: "capitalize",
        },
    })
);

export const styles = {
    height: "30px",
    border: " 1px solid rgb(217 207 207)",
    borderRadius: "5px",
    padding: "2px 4px",
    fontSize: 13,
    borderColor: "rgb(217 207 207)",
};

export const textStyles = { ...styles, width: 65, padding: "0px 5px" };
function groupRows(rows, assetMaster, grpBy = "asset_type") {
    const groupData = groupBy(rows, grpBy);
    // const aggregateFields = ["current", "min", "max", "risk", "return"];
    const updatedRows: any = [];
    let groupedRows: any = [];
    Object.keys(groupData).forEach((type) => {
        if (groupData[type]) {
            const value = groupData[type];
            const current = value.reduce((da, dc) => da + Number(dc.current) || 0, 0);
            const classLevelConstraint = assetMaster.find((ast) => ast.id === type.split(" ").join("_"));
            const updatedVal: any = [];
            if (value.length === 1) {
                updatedVal.push({ ...value[0], min: classLevelConstraint?.min });
            } else {
                updatedVal.push(...value);
            }
            updatedRows.push(...updatedVal);
            groupedRows = [
                ...groupedRows,
                {
                    category: type,
                    isGroupedRow: true,
                    current,
                    min: classLevelConstraint?.min,
                    max: classLevelConstraint?.max,
                },
                ...updatedVal,
            ];
        }
    });
    return { updatedRows, groupedRows };
}

const provider = (options: object[] = [], query) => {
    if (!query) {
        return Promise.resolve([options, options.length]);
    }
    const results = globalSearch(options, query, 0);
    return Promise.resolve([results, results.length]);
};

export const authorStyle: any = { color: "#c5c5c5", textTransform: "capitalize", fontStyle: "italic", marginLeft: 1 };

export const RenderOption = function (props, option, deleteOption) {
    return (
        <li {...props} key={option.id} style={{ fontSize: "14px" }}>
            <div style={{ display: "flex", width: "90%", justifyContent: "space-between" }}>
                <div className="col-12">
                    {option.label}
                    {option.author && <span style={authorStyle}>({option.author})</span>}
                </div>
                {typeof deleteOption === "function" && !option.author && (
                    <DeleteIcon
                        className="delete-icon"
                        style={{ color: "red", marginRight: "10px" }}
                        onClick={(e) => {
                            e.stopPropagation();
                            deleteOption(option);
                        }}
                    />
                )}
            </div>
        </li>
    );
};

export function formatModelData(data) {
    return {
        ...data?._meta,
    };
}

function InputFields({
    app,
    zone,
    formData,
    setFormData,
    handleFieldChange,
    refreshData,
    updateInfo,
    setUpdateInfo,
    benchmarkModelData,
    setBenchmarkModelData,
    selectedPastTemplate,
    onSelectChange,
    onConstraintChange,
    benchmarkInfo,
    setBenchmarkInfo,
    setInputDetails,
    inputDetails,
    onModelChange,
    assetsWithEntityIds,
    validationError,
    deleteOption,
    onEditName,
    editInfo,
    setEditInfo,
    onTemplateChange,
}) {
    const { objFuncList, currencyList, riskModelList, constraintList, modelList, inputs, benchmarkList } = formData;
    const [shareInfo, setShareInfo] = useState<any>({ open: false, shareBtnRef: null, data: null });

    useEffect(() => {
        setShareInfo((info) => ({ ...info, open: false }));
    }, [formData]);

    useEffect(() => {
        if (!selectedPastTemplate) {
            return;
        }
        setUpdateInfo((e) => ({ ...e, template: null }));
        let formInputs: any = { ...defaultFormData?.inputs };
        let inputsInfo = { template: null };
        let modelInfo: any = {};
        inputsInfo = { template: selectedPastTemplate };
        formInputs = {
            ...selectedPastTemplate,
            id: selectedPastTemplate?._id?.$oid,
        };
        if (selectedPastTemplate?.model) {
            modelInfo = formData?.modelList.find((ele) => ele.id == selectedPastTemplate.model) || {};
            const model = { id: modelInfo?.id, name: modelInfo.label };
            formInputs.model = model;
        }
        if (selectedPastTemplate?.constraint) {
            const constraintInfo =
                formData?.constraintList.find((ele) => ele.id == selectedPastTemplate.constraint) || {};
            formInputs.constraint = constraintInfo.id;
            onConstraintChange(constraintInfo.id, false);
        }
        if (selectedPastTemplate?.benchmark) {
            const selectedModel = benchmarkList?.find((f) => f.id == selectedPastTemplate?.benchmark);
            if (selectedModel) {
                setBenchmarkModelData(() => formatModelData(selectedModel));
            }
        }
        setInputDetails((e) => ({ ...e, ...inputsInfo }));
        onModelChange(modelInfo);
        setFormData((formData) => ({ ...formData, inputs: formInputs }));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedPastTemplate]);

    function onShare(e, value, list, isBenchmark = false) {
        const data = list?.find((ele) => ele?.id == value) || {};
        if (isBenchmark) {
            data._meta = { ...benchmarkModelData };
        }
        if (hasAccess(data?._meta)) {
            setShareInfo({ open: true, shareBtnRef: e.currentTarget, data });
        }
    }

    async function editOnSave(info, value) {
        setEditInfo({ open: false });
        const newValue = { id: info.id, label: value };

        const field = info?.field;
        const fieldNameForApi =
            field === "constraint" ? "-constarints" : field === "model" ? "-modelportfolio" : "-template";
        const request = { ...inputDetails?.[field], name: value + fieldNameForApi, Name: value };
        let response: any = {};
        const isCopy = info?.action == "copy";
        if (info?.action == "copy") {
            const keys: any = [
                "author",
                "author-id",
                "is_editable",
                "create_date",
                "update_date",
                "_id",
                "name_orig",
                "prev_final_objective",
                "prev_portfolio_asset_list",
                "audit_trail",
            ];
            const payload = removeKeys({ ...JSON.parse(JSON.stringify(request)) }, keys);
            payload["access"] = { system: false, dept: false, users: [] };
            response = await Api.createSharedState(app, zone, payload);
        } else {
            response = await Api.updateSharedState(info?.id, request);
        }
        if (response?.message) {
            setUpdateInfo((e) => ({ ...e, [field]: newValue }));
            errorNotification.next({ type: "success", text: response.message, open: true });
            if (!isCopy) {
                const newName = response?.["shared-object"]?.Name;
                let inputs = {};
                if (field == "template") {
                    inputs = { ...formData.inputs, name: newName, Name: newName };
                    setFormData((fd) => ({ ...fd, inputs: inputs }));
                } else if (field == "model") {
                    const fieldInfo = formData.inputs[field];
                    inputs = { ...formData.inputs, [field]: { ...fieldInfo, name: newName } };
                    setFormData((fd) => ({ ...fd, inputs: inputs }));
                }
            }
            refreshData().then((sharedObj) => {
                const { templateList = [], modelList = [], constraintList = [], benchmarkList = [] }: any = sharedObj;
                const id = response?.["shared-object"]?._id?.$oid;
                if (templateList?.length > 0 && field == "template") {
                    onTemplateChange(id, false);
                    onSelectChange(field, id, templateList, modelList);
                } else if (modelList?.length > 0 && field == "model") {
                    onSelectChange(field, id, templateList, modelList);
                } else if (constraintList?.length > 0 && field == "constraint") {
                    onConstraintChange(id, true, constraintList);
                } else if (benchmarkList?.length > 0 && field == "benchmark") {
                    onBenchmarkChange(id, benchmarkList);
                }
            });
        }
    }

    function getFieldValue(f) {
        let value = inputs?.[f]?.id;
        if (f == "template") {
            value = inputs?.id;
        }
        if (f == "constraint" || f == "benchmark") {
            value = inputs?.[f];
        }
        return value;
    }

    function isCopyBtnDisabled(f) {
        const value = getFieldValue(f);
        if (!value) {
            return true;
        }
        return false;
    }

    function isDisabled(f) {
        const value = getFieldValue(f);
        if (!value) {
            return true;
        }
        // if name modified
        if (value != inputDetails?.[f]?._id?.$oid) {
            return true;
        }
        if (inputDetails[f]?.["author-id"] && hasAccess(inputDetails[f])) {
            return false;
        }
        return true;
    }

    const getIconStyle = (f, isCopyBtn = false) => {
        const disabledBtnStyle = { ...squareBtnStyle, opacity: 0.4 };
        if (isCopyBtn) {
            return isCopyBtnDisabled(f) ? disabledBtnStyle : squareBtnStyle;
        }
        return isDisabled(f) ? disabledBtnStyle : squareBtnStyle;
    };

    function getSelectValue(f, list) {
        if (updateInfo?.[f]) {
            return updateInfo?.[f];
        }
        const value = f == "template" ? inputs?.id : f == "constraint" ? inputs?.[f] : inputs?.[f]?.id;
        return list?.find((t) => t.id == value);
    }

    function getRiskModel(riskModel) {
        let value = riskModelList?.find((f) => f.id == riskModel);
        if (!value) {
            value = riskModelList?.find((f) => f.id == defaultFormData?.inputs?.riskModel);
            if (value?.id) {
                handleFieldChange("riskModel", value?.id);
            }
        }
        return value;
    }

    function onBenchmarkChange(id, benchmarkList) {
        let selectedModel: any = {};
        let list = formData?.benchmarkList;
        if (benchmarkList?.length > 0) {
            list = benchmarkList;
        }
        handleFieldChange("benchmark", id);
        if (id) {
            selectedModel = list?.find((f) => f.id == id);
            if (selectedModel) {
                setBenchmarkModelData(() => formatModelData(selectedModel));
            }
        }
        setInputDetails((e) => ({ ...e, benchmark: selectedModel?._meta }));
    }

    return (
        <div className="w-100  filter-base">
            <EditModal editInfo={editInfo} setEditInfo={setEditInfo} editOnSave={editOnSave} />
            <div className="w-100 d-flex pt-2">
                <div className="input-grp">
                    <div className="input-label">Model</div>
                    <div className="input-field">
                        <SearchInput
                            onChange={(_, v) => onSelectChange("model", v?.id)}
                            onInputChange={(e, v) => {
                                if (e?.type === "change") {
                                    handleFieldChange("model", { name: v }, modelList);
                                }
                            }}
                            options={sortList(modelList)}
                            value={getSelectValue("model", modelList)}
                            placeholder="Model.."
                            inputPropsStyle={styles}
                            disableUnderline={true}
                            forcePopupIcon={true}
                            popperWidth="300px"
                            searchIcon={false}
                            renderOption={(props, option) => RenderOption(props, option, deleteOption)}
                        />
                        <FTIconButton
                            handler={() => onEditName("model", inputs?.model?.name, "copy")}
                            title={editInfo?.open ? "" : "Copy"}
                            btnIcon={<CopyAllIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />}
                            placement="top"
                            disabled={isCopyBtnDisabled("model")}
                            style={getIconStyle("model", true)}
                        />
                        <FTIconButton
                            handler={() => onEditName("model", inputs?.model?.name)}
                            title={editInfo?.open ? "" : "Rename"}
                            btnIcon={
                                <DriveFileRenameOutlineIcon
                                    style={{ fontSize: "1.1rem", color: "grey" }}
                                    color="primary"
                                />
                            }
                            placement="top"
                            disabled={isDisabled("model")}
                            style={getIconStyle("model")}
                        />
                        <FTIconButton
                            handler={(e) => onShare(e, inputs?.model?.id, modelList)}
                            title={shareInfo.open ? "" : "Share"}
                            btnIcon={<ShareIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />}
                            placement="top"
                            disabled={isDisabled("model")}
                            style={getIconStyle("model")}
                        />
                        <ShareWith
                            shareInfo={shareInfo}
                            setShareInfo={setShareInfo}
                            refreshData={refreshData}
                            setBenchmarkModelData={setBenchmarkModelData}
                        />
                    </div>
                </div>
                <div className="input-grp2" style={{ width: "30%" }}>
                    <div className="input-label" style={{ width: "35%" }}>
                        CME Date
                    </div>
                    <div className="input-field" style={{ width: "65%" }}>
                        <div className="date-picker-alignment">
                            <FTDatePicker
                                label=""
                                style={{ ...styles, padding: "5px" }}
                                dateStr={inputs?.cmeDate}
                                handleDateChange={(val) =>
                                    handleFieldChange("cmeDate", moment(val).format("YYYY-MM-DD"))
                                }
                                disableUnderline
                                inputPropsStyle={{ padding: 0, fontSize: 12.5 }}
                            />
                        </div>
                    </div>
                </div>
                <div className="input-grp2" style={{ width: "20%" }}>
                    <div className="input-label" style={{ width: "60%" }}>
                        CME Currency
                    </div>
                    <div className="input-field" style={{ width: "40%" }}>
                        <AutocompleteField
                            onChange={(_, v) => handleFieldChange("cme_currency_code", v?.id)}
                            provider={(q) => provider(currencyList, q)}
                            value={currencyList?.find((f) => f.id == inputs?.cme_currency_code)}
                            placeholder="Currency"
                            inputPropsStyle={styles}
                            disableUnderline={true}
                            forcePopupIcon={true}
                            searchIcon={false}
                            popperWidth="70px"
                            disableClearable={true}
                        />
                    </div>
                </div>
            </div>
            <div className="w-100 d-flex pt-2">
                <div className="input-grp">
                    <div className="input-label" style={{ width: "20%" }}>
                        Risk Model
                    </div>
                    <div className="input-field" style={{ width: "80%" }}>
                        <AutocompleteField
                            onChange={(_, v) => handleFieldChange("riskModel", v?.id)}
                            provider={(q) => provider(riskModelList, q)}
                            value={getRiskModel(inputs?.riskModel)}
                            placeholder="Risk Model.."
                            inputPropsStyle={styles}
                            disableUnderline={true}
                            forcePopupIcon={true}
                            popperWidth="300px"
                            searchIcon={false}
                        />
                    </div>
                </div>
                <div className="input-grp2">
                    <div className="input-label" style={validationError?.constraint ? { color: "red" } : undefined}>
                        Constraints
                    </div>
                    <div className="input-field">
                        <AutocompleteField
                            onChange={(_, v) => onConstraintChange(v?.id)}
                            provider={(q) => provider(sortList(constraintList), q)}
                            value={getSelectValue("constraint", constraintList)}
                            placeholder="Constraints.."
                            inputPropsStyle={
                                validationError?.constraint ? { ...styles, borderColor: "red" } : { ...styles }
                            }
                            disableUnderline={true}
                            forcePopupIcon={true}
                            popperWidth="300px"
                            searchIcon={false}
                            renderOption={(props, option) => RenderOption(props, option, deleteOption)}
                        />
                        <FTIconButton
                            handler={() => onEditName("constraint", inputs?.constraint, "copy")}
                            title={"Copy"}
                            btnIcon={<CopyAllIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />}
                            placement="top"
                            disabled={isCopyBtnDisabled("constraint")}
                            style={getIconStyle("constraint", true)}
                        />
                        <FTIconButton
                            handler={() => onEditName("constraint", inputs?.constraint)}
                            title={"Rename"}
                            btnIcon={
                                <DriveFileRenameOutlineIcon
                                    style={{ fontSize: "1.1rem", color: "grey" }}
                                    color="primary"
                                />
                            }
                            placement="top"
                            disabled={isDisabled("constraint")}
                            style={getIconStyle("constraint")}
                        />

                        {/* <FTIconButton
                            handler={() => openConstraintWindow()} // pass constraint name here
                            title="Edit"
                            btnIcon={<ModeEditIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />}
                            placement="top"
                            disabled={isDisabled("constraint")}
                            style={getIconStyle("constraint")}
                        /> */}
                        <FTIconButton
                            handler={(e) => onShare(e, inputs?.constraint, constraintList)}
                            title={shareInfo.open ? "" : "Share"}
                            btnIcon={<ShareIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />}
                            placement="top"
                            disabled={isDisabled("constraint")}
                            style={getIconStyle("constraint")}
                        />
                    </div>
                </div>
            </div>
            <div className="w-100 d-flex pt-2">
                <div className="input-grp">
                    <div className="input-label" style={{ width: "20%" }}>
                        Objectives fn
                    </div>
                    <div className="input-field" style={{ width: "80%" }}>
                        <AutocompleteField
                            onChange={(_, v) => handleFieldChange("objFuncs", v?.id)}
                            provider={(q) => provider(objFuncList, q)}
                            value={objFuncList?.find((f) => f.id == inputs?.objFuncs)}
                            placeholder="Objectives fn.."
                            inputPropsStyle={styles}
                            disableUnderline={true}
                            forcePopupIcon={true}
                            popperWidth="300px"
                            customStyle={{ color: "#355dd1" }}
                            searchIcon={false}
                        />
                    </div>
                </div>
                <div className="input-grp2">
                    <div className="input-label">Benchmark</div>
                    <div className="input-field">
                        <AutocompleteField
                            onChange={(_, v) => onBenchmarkChange(v?.id, benchmarkList)}
                            provider={(query) => provider(sortList(benchmarkList), query)}
                            value={benchmarkList?.find((f) => f.id == inputs?.benchmark)}
                            placeholder="Benchmark.."
                            inputPropsStyle={styles}
                            disableUnderline={true}
                            forcePopupIcon={true}
                            popperWidth="300px"
                            searchIcon={false}
                            renderOption={RenderOption}
                        />
                        {benchmarkInfo?.loading ? (
                            <div>
                                <CircularProgress style={{ height: "25px", width: "25px" }} />
                            </div>
                        ) : (
                            <>
                                <FTIconButton
                                    handler={() => onEditName("benchmark", inputs?.benchmark, "copy")}
                                    title={"Copy"}
                                    btnIcon={
                                        <CopyAllIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    disabled={isCopyBtnDisabled("benchmark")}
                                    style={getIconStyle("benchmark", true)}
                                />
                                <FTIconButton
                                    handler={() => onEditName("benchmark", inputs?.benchmark)}
                                    title={"Rename"}
                                    btnIcon={
                                        <DriveFileRenameOutlineIcon
                                            style={{ fontSize: "1.1rem", color: "grey" }}
                                            color="primary"
                                        />
                                    }
                                    placement="top"
                                    style={getIconStyle("benchmark")}
                                    disabled={isDisabled("benchmark")}
                                />
                                <FTIconButton
                                    handler={() => {
                                        if (inputs?.benchmark) {
                                            setBenchmarkInfo({ ...benchmarkInfo, open: true, saveType: "edit" });
                                        } else {
                                            setBenchmarkModelData({ "Model Suite": "Benchmark" });
                                            setBenchmarkInfo({ ...benchmarkInfo, open: true, saveType: "create" });
                                        }
                                    }}
                                    title="Edit"
                                    btnIcon={
                                        <ModeEditIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    style={squareBtnStyle}
                                    disabled={false}
                                />
                                <FTIconButton
                                    handler={(e) => onShare(e, inputs?.benchmark, benchmarkList, true)}
                                    title={shareInfo.open ? "" : "Share"}
                                    btnIcon={
                                        <ShareIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    style={getIconStyle("benchmark")}
                                    disabled={isDisabled("benchmark")}
                                />
                            </>
                        )}
                    </div>
                </div>
            </div>
            <div className="w-100 d-flex pt-2">
                <div className="input-grp">
                    <div className="input-label">Hurdles</div>
                    <div className="input-field">
                        <TextField
                            className="input-number"
                            variant="standard"
                            style={textStyles}
                            onChange={(e) => handleFieldChange("hurdle_risk", e.target.value)}
                            value={inputs?.hurdle_risk || ""}
                            type="number"
                            inputProps={{ style: { textAlign: "center", fontSize: ".9rem" } }}
                            InputProps={{
                                endAdornment: (
                                    <InputAdornment position="end" disablePointerEvents>
                                        {" "}
                                        %{" "}
                                    </InputAdornment>
                                ),
                                disableUnderline: true,
                            }}
                        />
                        <span className="text-label">Risk</span>
                        <TextField
                            className="input-number"
                            variant="standard"
                            style={{ ...textStyles, marginLeft: 25 }}
                            inputProps={{ style: { textAlign: "center", fontSize: ".9rem" } }}
                            onChange={(e) => handleFieldChange("return", e.target.value)}
                            value={inputs?.return || ""}
                            type="number"
                            InputProps={{
                                endAdornment: (
                                    <InputAdornment position="end" disablePointerEvents>
                                        {" "}
                                        %{" "}
                                    </InputAdornment>
                                ),
                                disableUnderline: true,
                            }}
                        />
                        <span className="text-label">Return</span>
                    </div>
                </div>
                <div className="input-grp2">
                    <div className="input-label" style={{ width: "22%" }}>
                        Tracking Error
                    </div>
                    <div className="input-field" style={{ width: "78%" }}>
                        <TextField
                            className="input-number"
                            variant="standard"
                            type="number"
                            style={{ ...textStyles }}
                            inputProps={{ min: 0, style: { textAlign: "center", fontSize: ".9rem" } }}
                            onChange={(e) => handleFieldChange("trackingError", e.target.value)}
                            value={inputs?.trackingError}
                            InputProps={{
                                endAdornment: (
                                    <InputAdornment position="end" disablePointerEvents>
                                        {" "}
                                        %{" "}
                                    </InputAdornment>
                                ),
                                disableUnderline: true,
                            }}
                        />
                    </div>
                </div>
            </div>
            <Dialog
                open={benchmarkInfo?.open}
                onClose={() => setBenchmarkInfo({ ...benchmarkInfo, open: false })}
                maxWidth="lg"
                fullWidth
            >
                <ModelPortfolio
                    handleViewButton={null}
                    showList={false}
                    isEditMode={true}
                    modelData={benchmarkModelData}
                    setModelData={setBenchmarkModelData}
                    saveType={benchmarkInfo?.saveType}
                    handleCancel={() => setBenchmarkInfo({ ...benchmarkInfo, open: false })}
                    cancelButtonText="Close"
                    modelListMap={null}
                    headerName="Benchmark"
                    modelSuites={["Benchmark"]}
                    disableModelSuites={true}
                    refreshModelList={() => {
                        refreshData();
                        setBenchmarkInfo({ ...benchmarkInfo, open: false });
                    }}
                    formatModelData={formatModelData}
                    customOptionCols={[
                        { key: "asset_type", label: "Asset Type", width: "15%" },
                        { key: "category", label: "Category", width: "20%" },
                        { key: "sub_category", label: "Sub Category", width: "25%" },
                        { key: "asset", label: "Asset", width: "25%" },
                    ]}
                    customSearchEntity={(query) => {
                        const searchColumns = ["asset_type", "category", "sub_category", "asset"];
                        const results = globalSearch(assetsWithEntityIds, query, 0, searchColumns);
                        return Promise.resolve([results, results.length]);
                    }}
                />
            </Dialog>
        </div>
    );
}
export default function SAAInput({
    app,
    zone,
    formData,
    setFormData,
    assetGroups,
    refreshData,
    outputData,
    onConstraintsSave,
    getCMEData,
    submitAndRunOutput,
    validationError,
    deleteOption,
    selectedTemplate,
    deleteObj,
    setDeleteObj,
    onTemplateChange,
}) {
    const classes = useStyles();

    const gridStyle = useMemo(
        () => ({
            height: "100%",
            // maxHeight: "calc(100vh - 475px)",
            width: "100%",
            overflow: "auto",
        }),
        []
    );
    const [rowsInfo, setRowsInfo] = useState<any>({ rows: [], groupedRows: [], isEditable: true });
    const [benchmarkModelData, setBenchmarkModelData] = useState<any>({});
    const [updateInfo, setUpdateInfo] = useState<any>({});
    const [loaders, setLoaders] = useState<any>({});
    const [auditTrail, setAuditTrail] = useState<any>({ open: false, selectedAuditIdx: null });
    const [inputDetails, setInputDetails] = useState<any>({ model: {} });
    const [benchmarkInfo, setBenchmarkInfo] = useState<any>({ open: false, loading: false, saveType: "" });
    const [createCopyDialog, setCreateCopyDialog] = useState(false);
    const [editInfo, setEditInfo] = useState<any>({ open: false, field: "", value: "" });

    function refreshRows(list) {
        setRowsInfo((info) => {
            const rows = updateRowValues(
                info?.rows,
                list,
                outputData?.data?.final_objective || formData?.inputs?.prev_final_objective
            );
            const { updatedRows, groupedRows } = groupRows(rows, assetGroups.master);
            return { ...info, rows: updatedRows, groupedRows };
        });
    }

    useEffect(() => {
        if (assetGroups?.master?.length > 0 && rowsInfo?.rows?.length > 0) {
            refreshRows(assetGroups?.master);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [assetGroups, outputData?.data?.final_objective]);

    useEffect(() => {
        // const templateInfo = formData.templateList?.find((ele) => ele.id == template);
        const templateId = formData?.inputs?.id;
        if (templateId) {
            Api.getAuditHistory(templateId).then((res) => {
                if (res && res.length) {
                    setAuditTrail({ ...auditTrail, records: res, selectedAuditIdx: res.length - 1 });
                }
            });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [formData?.inputs?.id]);

    useEffect(() => {
        if (selectedTemplate?.id && selectedTemplate?.reload) {
            onSelectChange("template", selectedTemplate?.id);
        }
        if (selectedTemplate?.id === null && selectedTemplate.name) {
            handleFieldChange("template", { id: null, name: selectedTemplate.name });
        }
        if (selectedTemplate?.editedName) {
            onEditName("template", formData?.inputs?.Name);
        } else if (selectedTemplate?.copy) {
            onEditName("template", formData?.inputs?.Name, "copy");
        }
        // eslint-disable-next-line
    }, [selectedTemplate]);

    useEffect(() => {
        let shouldClearData = false;
        let type = "";
        if (deleteObj?.deleted) {
            if (deleteObj.deleteObj?._meta?.type === "template") {
                shouldClearData = deleteObj.deleteObj?._meta?._id?.$oid === formData?.inputs?._id?.$oid;
                type = "template";
            } else if (deleteObj.deleteObj?._meta?.type === "modelportfolio") {
                shouldClearData ||= deleteObj.deleteObj?._meta?._id?.$oid === formData?.inputs?.model?.id;
                type = "model";
            } else if (deleteObj.deleteObj?._meta?.type === "constraints") {
                onConstraintChange(null);
                setUpdateInfo((e) => ({ ...e, constraint: null }));
                setDeleteObj((deleteObj) => ({ ...deleteObj, deleteObj: null, deleted: false }));
            }
        }
        if (shouldClearData) {
            onSelectChange(type, null);
            setDeleteObj((deleteObj) => ({ ...deleteObj, deleteObj: null, deleted: false }));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [deleteObj]);

    const handleFieldChange = (id, value) => {
        if (id == "cmeDate") {
            getCMEData(value);
        }
        if (id == "cme_currency_code") {
            getCMEData(formData.inputs?.cmeDate, value);
        }
        let updatedInputs = { ...formData.inputs };
        if (id == "template") {
            updatedInputs = { ...updatedInputs, ...value };
        } else {
            updatedInputs = { ...updatedInputs, [id]: value };
        }
        setFormData((fd) => ({ ...fd, inputs: updatedInputs }));
    };

    function onEditName(field, value, action = "rename") {
        let id = formData?.inputs?.[field]?.id;
        if (field == "template") {
            id = formData?.inputs?.id;
        }
        if (field == "constraint" || field == "benchmark") {
            id = value;
            value = inputDetails?.[field]?.Name;
        }
        setEditInfo({ open: true, field, value, id, action });
    }

    function onDelete(row) {
        setRowsInfo((info) => {
            const newRows = info?.rows?.filter((e) => !findAssetGroup(e, row));
            const { updatedRows, groupedRows } = groupRows(newRows, assetGroups.master);
            return {
                ...info,
                rows: updatedRows,
                groupedRows,
            };
        });
    }

    function onDeleteAll() {
        setRowsInfo((r) => ({ ...r, rows: [], groupedRows: [] }));
    }

    function onModelChange(modelInfo: any = {}, template) {
        let isEditable = true;
        isEditable = modelInfo && hasAccess(modelInfo?._meta);
        setInputDetails((e) => ({ ...e, model: modelInfo?._meta }));
        const groups = modelInfo?.assetGroups || [];
        setRowsInfo((info) => {
            const rows = updateRowValues(groups, assetGroups?.master, template?.prev_final_objective);
            const { updatedRows, groupedRows } = groupRows(rows, assetGroups?.master);
            return { ...info, rows: updatedRows, groupedRows, isEditable };
        });
    }

    function onConstraintChange(value, updateFormData = true, constraintList = []) {
        let constraintInfo: any = {};
        if (!value) {
            // if no constraint is selected or existing selected constraint removed
            refreshRows(assetGroups?.records);
        } else {
            let list = formData?.constraintList;
            if (constraintList?.length > 0) {
                list = constraintList;
            }
            constraintInfo = list.find((ele) => ele.id === value);
            if (constraintInfo?.constraints) {
                onConstraintsSave(constraintInfo, false);
            }
        }
        if (updateFormData) {
            handleFieldChange("constraint", value);
        }
        setInputDetails((e) => ({ ...e, constraint: constraintInfo?._meta }));
    }

    const onSelectChange = (id, value, templateList: any = [], modelList: any = []) => {
        let tmplInfo: any = {};
        let formInputs: any = { ...defaultFormData?.inputs };
        let inputsInfo = { template: null };
        let modelInfo: any = {};
        if (id == "template") {
            setUpdateInfo((e) => ({ ...e, [id]: null, model: null }));
            if (value) {
                if (templateList?.length > 0) {
                    tmplInfo = templateList?.find((r) => r.id == value);
                } else {
                    tmplInfo = formData?.templateList?.find((r) => r.id == value);
                }
                if (tmplInfo) {
                    tmplInfo = { cme_currency_code: "USD", ...tmplInfo };
                }
                inputsInfo = { template: tmplInfo?._meta };
                formInputs = { ...tmplInfo, name: tmplInfo?.Name, id: value };
                if (tmplInfo?.model) {
                    let list = formData?.modelList;
                    if (modelList?.length > 0) {
                        list = modelList;
                    }
                    modelInfo = list?.find((ele) => ele.id == tmplInfo.model) || {};
                    const model = { id: modelInfo?.id, name: modelInfo.label };
                    formInputs.model = model;
                }
                if (tmplInfo?.constraint) {
                    const constraintInfo = formData?.constraintList.find((ele) => ele.id == tmplInfo.constraint) || {};
                    formInputs.constraint = constraintInfo?.id;
                    onConstraintChange(constraintInfo?.id, false);
                }
                if (tmplInfo?.benchmark) {
                    const selectedModel = formData?.benchmarkList?.find((f) => f.id == tmplInfo?.benchmark);
                    if (selectedModel) {
                        setBenchmarkModelData(() => formatModelData(selectedModel));
                    }
                }
            }
            setFormData((fd) => ({ ...fd, inputs: formInputs }));
            setInputDetails((e) => ({ ...e, ...inputsInfo }));
            onModelChange(modelInfo, formInputs);
        } else if (id == "model") {
            setUpdateInfo((e) => ({ ...e, [id]: null }));
            let list = formData?.modelList;
            if (modelList?.length > 0) {
                list = modelList;
            }
            modelInfo = list.find((ele) => ele.id == value) || {};
            const model = { id: modelInfo?.id, name: modelInfo.label };
            handleFieldChange(id, model);
            onModelChange(modelInfo, {});
        }
    };

    function validateInputs(template, modelName, inputs, isModelOnly = false) {
        if (!isModelOnly && !template) {
            errorNotification.next({
                type: "error",
                text: "Please select or create a template to proceed",
                open: true,
            });
            return false;
        }
        if (!modelName) {
            errorNotification.next({ type: "error", text: "Please select or create a model to proceed", open: true });
            return false;
        }
        if (!isModelOnly && !inputs?.benchmark) {
            errorNotification.next({ type: "error", text: "Please select `Benchmark` to proceed", open: true });
            return false;
        }
        if (!isModelOnly && !inputs?.trackingError) {
            errorNotification.next({ type: "error", text: "Please select `Tracking Error` to proceed", open: true });
            return false;
        }

        if (!isModelOnly && !inputs?.cme_currency_code) {
            errorNotification.next({ type: "error", text: "Please select `currency` to proceed", open: true });
            return false;
        }
        if (!isModelOnly && !inputs?.riskModel) {
            errorNotification.next({ type: "error", text: "Please select `riskModel` to proceed", open: true });
            return false;
        }
        if (!isModelOnly && !inputs?.objFuncs) {
            errorNotification.next({ type: "error", text: "Please select `Objectives fn` to proceed", open: true });
            return false;
        }
        return true;
    }

    async function createOrUpdateModel(modelOnly = false) {
        try {
            const inputs = formData?.inputs || {};
            const modelName = updateInfo?.model?.label.trim() || inputs?.model?.name?.trim();
            if (modelOnly) {
                const isValid = validateInputs("", modelName, {}, modelOnly);
                if (!isValid) {
                    return { error: true };
                }
            }
            const modelInfo = formData.modelList?.find((ele) => ele.id == inputs?.model?.id);
            const rows = rowsInfo?.rows || [];
            if (rows?.length == 0) {
                errorNotification.next({
                    type: "error",
                    text: "Please select at least one asset group to create a model",
                    open: true,
                });
                return { error: true };
            }

            let modelId = modelInfo?.id;
            let payload = {
                Name: modelName,
                name: modelName + "-modelportfolio",
                type: "modelportfolio",
                assetGroups: rowsInfo?.rows.map((ele) => ({
                    entity_id: ele.entity_id,
                    asset_class: ele.asset_class,
                    asset_type: ele.asset_type,
                    category: ele.category,
                    sub_category: ele.sub_category,
                    asset: ele.asset,
                })),
            };
            let modelResp: any = {};

            if (modelOnly) {
                setLoaders((l) => ({ ...l, model: true }));
            }

            if (modelId) {
                payload = { ...modelInfo?._meta, ...payload };
                const updateAccess = hasAccess(modelInfo?._meta);
                if (modelOnly) {
                    if (!updateAccess) {
                        errorNotification.next({
                            type: "error",
                            text: "You don't have permission to update this model",
                            open: true,
                        });
                        setLoaders((l) => ({ ...l, model: false }));
                        return { error: true };
                    }
                }
                if (!updateAccess) {
                    return { modelId };
                }
                modelResp = await Api.updateSharedState(modelId, payload);
            } else {
                payload["access"] = { system: false, dept: false, users: [] };
                modelResp = await Api.createSharedState(app, zone, payload);
                modelId = modelResp._id;
                setFormData((formData) => ({
                    ...formData,
                    inputs: { ...formData.inputs, model: { ...formData.inputs.model, id: modelId } },
                }));
            }
            if (modelOnly && modelResp?.message) {
                errorNotification.next({ type: "success", text: modelResp.message, open: true });
                refreshData();
            }
            if (modelOnly) {
                setLoaders((l) => ({ ...l, model: false }));
            }
            return { modelId };
        } catch (err) {
            console.error(err);
            if (modelOnly) {
                setLoaders((l) => ({ ...l, model: false }));
            }
        }
    }

    async function handleSave(templateId, templateInputs, templateInfo) {
        try {
            let response: any = {};
            if (templateId) {
                if (!templateInfo) {
                    templateInfo = formData.templateList?.find((ele) => ele.id == templateId);
                }
                templateInputs = { ...templateInfo?._meta, ...templateInputs };
                response = await Api.updateSharedState(templateId, templateInputs);
            } else {
                templateInputs["access"] = { system: false, dept: false, users: [] };
                delete templateInputs.prev_final_objective;
                delete templateInputs.prev_portfolio_asset_list;
                response = await Api.createSharedState(app, zone, { ...templateInputs });
            }
            if (response?.["shared-object"]?._id?.$oid) {
                Api.getAuditHistory(response?.["shared-object"]?._id?.$oid).then((res) => {
                    if (res && res.length) {
                        setAuditTrail({ ...auditTrail, records: res, selectedAuditIdx: res.length - 1 });
                    }
                });
            }
            if (response?.message) {
                errorNotification.next({ type: "success", text: response.message, open: true });
                refreshData().then((sharedObj) => {
                    const { templateList = [], modelList = [] }: any = sharedObj;
                    if (templateList?.length > 0) {
                        const newTemplateId = response?.["shared-object"]?._id?.$oid;
                        onSelectChange("template", newTemplateId, templateList, modelList);
                    }
                });
            }
            return response["shared-object"]?._id?.$oid;
        } catch (err) {
            console.error(err);
        }
    }

    async function handleSubmit() {
        try {
            const inputs = formData?.inputs || {};
            const modelName = updateInfo?.model?.label.trim() || inputs?.model?.name?.trim();
            const template = updateInfo?.template?.label.trim() || inputs?.name?.trim();
            const templateId = inputs?.id;
            const isValid = validateInputs(template, modelName, inputs);
            if (!isValid) {
                return;
            }
            setLoaders((loaders) => ({ ...loaders, submit: true }));
            if (templateId && !hasAccess(inputs?._meta)) {
                setCreateCopyDialog(true);
            } else {
                const res: any = await createOrUpdateModel();
                if (res?.error) {
                    return;
                }
                const templateInputs = {
                    Name: template,
                    name: template + "-template",
                    type: "template",
                    cmeDate: inputs?.cmeDate,
                    objFuncs: inputs?.objFuncs,
                    cme_currency_code: inputs?.cme_currency_code,
                    riskModel: inputs?.riskModel,
                    benchmark: inputs?.benchmark,
                    trackingError: Number(inputs?.trackingError),
                    return: Number(inputs?.return),
                    hurdle_risk: Number(inputs?.hurdle_risk),
                    model: res?.modelId,
                    constraint: inputs?.constraint,
                    prev_final_objective: inputs.prev_final_objective,
                    prev_portfolio_asset_list: inputs.prev_portfolio_asset_list,
                };
                const modelInfo = formData?.modelList?.find((r) => r.id == inputs._meta?.model) || {};
                const changed =
                    compareTemplate(templateInputs, inputs?._meta) ||
                    compareAssets(modelInfo?.assetGroups, rowsInfo?.rows);
                if (changed) {
                    const savedTemplateId = await handleSave(templateId, templateInputs, inputs?._meta);
                    try {
                        await submitAndRunOutput(
                            { template_id: savedTemplateId },
                            benchmarkModelData?.assets,
                            rowsInfo?.rows
                        );
                    } finally {
                        setLoaders((loaders) => ({ ...loaders, submit: false }));
                    }
                } else {
                    try {
                        await submitAndRunOutput(
                            { template_id: templateId },
                            benchmarkModelData?.assets,
                            rowsInfo?.rows
                        );
                    } finally {
                        setLoaders((loaders) => ({ ...loaders, submit: false }));
                    }
                }
            }
        } catch (err) {
            console.error(err);
            setLoaders((loaders) => ({ ...loaders, submit: false }));
        }
    }

    const handleSearchChange = (_, doc) => {
        if (doc) {
            setRowsInfo((info) => {
                const _rows = info?.rows || [];
                const newRows = [..._rows, { ...doc }];
                const { updatedRows, groupedRows } = groupRows(newRows, assetGroups.master);
                return {
                    ...info,
                    rows: updatedRows,
                    groupedRows,
                };
            });
        }
    };

    function onSelectPastRecord(id) {
        Api.getSharedStateById(id).then((res) => {
            setAuditTrail({
                ...auditTrail,
                open: false,
                selectedAuditIdx: auditTrail.records.findIndex((rec) => rec._id.$oid === id),
                selectedAudit: res,
            });
        });
    }

    const assetsWithEntityIds = useMemo(() => assetGroups?.master?.filter((e: any) => e.entity_id), [assetGroups]);
    return (
        <>
            <div className={classes.saaCard}>
                <InputFields
                    app={app}
                    zone={zone}
                    formData={formData}
                    handleFieldChange={handleFieldChange}
                    setFormData={setFormData}
                    refreshData={refreshData}
                    updateInfo={updateInfo}
                    setUpdateInfo={setUpdateInfo}
                    benchmarkModelData={benchmarkModelData}
                    setBenchmarkModelData={setBenchmarkModelData}
                    selectedPastTemplate={auditTrail.selectedAudit}
                    onSelectChange={onSelectChange}
                    onConstraintChange={onConstraintChange}
                    benchmarkInfo={benchmarkInfo}
                    setBenchmarkInfo={setBenchmarkInfo}
                    setInputDetails={setInputDetails}
                    inputDetails={inputDetails}
                    onModelChange={onModelChange}
                    assetsWithEntityIds={assetsWithEntityIds}
                    validationError={validationError}
                    deleteOption={deleteOption}
                    onEditName={onEditName}
                    editInfo={editInfo}
                    setEditInfo={setEditInfo}
                    onTemplateChange={onTemplateChange}
                />

                <div style={{ height: "100%", width: "100%" }}>
                    <div id="saa-input-table" style={gridStyle} className="pt-2">
                        <AssetTable
                            rows={rowsInfo.groupedRows}
                            isEditable={rowsInfo?.isEditable}
                            onDelete={onDelete}
                            onDeleteAll={onDeleteAll}
                        />
                    </div>
                </div>
                <div className="d-flex w-100">
                    <div className={"w-50 search-box"}>
                        <SearchForAsset
                            list={assetsWithEntityIds || []}
                            ids={rowsInfo.rows?.map((r) => getAssetId(r))}
                            handleChange={handleSearchChange}
                            disabled={!rowsInfo.isEditable}
                        />
                    </div>
                    <div className={"btn-group"}>
                        <AdornedButton
                            className="save-btn"
                            onClick={() => createOrUpdateModel(true)}
                            variant="outlined"
                            size="small"
                            loading={loaders?.model}
                            disabled={loaders?.submit}
                        >
                            Save Model
                        </AdornedButton>
                        <Tooltip
                            title="Invalid constraint"
                            disableHoverListener={!validationError?.constraint}
                            placeholder="top"
                        >
                            <span>
                                <AdornedButton
                                    className={"save-btn m-1"}
                                    variant="outlined"
                                    size="small"
                                    onClick={() => handleSubmit()}
                                    loading={loaders?.submit}
                                    disabled={benchmarkInfo.loading || validationError?.constraint || loaders?.model}
                                >
                                    {" "}
                                    Save and Submit{" "}
                                </AdornedButton>
                            </span>
                        </Tooltip>
                    </div>
                </div>
                <div className="d-flex w-100 pt-1 align-items-center">
                    <div className="input-label" style={{ width: "auto" }}>
                        Audit Trail
                    </div>
                    <div
                        className="audit-trail"
                        onClick={() => {
                            setAuditTrail({ ...auditTrail, open: true });
                        }}
                    >
                        <span>{auditTrail.selectedAuditIdx >= 0 ? auditTrail.selectedAuditIdx + 1 : ""}</span>
                        {auditTrail.selectedAuditIdx >= 0
                            ? auditTrail.records?.[auditTrail.selectedAuditIdx]._meta?.create_timestamp.substring(0, 19)
                            : ""}
                        <span>
                            {auditTrail.selectedAuditIdx >= 0
                                ? auditTrail.records?.[auditTrail.selectedAuditIdx]._meta?.author
                                : ""}
                        </span>
                    </div>
                </div>
            </div>
            <Dialog
                open={auditTrail.open && auditTrail.records}
                onClose={() => setAuditTrail({ ...auditTrail, open: false })}
                maxWidth="lg"
                fullWidth
            >
                <AuditTrail records={auditTrail.records} onSelectPastRecord={onSelectPastRecord} />
            </Dialog>
            <Dialog open={createCopyDialog} onClose={() => setCreateCopyDialog(false)} maxWidth="sm" fullWidth>
                <DialogContent>
                    You selected a template that you do not have access to, do you want to create a copy or only run
                    outputs?
                </DialogContent>
                <DialogActions>
                    <AdornedButton
                        style={{ textTransform: "capitalize" }}
                        variant="contained"
                        onClick={async () => {
                            const inputs = formData?.inputs || {};
                            setCreateCopyDialog(false);
                            const res: any = await createOrUpdateModel();
                            if (res?.error) {
                                return;
                            }
                            const template = updateInfo?.template?.label.trim() || inputs?.name?.trim();
                            const templateInputs = {
                                Name: template,
                                name: template + "-template",
                                type: "template",
                                cmeDate: inputs?.cmeDate,
                                objFuncs: inputs?.objFuncs,
                                cme_currency_code: inputs?.cme_currency_code,
                                riskModel: inputs?.riskModel,
                                benchmark: inputs?.benchmark,
                                trackingError: Number(inputs?.trackingError),
                                return: Number(inputs?.return),
                                hurdle_risk: Number(inputs?.hurdle_risk),
                                model: res?.modelId,
                                constraint: inputs?.constraint,
                            };
                            const savedTemplateId = await handleSave(null, templateInputs, null);
                            try {
                                await submitAndRunOutput(
                                    { template_id: savedTemplateId },
                                    benchmarkModelData?.assets,
                                    rowsInfo?.rows
                                );
                            } finally {
                                setLoaders((loaders) => ({ ...loaders, submit: false }));
                            }
                        }}
                        color="secondary"
                    >
                        {" "}
                        Create Copy{" "}
                    </AdornedButton>
                    <AdornedButton
                        style={{ textTransform: "capitalize" }}
                        variant="contained"
                        onClick={async () => {
                            const templateId = formData?.inputs?.id;
                            setCreateCopyDialog(false);
                            try {
                                await submitAndRunOutput(
                                    { template_id: templateId },
                                    benchmarkModelData?.assets,
                                    rowsInfo?.rows
                                );
                            } finally {
                                setLoaders((loaders) => ({ ...loaders, submit: false }));
                            }
                        }}
                        color="primary"
                    >
                        Run Output
                    </AdornedButton>
                </DialogActions>
            </Dialog>
        </>
    );
}
