import React from "react";

import AutocompleteField from "common/AutocompleteField";
import { globalSearch } from "utils/helpers";

const searchColumns = ["asset_type", "category", "sub_category", "asset"];

const defaultStyles = {
    height: "30px",
    border: " 1px solid rgb(217 207 207)",
    borderRadius: "5px",
    fontSize: 13,
};

export default function SearchForAsset({ list, ids, handleChange, styles = {}, disabled = false }) {
    const options = list?.filter((res) => !ids?.includes(res.asset_id));

    const provider = (query) => {
        if (!query) {
            return Promise.resolve([options, options.length]);
        }
        const results = globalSearch(options, query, 0, searchColumns);
        return Promise.resolve([results, results.length]);
    };

    if (disabled) {
        styles = { ...styles, opacity: 0.5 };
    }

    const RenderOption = function (props, option) {
        return (
            <>
                {props["data-option-index"] == 0 && (
                    <li
                        {...props}
                        key={"headers"}
                        style={{
                            fontSize: "16px",
                            fontStyle: "italic",
                            color: "#c5c5c5",
                        }}
                    >
                        <div className="col-2 text-truncate">Asset_type</div>
                        <div className="col-3 text-truncate">Category</div>
                        <div className="col-3 text-truncate">Sub Category</div>
                        <div className="col-4 text-truncate">Asset</div>
                    </li>
                )}

                <li {...props} key={option?.asset_id} style={{ fontSize: "14px" }}>
                    <div className="col-2 text-truncate">{option?.asset_type}</div>
                    <div className="col-3 text-truncate">{option.category}</div>
                    <div className="col-3 text-truncate">{option.sub_category}</div>
                    <div className="col-4 text-truncate">{option.asset}</div>
                </li>
            </>
        );
    };

    return (
        <AutocompleteField
            placeholder={"Asset group.."}
            provider={provider}
            onChange={handleChange}
            disabled={disabled}
            renderOption={RenderOption}
            popperWidth="700px"
            inputPropsStyle={{ ...defaultStyles, ...styles }}
            disableUnderline
            forcePopupIcon
        />
    );
}
