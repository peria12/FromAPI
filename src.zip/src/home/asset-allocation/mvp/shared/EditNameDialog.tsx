import React, { useState, useEffect } from "react";
import { Dialog, TextField, DialogTitle, DialogActions, IconButton, Button } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { textStyles } from "../saa/SAAInput";

export default function EditModal({ editInfo, setEditInfo, editOnSave }) {
    const [name, setName] = useState("");
    const onClose = () => setEditInfo((e) => ({ ...e, open: false }));
    const onClear = () => {
        setName("");
        setEditInfo((e) => ({ ...e, open: false }));
    };

    useEffect(() => {
        setName(editInfo?.value || "");
    }, [editInfo]);

    const BootstrapDialogTitle = (props: any) => {
        const { children, onClose, ...other } = props;
        return (
            <DialogTitle sx={{ m: 0, p: 1 }} {...other}>
                {children}
                {onClose ? (
                    <IconButton
                        aria-label="close"
                        onClick={onClose}
                        sx={{
                            position: "absolute",
                            right: 1,
                            top: 1,
                            color: "grey",
                            padding: "4px",
                        }}
                    >
                        <CloseIcon style={{ fontSize: "1.3rem" }} />
                    </IconButton>
                ) : null}
            </DialogTitle>
        );
    };

    const isCopy = editInfo?.action == "copy"

    return (
        <Dialog className="saa saa-inputs" open={editInfo?.open} onClose={onClose} fullWidth maxWidth="xs">
            <BootstrapDialogTitle id="dialog-title" onClose={onClose}>
                <div
                    style={{
                        paddingLeft: 1,
                        color: "#c5c5c5",
                        fontStyle: "italic",
                        fontSize: "14px",
                        textTransform: "capitalize",
                    }}
                >
                    {isCopy ? `Copy ${editInfo?.field || ""}` : `Edit ${editInfo?.field || ""} name`}
                </div>
            </BootstrapDialogTitle>
            <div className="input-field" style={{ padding: "4px 8px", width: "100%" }}>
                <TextField
                    id="name"
                    onChange={(e) => setName(e.target.value)}
                    autoComplete="off"
                    variant="standard"
                    value={name || ""}
                    style={{ ...textStyles, width: "100%" }}
                    InputProps={{
                        disableUnderline: true,
                    }}
                />
            </div>
            <DialogActions>
                <div className="btn-group w-100 d-flex justify-content-end">
                    <Button onClick={onClear} className="sbt-btn" variant="outlined" size="small">
                        {" "}
                        Clear{" "}
                    </Button>
                    <Button
                        onClick={() => editOnSave(editInfo, name)}
                        className="save-btn m-1"
                        variant="outlined"
                        size="small"
                        disabled={!name}
                    >
                        {" "}
                        {isCopy ? "Copy" : "Save"}
                    </Button>
                </div>
            </DialogActions>
        </Dialog>
    );
}