import React, { useState } from "react";
import { Form } from "react-bootstrap";
import Popper from "@mui/material/Popper";
import Paper from "@mui/material/Paper";
import makeStyles from "@mui/styles/makeStyles";
import createStyles from "@mui/styles/createStyles";
import Api from "utils/api";
import Settings from "utils/settings";
import errorNotification from "utils/api-error";
import Access from "utils/access";
import { AdornedButton } from "common/FTButtons";
import { UserSelector, Users } from "common/UserSelector";
import { formatModelData } from "../saa/SAAInput";

const useStyles = makeStyles(() =>
    createStyles({
        container: {
            minWidth: 480,
            maxWidth: 480,
        },
        label: {
            color: "#797777",
            display: "inline-block",
            fontSize: "13px",
            fontStyle: "italic",
            marginRight: "5px",
            textAlign: "right",
            whiteSpace: "nowrap",
        },
    })
);

const defaultForm = { system: false, dept: false, users: [] };

export default function ShareWith({ shareInfo, setShareInfo, refreshData, setBenchmarkModelData }) {
    const [form, setForm] = useState<any>({ ...defaultForm });
    const [btnLoading, setBtnLoading] = useState<any>(false);
    const userEmail: string = Settings.getSettings()?.email;
    const classes = useStyles();

    const isAdmin = Access.hasAccessToZone("admin", "acl", ["admin"]);

    function onChange(key, val) {
        if (key === "users") {
            val = typeof val === "string" ? val.split(",") : val;
        }
        setForm((form) => ({ ...form, [key]: val }));
    }

    function setUsers(users) {
        setForm((f) => ({ ...f, users }));
    }

    React.useEffect(() => {
        if (shareInfo?.data) {
            const info = shareInfo?.data?._meta?.access || {};
            info.dept = !!(info.dept_code || info.dept);
            setForm((f) => ({ ...f, ...info, _meta: shareInfo?.data?._meta }));
        } else {
            setForm({ ...defaultForm });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [shareInfo]);

    function close() {
        setShareInfo((info) => ({ ...info, open: false }));
    }
    function onClear() {
        close();
        setForm((form) => ({ ...form, ["users"]: [] }));
    }

    function createOrUpdate(action) {
        if (action == "update" && form?._meta) {
            setBtnLoading(true);
            const obj = form?._meta || {};
            const users = form?.users;
            const modifiedUsers = users.length ? (users.includes(userEmail) ? users : [...users, userEmail]) : users;
            if (!obj._id?.$oid) {
                const payload = {
                    ...obj,
                    access: {
                        system: form.system,
                        dept: form.dept,
                        users: modifiedUsers,
                    },
                };
                delete payload._id;
                Api.editModelPortfolio(obj._id, payload)
                    .then((response) => {
                        if (response?.message) {
                            errorNotification.next({ type: "success", text: response.message, open: true });
                        }
                        setBenchmarkModelData(() => formatModelData(response?.["shared-object"]));
                        close();
                        setBtnLoading(false);
                    })
                    .catch(() => {
                        setBtnLoading(false);
                    });
            } else {
                Api.updateSharedState(obj._id?.$oid, {
                    ...obj,
                    access: {
                        system: form.system,
                        dept: form.dept,
                        users: modifiedUsers,
                    },
                })
                    .then((response) => {
                        if (response?.message) {
                            errorNotification.next({ type: "success", text: response.message, open: true });
                        }
                        refreshData();
                        close();
                        setBtnLoading(false);
                    })
                    .catch(() => {
                        setBtnLoading(false);
                    });
            }
        }
    }
    const btnStyle = { fontSize: 13, padding: "3px 6px" };
    return (
        <Popper
            anchorEl={shareInfo?.shareBtnRef}
            open={shareInfo?.open}
            placement="right"
            className={classes.container}
            style={{ zIndex: 1000 }}
        >
            <Paper square elevation={5} style={{ padding: "1px 10px" }} className="saa saa-inputs">
                <div className="mt-2 pb-2 d-flex align-items-center">
                    <span className={classes.label}>Share With:</span>
                    <Form.Check
                        inline
                        label={<span className={classes.label}>System</span>}
                        name="system"
                        type={"checkbox"}
                        id={`inline-checkbox-1`}
                        onChange={(event) => {
                            onChange("system", event.target.checked);
                        }}
                        checked={form?.system}
                        disabled={!isAdmin ? true : form?.users?.length || form?.dept ? true : false}
                    />
                    <Form.Check
                        inline
                        label={<span className={classes.label}>Dept</span>}
                        name="dept"
                        type={"checkbox"}
                        id={`inline-checkbox-2`}
                        onChange={(event) => {
                            onChange("dept", event.target.checked);
                        }}
                        checked={form?.dept}
                        disabled={form?.users?.length || form?.system ? true : false}
                    />
                    <UserSelector users={form?.users || []} setUsers={setUsers} disabled={form?.dept || form?.system} />
                </div>
                <Users users={form?.users || []} setUsers={setUsers} />
                <div className="d-flex w-100 p-1">
                    <div className="w-100 d-flex justify-content-end">
                        <AdornedButton
                            style={btnStyle}
                            onClick={onClear}
                            className={"sbt-btn"}
                            variant="outlined"
                            size="small"
                        >
                            Close
                        </AdornedButton>
                        <div style={{ paddingLeft: "8px" }}>
                            <AdornedButton
                                className="save-btn"
                                onClick={() => createOrUpdate("update")}
                                variant="outlined"
                                style={btnStyle}
                                size="small"
                                loading={btnLoading}
                            >
                                Update
                            </AdornedButton>
                        </div>
                    </div>
                </div>
            </Paper>
        </Popper>
    );
}
