import React, { useState } from "react";
import { Dialog, DialogActions } from "@mui/material";
import { AdornedButton } from "common/FTButtons";
import * as xlsx from "xlsx";
import Api from "utils/api";
import errorNotification from "utils/api-error";

const trimStr = (str) => (str ? str.trim() : "");
export default function UploadPopup({ uploadPopup, setUploadPopup }) {
    const [date, setDate] = useState(new Date().toISOString().substr(0, 7));
    const [selectedFile, setSelectedFile] = useState<any>({});
    const [loading, setLoading] = useState(false);

    const changeHandler = (event) => {
        setSelectedFile(event.target.files[0]);
    };

    function formatForm(uploaded, uloadFor) {
        const assetHeaders =
            uloadFor === "daa"
                ? ["class", "category", "sub_category", "asset", "percentage"]
                : ["class", "name", "region", "percentage"];
        const formattedObj: any = {};
        if (uploaded.length === 0) {
            return formattedObj;
        }
        uploaded.forEach((asset) => {
            Object.keys(asset).forEach((key) => {
                let portfolioId;
                if (!assetHeaders.includes(key)) {
                    if (!Object.hasOwn(formattedObj, key)) {
                        portfolioId = key;
                        formattedObj[key] = {
                            _id: "daa_" + portfolioId?.toLowerCase(),
                            asset_header: assetHeaders,
                            assets: [],
                            date,
                        };
                    }
                }
            });
        });
        uploaded.forEach((asset) => {
            const assetsArr =
                uloadFor === "daa"
                    ? [
                          trimStr(asset?.class),
                          trimStr(asset?.category),
                          trimStr(asset?.sub_category),
                          trimStr(asset?.asset),
                      ]
                    : [trimStr(asset?.class), trimStr(asset?.name), trimStr(asset?.region)];
            Object.keys(formattedObj).forEach((key) => {
                if (asset[key]) {
                    formattedObj[key].assets.push([...assetsArr, asset[key]]);
                }
            });
        });
        return formattedObj;
    }

    async function handleSubmission() {
        setLoading(true);
        const formData = new FormData();
        formData.append("File", selectedFile);
        const reader = new FileReader();
        reader.onload = (e: any) => {
            const data = e.target.result;
            const workbook = xlsx.read(data, { type: "array" });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const json = xlsx.utils.sheet_to_json(worksheet);
            const formattedArr = formatForm(json, uploadPopup);
            Promise.all(
                Object.keys(formattedArr).map((portfolioId) =>
                    Api.updateDocument(
                        "daa2",
                        "daa_" + portfolioId?.toLowerCase(),
                        { document: JSON.stringify(formattedArr[portfolioId]) },
                        { comment: "update" }
                    )
                )
            )
                .then(() => {
                    errorNotification.next({ type: "success", text: "Uploaded Successfully", open: true });
                    setLoading(false);
                    setUploadPopup(null);
                })
                .catch((err: any) => {
                    errorNotification.next(err);
                    setLoading(false);
                });
        };
        reader.readAsArrayBuffer(selectedFile);
    }

    return (
        <Dialog
            open={Boolean(uploadPopup)}
            onClose={() => {
                setDate(new Date().toISOString().substr(0, 7));
                setUploadPopup(null);
            }}
            fullWidth
            maxWidth="xs"
        >
            <div className="saa" style={{ padding: "20px" }}>
                <p className="grey-text">
                    {uploadPopup === "daa"
                        ? "To start using DAA, upload your portfolios"
                        : "To start using DAA, upload ISRC"}
                </p>
                {/* <label></label> */}
                <input
                    type="month"
                    id="date"
                    name="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    style={{ marginBottom: "10px" }}
                />
                <input type="file" name="file" onChange={changeHandler} />
            </div>
            <DialogActions>
                <div className="btn-group w-100 d-flex justify-content-end">
                    <AdornedButton
                        onClick={handleSubmission}
                        className="save-btn m-1"
                        loading={loading}
                        variant="outlined"
                        size="small"
                    >
                        {" "}
                        Upload
                    </AdornedButton>
                </div>
            </DialogActions>
        </Dialog>
    );
}
