import React, { useState } from "react";
import Typography from "@mui/material/Typography";
import { AdornedButton, FTIconButton } from "common/FTButtons";
import Api from "utils/api";
import errorNotification from "utils/api-error";
import CloseIcon from "@mui/icons-material/Close";
import { RenderOption } from "../saa/SAAInput";
import { styles } from "./DAAGraphs";
import { parentChildMappingCols1, parentChildMappingCols2, benchmarkMappingCfg } from "../utils/aa-cfg";
import { sortList } from "../utils/aa-helper";
import PortfolioSearch from "./PortfolioSearch";
import SearchInput from "common/SearchInput";
import Mapping from "./Mapping";
import ModeEditIcon from "@mui/icons-material/ModeEdit";
import { squareBtnStyle } from "./daa-helper";
import { hasAccess } from "../utils/aa-helper";

const iconStyle = { fontSize: "1.2rem", color: "grey", cursor: "pointer", marginBottom: "4px" };
const tablePortfoliosStyles = {
    height: "25px",
    border: " 1px solid rgb(217 207 207)",
    borderRadius: "5px",
    padding: "2px 18px 2px 4px",
    fontSize: 13,
    borderColor: "rgb(217 207 207)",
};
const tableInputStyles = {
    height: "25px",
};

export default function ParentChildMapping({
    app,
    zone,
    selectedMapping,
    userInfo,
    portfolioList,
    saaSharedObjList,
    refreshDaaData,
    changeParentChildMapping,
    appSettings,
    benchmarkMappingList,
    deleteOption,
    daaPfs,
}) {
    const [mappingName, setMappingName] = useState(selectedMapping?.selectedMapping?._meta);
    const [rows, setRows] = useState<any>([]);
    const [loading, setLoading] = useState(false);
    const [benchmarkMapping, setBenchmarkMapping] = useState<any>({ open: false });

    function updatePortfolioInTable(portfolioId, addOrUpdate, updateRowIdx = -1) {
        if (!portfolioId) {
            return;
        }
        const portfolioObj = portfolioList?.find((f) => f.id == portfolioId);
        setRows((rows) => {
            const newRows = [...rows];
            if (addOrUpdate === "add") {
                const newRow = {
                    portfolios: portfolioObj?.id,
                    benchmark: "",
                    currency: portfolioObj?.base_currency,
                    description: portfolioObj?.label,
                };
                parentChildMappingCols2.forEach((col) => {
                    newRow[col.name] = { min: 0, max: 100 };
                });
                newRows.push(newRow);
            } else {
                const newRow = {
                    portfolios: portfolioObj?.id,
                    benchmark: "",
                    currency: portfolioObj?.base_currency,
                    description: portfolioObj?.label,
                };
                newRows[updateRowIdx] = {
                    ...newRows[updateRowIdx],
                    ...newRow,
                };
            }
            return newRows;
        });
    }

    async function handleSave() {
        try {
            setLoading(true);
            const payload = {
                name: mappingName?.Name + "_daa_portfolios_mapping",
                Name: mappingName?.Name,
                type: "daa_portfolios_mapping",
                portfolios: rows.slice().map((row) => {
                    delete row?.saaInfo;
                    return {
                        ...row,
                        saa: row?.saa?._id?.$oid || row.saa,
                    };
                }),
            };
            let response;
            if (!mappingName?._id?.$oid) {
                response = await Api.createSharedState(app, zone, payload);
            } else {
                response = await Api.updateSharedState(mappingName?._id?.$oid, payload);
            }
            if (response.status === "ok") {
                const selected = response?.["shared-object"];
                let author = "";
                if (selected["author"] && selected["author-id"] != userInfo["uuid"]) {
                    author = selected["author"];
                }
                const info = {
                    key: selected._id?.$oid,
                    id: selected._id?.$oid,
                    label: selected.Name,
                    author,
                    _meta: { ...selected },
                };
                changeParentChildMapping(info);
            }
            if (response?.message) {
                errorNotification.next({ type: "success", text: response.message, open: true });
                refreshDaaData();
            }
            setLoading(false);
        } catch (err) {
            console.error(err);
            setLoading(false);
        }
    }

    const getSaaBM = (id) => saaSharedObjList?.benchmarkList?.find((bm) => bm.id == id);
    const getDaaBM = (id, pfId) => {
        if (id) {
            return benchmarkMappingList?.find((bm) => bm.id == id);
        }
        return { portfolio: pfId };
    };

    function saaOnChange(v, rowIdx) {
        setRows((rows) => {
            const newRows = rows.slice();
            newRows[rowIdx].saa = v?.id;
            newRows[rowIdx].saaInfo = v;
            newRows[rowIdx].benchmark = v?.benchmark;
            return newRows;
        });
    }

    React.useEffect(() => {
        const pfs = mappingName?.portfolios || [];
        if (pfs?.length > 0) {
            setRows(
                pfs?.map((p) => ({
                    ...p,
                    saaInfo: saaSharedObjList?.templateList?.find((t) => t.id == p?.saa),
                }))
            );
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [mappingName]);

    const isAuthorized = !selectedMapping?.selectedMapping?._meta || (mappingName && hasAccess(mappingName));

    const rowIconStyle = { ...squareBtnStyle, padding: "2px", width: "27px", marginLeft: "2px", marginTop: "-2px" };
    return (
        <div className="saa daa-graph" style={{ padding: "10px" }}>
            <Typography variant="h6">Parent/Child Mapping</Typography>
            {benchmarkMapping?.open && (
                <Mapping
                    app={app}
                    zone={zone}
                    appSettings={appSettings}
                    mappingInfo={benchmarkMapping}
                    setMappingInfo={setBenchmarkMapping}
                    daaSharedObjList={benchmarkMappingList || []}
                    refreshDaaData={refreshDaaData}
                    deleteOption={deleteOption}
                    daaPfs={daaPfs}
                    mappingConfig={benchmarkMappingCfg}
                />
            )}

            <div className="w-100 d-flex">
                <div className="temp-input-grp" style={{ width: "45%" }}>
                    <div className="input-label" style={{ width: "35%" }}>
                        Suite Template Name
                    </div>
                    <div className="input-field" style={{ width: "65%" }}>
                        <input
                            value={mappingName?.Name}
                            onChange={(e) => {
                                setMappingName((mappingName) => ({ ...mappingName, Name: e.target.value }));
                            }}
                        />
                    </div>
                </div>
                <div className="temp-input-grp2">
                    <div className="input-label" style={{ width: "35%" }}>
                        Created by
                    </div>
                    <div className="label-value capitalize" style={{ width: "65%" }}>
                        {selectedMapping?.author ? selectedMapping?.author : userInfo?.name}
                    </div>
                </div>
            </div>
            <div style={{ display: "flex" }}>
                <div style={{ minWidth: "800px" }}></div>
                <div className="top-grey-text-for-table ">Asset Level Constraints</div>
            </div>
            <div className="table-container" id="parent-child-mapping-table" style={{ flexDirection: "column" }}>
                <div className="saa-tb1" style={{ display: "flex" }}>
                    <div className="first-group-table" style={{ minWidth: "550px" }}>
                        <></>
                        <table>
                            <thead>
                                <tr>
                                    {parentChildMappingCols1.map((col: any, idx) => (
                                        <th key={idx} style={col.style}>
                                            <div>
                                                <span>{col.label}</span>
                                            </div>
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {rows.map((row, rowIdx) => (
                                    <tr key={rowIdx} className={row.className}>
                                        {parentChildMappingCols1.map((col: any, idx) => {
                                            if (col.name === "key") {
                                                return (
                                                    <td key={idx} style={col.style}>
                                                        {rowIdx + 1}&nbsp;
                                                    </td>
                                                );
                                            } else if (col.name === "del") {
                                                return (
                                                    <td key={idx} style={col.style}>
                                                        <CloseIcon
                                                            style={iconStyle}
                                                            onClick={() => {
                                                                setRows((rows) => {
                                                                    const newRows = [...rows];
                                                                    newRows.splice(rowIdx, 1);
                                                                    return newRows;
                                                                });
                                                            }}
                                                        />
                                                    </td>
                                                );
                                            } else if (col.name === "parent") {
                                                return (
                                                    <td key={idx} style={col.style}>
                                                        <input
                                                            type="radio"
                                                            name="parent"
                                                            checked={rows[rowIdx]?.isParent}
                                                            onChange={() => {
                                                                setRows((initialRows) => {
                                                                    const newRows = initialRows
                                                                        .slice()
                                                                        .map((r) => ({ ...r, isParent: false }));
                                                                    newRows[rowIdx].isParent = true;
                                                                    return newRows;
                                                                });
                                                            }}
                                                        />
                                                    </td>
                                                );
                                            } else if (col.name === "portfolios") {
                                                return (
                                                    <td key={idx}>
                                                        <PortfolioSearch
                                                            portfolioList={portfolioList}
                                                            value={row.portfolios}
                                                            handleChange={(_, val) => {
                                                                updatePortfolioInTable(val, "update", rowIdx);
                                                            }}
                                                            inputStyles={tablePortfoliosStyles}
                                                        />
                                                    </td>
                                                );
                                            } else if (col.name === "benchmark") {
                                                let bmInfo: any = null;
                                                if (row?.saaInfo?.benchmark) {
                                                    bmInfo = getSaaBM(row?.saaInfo?.benchmark);
                                                }
                                                if (row?.saaInfo && bmInfo) {
                                                    return (
                                                        <td key={idx} style={col.style}>
                                                            {bmInfo?.label}&nbsp;
                                                        </td>
                                                    );
                                                }

                                                const pfBenchmarks = benchmarkMappingList?.filter(
                                                    (ele) => ele?._meta?.portfolio == row?.portfolios
                                                );

                                                return (
                                                    <td key={idx}>
                                                        <div className="input-field" style={{ width: "100%" }}>
                                                            <SearchInput
                                                                onChange={(_, v) => {
                                                                    setRows((rows) => {
                                                                        const newRows = rows.slice();
                                                                        newRows[rowIdx].benchmark = v.id;
                                                                        return newRows;
                                                                    });
                                                                }}
                                                                onInputChange={(event, newInputValue, reason) => {
                                                                    if (reason === "clear") {
                                                                        setRows((rows) => {
                                                                            const newRows = rows.slice();
                                                                            newRows[rowIdx].benchmark = "";
                                                                            return newRows;
                                                                        });
                                                                    }
                                                                }}
                                                                options={sortList(pfBenchmarks)}
                                                                value={pfBenchmarks?.find(
                                                                    (bm) => bm.id == row?.benchmark
                                                                )}
                                                                placeholder="Benchmark Mapping.."
                                                                inputPropsStyle={{
                                                                    ...styles,
                                                                    minWidth: "50px",
                                                                    height: "25px",
                                                                    marginBottom: 0,
                                                                }}
                                                                disableUnderline={true}
                                                                forcePopupIcon={true}
                                                                popperWidth="300px"
                                                                searchIcon={false}
                                                                renderOption={(props, option) =>
                                                                    RenderOption(props, option, null)
                                                                }
                                                            />
                                                            <FTIconButton
                                                                handler={() => {
                                                                    setBenchmarkMapping((m) => ({
                                                                        ...m,
                                                                        open: true,
                                                                        selectedMapping: getDaaBM(
                                                                            row.benchmark,
                                                                            row?.portfolios
                                                                        ),
                                                                    }));
                                                                }}
                                                                title="Edit"
                                                                btnIcon={
                                                                    <ModeEditIcon
                                                                        style={{ fontSize: "1rem", color: "grey" }}
                                                                        color="primary"
                                                                    />
                                                                }
                                                                placement="top"
                                                                style={rowIconStyle}
                                                            />
                                                        </div>
                                                    </td>
                                                );
                                            } else if (col.name === "saa") {
                                                return (
                                                    <td key={idx}>
                                                        <SearchInput
                                                            onChange={(_, v) => saaOnChange(v, rowIdx)}
                                                            onInputChange={(event, newInputValue, reason) => {
                                                                if (reason === "clear") {
                                                                    setRows((rows) => {
                                                                        const newRows = rows.slice();
                                                                        newRows[rowIdx].saa = "";
                                                                        newRows[rowIdx].benchmark = "";
                                                                        newRows[rowIdx].saaInfo = null;
                                                                        return newRows;
                                                                    });
                                                                }
                                                            }}
                                                            options={sortList(saaSharedObjList?.templateList)}
                                                            value={saaSharedObjList?.templateList?.find(
                                                                (t) => t.id == row.saa
                                                            )}
                                                            placeholder="Template Name.."
                                                            inputPropsStyle={{
                                                                ...styles,
                                                                minWidth: "50px",
                                                                height: "25px",
                                                                marginBottom: 0,
                                                            }}
                                                            disableUnderline={true}
                                                            forcePopupIcon={true}
                                                            popperWidth="300px"
                                                            searchIcon={false}
                                                            renderOption={(props, option) =>
                                                                RenderOption(props, option, null)
                                                            }
                                                        />
                                                    </td>
                                                );
                                            } else if (col.name === "trackingError") {
                                                return (
                                                    <td key={idx} className="saa-input">
                                                        <input
                                                            type="text"
                                                            value={row.trackingError}
                                                            onChange={(e) => {
                                                                setRows((initialRows) => {
                                                                    const newRows = [...initialRows];
                                                                    newRows[rowIdx].trackingError = e.target.value;
                                                                    return newRows;
                                                                });
                                                            }}
                                                            style={tableInputStyles}
                                                        />
                                                        %
                                                    </td>
                                                );
                                            } else {
                                                return (
                                                    <td key={idx} style={col.style}>
                                                        {row[col.name]}&nbsp;
                                                    </td>
                                                );
                                            }
                                        })}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    {parentChildMappingCols2.map((col) => (
                        <div key={col.name} className="ft-saa-cwt">
                            <div className="saa-2">
                                <div className="saa-cwt">
                                    <div className="saa-h4" style={{ ...col.headerStyle, height: "19px" }}>
                                        {col.label}
                                    </div>
                                </div>
                            </div>
                            <table>
                                <thead>
                                    <tr style={{ borderBottom: "1px solid #E5E5E5" }}>
                                        <th>
                                            <div style={{ width: "60px", borderWidth: "0" }}>
                                                <span style={{ width: "80%", textAlign: "right" }}>Min%</span>
                                            </div>
                                        </th>
                                        <th style={{ width: "10px" }}>
                                            <div style={{ border: "none" }}>
                                                <span style={{ textAlign: "right", width: "45%" }}>--</span>
                                            </div>
                                        </th>
                                        <th>
                                            <div style={{ border: "none" }}>
                                                <span>Max%</span>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {rows.map((row, rowIdx) => {
                                        return (
                                            <tr key={row.key}>
                                                <td className="saa-input">
                                                    <input
                                                        type="text"
                                                        value={row?.[col.name]?.min || 0}
                                                        onChange={(e) => {
                                                            setRows((initialRows) => {
                                                                const newRows = [...initialRows];
                                                                if (!newRows[rowIdx][col.name]) {
                                                                    newRows[rowIdx][col.name] = {};
                                                                }
                                                                newRows[rowIdx][col.name].min = Number(e.target.value);
                                                                return newRows;
                                                            });
                                                        }}
                                                        style={tableInputStyles}
                                                    />
                                                    %
                                                </td>
                                                <td style={{ width: "10px" }}>
                                                    <div style={{ textAlign: "center" }}>
                                                        <span>--</span>
                                                    </div>
                                                </td>
                                                <td className="saa-input">
                                                    <input
                                                        type="text"
                                                        value={row?.[col.name]?.max || 100}
                                                        onChange={(e) => {
                                                            setRows((initialRows) => {
                                                                const newRows = [...initialRows];
                                                                if (!newRows[rowIdx][col.name]) {
                                                                    newRows[rowIdx][col.name] = {};
                                                                }
                                                                newRows[rowIdx][col.name].max = e.target.value;
                                                                return newRows;
                                                            });
                                                        }}
                                                        style={tableInputStyles}
                                                    />
                                                    %
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    ))}
                </div>
            </div>
            <div style={{ width: "35%", marginTop: "5px" }}>
                <PortfolioSearch
                    portfolioList={portfolioList || []}
                    handleChange={(_, val) => {
                        updatePortfolioInTable(val, "add");
                    }}
                    value={null}
                />
            </div>
            <div id="saa-output-btn" className="d-flex w-100">
                {isAuthorized && (
                    <div className="btn-group" style={{ width: "100%" }}>
                        <AdornedButton
                            className="clear-btn m-1"
                            variant="outlined"
                            size="small"
                            onClick={() => {
                                setRows([]);
                            }}
                        >
                            Clear
                        </AdornedButton>
                        <AdornedButton
                            className="save-btn"
                            variant="outlined"
                            size="small"
                            disabled={
                                !rows.length ||
                                rows.findIndex((row) => row.isParent && row.saa) === -1 ||
                                !mappingName?.Name
                            }
                            onClick={async () => {
                                handleSave();
                            }}
                            loading={loading}
                        >
                            Save
                        </AdornedButton>
                    </div>
                )}
            </div>
        </div>
    );
}
