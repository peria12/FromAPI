import React from "react";
import Paper from "@mui/material/Paper";
import { HChart } from "common/HChart";
import { numberVal } from "../utils/aa-helper";

function getSeries(pfIds, data) {
    return pfIds?.map((id) => {
        const info = data[id];
        return {
            x: numberVal(info?.total_risk),
            y: numberVal(info?.expected_return),
            name: id,
        };
    });
}

function getPoint(data = {}, key, name) {
    const info = data[key];
    return {
        x: numberVal(info?.total_risk),
        y: numberVal(info?.expected_return),
        name: name,
    };
}

function getOptions(data = {}, initialData = {}, portfolios) {
    if (!portfolios?.length && !Object.keys(data)?.length) {
        return { title: { text: "" } };
    }
    const defMarker = { enabled: true, radius: 4, lineWidth: 2, symbol: "circle" };
    const pfIds = portfolios?.map((e: any) => e?.portfolios);

    const seriesData: any = [
        {
            showInLegend: true,
            name: "Current",
            marker: { ...defMarker, fillColor: "#C5C5C5" },
            data: getSeries(pfIds, initialData),
            color: "#C5C5C5",
            dataLabels: {
                enabled: true,
                align: "right",
                format: '<span style="color:#C5C5C5">{point.name}</span>',
                style: { fontWeight: 400 },
            },
        },
        {
            showInLegend: true,
            name: "Proposed",
            marker: { ...defMarker, fillColor: "#AE5530" },
            data: getSeries(pfIds, data),
            color: "#CA663B",
            dataLabels: {
                enabled: true,
                align: "right",
                format: '<span style="color:#CA663B">{point.name}</span>',
                style: { fontWeight: 400 },
            },
        },
        {
            name: "SAA",
            showInLegend: false,
            marker: {
                ...defMarker,
                fillColor: "#FFF",
                lineColor: "#7C7C7C",
            },
            dataLabels: {
                enabled: true,
                align: "left",
                format: '<span style="color:#7C7C7C">{point.name}</span>',
            },
            data: [getPoint(data, "saaSolution", "SAA")],
        },
        {
            name: "ISRC",
            showInLegend: false,
            marker: {
                ...defMarker,
                fillColor: "#FFF",
                lineColor: "#2A2A2A",
            },
            dataLabels: {
                enabled: true,
                align: "left",
                format: '<span style="color:#2A2A2A">{point.name}</span>',
            },
            data: [getPoint(data, "isrc", "ISRC")],
        },
        {
            name: "BM",
            showInLegend: false,
            marker: {
                ...defMarker,
                fillColor: "#FFF",
                lineColor: "#FE9467",
            },
            dataLabels: {
                enabled: true,
                align: "left",
                format: '<span style="color:#FE9467">{point.name}</span>',
            },
            data: [getPoint(data, "bmProspectus", "BM")],
        },
    ];

    return {
        chart: { type: "line" },
        title: { text: "" },
        xAxis: {
            type: "linear",
            allowDecimals: true,
            tickAmount: 11,
            title: { text: "Expected Risk %" },
            labels: {
                overflow: "justify",
                format: "<b>{value}%</b>",
            },
        },
        yAxis: {
            gridLineWidth: 0,
            title: { text: "Expected Return %" },
            labels: { overflow: "justify", format: "<b>{value}%</b>" },
        },
        tooltip: {
            headerFormat: "<b>{series.name}</b><br />",
            pointFormat: "x = {point.x}, y = {point.y}",
        },
        plotOptions: {
            series: {
                pointStart: 0,
            },

            line: {
                enableMouseTracking: false,
            },
        },
        series: seriesData,
    };
}

export default function EfficientFrontier({ data, initialData, portfolios }) {
    const options: any = React.useMemo(
        () => getOptions(data, initialData, portfolios),
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [data]
    );
    return (
        <Paper
            className="saa-outputs"
            square
            elevation={5}
            style={{ width: "100%", overflow: "scroll", padding: "0px 8px" }}
        >
            <div
                className="card-header w-100"
                style={{
                    textAlign: "left",
                    marginBottom: 7,
                }}
            >
                Efficient Frontier
            </div>
            <HChart
                option={options}
                style={{
                    height: "100%",
                    width: "100%",
                    display: "flex",
                    alignItems: "center",
                    overflow: "hidden",
                }}
            />
        </Paper>
    );
}
