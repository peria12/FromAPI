import React, { useEffect, useState } from "react";
import { AdornedButton } from "common/FTButtons";
import SearchInput from "common/SearchInput";
import { sortList } from "../utils/aa-helper";
import DeleteIcon from "@mui/icons-material/Delete";
import Access from "utils/access";

import Api from "utils/api";
import errorNotification from "utils/api-error";
import { groupAsset, getAssetsWeights } from "./daa-helper";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import PortfolioSearch from "./PortfolioSearch";
import { mappingManager } from "./mapping";

const styles = {
    height: "30px",
    border: " 1px solid rgb(217 207 207)",
    borderRadius: "5px",
    padding: "2px 4px",
    fontSize: 13,
    borderColor: "rgb(217 207 207)",
};
export const authorStyle: any = { color: "#c5c5c5", textTransform: "capitalize", fontStyle: "italic", marginLeft: 1 };

const RenderOption = function (props, option, deleteOption) {
    return (
        <li {...props} key={option.id} style={{ fontSize: "14px" }}>
            <div style={{ display: "flex", width: "90%", justifyContent: "space-between" }}>
                <div className="col-12">
                    {option.label}
                    {option.author && <span style={authorStyle}>({option.author})</span>}
                </div>
                {typeof deleteOption === "function" && !option.author && (
                    <DeleteIcon
                        className="delete-icon"
                        style={{ color: "red", marginRight: "10px" }}
                        onClick={(e) => {
                            e.stopPropagation();
                            deleteOption(option);
                        }}
                    />
                )}
            </div>
        </li>
    );
};

function BootstrapDialogTitle(props: any) {
    const { children, onClose, ...other } = props;
    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: "absolute",
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
}
const defaultFormData = {
    name: { id: null, label: "" },
    portfolio: "",
};

export default function Mapping({
    app,
    zone,
    appSettings,
    mappingInfo,
    setMappingInfo,
    daaSharedObjList,
    refreshDaaData,
    deleteOption,
    daaPfs,
    mappingConfig,
}) {
    const [loader, setLoader] = useState<any>(false);
    const [formData, setFormData] = useState<any>({ ...defaultFormData });
    const [timeoutId, setTimeoutId] = useState<any>(null);

    const userInfo = Access.userInfo || {};
    const mappingAuthor = formData?.author;

    const { id, headers, offset, title, type } = mappingConfig;

    const mapping = mappingManager(id);

    const handleClose = () => {
        setMappingInfo({ ...mappingInfo, open: false });
    };

    const clrTimeout = () => {
        if (timeoutId) {
            clearTimeout(timeoutId);
        }
    };

    useEffect(() => {
        mapping.setHeaders(headers, offset);
    }, [mapping, headers, offset]);

    function initializeMapping(docId: any = null, mappingList: any = []) {
        const ms = !docId ? 500 : 0;
        let timeoutId: any = null;
        if (id == "benchmarkMapping") {
            const selectedMapping = mappingInfo?.selectedMapping || {};
            const mappingId = docId || selectedMapping?.id;
            if (mappingId) {
                timeoutId = setTimeout(() => onSelectChange(mappingId, mappingList), ms);
            } else if (selectedMapping?.portfolio) {
                timeoutId = setTimeout(() => onInputChange("portfolio", selectedMapping?.portfolio), ms);
            }
        } else {
            const assets = appSettings?.[id]?.assets || [];
            mapping.setList1(groupAsset(assets, "name"));

            const mappingId = docId || mappingInfo?.selectedMapping?.id;
            if (mappingId) {
                timeoutId = setTimeout(() => onSelectChange(mappingId, mappingList), ms);
            } else {
                timeoutId = setTimeout(() => mapping.loadMapping(), ms);
            }
        }
        if (timeoutId) {
            setTimeoutId(timeoutId);
        }
    }

    useEffect(() => {
        if (mappingInfo.open && !formData?.name?.id) {
            initializeMapping();
        } else if (!mappingInfo.open) {
            setFormData({ ...defaultFormData });
            if (id == "benchmarkMapping") {
                mapping.setList1([]);
            }
            mapping.setList2([]);
        }
        return clrTimeout;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [appSettings, mappingInfo]);

    function getValue(arr, value) {
        let info = arr?.find((f) => f.id == value);
        if (!info) {
            info = { id: "", label: "" };
        }
        return info;
    }

    function getInputValue(arr, value) {
        if (value.id) {
            return getValue(arr, value.id);
        }
        return value;
    }

    function getBenchmark(pfId) {
        const pfBenchmark = daaPfs?.find((pf) => pf?.id == pfId)?.benchmark || "";
        return pfBenchmark ? [{ id: pfBenchmark, benchmark: pfBenchmark }] : [];
    }

    const onSelectChange = (value, mappingList: any = []) => {
        let list = [...daaSharedObjList];
        if (mappingList?.length > 0) {
            list = mappingList;
        }
        const info = list?.find((e) => e?.id == value)?._meta;
        setFormData((fd) => ({
            ...fd,
            name: getValue(list, value),
            mappings: info?.mappings || [],
            portfolio: info?.portfolio,
            author: info?.author,
        }));
        const assets = appSettings?.portfolioMap?.[info?.portfolio]?.assets || [];
        if (id == "benchmarkMapping") {
            mapping.setList1(getBenchmark(info?.portfolio));
        }
        mapping.setList2(groupAsset(assets, "category"), false);
        mapping.setMappings(info?.mappings);
        mapping.loadMapping();
    };

    function onInputChange(field, value) {
        if (field == "portfolio") {
            const assets = appSettings?.portfolioMap?.[value]?.assets || [];
            if (id == "benchmarkMapping") {
                mapping.setList1(getBenchmark(value));
            }
            mapping.setList2(groupAsset(assets, "category"));
            mapping.loadMapping();
            setFormData((fd) => ({ ...fd, [field]: value }));
        } else if (field == "name") {
            setFormData((fd) => ({ ...fd, [field]: { id: null, label: value?.label || "" } }));
        }
    }

    async function onSave() {
        try {
            const mappingId = formData?.name?.id;
            const { mappings = {} } = mapping.getCurrentState();
            let response: any = null;
            const { name, portfolio } = formData;
            const mappingName = name?.label?.trim();
            const totalMappings = Object.keys(mappings)?.length;
            if (!mappingName) {
                errorNotification.next({
                    type: "error",
                    text: "Please select or create a mapping to proceed",
                    open: true,
                });
                return false;
            }
            if (!(totalMappings > 1)) {
                errorNotification.next({
                    type: "error",
                    text: "Please create at least one mapping to proceed ",
                    open: true,
                });
                return false;
            }
            if (!mapping?.getIsValidTotalWeight()) {
                errorNotification.next({
                    type: "error",
                    text: "Weight sum in each group must be 100%.",
                    open: true,
                });
                return false;
            }
            const payload = {
                Name: mappingName,
                name: mappingName + "-mapping",
                type: type,
                portfolio: portfolio,
                mappings: mappings,
            };
            if (id == "benchmarkMapping") {
                payload["assets"] = getAssetsWeights(mappings);
            }
            setLoader(true);
            if (!mappingId) {
                payload["access"] = { system: false, dept: false, users: [] };
                response = await Api.createSharedState(app, zone, payload);
            } else {
                response = await Api.updateSharedState(mappingId, payload);
            }
            if (response?.message) {
                errorNotification.next({ type: "success", text: response.message, open: true });
                refreshDaaData().then((sharedObj: any) => {
                    const { isrcMapping = [], benchmarkMapping = [], isrcBmMapping = [] }: any = sharedObj;
                    let list: any = [];
                    if (id == "isrc") {
                        list = isrcMapping;
                    } else if (id == "isrcBenchmark") {
                        list = isrcBmMapping;
                    } else if (id == "benchmarkMapping") {
                        list = benchmarkMapping;
                    }
                    const mappingId = response?.["shared-object"]?._id?.$oid;
                    setMappingInfo((info) => ({
                        ...info,
                        selectedMapping: response?.["shared-object"],
                    }));
                    initializeMapping(mappingId, list);
                });
            }
            setLoader(false);
        } catch (err) {
            console.error(err);
            setLoader(false);
        }
    }

    function isBtnDisabled() {
        const name = formData?.name?.label?.trim();
        const pf = formData?.portfolio;
        return name && pf;
    }

    return (
        <Dialog open={mappingInfo.open} onClose={handleClose} fullWidth={true} maxWidth="xl">
            <BootstrapDialogTitle id="customized-dialog-title" onClose={handleClose}>
                {title}
            </BootstrapDialogTitle>
            <DialogContent>
                <div className="saa">
                    <div id="daa-isrc-mapping" className="daa-mapping-container">
                        <div className="w-100 d-flex pt-2 daa">
                            <div className="input-grp">
                                <div className="input-label">Mapping Name</div>
                                <div className="input-field">
                                    <SearchInput
                                        onChange={(_, v) => onSelectChange(v?.id)}
                                        onInputChange={(e, v) => {
                                            if (e?.type === "change") {
                                                onInputChange("name", { label: v });
                                            }
                                        }}
                                        options={sortList(daaSharedObjList)}
                                        value={getInputValue(daaSharedObjList, formData?.name)}
                                        placeholder="Select ISRC Map"
                                        inputPropsStyle={styles}
                                        disableUnderline={true}
                                        forcePopupIcon={true}
                                        popperWidth="300px"
                                        searchIcon={false}
                                        renderOption={(props, option) => RenderOption(props, option, deleteOption)}
                                    />
                                </div>
                            </div>
                            <div className="temp-input-grp2">
                                <div className="input-label w-100">Created</div>
                                <div className="label-value capitalize" style={{ width: "100%" }}>
                                    {mappingAuthor ? mappingAuthor : userInfo?.name}
                                </div>
                            </div>
                        </div>
                        <div className="w-100 d-flex pt-2 daa">
                            <div className="input-grp">
                                <div className="input-label">Select Portfolio</div>
                                <div className="input-field">
                                    <PortfolioSearch
                                        portfolioList={daaPfs}
                                        value={formData?.portfolio}
                                        handleChange={(_, v) => onInputChange("portfolio", v)}
                                    />
                                </div>
                            </div>
                            <div className="temp-input-grp2">
                                <div className="input-label w-100">On</div>
                                <div className="label-value capitalize" style={{ width: "100%" }}>
                                    Wed Jul 5, 2023
                                </div>
                            </div>
                        </div>
                        <svg id="mapping-container" style={{ height: "140vh", width: "100%" }} />
                    </div>
                </div>
            </DialogContent>
            <DialogActions className="saa">
                <div className="btn-group btn-panel" style={{ width: "100%", padding: 2 }}>
                    <AdornedButton
                        className="save-btn"
                        variant="outlined"
                        size="small"
                        loading={loader}
                        disabled={!isBtnDisabled()}
                        onClick={onSave}
                    >
                        {" "}
                        Save{" "}
                    </AdornedButton>
                </div>
            </DialogActions>
        </Dialog>
    );
}
