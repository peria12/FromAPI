import { groupBy } from "utils/helpers";

const classColor = {
    Equity: "#3270FC",
    "Fixed Income": "#FD0F53",
    Alternatives: "#8F69F0",
    Cash: "#FD0F53",
};

const orderMap = {
    Equity: 1,
    "Fixed Income": 2,
    Alternatives: 3,
    Cash: 4,
};

export function groupAsset(list, field) {
    const types = Array.from(new Set(list?.map((e) => e?.class)));
    types.sort((a: any, b: any) => {
        const val1 = orderMap[a] || 100;
        const val2 = orderMap[b] || 100;
        return val1 - val2;
    });
    const groupData: any = groupBy(list, "class");
    let results: any = [];
    types?.forEach((type: any) => {
        if (groupData[type]) {
            const value = groupData[type];
            const color = classColor[type];
            results = [...results, { [field]: type, color, isGroupedRow: true }, ...value];
        }
    });
    return results;
}

export const transformAssets = (info, is_isrc = false) => {
    return info?.assets?.map((assetInfo) => {
        const obj: any = {};
        info?.asset_header.forEach((col, index) => {
            obj[col] = assetInfo[index];
        });
        const id = is_isrc ? generateIsrcId(obj) : generateAssetId(obj);
        obj.id = id;
        return obj;
    });
};

export const squareBtnStyle = {
    border: " 1px solid rgb(217 207 207)",
    borderRadius: 3,
    padding: "3px",
    width: "30px",
    marginLeft: 3,
};

export const generateIsrcId = (asset) => {
    const id = `${asset.class}||${asset.name || ""}||${asset.region || ""}`;
    return id?.toLowerCase()?.replaceAll(".", "");
};
export const generateAssetId = (asset) => {
    const id = `${asset.class}||${asset.category}||${asset.sub_category}||${asset.asset || ""}`;
    return id?.toLowerCase();
};

export const getAssetInfo = (str) => {
    const list = str?.split("||");
    return {
        class: list?.[0] || "",
        category: list?.[1] || "",
        sub_category: list?.[2] || "",
        asset: list?.[3] || "",
    };
};

export function getAssetsWeights(mappings = {}) {
    const assets: any = [];
    Object.keys(mappings)?.map((key) => {
        if (key?.startsWith("left_")) {
            const map = mappings[key] || {};
            Object.keys(map)?.map((k) => {
                const id = k.slice("right_".length);
                const asset: any = getAssetInfo(id);
                assets.push({
                    ...asset,
                    weight: map[k]?.[0],
                });
            });
            return false;
        }
        return true;
    });
    return assets;
}
