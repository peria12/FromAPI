/* eslint-disable */
import React, { useState, useEffect } from "react";
import AppCover from "home/dashboad/AppCover";
import Api from "utils/api";
import DAAGraphs from "./DAAGraphs";
// import { daaDefaultLayoutCfg, windowsCfgKeys } from "../utils/aa-cfg";
// import { useScreenshot } from "utils/helpers";
import { getSharedObjOptions } from "../utils/aa-helper";
import _ from "lodash";
import "../asset-allocation.scss";
import { AdornedButton } from "common/FTButtons";
import "../aa-winbox.scss";
import UploadPopup from "./UploadPopup";
import { getPreviousDayNY } from "utils/helpers";
import errorNotification from "utils/api-error";
import { transformAssets } from "./daa-helper";

export default function DAAContainer({ app, type }) {
    const [sharedObjList, setSharedObjList] = useState<any>([]);
    const [daaSharedObjList, setDaaSharedObjList] = useState({
        daaTemplates: [],
        isrcMapping: [],
        parentChildMapping: [],
        isrcBmMapping: [],
        benchmarkMapping: [],
    });
    const [uploadPopup, setUploadPopup] = useState<any>(null);
    const [appSettings, setAppSettings] = useState<any>({
        isrcBenchmark: null,
        isrc: null,
        portfolioMap: null,
        pfIds: [],
    });
    const [daaPfs, setDaaPfs] = useState([]);
    const [portfolioList, setPortfolioList] = useState([]);
    // const screenshot = useScreenshot();

    useEffect(() => {
        if (portfolioList?.length > 0 && appSettings?.pfIds?.length > 0) {
            const pfOptions: any = appSettings.pfIds.map((id) => {
                const pfInfo: any = portfolioList.find((e: any) => e?.id == id);
                return { id, label: pfInfo?.label || "", benchmark: pfInfo?.benchmark_name };
            });
            setDaaPfs(pfOptions);
        }
    }, [portfolioList, appSettings]);

    useEffect(() => {
        Api.getPortfoliosDal([getPreviousDayNY()])
            .then((resp) => {
                if (resp?.error) {
                    const errorInfo = {
                        type: "error",
                        text: `${resp?.error}`,
                        open: true,
                    };
                    errorNotification.next(errorInfo);
                }
                if (resp?.portfolio_list) {
                    const list = resp?.portfolio_list?.map((ele) => ({
                        id: ele?.port_ft_id,
                        entity_id: ele?.entity_id,
                        label: ele?.entity_name,
                        benchmark_name: ele?.benchmark_name,
                        base_currency: ele?.base_currency,
                    }));
                    setPortfolioList(list);
                }
            })
            .catch((e: any) => {
                console.log(e);
            });

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const errorInfo = { type: "error", text: `Unable to fetch settings`, open: true };
    const idPrefix = "daa_";
    async function loadZoneSettings() {
        await Api.getZoneSettings(app, type, false)
            .then((settings: any) => {
                if (!settings["daa_isrc"]) {
                    return errorNotification.next(errorInfo);
                }
                const portfolioMap = {};
                const pfIds: any = [];
                let isrc: any = null;
                let isrcBenchmark: any = null;
                Object.keys(settings).map((key) => {
                    key = key?.toLowerCase();
                    if (key?.startsWith(idPrefix)) {
                        const assetInfo = settings[key];
                        if (key == "daa_isrc") {
                            isrc = { id: key, assets: transformAssets(assetInfo, true), date: assetInfo.date };
                        } else if (key == "daa_isrc_benchmark") {
                            isrcBenchmark = { id: key, assets: transformAssets(assetInfo, true) };
                        } else {
                            const arr = key?.split(idPrefix);
                            if (arr?.[1]) {
                                key = arr?.[1];
                            }
                            portfolioMap[key] = { id: key, assets: transformAssets(assetInfo) };
                            pfIds.push(key);
                        }
                    }
                });
                setAppSettings((as) => ({ ...as, isrcBenchmark, isrc, portfolioMap, pfIds }));
            })
            .catch((err: any) => {
                console.error(err);
                errorNotification.next(errorInfo);
            });
    }

    useEffect(() => {
        loadZoneSettings();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        getSharedObjects();
        refreshDaaData();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [type, app]);

    function getSharedObjects() {
        return new Promise((resolve, reject) => {
            Api.getSharedState(app, "saa2")
                .then((response: any) => {
                    if (response.length > 0) {
                        const templateList = getSharedObjOptions(response, "template");
                        const benchmarkList = getSharedObjOptions(response, "benchmark");
                        setSharedObjList({ templateList, benchmarkList });
                    }
                    return resolve({});
                })
                .catch((err: any) => {
                    console.log(err);
                    reject();
                });
        });
    }

    function refreshDaaData() {
        loadZoneSettings();
        return new Promise((resolve, reject) => {
            Api.getSharedState(app, type)
                .then((response: any) => {
                    if (response.length > 0) {
                        const daaTemplates: any = getSharedObjOptions(response, "daa_template");
                        const isrcMapping: any = getSharedObjOptions(response, "isrcMapping");
                        const parentChildMapping: any = getSharedObjOptions(response, "daa_portfolios_mapping");
                        const isrcBmMapping: any = getSharedObjOptions(response, "isrcBenchmarkMapping");
                        const benchmarkMapping: any = getSharedObjOptions(response, "benchmarkMapping");
                        setDaaSharedObjList({
                            daaTemplates,
                            isrcMapping,
                            parentChildMapping,
                            isrcBmMapping,
                            benchmarkMapping,
                        });
                        return resolve({ isrcMapping, benchmarkMapping, isrcBmMapping });
                    }
                    return resolve({});
                })
                .catch((err: any) => {
                    console.log(err);
                    reject();
                });
        });
    }

    return (
        <AppCover
            header={
                <AdornedButton
                    variant="outlined"
                    size="small"
                    onClick={() => setUploadPopup("daa")}
                    loading={false}
                    style={{ padding: 0, margin: "0 10px 5px 0" }}
                >
                    Upload
                </AdornedButton>
            }
        >
            <div className="saa">
                <DAAGraphs
                    app={app}
                    type={type}
                    saaSharedObjList={sharedObjList}
                    appSettings={appSettings}
                    portfolioList={portfolioList}
                    setUploadPopup={setUploadPopup}
                    daaPfs={daaPfs}
                    refreshDaaData={refreshDaaData}
                    daaSharedObjList={daaSharedObjList}
                />
            </div>
            <UploadPopup uploadPopup={uploadPopup} setUploadPopup={setUploadPopup} />
        </AppCover>
    );
}
