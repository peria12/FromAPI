
import Access from "utils/access";

export const findAssetGroup = (e, r) => r.asset_type == e.asset_type && r.category == e.category && r.sub_category == e.sub_category && r.asset == e.asset;
const findAssetSolution = (entry, solution) => {
   const assetString= [entry.asset_type, entry.category, entry.sub_category, entry.asset].toString();
   return solution?.length && solution?.find(asset => asset.asset.toString() === assetString)?.holding;
}

export function updateRowValues(rows, astGroups, outputData) {
    return rows?.map((row) => {
        let min = 0, max = 100;
        let solution = 0;
        const entry = astGroups.find(ag => findAssetGroup(ag, row))
        if (entry) {
            min = entry.min
            max = entry.max
            solution = findAssetSolution(entry, outputData?.solution);
        }
        const updatedRow = { ...row, min, max, current: solution || "" }
        if (entry) {
            if ("return" in entry) {
                updatedRow["return"] = entry.return || ""
            }
            if ("risk" in entry) {
                updatedRow["risk"] = entry.risk || ""
            }
        }
        return updatedRow;
    });
}

export const numberVal = val => {
    if (val != undefined && val != null && val !== "") {
        val = Number(val).toFixed(2)
        return isNaN(val) ? null : Number(val)
    }
    return null;
}

export function getSharedObjOptions(list = [], key) {
    const userInfo = Access.userInfo || {};

    return list.filter(ele => ele.type == key).map(ele => {
        let author = ""
        if (ele["author"] && ele["author-id"] != userInfo["uuid"]) {
            author = ele["author"]
        }
        let info = { key: ele._id?.$oid, id: ele._id?.$oid, label: ele.Name, author, _meta: { ...ele } }
        if (key == "modelportfolio" || key == "benchmark") {
            info["assetGroups"] = ele.assetGroups
        } else if (key == "constraints") {
            info["constraints"] = ele.constraints
        } else if (key == "template") {
            info = { ...ele, ...info }
        }
        return info;
    })
}

export function hasAccess(info) {
    const userInfo = Access.userInfo || {};
    return info?.["author-id"] == userInfo?.["uuid"];
}

export function getAssetId(info) {
    const { asset_type, category, sub_category, asset } = info
    const idStr = `${asset_type || ""}${category || ""}${sub_category || ""}${asset || ""}`
    return idStr?.split(" ")?.join("_")
}

export function compareTemplate(input, origTemplate) {
    if (!origTemplate) {
        return true;
    }
    for (const key in input) {
        if (!origTemplate[key] || origTemplate[key] !== input[key]) {
            return true;
        }
    }
    return false;
}

export function compareAssets(modelAssets, currAssets) {
    if (modelAssets.length !== currAssets.length) {
        return true;
    }
    const currAssetsSet = new Set(currAssets.map(asset => asset.entity_id));
    return !modelAssets.every(modelAsset => currAssetsSet.has(modelAsset.entity_id));
}

export function updateConstraintList(constraint, list) {
    const constraintId = constraint?._id?.$oid;
    const index = list?.findIndex(con => con.id === constraintId);
    if (index >= 0) {
        list[index] = { id: constraint?._id?.$oid, label: constraint.Name, constraints: constraint.constraints, _meta: constraint };
    } else {
        list.push({ id: constraint?._id?.$oid, label: constraint.Name, constraints: constraint.constraints, _meta: constraint });
    }
    return list;
}

function sortByDate(a, b) {
    const key1 = new Date(a._meta?.update_date);
    const key2 = new Date(b._meta?.update_date);

    if (key1 < key2) {
        return 1;
    } else if (key1 == key2) {
        return 0;
    } else {
        return -1;
    }
}

export function sortList(options) {
    let res = [];
    if (!options) {
        return res;
    }
    const userOwns = [];
    const userNotOwns = [];
    options.forEach((option) => {
        if (hasAccess(option?._meta)) {
            userOwns.push(option);
        } else {
            userNotOwns.push(option);
        }
    });
    res = [...userOwns.sort(sortByDate), ...userNotOwns.sort(sortByDate)];
    return res;
}

export function removeKeys(obj = {}, list = []) {
    list.map((key) => {
        delete obj[key];
    });
    return obj;
}

export const percentPostfix = (value) => {
    if (typeof value === "number" && !Number.isNaN(value) && value !== undefined && value !== null) {
        return value + "%";
    }
    return "";
};
