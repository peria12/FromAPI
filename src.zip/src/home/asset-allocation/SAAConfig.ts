export const defaultReportInfo = {
    isLoading: false,
    btnLoading: false,
    isReportGenerated: false,
    reports: {},
};

export const tabs = [
    {
        id: "universe",
        label: "Universe",
        isDefault: true,
        elements: [
            {
                id: "universe",
                type: "table",
                width: "100%",
                columnWidth: "40%",
            },
        ],
    },
    {
        id: "returns",
        label: "Returns",
        elements: [
            {
                id: "rets",
                type: "table",
                width: "100%",
                columns: [
                    [
                        {
                            id: "MSCI USA",
                            colSpan: 4,
                        },
                        {
                            id: "Bbg US Agg",
                            colSpan: 4,
                        },
                    ],
                    [
                        {
                            id: "MSCI USA",
                            colSpan: 1,
                        },
                        {
                            id: "MSCI EAFE",
                            colSpan: 1,
                        },
                        {
                            id: "Bbg US Agg",
                            colSpan: 2,
                        },
                        {
                            id: "Bbg EM Hard Currency Agg",
                            colSpan: 3,
                        },
                    ],
                    [
                        {
                            id: "date",
                            percent: false,
                            type: "text",
                            width: "10%",
                        },
                        {
                            id: "MSCI USA",
                            width: "10%",
                            percent: true,
                            type: "text",
                            sortable: true,
                        },
                        {
                            id: "MSCI EAFE",
                            width: "10%",
                            percent: true,
                            type: "text",
                        },
                        {
                            id: "MSCI EM",
                            width: "10%",
                            percent: true,
                            type: "text",
                        },
                        {
                            id: "Bbg US Agg",
                            width: "10%",
                            percent: true,
                            type: "text",
                        },
                        {
                            id: "Bbg Multiverse x USD",
                            width: "10%",
                            percent: true,
                            type: "text",
                        },
                        {
                            id: "Bbg US Agg HY",
                            width: "10%",
                            percent: true,
                            type: "text",
                        },
                        {
                            id: "Bbg EM Hard Currency Agg",
                            width: "10%",
                            percent: true,
                            type: "text",
                        },
                    ],
                ],
            },
        ],
    },
    {
        id: "risk",
        label: "Risk",
        elements: [
            {
                id: "vols",
                title: "Volatility",
                width: "30%",
                type: "table",
                meta: {
                    outlinedColumns: true,
                },
            },
            {
                id: "corr",
                title: "Correlation",
                width: "100%",
                type: "table",
            },
        ],
    },
    {
        id: "cme",
        label: "CME",
        api: "cme",
        elements: [
            {
                id: "active_risk_targets",
                title: "Active Risk Targets",
                width: "30%",
                type: "input-table",
                accessKey: "cme_params.active_risk_targets",
                meta: {
                    outlinedColumns: true,
                },
                columns: [
                    {
                        id: "asset_class",
                        label: "Asset Class",
                        type: "text",
                    },
                    {
                        id: "value",
                        label: "Value",
                        percent: true,
                        type: "text",
                    },
                ],
                rows: [
                    {
                        id: "asset_class",
                        type: "label",
                    },
                    {
                        id: "value",
                        percent: true,
                        type: "number",
                        style: {
                            width: "130px",
                        },
                        suffix: "%",
                    },
                ],
            },
            {
                id: "submitBtn",
                type: "button",
                width: "100%",
                label: "Run",
                api: "/",
            },
            {
                id: "cme",
                title: "CME Target Portfolio",
                type: "table",
                width: "100%",
            },
            {
                id: "cme_analytics",
                title: "Summary Statistics",
                type: "table",
                width: "30%",
                gridType: "row",
            },
            {
                id: "cme_risk_decomp_by_asset_class",
                title: "Risk Decomposition By Asset Class",
                type: "table",
                width: "30%",
            },
            {
                id: "cme_risk_decomp_by_asset",
                title: "Risk Decomposition By Asset",
                type: "table",
                width: "40%",
            },
            {
                id: "cme_alpha_and_optimal_tilt",
                title: "CME, Alpha and Optimal Tilt",
                accessKey: "cme.data",
                type: "chart",
                width: "100%",
                xAxisFieldId: "asset_label",
                columns: [
                    {
                        id: "cme",
                        name: "CME",
                    },
                    {
                        id: "alpha",
                        name: "Alpha",
                    },
                    {
                        id: "optimal_tilt",
                        name: "Optimal",
                    },
                ],
            },
        ],
    },
    {
        id: "opt",
        label: "Optimization",
        api: "run_optimization",
        elements: [
            {
                id: "absolute_asset_bounds",
                title: "Absolute Asset Bounds",
                width: "55%",
                type: "input-table",
                accessKey: "opt_params.absolute_asset_bounds",
                columns: [
                    {
                        id: "asset",
                        label: "Asset",
                        percent: false,
                        type: "text",
                    },
                    {
                        id: "min",
                        label: "Min",
                        percent: true,
                        type: "text",
                    },
                    {
                        id: "max",
                        label: "Max",
                        percent: true,
                        type: "text",
                    },
                ],
                rows: [
                    {
                        id: "asset",
                        type: "label",
                    },
                    {
                        id: "min",
                        percent: true,
                        type: "number",
                        style: {
                            width: "100px",
                        },
                        suffix: "%",
                    },
                    {
                        id: "max",
                        percent: true,
                        type: "number",
                        style: {
                            width: "100px",
                        },
                        suffix: "%",
                    },
                ],
            },
            {
                id: "threshold_pos_size",
                type: "field-group",
                width: "55%",
                title: "Threshold Position Size",
                accessKey: "opt_params.threshold_pos_size",
                fields: [
                    {
                        id: "min",
                        type: "number",
                        validationType: "numeric",
                        suffix: "%",
                    },
                ],
            },
            {
                id: "te_frontier",
                type: "field-group",
                width: "55%",
                title: "Max Tracking Error vs. Benchmark",
                accessKey: "opt_params.te_frontier",
                fields: [
                    {
                        id: "start_value",
                        type: "number",
                        validationType: "numeric",
                        label: "Start",
                        suffix: "%",
                    },
                    {
                        id: "end_value",
                        type: "number",
                        validationType: "numeric",
                        label: "Stop",
                        suffix: "%",
                    },
                    {
                        id: "num_points",
                        type: "number",
                        validationType: "numeric",
                        label: "Points",
                    },
                ],
            },
            {
                type: "button",
                label: "Run Optimization",
                api: "run_optimization",
            },
            {
                id: "download-btn-groups",
                type: "button-groups",
                buttons: [
                    {
                        id: "download_wsp",
                        type: "download-button",
                        width: "20%",
                        accessKey: "workspace_file",
                        label: "Download WSP",
                    },
                    {
                        id: "download_excel_report",
                        type: "download-button",
                        width: "20%",
                        accessKey: "optimization_report_file",
                        label: "Download Excel Report",
                    },
                ],
            },
            {
                id: "opt_frontier",
                title: "Portfolio Weights",
                type: "table",
                width: "100%",
            },
            {
                id: "opt_analytics",
                title: "Summary Statistics",
                type: "table",
                width: "100%",
            },
            {
                id: "opt_risk_decomp_by_asset_class",
                title: "Risk Decomposition",
                accessKey: "opt_risk_decomps.by_asset_class",
                type: "table",
                width: "100%",
            },
            {
                id: "opt_risk_decomp_by_asset_class_vs_bench",
                title: "Active Risk Decomposition vs. Benchmark",
                accessKey: "opt_risk_decomps.by_asset_class_vs_bench",
                type: "table",
                width: "100%",
            },
            {
                id: "opt_risk_decomp_by_asset_class_vs_target",
                title: "Active Risk Decomposition vs. Target",
                accessKey: "opt_risk_decomps.by_asset_class_vs_target",
                type: "table",
                width: "100%",
            },
            {
                id: "opt_risk_decomp_by_asset",
                title: "Risk Decomposition",
                accessKey: "opt_risk_decomps.by_asset",
                type: "table",
                width: "100%",
            },
            {
                id: "opt_risk_decomp_by_asset_vs_bench",
                title: "Active Risk Decomposition vs. Benchmark",
                accessKey: "opt_risk_decomps.by_asset_vs_bench",
                type: "table",
                width: "100%",
            },
            {
                id: "opt_risk_decomp_by_asset_vs_target",
                title: "Active Risk Decomposition vs. Target",
                accessKey: "opt_risk_decomps.by_asset_vs_target",
                type: "table",
                width: "100%",
            },
        ],
    },
];
