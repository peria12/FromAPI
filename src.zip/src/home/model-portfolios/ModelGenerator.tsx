import React, { useEffect, useState, useMemo, useCallback, useRef } from "react";

import { ColDef, SelectionChangedEvent } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import Modal from "react-bootstrap/Modal";
import { downloadFile, useScreenshot } from "utils/helpers";
import AppCover from "home/dashboad/AppCover";
import Api from "utils/api";
import { unique } from "utils/helpers";
import { AdornedButton } from "common/FTButtons";
import errorNotification from "utils/api-error";
import ErrorModal from "./errorModal";
import SearchBox from "common/SearchBox";
import Button from "react-bootstrap/Button";
import InputGroup from "react-bootstrap/InputGroup";
import Form from "react-bootstrap/Form";
import { Link } from "react-router-dom";
import OverlayTrigger from "react-bootstrap/OverlayTrigger";
import Popover from "react-bootstrap/Popover";
import Access from "utils/access";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";

import "./model-portfolios.scss";

const DownloadLInk = (props) => {
    const download = () => {
        Api.getFileRaw(props.data.s3_file_path)
            .then(downloadFile)
            .catch((e: any) => {
                console.log("error", e);
                errorNotification.next({
                    type: "error",
                    text: "Failed to download file",
                    open: true,
                });
            });
    };

    if (props.data) {
        return <Link onClick={download}>Click to Download</Link>;
    }
    return "";
};

function ViewStatusPayload(props) {
    const response = props.data ? props.data.response : "";
    return (
        <>
            <OverlayTrigger
                trigger="click"
                rootClose
                key={"top"}
                placement={"top"}
                overlay={
                    <Popover id={`popover-positioned-top}`}>
                        <textarea style={{ width: "300px", height: "200px", padding: "10px" }} name="awesome">
                            {JSON.stringify(response)}
                        </textarea>
                    </Popover>
                }
            >
                <a href="#">{props.data.status}</a>
            </OverlayTrigger>
        </>
    );
}

function ViewPayload(props) {
    const payload = props.data ? props.data.payload : "";
    console.log(JSON.stringify(payload));
    return (
        <>
            <OverlayTrigger
                trigger="click"
                rootClose
                key={"top"}
                placement={"top"}
                overlay={
                    <Popover id={`popover-positioned-top}`}>
                        <textarea style={{ width: "300px", height: "200px", padding: "10px" }} name="awesome">
                            {JSON.stringify(payload)}
                        </textarea>
                    </Popover>
                }
            >
                <a href="#">Click to View Payload</a>
            </OverlayTrigger>
        </>
    );
}

export default function ModelGenerator() {
    const gridRef = useRef<AgGridReact>(null);
    const [loadingDownload, setLoadingDownload] = useState<boolean>(false);
    const [loading, setLoading] = useState<boolean>(false);
    const [showGenerateModal, setShowGenerateModal] = useState<boolean>(false);
    const [showReBalanceModal, setShowReBalanceModal] = useState<boolean>(false);
    const [showMessageModal, setShowMessageModal] = useState<boolean>(false);
    const [modalMessage, setModalMessage] = useState<string[]>([]);
    const [rebalanceIDs, setRebalanceIDs] = useState<string[]>([]);
    const [selectedMorgan, setSelectedMorgan] = useState<boolean>(false);
    const [isTransmit, setIsTransmit] = useState<boolean>(false);
    const [colDefs, setColDefs] = useState<any[]>([]);
    const [activeTab, setActiveTab] = useState("modelGenerator");
    const [modelGeneratorView, setModelGeneratorView] = useState("clientView");
    const [errors, setErrors] = useState<any>([]);
    const [rowData, setRowData] = useState<any[]>([]);
    const [audiTrailData, setAuditTrailData] = useState<any[]>([]);
    const [selectedNodes, setSelectedNodes] = useState<any[]>([]);
    const [openDialog, setOpenDialog] = useState(false);
    const [popupErr, setPopupErr] = useState<any>([]);
    const [searchText, setSearchText] = useState<any>(undefined);
    const [generateComments, setGenerateComments] = useState<any>("");
    const [preClearanceCheck, setPreClearanceCheck] = useState<boolean>(false);
    const containerStyle = useMemo(() => ({ width: "100%", height: "calc(100vh - 198px)" }), []);
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const screenshot = useScreenshot();
    const rebalanceColDef = [
        {
            headerName: "Onetis ID",
            field: "name",
            width: 250,
        },
        {
            headerName: "Allow Drift",
            field: "selected ",
            editable: true,
            checkboxSelection: true,
            width: 150,
        },
    ];
    const [rebalanceRowData, setRebalanceRowData] = useState<any>([]);

    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
            minWidth: 200,
            resizable: true,
            headerCheckboxSelection: false,
            // allow every column to be aggregated
            enableValue: true,
            // allow every column to be grouped
            enableRowGroup: true,
            // allow every column to be pivoted
            enablePivot: true,
            sortable: true,
            filter: true,
            rowSelection: "multiple",
            groupSelectsChildren: true,
            suppressRowClickSelection: true,
            suppressAggFuncInHeader: true,
        };
    }, []);

    const autoGroupColumnDef = useMemo<ColDef>(() => {
        return {
            headerName: "Client Name",
            field: "modelIdInfo",
            minWidth: 250,
            cellRenderer: "agGroupCellRenderer",

            cellRendererParams: {
                checkbox: true,
            },
        };
    }, []);

    useEffect(() => {
        if (gridRef && gridRef.current && gridRef.current.api) {
            gridRef.current.api.setQuickFilter(searchText);
        }
    }, [searchText]);

    const setClientView = useCallback(() => {
        if (gridRef && gridRef.current && gridRef.current.api) {
            gridRef.current.columnApi.setRowGroupColumns(["client", "name"]);
            autoGroupColumnDef.headerName = "Client Name";
            gridRef.current.api.setAutoGroupColumnDef(autoGroupColumnDef);
            setModelGeneratorView("clientView");
        }
    }, [autoGroupColumnDef]);

    const setModelView = useCallback(() => {
        if (gridRef && gridRef.current && gridRef.current.api) {
            gridRef.current.columnApi.setRowGroupColumns(["name", "client"]);
            autoGroupColumnDef.headerName = "Model Name";
            gridRef.current.api.setAutoGroupColumnDef(autoGroupColumnDef);
            setModelGeneratorView("modelView");
        }
    }, [autoGroupColumnDef]);

    const handleReBalanceModalClose = () => {
        setShowReBalanceModal(false);
        setShowGenerateModal(true);
    };

    const handleModalClose = () => {
        setShowGenerateModal(false);
        setGenerateComments("");
    };

    const handleReBalance = (transmit) => {
        const modelRequestMap = {};
        setIsTransmit(transmit);
        const getMorgan = selectedNodes.filter((item: any) => item.data.client === "morgan stanley");
        if (!getMorgan.length) {
            return handleReBalanceModalClose();
        }
        selectedNodes.forEach((node) => {
            const data = node.data;
            if (!modelRequestMap[data.name]) {
                modelRequestMap[data.name] = {
                    macroName: data.name,
                    ticker_mappings: data.ticker_mappings,
                    type: data.type,
                    outputs_info: { [data.client]: [data.outputs_info] },
                    name_mappings: data.name_mappings,
                };
            } else {
                const clientOutputMap = modelRequestMap[data.name].outputs_info;
                if (!clientOutputMap[data.client]) {
                    clientOutputMap[data.client] = [];
                }
                clientOutputMap[data.client].push(data.outputs_info);
                modelRequestMap[data.name].output_info = clientOutputMap;
            }
        });

        const findMorgan: any = Object.values(modelRequestMap).filter(
            (item: any) => item.outputs_info["morgan stanley"]
        );
        const oneTis_IDs: string[] = [];
        findMorgan.map((item) => item.outputs_info["morgan stanley"].map((item2) => oneTis_IDs.push(item2.id)));

        transmit ? setLoading(true) : setLoadingDownload(true);
        if (findMorgan.length) {
            Api.getRebalanceIds({ onetis_ids: oneTis_IDs })
                .then((response: any) => {
                    const modifyResponse = response.onetid_ids.map((item) => {
                        const getName = rowData.find((item2) => item2.onetisid === item);
                        return {
                            id: item,
                            name: getName.modelIdInfo,
                            isSelected: false,
                        };
                    });
                    setRebalanceRowData(modifyResponse);
                    setLoading(false);
                    setLoadingDownload(false);
                    setShowReBalanceModal(true);
                })
                .catch(() => {
                    setLoading(false);
                    setLoadingDownload(false);
                });
        }
    };

    useEffect(() => {
        Api.getModalReportData().then((response: any) => {
            if (response) {
                const compareFn = (a, b) =>
                    `${a.type_ui || ""}.${a.name}`.localeCompare(`${b.type_ui || ""}.${b.name}`);
                const models = response["model-portfolios"].sort(compareFn).map((x) => ({ ...x, open: false }));
                models.forEach(
                    (m) =>
                        (m.unique_ids = unique(
                            Object.values(m.output_info)
                                .flatMap((x) => x)
                                .map((x: any) => x.id)
                        ))
                );

                const rowData: any = [];
                const colDefs: any = [];

                colDefs.push({
                    headerName: "Model Name",
                    field: "name",
                    rowGroup: true,
                    rowGroupIndex: 1,
                });
                colDefs.push({ headerName: "Type", field: "type" });
                colDefs.push({
                    headerName: "Client",
                    field: "client",
                    rowGroup: true,
                    rowGroupIndex: 0,
                });

                colDefs.push({
                    headerName: "Error",
                    field: "errorMsg",
                    cellStyle: { color: "red" },
                });

                response["model-portfolios"].forEach((model) => {
                    Object.keys(model.output_info).forEach((client) => {
                        model.output_info[client].forEach((modelIdInfo: any) => {
                            if (modelIdInfo && (modelIdInfo != null || modelIdInfo != undefined)) {
                                let modelInfo;
                                if (modelIdInfo["id"]) {
                                    modelInfo = `${modelIdInfo["id"]} (${response["id-map"][modelIdInfo["id"]]})`;
                                }

                                const rowDataMap: any = {
                                    name: model.name,
                                    type: model.type,
                                    client: client,
                                    modelIdInfo: modelInfo,
                                    outputs_info: modelIdInfo,
                                    onetisid: modelIdInfo["id"],
                                    ticker_mappings: model.ticker_mappings,
                                    name_mappings: model.name_mappings,
                                };

                                rowData.push(rowDataMap);
                            }
                        });
                    });
                });

                setColDefs(colDefs);
                setRowData(rowData);
            }
        });

        Api.getModalPortfolioAuditData()
            .then((response: any) => {
                console.log(response);
                const auditData = JSON.parse(response["audit-records"]);
                setAuditTrailData(auditData);
            })
            .catch((error: any) => {
                console.log(error);
            });
    }, []);

    useEffect(() => {
        screenshot.take();
    }, [screenshot]);

    useEffect(() => {
        const errorMap = {};
        const genericErrors = [] as any[]
        errors.forEach((errorList) => {
            if (errorList && errorList.error) {
                errorList.error.forEach((err) => {
                    if (err) {
                        const onetisid = err[0];
                        const errorMsg = err[1];
                        errorMap[onetisid] = { errorMsg: errorMsg, model: errorList.model, output: errorList.output };
                    }
                });
            } else if (errorList) {
                genericErrors.push(errorList)
            }
        });

        if (genericErrors.length) {
            setShowMessageModal(true);
            setModalMessage(genericErrors)
        }

        const newRowData = rowData.map((data) => {
            const x = { ...data, errorMsg: "" };
            const obj = errorMap[data.onetisid];
            if (obj && obj.output == data.client && obj.model == data.name) {
                x.errorMsg = obj.errorMsg;
            }
            return x;
        });

        if (gridRef && gridRef.current && gridRef.current.api) {
            gridRef.current.api.forEachLeafNode((node) => {
                const data = node.data;
                if (
                    errorMap[data.onetisid] &&
                    errorMap[data.onetisid].output === data.client &&
                    errorMap[data.onetisid].model === data.name
                ) {
                    data.errorMsg = errorMap[data.onetisid].errorMsg;
                    node.parent?.setExpanded(true);
                }
            });
            setRowData(newRowData);
            gridRef.current.api.sizeColumnsToFit();
        }
        //eslint-disable-next-line react-hooks/exhaustive-deps
    }, [errors, gridRef, colDefs]);

    const onSelectionChanged = useCallback((event: SelectionChangedEvent) => {
        setSelectedNodes(event.api.getSelectedNodes());
    }, []);

    const onRebalnceSelectionChanged = useCallback((event: SelectionChangedEvent) => {
        const test = event.api.getSelectedNodes();

        const getSelected = test.map((item) => item.data);
        handleReBalanceIds(getSelected);
    }, []);

    const generate = () => {
        setShowMessageModal(true);
        setModalMessage(isTransmit ? ["Generating and transmitting files"] : ["Generating files"]);

        const modelRequestMap: any = {};
        selectedNodes.forEach((node) => {
            const data = node.data;
            if (!modelRequestMap[data.name]) {
                modelRequestMap[data.name] = {
                    macroName: data.name,
                    ticker_mappings: data.ticker_mappings,
                    type: data.type,
                    outputs_info: { [data.client]: [data.outputs_info] },
                    name_mappings: data.name_mappings,
                };
            } else {
                const clientOutputMap = modelRequestMap[data.name].outputs_info;
                if (!clientOutputMap[data.client]) {
                    clientOutputMap[data.client] = [];
                }
                clientOutputMap[data.client].push(data.outputs_info);
                modelRequestMap[data.name].output_info = clientOutputMap;
            }
        });
        const getRebalance = rebalanceIDs.map((item: any) => item.isSelected && item.id).filter((item) => item);

        Object.values(modelRequestMap).map((item: any) => {
            if (item.outputs_info["morgan stanley"] && item.outputs_info["morgan stanley"].length) {
                item.outputs_info["morgan stanley"].map((item2: any) => {
                    if (getRebalance.includes(item2.id)) {
                        item2.update = true;
                    } else {
                        item2.update && delete item2.update;
                    }
                    return item;
                });
            }
        });

        isTransmit ? setLoading(true) : setLoadingDownload(true);

        if (gridRef && gridRef.current && gridRef.current.api) {
            setRowData(rowData.map((x) => ({ ...x, errorMsg: "" })));
        }

        Api.getModalGenerator({
            ...(isTransmit && { save_to_sharepoint: isTransmit }),
            models: Object.values(modelRequestMap),
            comments: generateComments,
        })
            .then((response: any) => {
                setShowMessageModal(false);
                errorNotification.next({
                    type: "success",
                    text: isTransmit ? "File successfully transmitted" : "File successfully generated",
                    open: true,
                });
                setLoading(false);
                setLoadingDownload(false);
                setGenerateComments("");
                Api.getFileRaw(response[0].file_id)
                    .then(downloadFile)
                    .catch((e: any) => {
                        console.log("error", e);
                        errorNotification.next({
                            type: "error",
                            text: "Failed to download file",
                            open: true,
                        });
                    });
            })
            .catch((e: any) => {
                console.log("ERROR", e);
                setLoading(false);
                setLoadingDownload(false);
                setShowMessageModal(false);
                console.log(errors);
                setErrors(e?.response?.data[0].messages || []);
                errorNotification.next({
                    type: "error",
                    text: "Failed to download file",
                    open: true,
                });
            });

        handleModalClose();
    };

    const handleReBalanceIds = (e) => {
        const target = [...e];

        target.map((item: any) => {
            item.isSelected = true;
        });

        setRebalanceIDs(target);
    };

    useEffect(() => {
        const getMorgan = selectedNodes.filter((item: any) => item.data.client === "crd");
        if (getMorgan.length) {
            setSelectedMorgan(true);
        } else {
            setSelectedMorgan(false);
        }
    }, [selectedNodes]);

    const showTransmitButton = Access.hasAccessToZone("model_portfolios", "file_transforms", ["admin"]);
    const getRowId = (params) => `${params.data.client}-${params.data.name}-${params.data.onetisid}`;

    return (
        <AppCover
            className="model-generator"
            header={
                <div className="ms-2 d-flex">
                    <SearchBox setSearchText={setSearchText} />

                    <div className="model-actions">
                        <InputGroup className="mb-3">
                            <Button
                                variant="outline-secondary"
                                className={activeTab === "modelGenerator" ? "active" : ""}
                                onClick={() => {
                                    setActiveTab("modelGenerator");
                                }}
                            >
                                Model Generator
                            </Button>
                            <Button
                                variant="outline-secondary"
                                className={activeTab === "auditTrail" ? "active" : ""}
                                onClick={() => {
                                    setActiveTab("auditTrail");
                                }}
                            >
                                Audi Trail
                            </Button>
                        </InputGroup>
                    </div>
                </div>
            }
        >
            {openDialog && (
                <ErrorModal
                    openDialog={openDialog}
                    setOpenDialog={setOpenDialog}
                    popupError={popupErr}
                    setPopupErr={setPopupErr}
                ></ErrorModal>
            )}

            <div style={containerStyle}>
                {activeTab === "modelGenerator" && (
                    <>
                        <div className="sub-tool-bar">
                            <InputGroup className="mb-3">
                                <Button
                                    variant="outline-secondary"
                                    className={modelGeneratorView === "modelView" ? "active" : ""}
                                    onClick={setModelView}
                                >
                                    Model View
                                </Button>
                                <Button
                                    variant="outline-secondary"
                                    className={modelGeneratorView === "clientView" ? "active" : ""}
                                    onClick={setClientView}
                                >
                                    Client View
                                </Button>
                            </InputGroup>
                            <AdornedButton
                                onClick={() => handleReBalance(false)}
                                variant="contained"
                                disabled={!selectedNodes.length}
                                color="primary"
                                loading={loadingDownload}
                            >
                                Download
                            </AdornedButton>
                            {showTransmitButton && (
                                <AdornedButton
                                    onClick={() => handleReBalance(true)}
                                    variant="contained"
                                    disabled={selectedMorgan || !selectedNodes.length}
                                    color="primary"
                                    loading={loading}
                                >
                                    Transmit
                                </AdornedButton>
                            )}
                        </div>
                        <div style={gridStyle} className="ag-theme-balham">
                            <AgGridReact
                                rowData={rowData}
                                ref={gridRef}
                                columnDefs={colDefs}
                                defaultColDef={defaultColDef}
                                autoGroupColumnDef={autoGroupColumnDef}
                                rowSelection={"multiple"}
                                groupSelectsChildren={true}
                                suppressRowClickSelection={true}
                                suppressAggFuncInHeader={true}
                                sideBar={false}
                                suppressMenuHide={true}
                                groupDefaultExpanded={1}
                                onSelectionChanged={onSelectionChanged}
                                rememberGroupStateWhenNewData={true}
                                getRowId={getRowId}
                            ></AgGridReact>
                        </div>
                    </>
                )}
                {activeTab === "auditTrail" && (
                    <div style={gridStyle} className="ag-theme-balham">
                        <AgGridReact
                            rowData={audiTrailData}
                            columnDefs={[
                                { field: "username", filter: true, headerName: "User Name" },
                                { field: "request_received", filter: true, headerName: "Time Stamp" },
                                { field: "message", headerName: "Message" },
                                { field: "incomingPayload", headerName: "Payload", cellRenderer: ViewPayload },
                                { field: "downloadLink", headerName: "Download", cellRenderer: DownloadLInk },
                                { field: "status", headerName: "Status", cellRenderer: ViewStatusPayload },
                                { field: "total_file_count", headerName: "Total File Count" },
                            ]}
                            defaultColDef={defaultColDef}
                            suppressRowClickSelection={true}
                            suppressAggFuncInHeader={true}
                            sideBar={false}
                            suppressMenuHide={true}
                            rememberGroupStateWhenNewData={true}
                        ></AgGridReact>
                    </div>
                )}
            </div>

            <Modal show={showMessageModal} onHide={() => setShowMessageModal(false)} animation={false} centered>
                <Modal.Body>
                    <div
                        style={{
                            textAlign: "center",
                        }}
                    >
                        {modalMessage?.map((x, i) => <div key={i} className="alert alert-light mb-0"> {x} </div>)}
                    </div>
                </Modal.Body>
            </Modal>

            <Modal
                show={showReBalanceModal}
                onHide={() => setShowReBalanceModal(false)}
                animation={false}
                centered
                className="modal-rebalance"
            >
                <Modal.Header closeButton>
                    <Modal.Title>
                        <h4>Rebalance</h4>
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <h6>The following IDs do not have allocation changes. Do you want to allow drift?</h6>
                    <div
                        style={{
                            height: "200px",
                            width: "400px",
                        }}
                        className="ag-theme-balham"
                    >
                        <AgGridReact
                            rowSelection="multiple"
                            columnDefs={rebalanceColDef}
                            rowData={rebalanceRowData}
                            onSelectionChanged={onRebalnceSelectionChanged}
                            suppressRowClickSelection={true}
                            suppressAggFuncInHeader={true}
                        />
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <button
                        type="button"
                        className="btn btn-primary btn-sm"
                        onClick={() => handleReBalanceModalClose()}
                    >
                        Proceed
                    </button>
                </Modal.Footer>
            </Modal>
            <Modal
                show={showGenerateModal}
                onHide={handleModalClose}
                animation={false}
                centered
                className="modal-generator-confirm"
            >
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Generate Model</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <p>Please confirm that all selected models have cleared pre-trade compliance.</p>
                    <Form.Check
                        inline
                        label="Confirm"
                        name="group1"
                        type={"checkbox"}
                        id={`inline-checkbox-1`}
                        onChange={(event) => {
                            setPreClearanceCheck(event.target.checked);
                        }}
                    />
                    <br />
                    <Form.Control
                        type="text"
                        placeholder="Please enter comments"
                        onChange={(event) => {
                            setGenerateComments(event.target.value);
                        }}
                        style={{
                            marginTop: "10px",
                        }}
                    />
                </Modal.Body>
                <Modal.Footer>
                    <button type="button" className="btn  btn-sm" onClick={handleModalClose}>
                        Close
                    </button>
                    <button
                        type="button"
                        className="btn btn-primary btn-sm"
                        onClick={generate}
                        disabled={!(generateComments.length > 0 && preClearanceCheck)}
                    >
                        {isTransmit ? "Transmit" : "Download"}
                    </button>
                </Modal.Footer>
            </Modal>
        </AppCover>
    );
}