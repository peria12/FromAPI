import React, { useEffect, useState, useMemo, useRef } from "react";
import { ColDef } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import makeStyles from "@mui/styles/makeStyles";
import queryString from "query-string";

import Api from "utils/api";
import errorNotification from "utils/api-error";
import { errorHandler } from "utils/error-handler";
import DatePicker from "common/DatePicker";
import Settings from "utils/settings";
import { globalSearch, useScreenshot } from "utils/helpers";
import SearchBox from "common/SearchBox";
import { useHistory, useParams, useLocation } from "react-router-dom";
import Tooltip from "@mui/material/Tooltip";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import IconButton from "@mui/material/IconButton";
import ArrowUpIcon from "assets/ft-icons/up-arrow-green.png";
import ArrowDownIcon from "assets/ft-icons/down-arrow-red.png";
import AutocompleteField from "common/AutocompleteField";
import CustomFieldsDialog from "common/custom-fields/CustomFieldsDialog";
import { getPreviousDayNY, getLastMonthPreviousDate } from "utils/helpers";
import ViewsMenu from "common/views/ViewsMenu";
import DownloadIcon from "@mui/icons-material/Download";
import { FTIconButton } from "common/FTButtons";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import moment from "moment";
import PieChartIcon from "@mui/icons-material/PieChart";

import "./portfolio-holding.scss";
import {
    defaultColumnsInfo,
    collectionName,
    getColumInfo,
    defaultHoldingsInfo,
    // getAggregateSum,
} from "./holding-config";
import AppCover from "home/dashboad/AppCover";
// import Access from "utils/access";

const GridContext = React.createContext({ otherHoldings: [] });

function debounce(func, timeout = 300) {
    let timer;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => {
            func.apply(args);
        }, timeout);
    };
}

const useRowStyles = makeStyles({
    root: {
        "& > *": {
            borderBottom: "unset",
        },
    },
    base: {
        padding: "0px",
    },
    tableHeader: {
        fontWeight: "bold",
        borderBottom: "1px solid #777777",
        backgroundColor: "white",
    },
    toolbar: {
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-end",
        padding: 5,
    },

    autoCmpSearch: {
        marginRight: "auto",
        width: "50%",
    },

    tdWithBorder: {
        fontWeight: "bold",
        borderBottom: "none",
    },
    groupTitle: {
        fontWeight: 600,
    },
    tableRow: {
        borderBottom: "none",
        padding: "6px",
    },
    blueLabel: {
        background: "#00a0dc",
        color: "#fff",
    },
    borderTop: {
        borderTop: "1px solid black",
    },
    overLine: {
        textDecorationLine: "overline",
    },
    noData: {
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        width: "100%",
        fontSize: "18px",
        padding: "4px 0",
    },
    green: {
        color: "#4caf50",
    },
    red: {
        color: "#f44336",
    },
    upDownIcon: {
        display: "flex",
        alignItems: "center",
        padding: "1px 0px",
        justifyContent: "end",
    },
    icon: {
        height: "0.875rem",
        width: "20px",
        paddingLeft: "2px",
    },
});

const changeFieldMap = {
    mkt_value: "mkt_value_pct_chg",
    weight: "weight_chg",
};

function Toolbar({
    classes,
    columnsInfo,
    params,
    setSearchText,
    holdingsInfo,
    entityId,
    portfolioList,
    date,
    fetched_at,
    fieldsConfig,
    views,
    setViews,
    selectedView,
    setSelectedView,
    gridRef,
    filterState,
    getGridState,
}) {
    const history = useHistory();

    const exportToExcel = () => {
        const updatedColumns = columnsInfo?.fields?.filter((col: any) => {
            if (columnsInfo?.meta?.[col.id]) {
                return col;
            }
        });
        const keys = updatedColumns.map((columnHeader) => {
            const colTitle = columnHeader?.field_type === "percentage" ? columnHeader.title + "%" : columnHeader.title;
            return `"${colTitle}"`;
        });
        const ids = updatedColumns.map((columnHeader) => {
            return columnHeader.id;
        });
        const commaSeparatedString = [
            keys.join(","),
            holdingsInfo?.holdings
                ?.map((row) =>
                    ids
                        .map((key) => {
                            if (row[key]) {
                                const data = row[key];
                                if (!["number", "boolean"].includes(typeof data))
                                    return data?.includes(",") ? `"${row[key]}"` : row[key];
                                return row[key];
                            }
                            return "";
                        })
                        .join(",")
                )
                .join("\n"),
        ].join("\n");

        const link = document.createElement("a");
        link.href = window.URL.createObjectURL(new Blob([commaSeparatedString]));
        const selectedPortfolio = portfolioList.filter((portfolioData) => portfolioData.id == entityId);
        let filename = "";
        if (selectedPortfolio.length > 0) filename = selectedPortfolio[0]?.label;
        filename = `${filename}_${date || params.date}`;
        link.download = `${filename}.csv`;
        link.click();
    };

    return (
        <div className={classes.toolbar}>
            {fetched_at && (
                <Tooltip title={"Fetched At: " + fetched_at} aria-label="add" placement="top">
                    <IconButton aria-label="delete" style={{ padding: 0 }} size="large">
                        <AccessTimeIcon />
                    </IconButton>
                </Tooltip>
            )}
            <div className="date-picker-alignment">
                <DatePicker
                    label=""
                    dateStr={date || params.date}
                    handleDateChange={(e) => {
                        const query = queryString.stringify(
                            { ...params, date: e.target.value },
                            { arrayFormat: "bracket" }
                        );
                        history.push({
                            pathname: history.location.pathname,
                            search: query,
                        });
                    }}
                    shouldDisableOldDates={true}
                />
            </div>
            <div className={classes.autoCmpSearch}>
                {
                    <SearchBox
                        setSearchText={setSearchText}
                        placeholder={"Search holdings.."}
                        width={"100%"}
                        minWidth={"165px"}
                        height={"40px"}
                        style={{ background: "inherit" }}
                    />
                }
            </div>
            <FTIconButton
                handler={exportToExcel}
                title="Export"
                btnIcon={<DownloadIcon />}
                placement="top"
                hideBgColor={true}
            />
            {/* <Button variant="contained" color="primary" onClick={() => { exportToExcel(); }} className="me-3" >  </Button> */}
            <CustomFieldsDialog app="portfolios" zone="holdings" config={fieldsConfig} portfolioList={portfolioList} />
            <ViewsMenu
                app="portfolios"
                zone="holdings"
                views={views}
                setViews={setViews}
                selectedView={selectedView}
                setSelectedView={setSelectedView}
                gridRef={gridRef}
                filterState={filterState}
                getGridState={getGridState}
            />
        </div>
    );
}

export default function PortfolioHoldings() {
    const settings = Settings.getSettings();
    const classes = useRowStyles();
    const gridRef = useRef<AgGridReact>(null);
    const [colDefs, setColDefs] = useState<any[]>([]);
    const containerStyle = useMemo(() => ({ width: "auto", height: "calc(100vh - 145px)" }), []);
    const [holdingsInfo, setHoldingsInfo] = useState<any>({
        ...defaultHoldingsInfo,
        isLoading: true,
    });
    const [otherHoldings, setOtherHoldings] = useState<any>([]);
    const [columnsInfo, setColumnsInfo] = useState<any>({
        ...defaultColumnsInfo,
    });
    const [searchText, setSearchText] = useState("");
    const { search } = useLocation();
    const params = queryString.parse(search, { arrayFormat: "bracket" });
    const [portfolioList, setPortfolioList] = useState<any>([]);
    const [date, setDate] = useState<any>(null);
    const [fieldsConfig, setFieldsConfig] = useState<any>({});
    const history = useHistory();
    const routerParams = useParams();
    const [selectedView, setSelectedView] = useState<any>(settings?.app_settings?.portfolios?.holdings?.selectedView);
    const [filterState, setFilterState] = useState<any>("");
    const [views, setViews] = useState<any>([]);
    const loading = useRef<boolean>(false);
    const [filterData, setFilterData] = useState({});

    const ArrowCellRenderer = (props) => {
        if (isNaN(Number(props.value))) {
            return "";
        }
        const coldId = props.colDef.colId;
        const data = props.data;
        let icon;
        if (data) {
            if (data[changeFieldMap[coldId]] > 0) {
                icon = ArrowUpIcon;
            } else if (data[changeFieldMap[coldId]] < 0) {
                icon = ArrowDownIcon;
            }
        }

        const renderArrow = () => {
            return icon ? <img src={icon} className="arrow-icon" /> : "";
        };
        const cssClass = icon ? "" : "no-arrow";

        return (
            <div className={cssClass}>
                <span>{props.valueFormatted || props.value}</span>
                {renderArrow()}
            </div>
        );
    };

    const IdCellRenderer = (props) => {
        return (
            <div style={{ cursor: "pointer" }}>
                {props.rowIndex !== 0 && <PieChartIcon sx={{ marginRight: "10px" }} />}
                <span>{props.valueFormatted || props.value || "Blank"}</span>
            </div>
        );
    };

    useEffect(() => {
        // if (portfolioList?.length) {
        //     return; // do not re-load list of portfolios
        // }
        const date = params.date || getPreviousDayNY();
        Api.getPortfoliosDal([date])
            .then((response) => {
                const options: any = [];
                if (response?.error) {
                    const errorInfo = {
                        type: "error",
                        text: `${response?.error}`,
                        open: true,
                    };
                    errorNotification.next(errorInfo);
                }

                let portfolios: any = [];

                if (response?.portfolio_list) {
                    portfolios = [...portfolios, ...response.portfolio_list];
                }
                if (response?.portfolios_not_allowed) {
                    portfolios = [...portfolios, ...response.portfolios_not_allowed];
                    portfolios = portfolios.map((x) => ({
                        ...x,
                        portfolioNotAllowed: true,
                    }));
                }

                portfolios.filter((item) => {
                    if (item.entity_id && options.findIndex((x) => x.id == item.entity_id) <= -1) {
                        options.push({
                            id: item.entity_id,
                            port_ft_id: item.port_ft_id,
                            label: item?.entity_name,
                            portfolioNotAllowed: !!item?.portfolioNotAllowed,
                        });
                    } else {
                        options.push({
                            id: item.entity_id,
                            port_ft_id: item.port_ft_id,
                            label: item?.entity_name,
                            portfolioNotAllowed: !!item?.portfolioNotAllowed,
                        });
                    }
                });

                const first = options.length > 0 ? options[0].id : 0;
                const sortedOptions = options.sort((a: any, b: any) => a.port_ft_id - b.port_ft_id);
                setPortfolioList(sortedOptions);

                if (!routerParams?.entityId) {
                    if (first) {
                        history.push({ pathname: `/portfolios/holdings/${first}`, search });
                    } else {
                        gridRef?.current?.api.showNoRowsOverlay();
                        loading.current = false;
                    }
                }
            })
            .catch((e: any) => {
                errorHandler(e);
                if (!routerParams.entityId) {
                    setHoldingsInfo({ ...holdingsInfo, isLoading: false });
                }
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [params.date]);

    useEffect(() => {
        if (!routerParams.entityId || routerParams.entityId == "undefined") {
            const first = portfolioList.length > 0 ? portfolioList[0].id : "";
            if (first) {
                history.push({ pathname: `/portfolios/holdings/${first}`, search });
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [routerParams.entityId]);

    const screenshot = useScreenshot();

    if (!params.date) {
        params.date = getPreviousDayNY();
    }

    useEffect(() => {
        Api.getZoneSettings("portfolios", collectionName)
            .then((response: any) => {
                let fields = response?.fields?.fields || [];
                const custom_fields = response?.custom_fields?.fields || [];
                setFieldsConfig({ fields: fields, custom_fields: custom_fields });
                if (fields?.length == 0) {
                    const errorInfo = {
                        type: "error",
                        text: `Unable to fetch settings`,
                        open: true,
                    };
                    errorNotification.next(errorInfo);
                    setHoldingsInfo({ ...holdingsInfo, isLoading: false });
                } else {
                    const colMap = settings.portfolios?.holdings?.holdings?.columnsMeta || {};
                    const user_custom_fields = settings?.app_settings?.portfolios?.holdings?.custom_fields || [];

                    const all_custom_fields = [...custom_fields, ...user_custom_fields].map((f, i) => ({
                        hide: true,
                        id: f?.name,
                        show_on_table: true,
                        title: f?.name + "*",
                        view_order: i + 100,
                        field_type: "string",
                    }));
                    const colDefs: any = [];
                    fields = [...fields, ...all_custom_fields];

                    fields.forEach((column) => {
                        let valueFormatter;
                        let cellRenderer;
                        const colDef: any = {
                            headerName: column.title,
                            field: column.id,
                            colId: column.id,
                            key: column.id,
                            suppressSizeToFit: false,
                            hide: !!column.hide,
                            aggFunc: column.aggFunc || null,
                            cellClass: column.cellClass ? column.cellClass : "",
                            headerClass:
                                column.field_type === "percentage" || column.field_type === "number"
                                    ? "numeric-header-cell"
                                    : "text-header-cell",
                        };

                        if (column.aggFunc) {
                            colDef.aggFunc = column.aggFunc;
                        }
                        if (column.rowGroup) {
                            colDef.rowGroupIndex = column.rowGroupIndex;
                            colDef.rowGroup = column.rowGroup;
                        }

                        if (["weight", "mkt_value"].includes(column.id)) {
                            cellRenderer = ArrowCellRenderer;
                        }

                        if (column.field_type === "percentage") {
                            valueFormatter = (params) => {
                                let value = params.value;
                                if (value) {
                                    value = value ? parseFloat(value).toFixed(2) : "";
                                    if (!isFinite(value)) {
                                        return "";
                                    }
                                    return value;
                                } else if (isNaN(value)) {
                                    return "";
                                }
                                return "";
                            };
                        }

                        if (column.field_type === "number") {
                            valueFormatter = (params) => {
                                let value = params.value;
                                if (value) {
                                    value = value ? parseInt(value) : "";
                                    if (!isFinite(value)) {
                                        return "";
                                    }
                                    value = value.toLocaleString(undefined, {
                                        minimumFractionDigits: 0,
                                        maximumFractionDigits: 0,
                                    });
                                    if (["book_value", "mkt_value"].includes(params.colDef.colId)) {
                                        return "$" + value;
                                    } else {
                                        return value;
                                    }
                                } else if (isNaN(value)) {
                                    return "";
                                }
                                return "";
                            };
                        }

                        if (column.field_type === "percentage" || column.field_type === "number") {
                            colDef.cellClass = "numeric-cell";
                            colDef.headerClass = "numeric-header-cell";
                        } else {
                            colDef.cellClass = "text-cell";
                            colDef.headerClass = "text-header-cell";
                        }
                        if (column.id === "separator") {
                            colDef.cellClass = "separator-cell";
                            colDef.headerClass = "separator-header-cell";
                            colDef.width = 1;
                            colDef.minWidth = 1;
                            colDef.maxWidth = 1;
                        }

                        if (valueFormatter) {
                            colDef.valueFormatter = valueFormatter;
                        }

                        if (cellRenderer) {
                            colDef.cellRenderer = cellRenderer;
                        }
                        colDefs.push(colDef);
                    });
                    const groupCol = {
                        headerName: "Series Name",
                        field: "series",
                        hide: true,
                        id: "series",
                        colId: "series",
                        rowGroup: true,
                        rowGroupIndex: 0,
                        aggFunc: "sum",
                        suppressColumnsToolPanel: true,
                    };
                    colDefs.push(groupCol);

                    setColDefs(colDefs);
                    setColumnsInfo(getColumInfo(fields, colMap));
                }
            })
            .catch((err: any) => {
                console.log(err);
                setHoldingsInfo({ ...holdingsInfo, isLoading: false });
                setColumnsInfo(defaultColumnsInfo);
                setFieldsConfig({});
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (routerParams.entityId) {
            setDate(null);
            setHoldingsInfo({ ...holdingsInfo, isLoading: true });
            showLoading();

            Api.getHoldingsDal([params.date], [parseInt(routerParams.entityId, 10)])
                .then((resp) => {
                    if (resp?.error) {
                        const errorInfo = {
                            type: "error",
                            text: `${resp?.error}`,
                            open: true,
                        };
                        errorNotification.next(errorInfo);
                    }

                    if (resp?.portfolio_holdings?.length > 0) {
                        setOtherHoldings(resp.portfolio_holdings_others);
                        const holdingsArr = resp.portfolio_holdings;
                        const firstRow = holdingsArr?.[0];
                        if (firstRow?.date != params?.date) {
                            setDate(firstRow?.date);
                        }
                        // const totalMktValue = getAggregateSum(holdingsArr, "mkt_value");
                        const holdings = holdingsArr.map((holding) => ({
                            ...holding,
                            is_cash_yn: holding?.is_cash ? "Y" : "N",
                            country:
                                holding?.country_risk_iso3 ||
                                holding?.country_domicile_iso3 ||
                                holding?.country_inc_iso3 ||
                                "",
                            // weight: (holding?.mkt_value * 100) / totalMktValue,
                        }));
                        setHoldingsInfo({ isLoading: false, holdings: holdings });
                    } else {
                        hideOverlay();
                        setHoldingsInfo(defaultHoldingsInfo);
                    }
                    screenshot.take();
                })
                .catch((e: any) => {
                    errorHandler(e);
                    setHoldingsInfo(defaultHoldingsInfo);
                });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [params.date, routerParams.entityId]);

    useEffect(() => {
        if (holdingsInfo?.isLoading) {
            showLoading();
        } else {
            hideOverlay();
        }
    }, [holdingsInfo]);

    useEffect(() => {
        if (gridRef && gridRef.current && gridRef.current.api) {
            gridRef.current.api.setQuickFilter(searchText);
        }
    }, [searchText]);

    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
            minWidth: 100,
            resizable: true,
            headerCheckboxSelection: false,
            // allow every column to be aggregated
            enableValue: true,
            // allow every column to be grouped
            enableRowGroup: true,
            // allow every column to be pivoted
            enablePivot: true,
            sortable: true,
            filter: true,
            rowSelection: "multiple",
            groupSelectsChildren: true,
            suppressRowClickSelection: true,
            suppressAggFuncInHeader: true,
        };
    }, []);

    const onGridReady = (params) => {
        setFilterState(params.api);

        gridRef.current?.api?.forEachNode((node) => {
            if (node?.key) {
                node?.setExpanded(true);
            }
        });
        if (!holdingsInfo?.holdings.length) {
            showLoading();
        }
    };

    const showLoading = () => {
        gridRef?.current?.api?.showLoadingOverlay();
        loading.current = true;
    };

    const hideOverlay = () => {
        gridRef?.current?.api?.hideOverlay();
        loading.current = false;
    };

    const getRowClass = (params) => {
        if (params.data && !params.node.group) {
            return "holdings-leaf-group no-detailed-grid";
        }
        if (params.node.rowPinned === "top") {
            return "top-total-row";
        }
        if (params.node.rowPinned === "bottom") {
            return "bottom-total-row";
        }
    };

    const saveGridStateFilter = debounce(() => {
        const getFilterData = filterState.getFilterModel();
        const getKeys = Object.keys(getFilterData);
        const createFilterData = {};

        if (getKeys.length) {
            if (getKeys.includes("ag-Grid-AutoColumn")) {
                createFilterData["Name"] = getFilterData["ag-Grid-AutoColumn"];
            }

            colDefs.map((column) => {
                if (getKeys.includes(column.field)) {
                    createFilterData[column.headerName] = getFilterData[column.field];
                }
            });
        }

        setFilterData(createFilterData);
    });

    const autoGroupColumnDef = useMemo<ColDef>(() => {
        return {
            headerName: "Name",
            field: "entity_name",
            minWidth: 250,
            showRowGroup: true,
            cellRenderer: "agGroupCellRenderer",
            cellRendererParams: {
                innerRenderer: IdCellRenderer,
            },
            valueGetter: (params) => {
                return (params.data && params.data["entity_name"]) || " ";
            },
            onCellClicked: (event) => {
                history.push({
                    pathname: `/portfolios/security_holdings/${event.data["entity_id"]}`,
                    search,
                });
            },
        };
    }, [history, search]);

    const fetched_at = holdingsInfo?.holdings?.[0]?.fetched_at || "";

    useEffect(() => {
        if (selectedView && views?.length) {
            const view = views.find((v) => v._id["$oid"] == selectedView);
            if (view) {
                const columnState = view.gridState?.columnState;
                const filterModel = view.gridState?.filterModel;

                gridRef?.current?.columnApi?.applyColumnState({
                    state: columnState,
                    applyOrder: true,
                });
                gridRef?.current?.api?.setFilterModel(filterModel);
            }
        } else {
            gridRef?.current?.columnApi?.resetColumnState();
            gridRef?.current?.api?.setFilterModel(null);
        }
    }, [selectedView, views, colDefs, holdingsInfo?.holdings]);

    useEffect(() => {
        Settings.updateSettings("portfolios", "holdings", "selectedView", selectedView);
    }, [selectedView]);

    useEffect(() => {
        Api.getSharedState("portfolios", "holdings").then((res) => {
            const views = res.filter((item) => item.type == "view");
            setViews(views);
        });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const getGridState = () => {
        const columnState = gridRef?.current?.columnApi?.getColumnState();
        const filterModel = gridRef?.current?.api?.getFilterModel();
        return { columnState, filterModel };
    };

    console.log("holdings", holdingsInfo?.holdings);

    return (
        <AppCover
            header={
                <div className="d-flex">
                    <div style={{ minWidth: "250px" }} className="d-flex align-items-center">
                        <PortfolioSearch portfolioList={portfolioList} portfolioId={routerParams?.entityId} />
                    </div>
                    <Toolbar
                        classes={classes}
                        entityId={routerParams.entityId}
                        portfolioList={portfolioList}
                        columnsInfo={columnsInfo}
                        params={params}
                        setSearchText={setSearchText}
                        holdingsInfo={holdingsInfo}
                        date={date}
                        fetched_at={fetched_at}
                        fieldsConfig={fieldsConfig}
                        views={views}
                        setViews={setViews}
                        selectedView={selectedView}
                        setSelectedView={setSelectedView}
                        gridRef={gridRef}
                        filterState={filterData}
                        getGridState={getGridState}
                    />
                </div>
            }
        >
            <div className={classes.base}>
                <>
                    <div style={containerStyle}>
                        <div style={gridStyle} className="ag-theme-balham portfolio-holdings">
                            <GridContext.Provider value={{ otherHoldings }}>
                                <AgGridReact
                                    rowData={holdingsInfo?.holdings}
                                    ref={gridRef}
                                    columnDefs={colDefs}
                                    defaultColDef={defaultColDef}
                                    rowSelection={"multiple"}
                                    groupSelectsChildren={true}
                                    suppressRowClickSelection={true}
                                    suppressAggFuncInHeader={true}
                                    sideBar={false}
                                    groupDefaultExpanded={1}
                                    suppressMenuHide={true}
                                    rememberGroupStateWhenNewData={true}
                                    onGridReady={onGridReady}
                                    overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Loading...</span>'}
                                    overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${
                                        !params.date || moment(params.date).isSameOrBefore(getLastMonthPreviousDate())
                                            ? "No Data"
                                            : `The data is not available for this date or you do not have access`
                                    }.</span>`}
                                    autoGroupColumnDef={autoGroupColumnDef}
                                    paginationAutoPageSize={true}
                                    getRowClass={getRowClass}
                                    onFilterChanged={saveGridStateFilter}
                                    multiSortKey="ctrl"
                                ></AgGridReact>
                            </GridContext.Provider>
                        </div>
                    </div>
                </>
            </div>
        </AppCover>
    );
}

function PortfolioSearch({ portfolioList, portfolioId }) {
    const options = [...portfolioList];
    const history = useHistory();
    const { search } = useLocation();

    const handleChange = (_, portfolioInfo) => {
        if (portfolioInfo) {
            history.push({
                pathname: `/portfolios/holdings/${portfolioInfo?.id}`,
                search,
            });
        }
    };

    const provider = (query) => {
        if (!query) {
            return Promise.resolve([options, options.length]);
        }
        const results = globalSearch(options, query);
        return Promise.resolve([results, results.length]);
    };

    const RenderOption = function (props, option) {
        let customProps = { ...props };

        if (option.portfolioNotAllowed) {
            customProps = {
                ...props,
                key: props["data-option-index"],
                "aria-disabled": false,
                "aria-selected": false,
                onClick: () => {
                    //
                },
                onMouseOver: () => {
                    //
                },
                onTouchStart: () => {
                    //
                },
            };
        }

        return (
            <li {...customProps} style={{ fontSize: "14px" }}>
                <div className="col-1 text-truncate">
                    {option.portfolioNotAllowed ? (
                        <Tooltip title={`You do not have access to this data beyond ${getLastMonthPreviousDate()}`}>
                            <VisibilityOffIcon fontSize="small" />
                        </Tooltip>
                    ) : (
                        <VisibilityIcon fontSize="small" />
                    )}
                </div>
                <div className="col-2 text-truncate">{option?.port_ft_id}</div>
                <div className="col-10 text-truncate">{option.label}</div>
            </li>
        );
    };

    return (
        <AutocompleteField
            placeholder="Portfolios..."
            provider={provider}
            onChange={handleChange}
            value={options.find((f) => f.id == portfolioId)}
            isGrouped={true}
            inputPropsStyle={{ height: "40px" }}
            renderOption={RenderOption}
            popperWidth="700px"
        />
    );
}
