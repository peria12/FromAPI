export const PortfolioSummaryColumns = [
    {
        id: "port_ft_id",
        name: "FT ID",
        type: "numeric",
        sortable: true,
        sort: "asc",
        isGroupByField: true,
        cellClass: "numeric-cell",
        headerClass: "",
        comparator: (valueA, valueB) => {
            if (Number(valueA) == Number(valueB)) return 0;
            return Number(valueA) > Number(valueB) ? 1 : -1;
        },
    },
    { id: "entity_name", name: "Name", sortable: true, isGroupByField: true, width: 300 },
    { id: "lead_portfolio_manager", name: "Manager Name", sortable: true, isGroupByField: true },
    { id: "strategy", name: "Strategy Name", sortable: true, isGroupByField: true },
    { id: "entity_id", name: "Entity Id", sortable: true, type: "numeric", cellClass: "numeric-cell" },
    { id: "currency", name: "Currency", sortable: true, isGroupByField: true },
    {
        id: "mkt_value",
        name: "AUM",
        sortable: true,
        type: "numeric",
        convertToNumberSys: true,
        // grpByAggregation: "none",
        aggregateSum: true,
        cellClass: "numeric-cell",
    },
    {
        id: "cash_mkt_value",
        name: "Cash",
        type: "numeric",
        convertToNumberSys: true,
        sortable: true,
        aggregateSum: true,
        cellClass: "numeric-cell",
    },
    { id: "cash_pct", name: "% Cash of Total AUM", type: "percentage", cellClass: "numeric-cell" },
    // { id: "cash_target", name: "Cash Target", type: "percentage" },
    { id: "cash_target_threshold", name: "Threshold", type: "percentage" },
    // { id: "action_btn", name: "Action" },

    { id: "benchmark_name", name: "Benchmark" },
    { id: "benchmarkportfolionumber", name: "Benchmark Portfolio Number" },

    { id: "portfolioreturn1d", name: "Portfolio Return 1d", type: "percentage" },
    { id: "benchmarkreturn1d", name: "Benchmark Return 1d", type: "percentage" },
    { id: "excessreturn1d", name: "Excess Return 1d", type: "percentage" },

    { id: "portfolioreturn1m", name: "Portfolio Return 1m", type: "percentage", hide: true },
    { id: "benchmarkreturn1m", name: "Benchmark Return 1m", type: "percentage", hide: true },
    { id: "excessreturn1m", name: "Excess Return 1m", type: "percentage", hide: true },

    { id: "portfolioreturn3m", name: "Portfolio Return 3m", type: "percentage", hide: true },
    { id: "benchmarkreturn3m", name: "Benchmark Return 3m", type: "percentage", hide: true },
    { id: "excessreturn3m", name: "Excess Return 3m", type: "percentage", hide: true },

    { id: "portfolioreturn6m", name: "Portfolio Return 6m", type: "percentage", hide: true },
    { id: "benchmarkreturn6m", name: "Benchmark Return 6m", type: "percentage", hide: true },
    { id: "excessreturn6m", name: "Excess Return 6m", type: "percentage", hide: true },

    { id: "portfolioreturn1y", name: "Portfolio Return 1y", type: "percentage", hide: true },
    { id: "benchmarkreturn1y", name: "Benchmark Return 1y", type: "percentage", hide: true },
    { id: "excessreturn1y", name: "Excess Return 1y", type: "percentage", hide: true },

    { id: "portfolioreturn2y", name: "Portfolio Return 2y", type: "percentage", hide: true },
    { id: "benchmarkreturn2y", name: "Benchmark Return 2y", type: "percentage", hide: true },
    { id: "excessreturn2y", name: "Excess Return 2y", type: "percentage", hide: true },

    { id: "portfolioreturn3y", name: "Portfolio Return 3y", type: "percentage", hide: true },
    { id: "benchmarkreturn3y", name: "Benchmark Return 3y", type: "percentage", hide: true },
    { id: "excessreturn3y", name: "Excess Return 3y", type: "percentage", hide: true },

    { id: "portfolioreturn5y", name: "Portfolio Return 5y", type: "percentage", hide: true },
    { id: "benchmarkreturn5y", name: "Benchmark Return 5y", type: "percentage", hide: true },
    { id: "excessreturn5y", name: "Excess Return 5y", type: "percentage", hide: true },

    { id: "portfolioreturn7y", name: "Portfolio Return 7y", type: "percentage", hide: true },
    { id: "benchmarkreturn7y", name: "Benchmark Return 7y", type: "percentage", hide: true },
    { id: "excessreturn7y", name: "Excess Return 7y", type: "percentage", hide: true },

    { id: "portfolioreturn10y", name: "Portfolio Return 10y", type: "percentage", hide: true },
    { id: "benchmarkreturn10y", name: "Benchmark Return 10y", type: "percentage", hide: true },
    { id: "excessreturn10y", name: "Excess Return 10y", type: "percentage", hide: true },

    { id: "portfolioreturnmtd", name: "Portfolio Return MTD", type: "percentage", hide: true },
    { id: "benchmarkreturnmtd", name: "Benchmark Return MTD", type: "percentage", hide: true },
    { id: "excessreturnmtd", name: "Excess Return MTD", type: "percentage", hide: true },

    { id: "portfolioreturnqtd", name: "Portfolio Return QTD", type: "percentage", hide: true },
    { id: "benchmarkreturnqtd", name: "Benchmark Return QTD", type: "percentage", hide: true },
    { id: "excessreturnqtd", name: "Excess Return QTD", type: "percentage", hide: true },

    { id: "portfolioreturnytd", name: "Portfolio Return YTD", type: "percentage", hide: true },
    { id: "benchmarkreturnytd", name: "Benchmark Return YTD", type: "percentage", hide: true },
    { id: "excessreturnytd", name: "Excess Return YTD", type: "percentage", hide: true },

    { id: "portfolioreturnsncinc", name: "Portfolio Return Since Inception", type: "percentage", hide: true },
    { id: "benchmarkreturnsncinc", name: "Benchmark Return Since Inception", type: "percentage", hide: true },
    { id: "excessreturnsncinc", name: "Excess Return Since Inception", type: "percentage", hide: true },
];

export const defaultHiddenCols = {
    portfolioreturn1m: false,
    benchmarkreturn1m: false,
    excessreturn1m: false,

    portfolioreturn3m: false,
    benchmarkreturn3m: false,
    excessreturn3m: false,

    portfolioreturn6m: false,
    benchmarkreturn6m: false,
    excessreturn6m: false,

    portfolioreturn1y: false,
    benchmarkreturn1y: false,
    excessreturn1y: false,

    portfolioreturn2y: false,
    benchmarkreturn2y: false,
    excessreturn2y: false,

    portfolioreturn3y: false,
    benchmarkreturn3y: false,
    excessreturn3y: false,

    portfolioreturn5y: false,
    benchmarkreturn5y: false,
    excessreturn5y: false,

    portfolioreturn7y: false,
    benchmarkreturn7y: false,
    excessreturn7y: false,

    portfolioreturn10y: false,
    benchmarkreturn10y: false,
    excessreturn10y: false,

    portfolioreturnmtd: false,
    benchmarkreturnmtd: false,
    excessreturnmtd: false,

    portfolioreturnqtd: false,
    benchmarkreturnqtd: false,
    excessreturnqtd: false,

    portfolioreturnytd: false,
    benchmarkreturnytd: false,
    excessreturnytd: false,
};
