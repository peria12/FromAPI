import React, { useState, useRef, useEffect } from "react";
import { AgGridReact } from "ag-grid-react";
import moment from "moment";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Api from "utils/api";
import "./modal.css";
import { CircularProgress } from "@mui/material";

const columns = [
    {
        field: "file",
        headerName: "WSP Filename",
        checkboxSelection: true,
        headerCheckboxSelection: true,
        width: 300,
    },
    { field: "create_time", headerName: "Created" },
    {
        field: "status",
        headerName: "Status",
        cellStyle: (params) => {
            if (params.value === "Ready") {
                return { color: "#68C18F" };
            } else if (params.value === "In Progress") {
                return { color: "#F59855" };
            } else if (params.value === "Failed") {
                return { color: "red" };
            }
            return null;
        },
    },
];

function format(wspFiles) {
    return wspFiles.map((file) => {
        return {
            ...file,
            create_time: moment(file.create_time * 1000).format("MM/DD/YYYY hh:mm:ss A"),
        };
    });
}

export default function Modal({ selectedAccount, wspFiles, date, closeModal }) {
    const gridRef = useRef<AgGridReact>(null);
    const [selected, setSelected] = useState<readonly string[]>([]);
    const [dataForTable, setDataForTable] = useState(format(wspFiles));
    const [reportError, setReportError] = useState(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        setDataForTable(format(wspFiles));
        setReportError(null);
    }, [wspFiles]);

    const handleSelect = () => {
        const newSelected = gridRef?.current?.api.getSelectedNodes().map((row) => row.data.file) || [];
        setSelected(newSelected);
    };

    function changeSelectedFileStatus(status) {
        const newData = dataForTable.map((data) => {
            if (selected.includes(data.file)) {
                return {
                    ...data,
                    status,
                };
            } else {
                return data;
            }
        });
        setDataForTable(newData);
    }

    function updateFileStatusByRes(details) {
        const newData = dataForTable.map((data) => {
            if (Object.hasOwn(details, data.file)) {
                return {
                    ...data,
                    status: details[data.file].success ? "Ready" : "Failed",
                };
            } else {
                return data;
            }
        });
        setDataForTable(newData);
    }

    return (
        <div id="sys-strategy-modal">
            <div className="wrapper">
                <nav className="sys-strategy-modal-nav">
                    <div className="sys-strategy-container">
                        <div className="sys-strategy-tab-triger">
                            <div className="sys-strategy-header">Create Analytics</div>
                            <ul>
                                <li>{selectedAccount}</li>
                            </ul>
                        </div>
                        <div className="sys-strategy-tab-container-wrap">
                            <div className="ag-theme-alpine sys-strategy-tab-content-box">
                                <AgGridReact
                                    ref={gridRef}
                                    rowData={dataForTable}
                                    columnDefs={columns}
                                    rowSelection="multiple"
                                    onSelectionChanged={handleSelect}
                                    suppressRowClickSelection
                                />
                            </div>
                        </div>
                    </div>
                </nav>
                <button
                    className="sys-strategy-button"
                    disabled={selected.length === 0 || loading}
                    onClick={() => {
                        changeSelectedFileStatus("In Progress");
                        setLoading(true);
                        const request = {
                            account_id: selectedAccount,
                            date: new Date(date).toISOString().substring(0, 10).split("-").join(""),
                            wsp_files: selected,
                        };
                        Api.generateReports(request).then((res) => {
                            if (!res.success) {
                                setReportError(res.error);
                                changeSelectedFileStatus("Failed");
                            } else if (res.details) {
                                updateFileStatusByRes(res.details);
                            }
                            setLoading(false);
                        });
                    }}
                >
                    {loading && <CircularProgress size={20} />}
                    Run
                </button>
                <div className="sys-strategy-submission-status">
                    <div className="sys-strategy-status-title">
                        <div>Submission Status</div>
                        <MoreVertIcon style={{ color: "#D9D9D9", cursor: "pointer" }} onClick={() => closeModal()} />
                    </div>
                    <div className="sys-strategy-status">
                        {reportError ? reportError : "No errors, all records created."}
                    </div>
                </div>
            </div>
        </div>
    );
}
