import React, { useEffect, useState, useMemo, useRef, useCallback } from "react";
import { ColDef } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { Link } from "react-router-dom";
import makeStyles from "@mui/styles/makeStyles";
import IconButton from "@mui/material/IconButton";
import Api from "utils/api";
import { errorHandler } from "utils/error-handler";
import DatePicker from "common/DatePicker";
import { useHistory } from "react-router-dom";
import queryString from "query-string";
import { useLocation } from "react-router-dom";
import Settings from "utils/settings";
import FTSnackBar from "common/FTSnackBar";
import { useScreenshot, convertToInternationalCurrencySystem } from "utils/helpers";
import SearchBox from "common/SearchBox";
import { PortfolioSummaryColumns } from "./PortfolioConfig";
import AppCover from "home/dashboad/AppCover";
import errorNotification from "utils/api-error";
import Tooltip from "@mui/material/Tooltip";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import ArrowUpIcon from "assets/ft-icons/up-arrow-green.png";
import ArrowDownIcon from "assets/ft-icons/down-arrow-red.png";
import { getPreviousDayNY, getLastMonthPreviousDate } from "utils/helpers";
import ViewsMenu from "common/views/ViewsMenu";
// import Access from "utils/access";
import WarningIcon from "@mui/icons-material/Warning";

function debounce(func, timeout = 300) {
    let timer;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => {
            func.apply(args);
        }, timeout);
    };
}

const useRowStyles = makeStyles({
    root: {
        "& > *": {
            borderBottom: "unset",
        },
    },
    base: {
        padding: "0px",
    },
    tableHeader: {
        fontWeight: "bold",
        borderBottom: "1px solid #777777",
        backgroundColor: "white",
    },
    detailedView: {
        backgroundSize: "100% 100%;",
        width: "40%",
        height: "600px",
        backgroundRepeat: "no-repeat",
        textAlign: "center",
    },
    toolbar: {
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-end",
        paddingLeft: 8,
    },
    visuallyHidden: {
        border: 0,
        clip: "rect(0 0 0 0)",
        height: 1,
        margin: -1,
        overflow: "hidden",
        padding: 0,
        position: "absolute",
        top: 20,
        width: 1,
    },
    formControl: {
        margin: 8,
        minWidth: 120,
    },
    grpByFistCol: {
        backgroundColor: "#b3e5fc",
        borderRight: "1px solid #90a4ae",
    },
    grpBySecCol: {
        backgroundColor: "#e1f5fe",
        borderRight: "1px solid #90a4ae",
    },
    autoCmpSearch: {
        marginRight: "auto",
    },
    green: {
        color: "#4caf50",
    },
    red: {
        color: "#f44336",
    },
    icon: {
        height: "0.875rem",
        width: "20px",
        paddingLeft: "2px",
    },
});

const FTCellRenderer = (props) => {
    const { search } = useLocation();
    const params = queryString.parse(search, { arrayFormat: "bracket" });
    let date = params.date;
    if (!params.date) {
        date = getPreviousDayNY();
    }
    if (props.data) {
        return props.data.portfolioNotAllowed ? (
            <div
                style={{ display: "flex", flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}
            >
                <Tooltip title={`You do not have access to this data beyond ${getLastMonthPreviousDate()}`}>
                    <WarningIcon color="warning" sx={{ margin: "0 10px" }} />
                </Tooltip>

                <span> {props.value} </span>
            </div>
        ) : (
            <Link to={`/portfolios/holdings/${props.data["entity_id"]}?date=${date}`}> {props.value} </Link>
        );
    }
    return "";
};

const changeFieldMap = {
    mkt_value: "mkt_value_pct_chg",
    cash_mkt_value: "cash_mkt_value_pct_chg",
    cash_pct: "cash_pct_chg",
};

const CashCellRenderer = (props) => {
    if (isNaN(Number(props.value))) {
        return "";
    }
    const coldId = props.colDef.colId;
    const data = props.data;
    let icon;
    if (data) {
        if (data[changeFieldMap[coldId]] > 0) {
            icon = ArrowUpIcon;
        } else if (data[changeFieldMap[coldId]] < 0) {
            icon = ArrowDownIcon;
        }
    }

    const renderArrow = () => {
        return icon ? <img src={icon} className="arrow-icon" /> : "";
    };
    const cssClass = icon ? "" : "no-arrow";

    return (
        <div className={cssClass}>
            <span>{props.valueFormatted || props.value}</span>
            {renderArrow()}
        </div>
    );
};

function Toolbar({
    classes,
    params,
    date,
    setSearchText,
    fetched_at,
    views,
    setViews,
    selectedView,
    setSelectedView,
    gridRef,
    filterState,
    getGridState,
}): JSX.Element {
    const history = useHistory();
    return (
        <div className={classes.toolbar}>
            <div className={classes.autoCmpSearch}>
                {
                    <SearchBox
                        setSearchText={setSearchText}
                        placeholder={"Search portfolios..."}
                        width={"95%"}
                        height={"40px"}
                    />
                }
            </div>

            {fetched_at && (
                <Tooltip title={"Fetched At: " + fetched_at} aria-label="add" placement="top">
                    <IconButton aria-label="delete" style={{ padding: 0 }} size="large">
                        <AccessTimeIcon />
                    </IconButton>
                </Tooltip>
            )}

            <div className="date-picker-alignment">
                <DatePicker
                    label=""
                    dateStr={date || params.date}
                    shouldDisableOldDates={true}
                    handleDateChange={(e) => {
                        const query = queryString.stringify(
                            { ...params, date: e.target.value },
                            { arrayFormat: "bracket" }
                        );
                        history.push({ pathname: history.location.pathname, search: query });
                    }}
                />
            </div>
            <ViewsMenu
                app="portfolios"
                zone="summary"
                views={views}
                setViews={setViews}
                selectedView={selectedView}
                setSelectedView={setSelectedView}
                gridRef={gridRef}
                filterState={filterState}
                getGridState={getGridState}
            />
        </div>
    );
}

export default function PortfolioSummary() {
    const settings = Settings.getSettings();
    const classes = useRowStyles();
    const gridRef = useRef<AgGridReact>(null);
    const [colDefs, setColDefs] = useState<any[]>([]);
    const [rowData, setRowData] = useState<any[]>([]);
    const containerStyle = useMemo(() => ({ width: "100%", height: "calc(100vh - 140px)" }), []);
    const [searchText, setSearchText] = useState("");
    const [date, setDate] = useState<any>(null);
    const [selectedView, setSelectedView] = useState<any>(settings?.app_settings?.portfolios?.summary?.selectedView);
    const [filterState, setFilterState] = useState<any>("");
    const [filterData, setFilterData] = useState({});
    const [views, setViews] = useState<any>([]);
    const { search } = useLocation();
    const params = queryString.parse(search, { arrayFormat: "bracket" });
    if (!params.date) {
        params.date = getPreviousDayNY();
    }
    const loading = useRef<boolean>(false);

    const screenshot = useScreenshot();

    useEffect(() => {
        setDate(null);
        showLoading();
        Api.getPortfoliosDal([params.date])
            .then((resp) => {
                if (resp?.error) {
                    const errorInfo = {
                        type: "error",
                        text: `${resp?.error}`,
                        open: true,
                    };
                    errorNotification.next(errorInfo);
                }
                let portfolioMaster: any = [];
                if (resp?.portfolio_list) {
                    portfolioMaster = [...resp.portfolio_list];
                }
                if (resp?.portfolios_not_allowed) {
                    const customAttributeAdded = [...resp.portfolios_not_allowed].map((y) => ({
                        ...y,
                        portfolioNotAllowed: true,
                    }));
                    portfolioMaster = [...portfolioMaster, ...customAttributeAdded];
                }
                const firstRow = portfolioMaster?.[0];

                if (firstRow?.date != params?.date) {
                    setDate(firstRow?.date);
                }

                setRowData(portfolioMaster);

                hideOverlay();
                if (!resp.portfolio_list && !resp.portfolios_not_allowed) {
                    loading.current = false;
                    gridRef?.current?.api.showNoRowsOverlay();
                }

                screenshot.take();
            })
            .catch((e: any) => {
                errorHandler(e);
            });

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [params.date]);

    useEffect(() => {
        if (selectedView && views?.length) {
            const view = views.find((v) => v._id["$oid"] == selectedView);
            if (view) {
                const columnState = view.gridState?.columnState;
                const filterModel = view.gridState?.filterModel;

                gridRef?.current?.columnApi?.applyColumnState({ state: columnState, applyOrder: true });
                gridRef?.current?.api?.setFilterModel(filterModel);
            }
        } else {
            gridRef?.current?.columnApi?.resetColumnState();
            gridRef?.current?.api?.setFilterModel(null);
        }
    }, [selectedView, views, colDefs, rowData]);

    useEffect(() => {
        Api.getSharedState("portfolios", "summary").then((res) => {
            const views = res?.filter((item) => item.type == "view") || []; //&& item["author-id"] === Access.userInfo.uuid
            setViews(views);
        });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onGridReady = (params) => {
        setFilterState(params.api);

        if (!rowData.length && loading.current) {
            showLoading();
        }
    };

    useEffect(() => {
        const columnDef: any = [];

        PortfolioSummaryColumns.forEach((column) => {
            let cellRenderer;
            let valueFormatter;
            const colDef: any = {
                headerName: column.name,
                field: column.id,
                colId: column.id,
                key: column.id,
                checked: true,
                value: column.name,
                name: column.name,
                suppressSizeToFit: false,
                hide: !!column.hide,
                cellClass: column.cellClass ? column.cellClass : "",
                headerClass:
                    column.type === "percentage" || column.type === "numeric"
                        ? "numeric-header-cell"
                        : "text-header-cell",
            };

            if (column.width) {
                colDef.minWidth = column.width;
            }
            if (column.sort) {
                colDef.sort = column.sort;
            }
            if (column.id === "port_ft_id") {
                cellRenderer = FTCellRenderer;
                valueFormatter = (params) => {
                    return Number(params.value);
                };
            }
            if (column.comparator) {
                colDef.comparator = column.comparator;
            }

            if (column.id === "mkt_value" || column.id === "cash_mkt_value" || column.id === "cash_pct") {
                cellRenderer = CashCellRenderer;
            }

            if (column.id === "mkt_value" || column.id === "cash_mkt_value") {
                valueFormatter = (params) => {
                    return convertToInternationalCurrencySystem(params.value);
                };
            }

            if (column.type === "percentage" || column.type === "numeric") {
                colDef.cellClass = "numeric-cell";
            } else {
                colDef.cellClass = "text-cell";
            }

            if (column.type === "percentage") {
                valueFormatter = (params) => {
                    let newValue = params.value;
                    if (newValue) {
                        newValue = parseFloat(newValue).toFixed(2);
                        if (!isFinite(newValue)) {
                            return "";
                        }
                        return newValue + "%";
                    } else if (isNaN(newValue)) {
                        return "";
                    }
                };
            }
            if (cellRenderer) {
                colDef.cellRenderer = cellRenderer;
            }

            if (valueFormatter) {
                colDef.valueFormatter = valueFormatter;
            }
            columnDef.push(colDef);
        });
        setColDefs(columnDef);
    }, []);

    useEffect(() => {
        if (gridRef && gridRef.current && gridRef.current.api) {
            gridRef.current.api.setQuickFilter(searchText);
        }
    }, [searchText]);

    const fetched_at = rowData?.[0]?.fetched_at || "";
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
            minWidth: 100,
            resizable: true,
            headerCheckboxSelection: false,
            // allow every column to be aggregated
            enableValue: true,
            // allow every column to be grouped
            enableRowGroup: true,
            // allow every column to be pivoted
            enablePivot: true,
            sortable: true,
            filter: true,
            rowSelection: "multiple",
            groupSelectsChildren: true,
            suppressRowClickSelection: true,
            suppressAggFuncInHeader: true,
        };
    }, []);

    const saveGridStateFilter = debounce(() => {
        const getFilterData = filterState.getFilterModel();
        const getKeys = Object.keys(getFilterData);
        const createFilterData = {};

        if (getKeys.length) {
            colDefs.map((column) => {
                if (getKeys.includes(column.field)) {
                    createFilterData[column.headerName] = getFilterData[column.field];
                }
            });
        }

        setFilterData(createFilterData);
    });

    const showLoading = useCallback(() => {
        gridRef?.current?.api?.showLoadingOverlay();
        loading.current = true;
    }, []);

    const hideOverlay = useCallback(() => {
        gridRef?.current?.api?.hideOverlay();
        loading.current = false;
    }, []);

    const message = { type: "", text: "", open: false };

    const getGridState = () => {
        const columnState = gridRef?.current?.columnApi?.getColumnState();
        const filterModel = gridRef?.current?.api?.getFilterModel();
        return { columnState, filterModel };
    };

    useEffect(() => {
        Settings.updateSettings("portfolios", "summary", "selectedView", selectedView);
    }, [selectedView]);

    return (
        <AppCover
            className="portfolio-summary"
            header={
                <>
                    <Toolbar
                        classes={classes}
                        params={params}
                        date={date}
                        fetched_at={fetched_at}
                        setSearchText={setSearchText}
                        views={views}
                        setViews={setViews}
                        selectedView={selectedView}
                        setSelectedView={setSelectedView}
                        gridRef={gridRef}
                        filterState={filterData}
                        getGridState={getGridState}
                    />
                </>
            }
        >
            <div className={classes.base}>
                <>
                    <FTSnackBar snack={message} />
                    <div style={containerStyle}>
                        <div style={gridStyle} className="ag-theme-balham">
                            <AgGridReact
                                rowData={rowData}
                                ref={gridRef}
                                columnDefs={colDefs}
                                defaultColDef={defaultColDef}
                                rowSelection={"multiple"}
                                groupSelectsChildren={true}
                                suppressRowClickSelection={true}
                                suppressAggFuncInHeader={true}
                                sideBar={false}
                                suppressMenuHide={true}
                                groupDefaultExpanded={1}
                                rememberGroupStateWhenNewData={true}
                                onGridReady={onGridReady}
                                onFilterChanged={saveGridStateFilter}
                                overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Loading...</span>'}
                                overlayNoRowsTemplate={'<span class="ag-overlay-loading-center">No Data</span>'}
                                pagination={true}
                                multiSortKey="ctrl"
                            ></AgGridReact>
                        </div>
                    </div>
                </>
            </div>
        </AppCover>
    );
}
