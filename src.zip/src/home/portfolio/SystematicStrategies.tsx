import { AgGridReact } from "ag-grid-react";
import AppCover from "home/dashboad/AppCover";
import React, { useEffect, useMemo, useRef, useState } from "react";
import SearchBox from "common/SearchBox";
import Tooltip from "@mui/material/Tooltip";
import { useHistory } from "react-router-dom";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import IconButton from "@mui/material/IconButton";
import queryString from "query-string";
import makeStyles from "@mui/styles/makeStyles";
import Api from "utils/api";
import RefreshIcon from "@mui/icons-material/Refresh";
import Modal from "./Modal";
import { useLocation } from "react-router-dom";
import { getPreviousDayNY, useScreenshot } from "utils/helpers";

import "./systematicStrategies.scss";
import { ColDef } from "ag-grid-community";
import FTDatePicker from "common/FTDatePicker";
import moment from "moment";

const useRowStyles = makeStyles({
    toolbar: {
        width: "100%",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-end",
        paddingLeft: 8,
    },
    autoCmpSearch: {
        marginRight: "auto",
    },
    icon: {
        height: "0.875rem",
        width: "20px",
        paddingLeft: "2px",
    },
});

function Toolbar({ classes, params, date, setSearchText, fetched_at }): JSX.Element {
    const history = useHistory();
    function disableWeekends(date) {
        return date.getDay() === 0 || date.getDay() === 6;
    }

    const todayDate = new Date();
    const maxDate = `${todayDate.getFullYear()}-${("0" + (todayDate.getMonth() + 1)).slice(-2)}-${(
        "0" +
        (todayDate.getDate() - 1)
    ).slice(-2)}`;

    return (
        <div className={classes.toolbar}>
            <div className={classes.autoCmpSearch}>
                {
                    <SearchBox
                        setSearchText={setSearchText}
                        placeholder={"Search portfolios..."}
                        width={"95%"}
                        height={"40px"}
                    />
                }
            </div>

            {fetched_at && (
                <Tooltip title={"Fetched At: " + fetched_at} aria-label="add" placement="top">
                    <IconButton aria-label="delete" style={{ padding: 0 }} size="large">
                        <AccessTimeIcon />
                    </IconButton>
                </Tooltip>
            )}

            <div className="date-picker-alignment me-2">
                <FTDatePicker
                    label=""
                    dateStr={date || params.date}
                    maxDate={maxDate}
                    format="yyyy-MM-dd"
                    shouldDisableDate={disableWeekends}
                    handleDateChange={(e) => {
                        const d = new Date(e);
                        const date = `${d.getFullYear()}-${("0" + (d.getMonth() + 1)).slice(-2)}-${(
                            "0" + d.getDate()
                        ).slice(-2)}`;
                        const query = queryString.stringify({ ...params, date: date }, { arrayFormat: "bracket" });
                        history.push({
                            pathname: history.location.pathname,
                            search: query,
                        });
                    }}
                />
            </div>
        </div>
    );
}

export default function SystematicStrategies() {
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const gridRef = useRef<AgGridReact>(null);
    const classes = useRowStyles();
    const [accountRowData, setAccountRowData] = useState([]);
    const [statusData, setStatusData] = useState([]);
    const [searchText, setSearchText] = useState("");
    const [selectedAccount, setSelectedAccount] = useState("");
    const [date, setDate] = useState<any>(null);
    const [showModal, setShowModal] = useState({ analytics: false });
    const { search } = useLocation();
    const params = queryString.parse(search, { arrayFormat: "bracket" });
    if (!params.date) {
        params.date = getPreviousDayNY();
    }

    const screenshot = useScreenshot();

    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
            minWidth: 200,
            resizable: true,
            headerCheckboxSelection: false,
            // allow every column to be aggregated
            enableValue: true,
            // allow every column to be grouped
            groupSelectsChildren: true,
            suppressRowClickSelection: true,
            suppressAggFuncInHeader: true,
        };
    }, []);

    const dateCellRenderer = (row) => {
        if (!statusData || !row.data) {
            return <></>;
        }

        const status: any = statusData[row.data.account_id];

        if (!status || !status.last_update_time) {
            return <></>;
        }

        return moment(status.last_update_time * 1000).format("MM/DD/YYYY hh:mm:ss A");
    };

    const statusCellRenderer = (data) => {
        if (!statusData || !data.data) {
            return <></>;
        }

        const status: any = statusData[data.data.account_id];

        if (!status) {
            return <></>;
        }
        return (
            <div className="status-cell">
                <div className="ft-box">
                    <nav>
                        <ul className="ft-nav">
                            <li
                                className={`ft-dataQ ${
                                    status.data_q === true
                                        ? "ft-check"
                                        : status.data_q === false
                                        ? "ft-unknown"
                                        : "ft-progress"
                                }`}
                            >
                                <a href="#">
                                    {status.data_q === true ? (
                                        <div className="ft-text">&#10004;</div>
                                    ) : status.data_q === false ? (
                                        <div className="ft-text">&#33;&#33;&#33;</div>
                                    ) : (
                                        <div className="ft-text">&#8943;</div>
                                    )}
                                    <p className="ft-text1">DataQ</p>
                                </a>
                            </li>
                            <li
                                className={`ft-alpha ${
                                    status.has_alpha === true
                                        ? "ft-check"
                                        : status.has_alpha === false
                                        ? "ft-unknown"
                                        : "ft-progress"
                                }`}
                            >
                                <a href="#">
                                    {status.has_alpha === true ? (
                                        <div className="ft-text">&#10004;</div>
                                    ) : status.has_alpha === false ? (
                                        <div className="ft-text">&#33;&#33;&#33;</div>
                                    ) : (
                                        <div className="ft-text">&#8943;</div>
                                    )}
                                    <p className="ft-text1">Alpha</p>
                                </a>
                            </li>
                            <li
                                className={`ft-optmzr ${
                                    status.has_optimization === true
                                        ? "ft-check"
                                        : status.has_optimization === false
                                        ? "ft-unknown"
                                        : "ft-progress"
                                }`}
                            >
                                <a href="#">
                                    {status.has_optimization === true ? (
                                        <div className="ft-text">&#10004;</div>
                                    ) : status.has_optimization === false ? (
                                        <div className="ft-text">&#33;&#33;&#33;</div>
                                    ) : (
                                        <div className="ft-text">&#8943;</div>
                                    )}
                                    <p className="ft-text1">Optmzr</p>
                                </a>
                            </li>
                            <li
                                className={`ft-anlytcs ${
                                    status.has_report === true
                                        ? "ft-check"
                                        : status.has_report === false
                                        ? "ft-unknown"
                                        : "ft-progress"
                                }`}
                            >
                                <a href="#">
                                    {status.has_report === true ? (
                                        <div className="ft-text">&#10004;</div>
                                    ) : status.has_report === false ? (
                                        <div className="ft-text">&#33;&#33;&#33;</div>
                                    ) : (
                                        <div className="ft-text">&#8943;</div>
                                    )}
                                    <p className="ft-text1">Anlytcs</p>
                                </a>
                            </li>

                            <div className="ft-btn1">View Analytics Report</div>
                        </ul>
                    </nav>
                </div>

                <button className="refresh-button" disabled>
                    <RefreshIcon width={20} height={20} />
                </button>
            </div>
        );
    };

    const accountIdRenderer = (data) => {
        if (!data.data) return "";

        return (
            <div className="account-id-wrap">
                <input
                    type="radio"
                    name="account"
                    id={data.data.account_id}
                    checked={selectedAccount === data.data.account_id}
                />
                <span className="account-id">{data.data.account_id}</span>
            </div>
        );
    };

    const handleSelection = () => {
        const selected = gridRef?.current?.api.getSelectedNodes();

        setSelectedAccount(selected ? selected[0]?.data?.account_id : "");
    };

    useEffect(() => {
        if (gridRef && gridRef.current && gridRef.current.api) {
            gridRef.current.api.setQuickFilter(searchText);
        }
    }, [searchText]);

    const colDefs = [
        {
            headerName: "Acct ID",
            field: "account_id",
            cellRenderer: accountIdRenderer,
            maxWidth: 100,
        },
        {
            headerName: "Portfolio/Account Name",
            field: "account_name",
        },
        {
            headerName: "Status",
            field: "status",
            cellRenderer: statusCellRenderer,
            minWidth: 200,
            cellClass: "grid-status-cell",
        },
        {
            headerName: "Last Update",
            field: "dates",
            cellRenderer: dateCellRenderer,
        },
    ];

    useEffect(() => {
        Api.getAccounts().then((res) => {
            setAccountRowData(Object.values(res));
        });
    }, []);

    useEffect(() => {
        setDate(params.date);

        Api.getStatus(params.date.split("-").join("")).then((res) => {
            setStatusData(res);
            screenshot.take();
        });
    }, [params.date, screenshot]);

    const handleClick = () => {
        Api.refreshStatus({});
    };

    return (
        <AppCover
            className="systematic-strategies"
            header={
                <>
                    <Toolbar classes={classes} params="" date={date} fetched_at="" setSearchText={setSearchText} />
                </>
            }
        >
            <div style={{ height: "60%", boxSizing: "border-box" }}>
                <div style={gridStyle} className="ag-theme-balham">
                    <AgGridReact
                        rowData={accountRowData}
                        ref={gridRef}
                        columnDefs={colDefs}
                        rowSelection="single"
                        onSelectionChanged={handleSelection}
                        defaultColDef={defaultColDef}
                        rowHeight={30}
                        headerHeight={29}
                        suppressRowTransform
                    />
                    <div className="button-container">
                        <div>
                            <button className="ft-add-btn" onClick={() => handleClick()} disabled>
                                Re-run all Optimizations
                            </button>
                        </div>
                        <div style={{ display: "flex", columnGap: "10px" }}>
                            <button
                                className="ft-add-btn"
                                onClick={() => {
                                    setShowModal({ ...showModal, analytics: true });
                                }}
                                disabled={!selectedAccount}
                            >
                                Create Analytics
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            {showModal.analytics && (
                <Modal
                    selectedAccount={selectedAccount}
                    date={date}
                    wspFiles={statusData[selectedAccount]?.wsp_files || []}
                    closeModal={() => setShowModal({ analytics: false })}
                />
            )}
        </AppCover>
    );
}
