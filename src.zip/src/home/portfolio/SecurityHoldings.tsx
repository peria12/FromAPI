import React, { useEffect, useState, useMemo, useRef, useCallback } from "react";
import { useHistory, useParams, useLocation, Link } from "react-router-dom";
import queryString from "query-string";
import { AgGridReact } from "ag-grid-react";
import { ColDef } from "ag-grid-community";
import Highcharts from "highcharts/highstock";
import PieChart from "highcharts-react-official";

import { useScreenshot, getPreviousDayNY, getLastMonthPreviousDate } from "utils/helpers";
import AutocompleteField from "common/AutocompleteField";
import AppCover from "home/dashboad/AppCover";
import DatePicker from "common/DatePicker";
import Api from "utils/api";
import errorNotification from "utils/api-error";
import { errorHandler } from "utils/error-handler";
import Settings from "utils/settings";
import { FTIconButton } from "common/FTButtons";
import DownloadIcon from "@mui/icons-material/Download";
import ViewsMenu from "common/views/ViewsMenu";

import "./portfolio-holding.scss";
import moment from "moment";
import { Typography } from "@mui/material";

function debounce(func, timeout = 300) {
    let timer;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => {
            func.apply(...args);
        }, timeout);
    };
}

//#region - main component

export default function SecurityHoldings() {
    //#region - variables

    const settings = Settings.getSettings();
    const routerParams = useParams();
    const history = useHistory();
    const { search } = useLocation();
    const params = queryString.parse(search, { arrayFormat: "bracket" });
    const screenshot = useScreenshot();
    const loading = useRef<boolean>(false);
    const gridRef = useRef<AgGridReact>(null);
    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
            minWidth: 100,
            resizable: true,
            headerCheckboxSelection: false,
            // allow every column to be aggregated
            enableValue: true,
            // allow every column to be grouped
            enableRowGroup: true,
            // allow every column to be pivoted
            enablePivot: true,
            sortable: true,
            filter: true,
            rowSelection: "multiple",
            groupSelectsChildren: true,
            suppressRowClickSelection: true,
            suppressAggFuncInHeader: true,
        };
    }, []);
    const autoGroupColumnDef = useMemo<ColDef>(() => {
        return {
            headerName: "Name",
            field: "entity_name",
            minWidth: 250,
            cellRenderer: "agGroupCellRenderer",
            valueGetter: (params) => {
                return (params.data && params.data["entity_name"]) || " ";
            },
        };
    }, []);

    //#endregion
    //#region - useState

    const [date, setDate] = useState<any>("");
    const [securityHoldingInfo, setSecurityHoldings] = useState<any>({
        securityHoldings: [],
        isLoading: false,
    });
    const [filterState, setFilterState] = useState<any>({});
    const [views, setViews] = useState<any>([]);
    const [selectedView, setSelectedView] = useState<any>(
        settings?.app_settings?.portfolios?.security_holdings?.selectedView
    );
    const [filterData, setFilterData] = useState({});

    //#endregion
    //#region - useEffect

    useEffect(() => {
        if (!params.date) {
            const yesterday = getPreviousDayNY();

            setDate(yesterday);
            const query = queryString.stringify({ ...params, date: yesterday }, { arrayFormat: "bracket" });
            history.push({
                pathname: history.location.pathname,
                search: query,
            });
        } else {
            setDate(null);
        }
    }, [history, params, params.date]);

    useEffect(() => {
        if (!params.date) {
            return;
        }

        setSecurityHoldings((sh) => ({ ...sh, isLoading: true }));
        showLoading();

        Api.getSecurityHoldingsDal(
            [params.date],
            routerParams?.entityId ? [parseInt(routerParams?.entityId, 10)] : undefined
        )
            .then((resp) => {
                if (resp?.error) {
                    const errorInfo = {
                        type: "error",
                        text: `${resp?.error}`,
                        open: true,
                    };
                    errorNotification.next(errorInfo);
                }

                if (resp?.security_holdings?.length > 0) {
                    const newSecurityHoldings =
                        resp?.security_holdings.sort((holding1: any, holding2: any) => {
                            if (holding1.mkt_value && holding2.mkt_value) {
                                return Math.abs(holding2.mkt_value) - Math.abs(holding1.mkt_value);
                            }
                            return 0;
                        }) || [];
                    const securityHoldingsSum = resp?.security_holdings?.reduce(
                        (acc: any, curr: any) => ({
                            ...acc,
                            date: curr.date,
                            entity_name: "",
                            ft_id: "",
                            mkt_value: acc.mkt_value + curr.mkt_value,
                            other_port_ft_id: "",
                            port_ft_id: "",
                            port_mkt_value: acc.port_mkt_value + curr.port_mkt_value,
                            req_entity_id: 0,
                        }),
                        {
                            mkt_value: 0,
                            port_mkt_value: 0,
                        }
                    );

                    newSecurityHoldings.push(securityHoldingsSum);

                    setSecurityHoldings({
                        securityHoldings: newSecurityHoldings,
                        isLoading: false,
                    });
                } else {
                    hideOverlay();
                    setSecurityHoldings({ securityHoldings: [], isLoading: false });
                }
                screenshot.take();
            })
            .catch((e: any) => {
                errorHandler(e);
                setSecurityHoldings({ securityHoldings: [], isLoading: false });
            });
    }, [routerParams?.entityId, params.date, screenshot]);

    useEffect(() => {
        Api.getSharedState("portfolios", "security_holdings").then((res) => {
            const views = res.filter((item) => item.type == "view");
            setViews(views);
        });
    }, [settings.email]);

    //#endregion

    //#region - custom functions

    const IdCellRenderer = (props) => {
        const { search } = useLocation();
        const params = queryString.parse(search, { arrayFormat: "bracket" });
        let date = params.date;
        if (!params.date) {
            date = getPreviousDayNY();
        }
        if (props.data) {
            return (
                <Link to={`/portfolios/holdings/${props.data["port_entity_id"]}?date=${date}`}> {props.value} </Link>
            );
        }
        return "";
    };

    const colDefs = useMemo(
        () => [
            { id: "port_ft_id", field: "port_ft_id", headerName: "Portfolio Id", cellRenderer: IdCellRenderer },
            {
                id: "portfolio_name",
                field: "portfolio_name",
                headerName: "Portfolio Name",
                cellClass: "text-cell",
                headerClass: "text-header-cell",
            },
            {
                id: "port_mkt_value",
                field: "port_mkt_value",
                headerName: "Portfolio AUM ",
                cellClass: "numeric-cell",
                headerClass: "numeric-header-cell",
                valueFormatter: (params) => {
                    let value = params.value;
                    if (value) {
                        value = value ? parseInt(value) : "";
                        if (!isFinite(value)) {
                            return "";
                        }
                        value = value.toLocaleString(undefined, {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 0,
                        });

                        return "$" + value;
                    } else if (isNaN(value)) {
                        return "";
                    }
                    return "";
                },
            },
            {
                id: "mkt_value",
                field: "mkt_value",
                headerName: "Market Value ",
                cellClass: "numeric-cell",
                sortable: true,
                headerClass: "numeric-header-cell",
                comparator: (value1, value2) => {
                    if (value1 && value2) {
                        return Math.abs(value2) - Math.abs(value1);
                    }
                    return 0;
                },
                valueFormatter: (params) => {
                    let value = params.value;
                    if (value) {
                        value = value ? parseInt(value) : "";
                        if (!isFinite(value)) {
                            return "";
                        }
                        value = value.toLocaleString(undefined, {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 0,
                        });

                        return "$" + value;
                    } else if (isNaN(value)) {
                        return "";
                    }
                    return "";
                },
            },
            {
                id: "book_value",
                field: "book_value",
                headerName: "Book Value ",
                cellClass: "numeric-cell",
                sortable: true,
                headerClass: "numeric-header-cell",
                comparator: (value1, value2) => {
                    if (value1 && value2) {
                        return Math.abs(value2) - Math.abs(value1);
                    }
                    return 0;
                },
                valueFormatter: (params) => {
                    let value = params.value;
                    if (value) {
                        value = value ? parseInt(value) : "";
                        if (!isFinite(value)) {
                            return "";
                        }
                        value = value.toLocaleString(undefined, {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 0,
                        });

                        return "$" + value;
                    } else if (isNaN(value)) {
                        return "";
                    }
                    return "";
                },
            },
            {
                field: " AUM % ",
                fieldType: "percentage",
                cellClass: "numeric-cell",
                headerClass: "numeric-header-cell",
                valueFormatter: (params) => {
                    const data: any = params.data;
                    let value: any = data?.mkt_value ? Number((data.mkt_value / data.port_mkt_value) * 100) : 0;
                    if (value) {
                        value = parseFloat(value).toFixed(2);
                        if (!isFinite(value)) {
                            return "";
                        }
                        return value + "%";
                    } else if (isNaN(value)) {
                        return "";
                    }
                    return "";
                },
            },
            {
                id: "lead_portfolio_manager",
                field: "lead_portfolio_manager",
                headerName: "Manager",
                cellClass: "text-cell",
                headerClass: "text-header-cell",
            },
            {
                id: "port_entity_id",
                field: "port_entity_id",
                headerName: "Entity ID",
                cellClass: "text-cell",
                headerClass: "text-header-cell",
                hide: true,
            },
            {
                id: "entity_name",
                field: "entity_name",
                headerName: "Symbol",
                cellClass: "text-cell",
                headerClass: "text-header-cell",
                hide: true,
            },
            {
                id: "entity_type",
                field: "entity_type",
                headerName: "Security Type",
                cellClass: "text-cell",
                headerClass: "text-header-cell",
            },
            {
                id: "qty",
                field: "qty",
                headerName: "Quantity",
                cellClass: "text-cell",
                headerClass: "text-header-cell",
            },
            {
                id: "currency",
                field: "currency",
                headerName: "Currency",
                cellClass: "text-cell",
                headerClass: "text-header-cell",
            },
            {
                id: "port_currency",
                field: "port_currency",
                headerName: "Port Currency",
                cellClass: "text-cell",
                headerClass: "text-header-cell",
            },
            {
                id: "global_category_assetclass_name",
                field: "global_category_assetclass_name",
                headerName: "Global Category Assetclass Name",
                cellClass: "text-cell",
                headerClass: "text-header-cell",
            },
            {
                id: "morningstar_category_us_assetclass_name",
                field: "morningstar_category_us_assetclass_name",
                headerName: "Morning Star Category US Assetclass Name",
                cellClass: "text-cell",
                headerClass: "text-header-cell",
            },
            {
                id: "morningstar_category_name",
                field: "morningstar_category_name",
                headerName: "Morning Category Name",
                cellClass: "text-cell",
                headerClass: "text-header-cell",
            },
            {
                id: "mstar_id",
                field: "mstar_id",
                headerName: "MorningStarId",
                cellClass: "text-cell",
                headerClass: "text-header-cell",
                hide: true,
            },
        ],
        []
    );

    useEffect(() => {
        if (selectedView && views?.length) {
            const view = views.find((v) => v._id["$oid"] == selectedView);
            if (view) {
                const columnState = view.gridState?.columnState;
                const filterModel = view.gridState?.filterModel;

                gridRef?.current?.columnApi?.applyColumnState({ state: columnState, applyOrder: true });
                gridRef?.current?.api?.setFilterModel(filterModel);
            }
        } else {
            gridRef?.current?.columnApi?.resetColumnState();
            gridRef?.current?.api?.setFilterModel(null);
        }
    }, [selectedView, views, colDefs, securityHoldingInfo?.securityHoldings]);

    const showLoading = () => {
        gridRef?.current?.api?.showLoadingOverlay();
        loading.current = true;
    };

    const hideOverlay = () => {
        gridRef?.current?.api?.hideOverlay();
        loading.current = false;
    };

    const saveGridStateFilter = debounce(() => {
        const getFilterData = filterState.getFilterModel();
        const getKeys = Object.keys(getFilterData);
        const createFilterData = {};

        if (getKeys.length) {
            if (getKeys.includes("ag-Grid-AutoColumn")) {
                createFilterData["Name"] = getFilterData["ag-Grid-AutoColumn"];
            }

            colDefs.map((column: any) => {
                if (getKeys.includes(column.field)) {
                    createFilterData[column?.headerName] = getFilterData[column.field];
                }
            });
        }

        setFilterData(createFilterData);
    });

    const onGridReady = () => {
        setFilterState(params.api || {});

        gridRef.current?.api?.forEachNode((node) => {
            if (node?.key) {
                node?.setExpanded(true);
            }
        });
        if (!securityHoldingInfo?.securityHoldings.length) {
            showLoading();
        }
    };

    const getRowClass = (params) => {
        if (params.data && !params.node.group) {
            return "holdings-leaf-group no-detailed-grid";
        }
        if (params.node.rowPinned === "top") {
            return "top-total-row";
        }
        if (params.node.rowPinned === "bottom") {
            return "bottom-total-row";
        }
    };

    const getGridState = () => {
        const columnState = gridRef?.current?.columnApi?.getColumnState();
        const filterModel = gridRef?.current?.api?.getFilterModel();
        return { columnState, filterModel };
    };

    const exportToExcel = () => {
        const updatedColumns: any = colDefs.filter((cds) => cds.id);
        const keys = updatedColumns.map((columnHeader) => {
            const colTitle =
                columnHeader?.field_type === "percentage" ? columnHeader.headerName + "%" : columnHeader.headerName;
            return `"${colTitle}"`;
        });
        const ids = updatedColumns.map((columnHeader) => {
            return columnHeader.field;
        });
        const commaSeparatedString = [
            keys.join(","),
            securityHoldingInfo?.securityHoldings
                ?.map((row) =>
                    ids
                        .map((key) => {
                            if (row[key]) {
                                const data: any = row[key];
                                if (!["number", "boolean"].includes(typeof data))
                                    return data?.includes(",") ? `"${row[key]}"` : row[key];
                                return row[key];
                            }
                            return "";
                        })
                        .join(",")
                )
                .join("\n"),
        ].join("\n");
        const link = document.createElement("a");
        link.href = window.URL.createObjectURL(new Blob([commaSeparatedString]));
        const selectedEntity = securityHoldingInfo?.securityHoldings;
        let filename = "";
        if (selectedEntity.length > 0) filename = selectedEntity[0]?.["entity_name"];
        filename = `${filename}_${date || params.date}`;
        link.download = `${filename}.csv`;
        link.click();
    };

    //#endregion
    //#region - render

    return (
        <AppCover
            header={
                <div className="d-flex">
                    <div style={{ minWidth: "250px" }} className="d-flex align-items-center">
                        <HoldingsSearch date={params.date} entityId={routerParams?.entityId} />
                    </div>

                    <div
                        style={{
                            display: "flex",
                            flexDirection: "row",
                            alignItems: "center",
                            justifyContent: "flex-end",
                            padding: 5,
                        }}
                    >
                        <div className="date-picker-alignment">
                            <DatePicker
                                label=""
                                dateStr={date || params.date}
                                handleDateChange={(e) => {
                                    const query = queryString.stringify(
                                        { ...params, date: e.target.value },
                                        { arrayFormat: "bracket" }
                                    );
                                    history.push({
                                        pathname: history.location.pathname,
                                        search: query,
                                    });
                                }}
                                shouldDisableOldDates={true}
                            />
                        </div>

                        <FTIconButton
                            handler={exportToExcel}
                            title="Export"
                            btnIcon={<DownloadIcon />}
                            placement="top"
                            hideBgColor={true}
                        />

                        <ViewsMenu
                            app="portfolios"
                            zone="security_holdings"
                            views={views}
                            setViews={setViews}
                            selectedView={selectedView}
                            setSelectedView={setSelectedView}
                            gridRef={gridRef}
                            filterState={filterData}
                            getGridState={getGridState}
                        />
                    </div>
                </div>
            }
        >
            <div style={{ height: "100%" }}>
                {securityHoldingInfo?.securityHoldings?.length ? (
                    <div
                        style={{
                            display: "flex",
                            flexDirection: "row",
                            alignItems: "center",
                            marginBottom: "10px",
                        }}
                    >
                        <Typography
                            variant="body1"
                            sx={{
                                marginRight: "10px",
                            }}
                        >
                            {securityHoldingInfo?.securityHoldings?.[0]?.entity_id}:
                        </Typography>
                        <Typography variant="body1">
                            {securityHoldingInfo?.securityHoldings?.[0]?.entity_name}
                        </Typography>
                        <Typography
                            variant="body1"
                            sx={{
                                marginLeft: "10px",
                            }}
                        >
                            {`(${securityHoldingInfo?.securityHoldings?.[0]?.entity_type})`}
                        </Typography>
                    </div>
                ) : null}
                <div className="detailed-security-holdings" style={{ height: "95%" }}>
                    <div className="ag-theme-balham">
                        <AgGridReact
                            rowData={securityHoldingInfo?.securityHoldings}
                            masterDetail={true}
                            ref={gridRef}
                            columnDefs={colDefs}
                            defaultColDef={defaultColDef}
                            onGridReady={onGridReady}
                            overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Loading...</span>'}
                            overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${
                                !params.date || moment(params.date).isSameOrBefore(getLastMonthPreviousDate())
                                    ? "No Data"
                                    : `The data is not available for this date or you do not have access`
                            }.</span>`}
                            isRowMaster={() => true}
                            rowSelection={"multiple"}
                            groupSelectsChildren={true}
                            suppressRowClickSelection={true}
                            suppressAggFuncInHeader={true}
                            sideBar={false}
                            groupDefaultExpanded={0}
                            suppressMenuHide={true}
                            rememberGroupStateWhenNewData={true}
                            autoGroupColumnDef={autoGroupColumnDef}
                            paginationAutoPageSize={true}
                            getRowClass={getRowClass}
                            onFilterChanged={saveGridStateFilter}
                            multiSortKey="ctrl"
                        ></AgGridReact>
                    </div>

                    <div>
                        <PieChart
                            highcharts={Highcharts}
                            options={{
                                chart: {
                                    plotBackgroundColor: null,
                                    plotBorderWidth: null,
                                    plotShadow: false,
                                    type: "pie",
                                },
                                credits: {
                                    enabled: false,
                                },
                                title: {
                                    text: "",
                                },
                                tooltip: {
                                    pointFormatter: function () {
                                        let value = (this as any).y;
                                        if (value) {
                                            value = value ? parseInt(value) : "";
                                            if (!isFinite(value)) {
                                                return "";
                                            }
                                            value = value.toLocaleString(undefined, {
                                                minimumFractionDigits: 0,
                                                maximumFractionDigits: 0,
                                            });

                                            return "$" + value;
                                        } else if (isNaN(value)) {
                                            return "";
                                        }

                                        return "<b>" + value + "</b>";
                                    },
                                },
                                accessibility: {
                                    point: {
                                        valueSuffix: "%",
                                    },
                                },
                                plotOptions: {
                                    pie: {
                                        size: "100%",
                                        allowPointSelect: true,
                                        cursor: "pointer",
                                        dataLabels: {
                                            enabled: false,
                                        },
                                    },
                                },
                                series: [
                                    {
                                        name: "Brands",
                                        colorByPoint: true,
                                        data:
                                            securityHoldingInfo?.securityHoldings
                                                ?.filter((x: any) => x.port_ft_id)
                                                ?.map((oh: any) => {
                                                    return { name: oh.portfolio_name, y: oh.mkt_value };
                                                }) || [],
                                    },
                                ],
                            }}
                        />
                    </div>
                </div>
            </div>
        </AppCover>
    );

    //#endregion
}

//#endregion

//#region - Dependent Component

function HoldingsSearch({ date, entityId }) {
    //#region - variables

    const history = useHistory();
    const { search } = useLocation();

    //#endregion
    //#region - useState

    const [entity, setEntity] = useState({
        id: -1,
        label: "",
    });

    //#endregion
    //#region - useEfffect

    useEffect(() => {
        if (!date) {
            return;
        }

        (async () => {
            const resp = await Api.getEntitesForSecurityHoldings({
                date,
                search_string: entityId ? String(entityId) : "",
            });

            const entities =
                resp?.hits?.hits?.map((ht) => ({
                    id: ht?._source?.entity_id,
                    label: ht?._source?.entity_name,
                })) || [];

            const ent = entities?.find((ent) => ent.id == entityId);

            if (ent) {
                setEntity(ent);
            } else {
                const firstEnt = entities?.[0];

                setEntity(firstEnt);
            }
        })();
    }, [date, entityId]);

    //#endregion
    //#region - custom functions

    const handleChange = (_, entityInfoSelected) => {
        if (entityInfoSelected) {
            setEntity(entityInfoSelected);
            history.push({
                pathname: `/portfolios/security_holdings/${entityInfoSelected?.id}`,
                search,
            });
        } else {
            history.push({
                pathname: `/portfolios/security_holdings/`,
                search,
            });
        }
    };

    const provider = useCallback(
        async (query) => {
            try {
                const entites = await Api.getEntitesForSecurityHoldings({
                    date,
                    search_string: query || "",
                }).then((resp) => {
                    const entites =
                        resp?.hits?.hits?.map((ht) => ({
                            id: ht?._source?.entity_id,
                            label: ht?._source?.entity_name,
                        })) || [];

                    return entites;
                });

                return Promise.resolve([entites, entites?.length]);
            } catch (e) {
                errorHandler(e);
                return Promise.resolve([[], 0]);
            }
        },
        [date]
    );

    const RenderOption = function (props, option) {
        return (
            <li {...props} style={{ fontSize: "14px" }} key={option?.id}>
                <div className="col-2 text-truncate">{option?.id}</div>
                <div className="col-10 text-truncate">{option.label}</div>
            </li>
        );
    };

    //#endregion
    //#region - render return

    return (
        <AutocompleteField
            placeholder="Entities..."
            provider={provider}
            onChange={handleChange}
            value={entity}
            isGrouped={true}
            inputPropsStyle={{ height: "40px" }}
            renderOption={RenderOption}
            popperWidth="700px"
            debounce={500}
        />
    );

    //#endregion
}

//#endregion
