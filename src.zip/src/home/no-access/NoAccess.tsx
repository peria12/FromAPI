import React from 'react';
import "./NoAccess.scss";
import Api from "utils/api";

const NoAccess = () => {
    const [requestedPermission, setRequestedPermission] = React.useState(false);
    const [loading, setLoading] = React.useState(false);

    const onContinue = () => {
        try {
            setLoading(true);
            Api.requestAccess().then((response) => {
                if (response.message === "Email sent") {
                    setRequestedPermission(true);
                    setLoading(false);
                }
            });
        } catch (e) {
            console.log(e);
        }
    }

    return (
        <div className='div-no-access div-center'>
            <div className="div-no-access-backdrop">
                <div className="div-no-access-content padded-div">
                    <div className="title">
                        <h5>No Access</h5>
                    </div>
                    <div className="content">
                        {requestedPermission ?
                            <label className='label-no-access'>
                                Thank you for your interest. Please access this site after you receive an email granting access to this platform.
                            </label>
                            :
                            <label className='label-no-access'>
                                You do not have permission to access the requested page.
                                <br />
                                Click &apos;Continue&apos; to request access.
                            </label>
                        }

                        {
                            !requestedPermission &&
                            <button disabled={loading} onClick={onContinue} className={`button-no-access  ${loading ? 'button-no-access-disabled' : 'button-no-access-enabled'} `}>Continue</button>

                        }
                    </div>
                </div>
            </div>
        </div >
    )
}

export default NoAccess