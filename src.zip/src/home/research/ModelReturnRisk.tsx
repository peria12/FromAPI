import React from "react";
import { AbsPerformanceTable } from "./components/AbsPerformanceTable";
import { RelPerformanceTable } from "./components/RelPerformanceTable";
import { RiskTable } from "./components/RiskTable";
import { ReturnProfileChart } from "./components/ReturnProfileChart";
import { ReturnProfileTable } from "./components/ReturnProfileTable";
import { SharpeChart } from "./components/SharpeChart";
import { Rolling18MonthStatChart } from "./components/Rolling18MonthStatChart";
import { ExcessRetDistChart } from "./components/ExcessRetDistChart";
import { BetaProfileTable } from "./components/BetaProfileTable";
import { StressScenariosActivePerfChart } from "./components/StressScenariosActivePerfChart";
import { ModelRiskTable } from "./components/ModelRiskTable";
import { CorrelationTable } from "./components/CorrelationTable";
import { RBAContext, RBAModelReturnRiskContext } from "utils/context";
import { Period } from "./components/Period";
import { toRecords } from "./utils";

export default function ModelReturnRisk() {
    const { pairs, pairIndex, getEntityName, getFundBenchNames } = React.useContext(RBAContext);
    if (!pairs?.length) {
        return <></>;
    }

    const pair = pairs[pairIndex];
    const [fundName, benchName] = getFundBenchNames(pair);

    const fund_returns = toRecords(pair.fund)
    const bench_returns = toRecords(pair.bench)

    return (
        <div className="rounded">
            <RBAModelReturnRiskContext.Provider
                value={{
                    pair,
                    getEntityName,
                    fundName,
                    benchName,
                    getFundBenchNames,
                    fund_returns,
                    bench_returns,
                }}
            >
                <div className="d-flex flex-wrap">
                    <div className="d-flex flex-column me-2" style={{ width: 1450 }}>
                        <AbsPerformanceTable />
                        <RelPerformanceTable />
                        <RiskTable />
                        <div className="rounded bg-white border mb-2 p-1">
                            <div className="d-flex">
                                <div className="ft-card-header" style={{ width: 640 }}>
                                    Return Profile
                                </div>
                                <Period />
                            </div>
                            <div className="d-flex">
                                <div style={{ width: 640 }}>
                                    <ReturnProfileChart />
                                </div>
                                <div style={{ width: 300 }} className="mx-3">
                                    <ReturnProfileTable />
                                </div>
                                <div style={{ width: 500 }} className="me-1">
                                    <ExcessRetDistChart />
                                </div>
                            </div>
                        </div>
                        <div className="d-flex w-100">
                            <Rolling18MonthStatChart />
                            <SharpeChart />
                        </div>
                    </div>
                    <div className="d-flex flex-column" style={{ width: 1450 }}>
                        <div className="d-flex flex-column">
                            <div className="d-flex w-100">
                                <BetaProfileTable />
                                <div>

                                <div className="d-flex flex-column">
                                    <ModelRiskTable />
                                    <StressScenariosActivePerfChart />
                                </div>
                                </div>
                            </div>
                            <div className="d-flex">
                                <CorrelationTable />
                            </div>
                        </div>
                    </div>
                </div>
            </RBAModelReturnRiskContext.Provider>
        </div>
    );
}
