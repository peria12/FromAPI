import React from "react";

import { toRecords } from "./utils";
import { RBAContext } from "utils/context";
import { FTGrid } from "./components/FTGrid";
import { Cover } from "./Cover";
import { HChart } from "common/HChart";

export function FundAnalyzer() {
    const { pairs, pairIndex } = React.useContext(RBAContext);

    if (!pairs?.length) return <></>;

    const pair = pairs[pairIndex];
    const roll_stats = toRecords(pair?.rolling_stats);
    const max_months = Math.max(...roll_stats.map((x) => x.months));
    const max_year = isFinite(max_months) ? max_months / 12 : 7; // if no data, then show 7

    const headerClass = "ft-grid-th-div-span ft-border-right text-center";
    const headerClassR = "ft-grid-th-div-span ft-border-right";
    const headerClassNB = "ft-grid-th-div-span text-center";
    const cellClass = (val) => "ft-border-right ft-grid-td ft-pad-right " + (val < 0 ? "red-value" : "");
    const cellClassNBR = (val) => "ft-pad-right ft-grid-td " + (val < 0 ? "red-value" : "");
    const format = (val, row) =>
        val ? (isNaN(val) ? val : row.pct ? `${(val * 100).toFixed(2)}%` : val.toFixed(2)) : "";
    const width = 60;
    const headerWidth = 240;

    const get_roll_col = (month) => [
        [
            { headerClass: "ft-border-right" },
            {
                headerName: `Last ${max_year} Year Stats`,
                colSpan: 1,
                headerClass: "ft-border-right ft-card-header border-bottom",
            },
            {
                headerName: "Last 5 Year Stats",
                colSpan: 1,
                headerClass: "ft-border-right ft-card-header border-bottom",
            },
            { headerName: "Last 3 Year Stats", colSpan: 1, headerClass: "ft-card-header border-bottom" },
        ],
        [
            { headerName: "", field: "title", width: headerWidth, headerClass, cellClass: () => headerClassR },
            { headerName: `Rolling ${month} Month`, format, field: "ymax", width: width * 2, headerClass, cellClass },
            { headerName: `Rolling ${month} Month`, format, field: "y5", width: width * 2, headerClass, cellClass },
            {
                headerName: `Rolling ${month} Month`,
                format,
                field: "y3",
                width: width * 2,
                headerClass: headerClassNB,
                cellClass: cellClassNBR,
            },
        ],
    ];

    const getRowsRoll = (window) => {
        const y3 = roll_stats.find((x) => x.months == 36 && x.window == window) || {};
        const y5 = roll_stats.find((x) => x.months == 60 && x.window == window) || {};
        const ymax = roll_stats.find((x) => x.months == max_months && x.window == window) || {};

        return [
            { title: "Avg Performance", ymax: ymax.avg_perf, y5: y5.avg_perf, y3: y3.avg_perf, pct: true },
            { title: "Hit Rate", ymax: ymax.hit_rate, y5: y5.hit_rate, y3: y3.hit_rate, pct: true },
            {
                title: "Avg Outperformance",
                ymax: ymax.avg_out_perf,
                y5: y5.avg_out_perf,
                y3: y3.avg_out_perf,
                pct: true,
            },
            {
                title: "Avg Underperformance",
                ymax: ymax.avg_under_perf,
                y5: y5.avg_under_perf,
                y3: y3.avg_under_perf,
                pct: true,
            },
        ];
    };
    const roll_ret_recs = toRecords(pair?.rel_returns_rolling);

    const getLineChart = (field) => {
        return {
            title: {
                text: "",
            },

            yAxis: {
                title: {
                    text: "Relative Return",
                },
                labels: {
                    format: "{value}%",
                },
                tickInterval: 5,
                plotLines: [{
                    value: 0,
                    width: 2
                }]
            },

            xAxis: {
                type: "datetime",
            },

            plotOptions: {
                series: {
                    label: {
                        connectorAllowed: false,
                    },
                },
            },
            tooltip: {
                pointFormat: "Value: {point.y:.2f} %",
            },

            series: [
                {
                    name: "Relative Return",
                    data: roll_ret_recs.map((x) => [new Date(x.date).getTime(), x[field] * 100]),
                    color: "#57DFD4",
                },
            ],
        };
    };

    const getBarChart = (field) => {
        return {
            chart: {
                type: "column",
            },
            title: {
                text: "",
            },
            tooltip: {
                pointFormat: "Value: {point.y:.2f} %",
            },

            yAxis: {
                title: {
                    text: "Relative Return",
                },
                labels: {
                    format: "{value}%",
                },
                tickInterval: 5,
            },

            plotOptions: {
                series: {
                    label: {
                        connectorAllowed: false,
                    },
                },
            },

            series: [
                {
                    name: "Relative Return",
                    data: roll_ret_recs
                        .map((x) => x[field])
                        .sort((a, b) => a - b)
                        .map((x, i) => [i, x * 100]),
                    color: "#FA9375",
                },
            ],
        };
    };

    const chart_height = 200;
    const chart_width = "600px";
    const rows_roll3 = getRowsRoll(3);
    const rows_roll6 = getRowsRoll(6);
    const rows_roll12 = getRowsRoll(12);

    const getSection = (rows, key, months) => {
        return (
            <div className="d-flex">
                <div className="me-4">
                    <FTGrid columnDefs={get_roll_col(months)} rowData={rows} />
                </div>
                <div className="d-flex flex-wrap">
                    <div style={{ width: chart_width }} className="me-2">
                        <Cover title={`Rolling ${months} Month Average Return`} cls={"text-center"} width="100%">
                            <HChart option={getLineChart(key)} height={chart_height} />
                        </Cover>
                    </div>
                    <div style={{ width: chart_width }}>
                        <Cover title={`Rolling ${months} Month Average Return`} cls={"text-center"} width="100%">
                            <HChart option={getBarChart(key)} height={chart_height} />
                        </Cover>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div>
            <div className="d-flex flex-column">
                {getSection(rows_roll3, "rel_returns_3m", 3)}
                {getSection(rows_roll6, "rel_returns_6m", 6)}
                {getSection(rows_roll12, "rel_returns_12m", 12)}
            </div>
        </div>
    );
}
