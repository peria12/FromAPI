import React, { useEffect, useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import TextField from "@mui/material/TextField";
import errorNotification from "utils/api-error";
import FTSelect from "common/FTSelect";
import ConfirmDialog from "common/ConfirmDialog";
import { FTIconButton } from "common/FTButtons";
import DeleteIcon from "@mui/icons-material/Delete";
import viewIcon from "assets/View.svg";
import { Form } from "react-bootstrap";
import Access from "utils/access";
import { UserSelector, Users } from "common/UserSelector";
import ClearIcon from "@mui/icons-material/Clear";

const BootstrapDialogTitle = (props: any) => {
    const { children, onClose, ...other } = props;
    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: "absolute",
                        right: 6,
                        top: 6,
                        color: (theme) => theme?.palette?.grey?.[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

const defaultFormData = { name: "", update: false, create: false };

function AnalysisDialog({ selectedAnalysis, analysis, updateAnalysis, clearPage }) {
    const [openDialog, setOpenDialog] = useState(false);
    const [system, setSystem] = useState(false);
    const [dept, setDept] = useState(false);
    const [users, setUsers] = useState([]);
    const [isUpdate, setIsUpdate] = useState(false);
    const [formData, setFormData] = useState({ ...defaultFormData, name: selectedAnalysis?.name || "" });
    const isAdmin = Access.hasAccessToZone("admin", "acl", ["admin"]);
    const analysisSet = new Set();
    analysis.forEach((element) => analysisSet.add(element.name));

    function onChange(key, value) {
        if (key === "name") {
            value === "" && setIsUpdate(true);
            if (value === "") {
                setUsers([]);
                setDept(false);
                setSystem(false);
            }
        }
        setFormData({ ...formData, [key]: value });
    }

    useEffect(() => {
        if (selectedAnalysis) {
            setUsers(selectedAnalysis.access?.users || []);
            setDept(selectedAnalysis.access?.dept || Boolean(selectedAnalysis.access?.dept_code) || false);
            setSystem(selectedAnalysis.access?.system || false);
        }
    }, [selectedAnalysis, analysis]);

    useEffect(() => {
        selectedAnalysis ? setIsUpdate(false) : setIsUpdate(true);
        if (!selectedAnalysis) {
            setUsers([]);
            setDept(false);
            setSystem(false);
        }
        setFormData((form) => ({ ...form, name: selectedAnalysis?.name }));
    }, [selectedAnalysis]);

    function clear() {
        setOpenDialog(false);
    }

    function createView(key) {
        if (!formData?.name) {
            errorNotification.next({
                type: "error",
                text: `Please enter analysis name`,
                open: true,
            });
            return;
        }
        const name = formData.name?.trim();

        setFormData({ ...formData, [key]: true });
        updateAnalysis(key, { name: name, access: { system: system, dept: dept, users: users } });
        clear();
    }

    return (
        <div className="ps-3">
            <FTIconButton
                handler={() => clearPage()}
                title="Clear"
                btnIcon={<ClearIcon />}
                placement="top"
                hideBgColor={true}
            />
            <FTIconButton
                handler={() => setOpenDialog(true)}
                title="Save Analysis"
                btnIcon={<img src={viewIcon} />}
                placement="top"
                hideBgColor={true}
            />
            <Dialog open={openDialog} onClose={() => setOpenDialog(false)} fullWidth maxWidth="sm">
                <BootstrapDialogTitle id="dialog-title" onClose={() => setOpenDialog(false)}>
                    Save analysis template
                </BootstrapDialogTitle>
                <DialogContent dividers>
                    <TextField
                        id="name"
                        label="Analysis Name"
                        onChange={(e) => onChange("name", e.target.value)}
                        autoComplete="off"
                        variant="standard"
                        value={formData?.name || ""}
                        error={false}
                        style={{ width: "100%" }}
                    />
                    <div
                        className="mt-2 pb-2 d-flex align-items-center"
                        style={{
                            borderBottom: "1px solid rgb(148 148 148)",
                        }}
                    >
                        <span className="mr-11">Share With:</span>
                        <Form.Check
                            inline
                            label="System"
                            name="system"
                            type={"checkbox"}
                            id={`inline-checkbox-1`}
                            onChange={(event) => {
                                setSystem(event.target.checked);
                            }}
                            checked={system}
                            disabled={!isAdmin ? true : users.length || dept ? true : false}
                        />
                        <Form.Check
                            inline
                            label="Dept"
                            name="dept"
                            type={"checkbox"}
                            id={`inline-checkbox-2`}
                            onChange={(event) => {
                                setDept(event.target.checked);
                            }}
                            checked={dept}
                            disabled={users.length || system ? true : false}
                        />
                        <UserSelector users={users} setUsers={setUsers} disabled={dept || system} />
                    </div>
                    <Users users={users} setUsers={setUsers} />

                    {/* <FormControlLabel label="Users" control={<Dropdown>
                            <OptionGroupUnstyled>test</OptionGroupUnstyled>
                        </Dropdown>} /> */}
                </DialogContent>
                <DialogActions>
                    <div className="w-50">
                        {/* <AdornedButton
                            size={"small"}
                            className="text-capitalize"
                            variant="contained"
                            onClick={() => setOpenDialog(false)}
                            color="secondary"
                        >
                            {" "}
                            Close{" "}
                        </AdornedButton> */}
                        <button
                            type="button"
                            className="btn btn-danger btn-sm text-capitalize"
                            onClick={() => setOpenDialog(false)}
                        >
                            Cancel
                        </button>
                    </div>
                    <div className="w-50 d-flex justify-content-end">
                        <button
                            type="button"
                            className="btn btn-secondary btn-sm text-capitalize"
                            onClick={() => createView("update")}
                            disabled={
                                isUpdate ||
                                !(selectedAnalysis?.is_editable || !selectedAnalysis?.["author-id"]) ||
                                !(!analysisSet.has(formData?.name) || selectedAnalysis?.name === formData?.name)
                            }
                        >
                            Update
                        </button>
                        <div style={{ paddingLeft: "8px" }}>
                            <button
                                type="button"
                                className="btn btn-primary btn-sm text-capitalize"
                                onClick={() => createView("create")}
                                disabled={analysisSet.has(formData?.name)}
                            >
                                Create
                            </button>
                        </div>
                    </div>
                </DialogActions>
            </Dialog>
        </div>
    );
}

export default function AnalysisMenu({ analysis, selectedAnalysis, selectAnalysis, updateAnalysis, clearPage }) {
    const [confirmOpen, setConfirmOpen] = useState(false);
    const options = analysis?.map((v: any) => ({
        key: v?._id?.$oid,
        value: v["author-id"] === Access.userInfo.uuid || !v["author-id"] ? v?.name : v?.name + ` (${v?.author})`,
    }));
    options.sort((a, b) => a.value.localeCompare(b.value));
    options.unshift({ key: "_default_", value: "(Default)" });
    return (
        <>
            <div style={{ width: "200px", paddingTop: "8px" }}>
                <FTSelect
                    placeholder="Analysis"
                    value={selectedAnalysis?._id?.$oid || "_default_"}
                    onChange={(value) => selectAnalysis(value)}
                    options={options}
                />
            </div>
            <AnalysisDialog
                selectedAnalysis={selectedAnalysis}
                analysis={analysis}
                updateAnalysis={updateAnalysis}
                clearPage={clearPage}
            />
            {confirmOpen && (
                <ConfirmDialog
                    title={`Delete?`}
                    open={confirmOpen}
                    setOpen={setConfirmOpen}
                    stopPropagation={true}
                    onConfirm={(e) => {
                        e?.stopPropagation();
                        updateAnalysis("delete");
                    }}
                >
                    Are you sure you want to delete <b>{selectedAnalysis.name}</b>?
                </ConfirmDialog>
            )}
            {selectedAnalysis && (
                <FTIconButton
                    handler={() => setConfirmOpen(true)}
                    title="Delete analysis"
                    btnIcon={<DeleteIcon />}
                    placement="top"
                    hideBgColor={true}
                />
            )}
        </>
    );
}
