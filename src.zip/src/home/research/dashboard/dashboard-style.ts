import makeStyles from "@mui/styles/makeStyles";
import createStyles from "@mui/styles/createStyles";

export const useStyles = makeStyles(() =>
    createStyles({
        base: {
            width: "100%",
            display: "flex",
        },
        leftPanel: {
            width: "80%",
        },
        rightPanel: {
            width: "20%",
            height: "auto",
        },
        container: {
            width: "100%",
            paddingTop: "8px",
            display: "flex",
            flexDirection: "row",
        },
        item: {
            display: "flex",
            flexDirection: "column",
            padding: "0 12px",
        },
        rowGrid: {
            display: "flex",
            width: "75%",
            paddingBottom: "30px",
        },
        formControlRow: {
            // borderBottom: "2px solid red",
            width: "33%",
            display: "flex",
            paddingRight: "8px",
            paddingLeft: "8px",
            alignItems: "center",
        },
        formControl: {
            paddingBottom: "25px",
            width: "100%",
            display: "flex",
        },
        separator: {
            borderRight: "2px solid grey",
        },
        btn: {
            textTransform: "capitalize",
        },
        cardGrid: {
            display: "flex",
            flexDirection: "row",
            flexWrap: "wrap",
            alignItems: "flex-start",
            justifyContent: "flex-start",
        },
        inputLabel: {
            color: "rgba(0, 0, 0, 0.6)",
            fontWeight: 400,
            fontSize: ".75rem",
            lineHeight: "1.4375em",
            letterSpacing: "0.04938em",
        },
    })
);
