import React from "react";
import makeStyles from "@mui/styles/makeStyles";
import createStyles from "@mui/styles/createStyles";
import IconButton from "@mui/material/IconButton";
import CancelIcon from "@mui/icons-material/Cancel";
import FileCopyIcon from "@mui/icons-material/FileCopy";
import Tooltip from "@mui/material/Tooltip";

export const useStyles = makeStyles(() =>
    createStyles({
        container: {
            display: "flex",
            justifyContent: "center",
            flex: "0 0 20%",
            paddingTop: "5px",
        },
        card: {
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            justifyItems: "center",
            width: "140px",
            height: "72px",
            margin: "3px",
            borderRadius: "5px",
            position: "relative",
        },
        btnClose: {
            border: "0px",
            backgroundColor: "white !important",
            right: "6px",
            position: "absolute",
            top: "-3px",
            color: "black",
            padding: "2px",
            width: "10px",
            height: "10px",
            transition: "all 0.1s ease-in",
        },
        btnCopy: {
            border: "0px",
            right: "28px",
            position: "absolute",
            top: "-3px",
            color: "black",
            padding: "2px",
            width: "10px",
            height: "10px",
            transition: "all 0.1s ease-in",
        },
        title: {
            display: "block",
            fontFamily: "Roboto",
            fontSize: "10pt",
            fontWeight: "600",
            margin: "0",
            paddingTop: "8px",
            textAlign: "center",
            color: "inherit",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
            overflow: "hidden",
            paddingLeft: "3px",
            paddingRight: "3px",
        },
        separator: {
            color: "rgb(123, 128, 128)",
            display: "block",
            fontFamily: "Roboto",
            fontSize: "8pt",
            fontWeight: "400",
            justifyItems: "center",
            margin: "0",
            paddingTop: "1px",
            textAlign: "center",
        },
        funds: {
            borderBottom: "2px solid white",
            borderTopLeftRadius: "5px",
            borderTopRightRadius: "5px",
            height: "35px",
        },
        fund1: { backgroundColor: "rgb(28, 117, 188)" },
        fund2: { backgroundColor: "rgb(247, 148, 29)" },
        fund3: { backgroundColor: "rgb(249, 237, 50)" },
        vs: {
            backgroundColor: "rgb(209, 206, 206)",
            borderRadius: "8px",
            height: "16px",
            position: "absolute",
            right: "60px",
            width: "16px",
            zIndex: "1",
        },
        benchmarks: {
            height: "35px",
            borderBottomLeftRadius: "5px",
            borderBottomRightRadius: "5px",
        },
        benchmark1: { backgroundColor: "rgb(141, 198, 63)" },
        benchmark2: { backgroundColor: "rgb(148, 77, 177)" },
        benchmark3: { backgroundColor: "rgb(241, 90, 41)" },
    })
);

const colors = [
    [{ backgroundColor: "rgb(87, 132, 186)", color: "#fff" }, { backgroundColor: "rgb(147, 206, 181)" }],
    [{ backgroundColor: "rgb(249, 150, 139)" }, { backgroundColor: "rgb(161, 93, 152)", color: "#fff" }],
    [{ backgroundColor: "rgb(244, 200, 21)" }, { backgroundColor: "rgb(236, 132, 97)", color: "#fff" }],
    [{ backgroundColor: "rgb(179, 142, 171)", color: "#fff" }, { backgroundColor: "rgb(127, 188, 192)" }],
    [{ backgroundColor: "rgb(132, 166, 214)", color: "#fff" }, { backgroundColor: "rgb(247, 206, 118)" }],
    [{ backgroundColor: "rgb(173, 169, 80)" }, { backgroundColor: "rgb(219, 147, 165)", color: "#fff" }],
];

export default function FundsInfo({ item, groupId, index, onDelete, onCopy, models }) {
    const classes = useStyles();
    const fundId = groupId === "funds" ? "fund" : "factFund";
    const benchId = groupId === "funds" ? "benchmark" : "factBenchmark";
    const colorStyle = colors[index % colors.length];

    const getModelName = (model_id) => models.find((m) => m.id == model_id)?.key;
    const fund = item?.[fundId];
    const bench = item?.[benchId];
    const fundName =
        fund?.model_id != null ? getModelName(fund?.model_id) : fund?.bb_ticker || fund?.symbol || fund?.entity_name;
    const benchmarkName =
        bench?.model_id != null
            ? getModelName(bench?.model_id)
            : bench?.bb_ticker || bench?.symbol || bench?.entity_name;

    return (
        <div className="mx-1 mb-3">
            <div className={classes.card}>
                <IconButton size="small" aria-label="close" onClick={() => onDelete(item)} className={classes.btnClose}>
                    <CancelIcon style={{ fontSize: "1.3rem" }} className="pointer text-danger" />
                </IconButton>
                <IconButton size="small" aria-label="close" onClick={() => onCopy(item)} className={classes.btnCopy}>
                    <FileCopyIcon style={{ fontSize: "1.3rem" }} className="pointer text-success" />
                </IconButton>
                <div className={classes.funds} style={colorStyle[0]}>
                    <Tooltip title={fundName} aria-label="add" placement="top">
                        <h2 className={classes.title}>{fundName}</h2>
                    </Tooltip>
                </div>
                {groupId === "factors" && !benchmarkName ? (
                    <div className={classes.benchmarks} />
                ) : (
                    <>
                        <div className={classes.vs}>
                            <p className={classes.separator}> vs</p>
                        </div>
                        <div className={classes.benchmarks} style={colorStyle[1]}>
                            <Tooltip title={benchmarkName} aria-label="add" placement="bottom">
                                <h3 className={classes.title} style={{ paddingTop: "9px" }}>
                                    {benchmarkName}
                                </h3>
                            </Tooltip>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}
