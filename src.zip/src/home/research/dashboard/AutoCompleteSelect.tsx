import React from "react";
import AutocompleteField from "common/AutocompleteField";
import { getQueryParams } from "./dashboard-config";
import Api from "utils/api";

export default function AutoCompleteSelect({
    fieldId,
    value = null,
    placeholder = "",
    handleChange,
    label = "",
    disabled = false,
}: any) {
    const getLabel = (x) => (x.bb_ticker ? `${x.bb_ticker} - ${x.entity_name}` : x.entity_name);
    let [scroll_id] = React.useState<any>(null);

    function getFundCategories(e: any) {
        const fundTypes = [
            { id: "PRICE", label: "Price" },
            { id: "NET", label: "Net" },
            { id: "TOTAL", label: "Total" },
        ];
        return fundTypes.map((type) => ({
            ...e,
            entity_name: `${e?.entity_name} - ${type?.label}`,
            type: type.id,
        }));
    }

    const valueProvider = (query, more) => {
        if (!query && !(more && scroll_id)) {
            return Promise.resolve([[], 0]);
        }
        const queryParams = more ? { scroll_id } : getQueryParams(query);
        scroll_id = null;
        return Api.entitySearchRBA(queryParams).then((data) => {
            scroll_id = data.entities.length ? data.scroll_id : null;
            let entities: any = [];
            data.entities.forEach((entity) => {
                if (entity?.entity_type == "INDEX") {
                    const newItems = getFundCategories(entity);
                    entities = [...entities, ...newItems];
                } else {
                    entities.push(entity);
                }
            });
            return [entities.map((x) => ({ ...x, id: x.entity_id, label: getLabel(x) })), data.total_records];
        });
    };

    const RenderOption = function (props, option) {
        const first = props["data-option-index"] == 0;
        return (
            <>
                {first ? (
                    <li {...props} style={{ position: "sticky", top: "0px", background: "white" }}>
                        <div className="col-2 text-truncate ft-grid-header">Ticker</div>
                        <div className="col-5 text-truncate ft-grid-header">Entity Name</div>
                        <div className="col-2 text-truncate ft-grid-header">FS_BM_ID</div>
                        <div className="col-2 text-truncate ft-grid-header">MSTAR_ID</div>
                        <div className="col-1 text-truncate ft-grid-header">Type</div>
                    </li>
                ) : (
                    <></>
                )}
                <li {...props} style={{ fontSize: "14px" }} key={option.entity_id}>
                    <div className="col-2 text-truncate">{option.bb_ticker || option.symbol}</div>
                    <div className="col-5 text-truncate">{option.entity_name}</div>
                    <div className="col-2 text-truncate">{option.fs_bm_id}</div>
                    <div className="col-2 text-truncate">{option.mstar_id}</div>
                    <div className="col-1 text-truncate">{option.entity_type}</div>
                </li>
            </>
        );
    };

    return (
        <AutocompleteField
            placeholder={placeholder}
            label={label}
            provider={valueProvider}
            onChange={(_, info) => handleChange(fieldId, info)}
            value={value}
            disabled={disabled}
            isGrouped={true}
            inputPropsStyle={{ height: "33px" }}
            renderOption={RenderOption}
            popperWidth="1000px"
        />
    );
}
