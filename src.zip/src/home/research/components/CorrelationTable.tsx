import React from "react";
import { RBAModelReturnRiskContext } from "utils/context";
import { getSlantedTextPadding, toFixed, unique } from "utils/helpers";
import { Cover } from "../Cover";
import { toRecords } from "../utils";
import { FTGrid } from "./FTGrid";

export function CorrelationTable() {
    const { pair } = React.useContext(RBAModelReturnRiskContext);
    if (!pair?.model_correlations) return <></>;

    const model_correlation_recs = toRecords(pair?.model_correlations);

    const headerClass = "ft-grid-td-div-span slanted-text"
    const cellClass = val => val == null ? "ft-grid-td-c gray-bg" : val < 0 ? "ft-grid-td-c red-value" : "ft-grid-td-c"
    const cellClass2 = () => "ft-grid-td-div-span"
    const format = val => toFixed(val)

    const getLen = (name) => name == 'Portfolio' ? 1001 : name == 'Benchmark' ? 1000 : name?.length
    const sortFn = (a, b) => getLen(b) - getLen(a)
    const unique_names: any  = unique(model_correlation_recs?.flatMap(x => [x.name1, x.name2]) || []).sort(sortFn)
    const cols= [{headerName: '', field: 'name', cellClass: cellClass2, width: 350},
     ...unique_names.map(x => ({headerName: x, field: x, format, cellClass, headerClass, width: 50 })).slice(1)]

    const [paddingTop, paddingRight] = getSlantedTextPadding(cols.map(c => c.headerName))

    const corr_map = {}
    model_correlation_recs?.forEach(x => {
        if (!(x.name1 in corr_map)) {
            corr_map[x.name1] = {}
        }
        if (!(x.name2 in corr_map)) {
            corr_map[x.name2] = {};
        }
        corr_map[x.name1][x.name2] = x.correlation
        corr_map[x.name2][x.name1] = x.correlation
    })

    const rows = unique_names.map((name1: string, i) => {
            const rec = {name: name1}
            unique_names.filter((_, j) => j > i).forEach((name2: string) => { rec[name2] = corr_map[name1]?.[name2] })
            return rec
        }).slice(0, -1)

    console.log("ROWS", rows)

    return <Cover title={"Correlations"}>
        <div style={{paddingTop, paddingRight }}>
            <FTGrid columnDefs={cols} rowData={rows}></FTGrid>
        </div>
    </Cover>
}
