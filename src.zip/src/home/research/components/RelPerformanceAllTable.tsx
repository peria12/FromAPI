import React from "react";
import { getYears, rowsForRelPerf } from "../utils";
import { RBAContext } from "utils/context";
import { FTGrid } from "./FTGrid";
import { Cover } from "../Cover";

export function RelPerformanceAllTable() {
    const { pairs, getFundBenchNames } = React.useContext(RBAContext);

    const headerClass = "ft-grid-th-div-span";
    const cellClass = (val) => (val < 0 ? "ft-grid-td red-value" : "ft-grid-td");
    const cellClass2 = () => "ft-grid-td-div-span ft-border-right";
    const width = 58.73684;
    const pct = true;

    const cols = [
        { headerName: "Fund", field: "fundName", minWidth: 150, maxWidth: 400, cellClass: cellClass2, headerClass },
        { headerName: "Bechmark", field: "benchName", minWidth: 150, maxWidth: 400, cellClass: cellClass2, headerClass },
        { headerName: "1M", field: "1M", width, cellClass, headerClass, pct },
        { headerName: "3M", field: "3M", width, cellClass, headerClass, pct },
        { headerName: "6M", field: "6M", width, cellClass, headerClass, pct },
        { headerName: "1Y", field: "1Y", width, cellClass, headerClass, pct },
        { headerName: "3Y", field: "3Y", width, cellClass, headerClass, pct },
        { headerName: "5Y", field: "5Y", width, cellClass, headerClass, pct },
        { headerName: "7Y", field: "7Y", width, cellClass, headerClass, pct },
        { headerName: "10Y", field: "10Y", width, cellClass, headerClass, pct },
        ...getYears(pairs).map((y: any) => ({ headerName: y.year_display, field: y.year, width, cellClass, headerClass, pct })),
    ];

    const getRows = () => {
        return pairs.filter((x) => x).map((p) => rowsForRelPerf(p, getFundBenchNames)) || [];
    };

    return (
        <Cover title={"Performance - Relative"}>
            <FTGrid columnDefs={cols} rowData={getRows()}></FTGrid>
        </Cover>
    );
}
