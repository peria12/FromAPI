import { HChart } from "common/HChart";
import React from "react";
import { RBAModelReturnRiskContext } from "utils/context";
import { toRecords } from "../utils";

export function Rolling18MonthStatChart() {
    const { pair, fundName } = React.useContext(RBAModelReturnRiskContext);

    const getOptions = () => {
        const recs = toRecords(pair?.rolling_18m_a_b)?.map((x) => ({
            ...x,
            date: new Date(x.date).getTime(),
        }));
        return {
            title: {
                text: "",
            },
            xAxis: {
                type: "datetime",
            },
            yAxis: [
                {
                    title: {
                        text: "",
                    },
                    labels: { format: "{text} %" },
                    alignTicks: false,
                    plotLines: [
                        {
                            value: 0,
                            width: 2,
                        },
                    ],
                },
                {
                    title: {
                        text: "",
                    },
                    opposite: true,
                    alignTicks: false,
                },
            ],
            tooltip: {
                valueDecimals: 2,
            },
            series: [
                {
                    name: `${fundName} vs Benchmark`,
                    yAxis: 0,
                    type: "line",
                    marker: {
                        enabled: false,
                    },
                    data: recs?.map((x) => [x.date, 100.0 * (x.fund_return - x.bench_return)]) || [],
                },
                {
                    name: "Alpha (LHS)",
                    type: "line",
                    dashStyle: 'shortdash',
                    color: "orange",
                    data: recs?.map((x) => [x.date, 100.0 * x.alpha]) || [],
                    marker: { enabled: false }
                },
                {
                    name: "TE (LHS)",
                    type: "line",
                    dashStyle: "longdash",
                    color: "#de161d",
                    data: recs?.map((x) => [x.date, 100.0 * x.te]) || [],
                    marker: { enabled: false }
                },
                {
                    name: "Beta (RHS)",
                    yAxis: 1,
                    type: "line",
                    color: "#57b6ba",
                    dashStyle: 'shortdot',
                    data: recs?.map((x) => [x.date, x.beta]) || [],
                    marker: { enabled: false }
                },
            ],
        };
    };

    return (
        <div className="rounded bg-white border me-2 mb-2 p-1 flex-fill">
            <div className="ft-card-header mb-3">Rolling 18M Excess Return - Alpha / Beta / TE vs Benchmark</div>
            <HChart option={getOptions()}></HChart>
        </div>
    );
}
