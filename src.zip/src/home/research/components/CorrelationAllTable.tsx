import React from "react";
import { toRecords } from "../utils";
import { RBAContext } from "utils/context";
import { FTGrid } from "./FTGrid";
import { Cover } from "../Cover";
import { getSlantedTextPadding, unique } from "utils/helpers";

export function CorrelationAllTable() {
    const { data, getEntityName } = React.useContext(RBAContext);

    const cellClass = (val) =>
        val == null ? "ft-grid-td-c gray-bg" : val < 0 ? "ft-grid-td-c red-value" : "ft-grid-td-c";
    const cellClassB = (val) => `${cellClass(val)} ft-border-left`;
    const cellClass2 = () => "ft-grid-td-div-span";
    const getName = (x) => {
        const [id_type, id_value, bench_id_type, bench_id_value] = x.split(":");
        const name1 = getEntityName(id_type, id_value);
        const name2 = getEntityName(bench_id_type, bench_id_value);
        return `${name1} - ${name2}`;
    };

    const corr_recs = toRecords(data?.excess_return_correlations);

    if (!corr_recs?.length) return <></>;

    const get_key1 = (x) => `${x.id_type1}:${x.id_value1}:${x.bench_id_type1}:${x.bench_id_value1}`;
    const get_key2 = (x) => `${x.id_type2}:${x.id_value2}:${x.bench_id_type2}:${x.bench_id_value2}`;

    const names1 = corr_recs?.map(get_key1) || [];
    const names2 = corr_recs?.map(get_key2) || [];
    const unique_names: any = unique([...names1, ...names2]).sort(
        (a: any, b: any) => getName(b).length - getName(a).length
    );

    const headerC = "ft-grid-td-div-span slanted-text";
    const headerClass = "ft-grid-th-div-span text-center";

    const names_3y = unique_names
        .filter((_, i) => i)
        .map((x, i) => ({
            headerName: getName(x),
            field: `${x}_3_year_correlation`,
            width: 50,
            cellClass: i ? cellClass : cellClassB,
            headerClass: headerC,
        }));
    const names_5y = unique_names
        .filter((_, i) => i)
        .map((x, i) => ({
            headerName: getName(x),
            field: `${x}_5_year_correlation`,
            width: 50,
            cellClass: i ? cellClass : cellClassB,
            headerClass: headerC,
        }));
    const [paddingTop, paddingRight] = getSlantedTextPadding(names_5y.map((c) => c.headerName));

    const corr_map = {};
    corr_recs?.forEach((x) => {
        const key1 = get_key1(x);
        const key2 = get_key2(x);
        if (!(key1 in corr_map)) {
            corr_map[key1] = {};
        }
        if (!(key2 in corr_map)) {
            corr_map[key2] = {};
        }
        corr_map[key1][key2] = x;
        corr_map[key2][key1] = x;
    });

    const rows = unique_names
        .map((name1: string, i) => {
            const rec = { name: name1, entity_name: getName(name1) };
            unique_names
                ?.filter((_, j) => j > i)
                .forEach((name2: string) => {
                    rec[`${name2}_3_year_correlation`] = corr_map[name1]?.[name2]?.corr_3yr;
                    rec[`${name2}_5_year_correlation`] = corr_map[name1]?.[name2]?.corr_5yr;
                });
            return rec;
        })
        .slice(0, -1);

    const width = Math.max(...rows.map((a) => a.entity_name?.length * 6 || 0), 200);

    const cols = [
        [
            { headerName: "", colSpan: 1 },
            { headerName: "3Y", colSpan: names_3y.length, headerClass },
            { headerName: "", colSpan: 1 },
            { headerName: "5Y", colSpan: names_5y.length, headerClass },
        ],
        [{ headerName: "", headerStyle: { height: paddingTop } }], // padding
        [
            { headerName: "", field: "entity_name", width, cellClass: cellClass2, headerClass: headerC },
            ...names_3y,
            { width: paddingRight },
            ...names_5y,
        ],
    ];
    if (!rows.length) return <></>;

    return (
        <Cover title={"Excess Return Correlations"}>
            <div style={{ paddingRight }}>
                <FTGrid columnDefs={cols} rowData={rows} />
            </div>
        </Cover>
    );
}
