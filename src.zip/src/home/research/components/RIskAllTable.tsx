import React from "react";
import { toRecords } from "../utils";
import { RBAContext } from "utils/context";
import { FTGrid } from "./FTGrid";
import { Cover } from "../Cover";

export function RiskAllTable() {
    const { pairs, getFundBenchNames } = React.useContext(RBAContext);

    const headerClass = "ft-grid-th-div-span";
    const headerClassC = "ft-grid-th-div-span text-center";
    const headerClassB = "ft-grid-th-div-span ft-border-right";
    const cellClass = (val) => (val < 0 ? "ft-grid-td red-value" : "ft-grid-td");
    const cellClass2B = () => "ft-grid-td-div-span ft-border-right";

    const upCapClass = (val, row) => "ft-grid-td " + (row.up_cap_color > 0 ? "green-value" : "red-value");
    const downCapClass = (val, row) =>
        "ft-border-right ft-grid-td " + (row.down_cap_color > 0 ? "green-value" : "red-value");

    const downCapClassNB = (val, row) => "ft-grid-td " + (row.down_cap_color > 0 ? "green-value" : "red-value");

    const width = 62;
    const pct = true;

    const cols = [
        [
            { headerName: "", colSpan: 2 },
            { headerName: "3Y", colSpan: 9, headerClass: headerClassC },
            { headerName: "5Y", colSpan: 9, headerClass: headerClassC },
        ],
        [
            { headerName: "Fund", field: "fundName", minWidth: 100, maxWidth: 400, cellClass: cellClass2B, headerClass },
            {
                headerName: "Benchmark",
                field: "benchName",
                minWidth: 100,
                maxWidth: 400,
                cellClass: cellClass2B,
                headerClass: headerClass,
            },
            { headerName: "𝜎(P)", field: "fund_std", width, cellClass, headerClass, pct },
            { headerName: "𝜎(BM)", field: "bench_std", width, cellClass, headerClass, pct },
            { headerName: "Beta", field: "beta", width, cellClass, headerClass },
            { headerName: "TE", field: "te", width, cellClass, headerClass, pct },
            { headerName: "Alpha", field: "alpha", width, cellClass, headerClass, pct },
            { headerName: "Sharpe", field: "sharpe_ratio", width, cellClass, headerClass },
            { headerName: "IR", field: "ir", width, cellClass, headerClass },
            { headerName: "UpCap", field: "up_cap", width, cellClass: upCapClass, headerClass, pct },
            {
                headerName: "DownCap",
                field: "down_cap",
                width,
                cellClass: downCapClass,
                headerClass: headerClassB,
                pct,
            },
            { headerName: "𝜎(P)", field: "fund_std_5y", width, cellClass, headerClass, pct },
            { headerName: "𝜎(BM)", field: "bench_std_5y", width, cellClass, headerClass, pct },
            { headerName: "Beta", field: "beta_5y", width, cellClass, headerClass },
            { headerName: "TE", field: "te_5y", width, cellClass, headerClass, pct },
            { headerName: "Alpha", field: "alpha_5y", width, cellClass, headerClass, pct },
            { headerName: "Sharpe", field: "sharpe_ratio_5y", width, cellClass, headerClass },
            { headerName: "IR", field: "ir_5y", width, cellClass, headerClass },
            { headerName: "UpCap", field: "up_cap_5y", width, cellClass: upCapClass, headerClass, pct },
            { headerName: "DownCap", field: "down_cap_5y", width, cellClass: downCapClassNB, headerClass, pct },
        ],
    ];

    const getRows = () => {
        return (
            pairs
                .filter((x) => x)
                .map((p) => {
                    const recs = toRecords(p?.stats);
                    const [fundName, benchName] = getFundBenchNames(p);
                    const y3 = recs?.find((x) => x.months == 36) || {};
                    const y5 = recs?.find((x) => x.months == 60) || {};
                    const y5_mod = Object.keys(y5).reduce((d, v) => {
                        d[`${v}_5y`] = y5[v];
                        return d;
                    }, {});
                    return { fundName, benchName, ...y3, ...y5_mod };
                }) || []
        );
    };

    return (
        <Cover title={"Risk - Absolute/Relative"}>
            <FTGrid columnDefs={cols} rowData={getRows()}></FTGrid>
        </Cover>
    );
}
