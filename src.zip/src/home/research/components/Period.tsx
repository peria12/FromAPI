import React from "react";
import { RBAModelReturnRiskContext } from "utils/context";
import { toRecords } from "../utils";

export function Period() {
    const { fund_returns, pair } = React.useContext(RBAModelReturnRiskContext);

    const date_last = fund_returns[0]?.date;
    const date_first = fund_returns[fund_returns.length - 1]?.date;
    // TODO check why the order is reveresed sometimes
    const [startDate, endDate] = date_first < date_last ? [date_first, date_last] : [date_last, date_first];
    const months = pair ? Math.max(...toRecords(pair.stats).map((x) => x.months)) : 0;

    return (
        <>
            <div className="ft-grid-th-div-span" style={{ lineHeight: "30px" }}>
                Period:&nbsp;
            </div>
            <div className="fw-bold font-rc fst-italic font-20">
                {startDate} - {endDate}
            </div>
            <div className="ft-grid-th-div-span ms-3" style={{ lineHeight: "30px" }}>
                Entire Period:&nbsp;
            </div>
            <div className="fw-bold font-rc fst-italic font-20">{months} Months</div>
        </>
    );
}
