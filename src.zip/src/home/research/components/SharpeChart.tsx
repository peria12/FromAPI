import { HChart } from "common/HChart";
import React from "react";
import { RBAModelReturnRiskContext } from "utils/context";
import { toFixed } from "utils/helpers";
import { getMaxAbsPerf, toRecords } from "../utils";

export function SharpeChart() {
    const { pair } = React.useContext(RBAModelReturnRiskContext);
    if (!pair) return <>NA</>;

    const data = pair.stats;
    const stat_recs = toRecords(pair?.stats);
    const max_month = Math.max(...stat_recs.map((x) => x.months));
    const max_rec = stat_recs.find((x) => x.months == max_month);
    const sharpe = max_rec?.sharpe_ratio;
    const sharpe_bm = max_rec?.bench_sharpe_ratio;
    const maxAbsPerf = getMaxAbsPerf(pair);
    const pfIndex = data?.columns.indexOf("fund_std");
    const benchIndex = data?.columns.indexOf("bench_std");
    const latestRecords = data?.records[data?.records?.length - 1];
    const max =
        Math.max(latestRecords?.[pfIndex], latestRecords?.[benchIndex], maxAbsPerf?.return, maxAbsPerf?.bench_return) *
        110;
    const min = sharpe < 0 || sharpe_bm < 0 ? -max : 0;

    const getOptions = () => {
        return {
            title: "",
            xAxis: {
                tickInterval: 5,
                gridLineWidth: 1,
                min: 0, // min * 1.2,
                title: { text: "Annualized Standard Deviation" },
                max: max * 1.2,
                labels: { format: "{text} %" },
            },
            yAxis: {
                tickInterval: 5,
                min,
                title: { text: "Annualized Return" },
                labels: { format: "{text} %" },
                max,
            },
            plotOptions: {
                scatter: {},
            },
            tooltip: {
                valueDecimals: 2,
                shared: true,
                pointFormat: "Std Dev: {point.x:.2f}%, Return: {point.y:.2f}%",
            },
            series: [
                {
                    type: "line",
                    showInLegend: false,
                    dashStyle: "dash",
                    marker: {
                        enabled: false,
                    },
                    states: {
                        hover: {
                            lineWidth: 0,
                        },
                    },
                    enableMouseTracking: false,
                    color: "#FA9375",
                    data: [
                        [0, 0],
                        [max * 2, max * 2],
                    ],
                },
                {
                    type: "scatter",
                    name: "Fund",
                    data: [[latestRecords?.[pfIndex] * 100, maxAbsPerf?.return * 100]],
                    marker: {
                        radius: 4,
                        symbol: "circle",
                    },
                    dataLabels: {
                        enabled: true,
                        formatter: function () {
                            return `Fund: ${toFixed(sharpe)}`;
                        },
                    },
                },
                {
                    type: "scatter",
                    name: "Benchmark",
                    data: [[latestRecords?.[benchIndex] * 100, maxAbsPerf?.bench_return * 100]],
                    marker: {
                        radius: 4,
                        symbol: "circle",
                    },
                    dataLabels: {
                        enabled: true,
                        formatter: function () {
                            return `Benchmark: ${toFixed(sharpe_bm)}`;
                        },
                    },
                },
            ],
        };
    };

    return (
        <div className="rounded bg-white border mb-2 p-1" style={{ width: 320 }}>
            <div className="ft-card-header mb-3">Sharpe</div>
            <div className="d-flex justify-content-center">
                <div style={{ width: min < 0 ? "70%" : "100%" }}>
                    <HChart option={getOptions()}></HChart>
                </div>
            </div>
        </div>
    );
}
