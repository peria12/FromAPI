import { HChart } from "common/HChart";
import React from "react";
import { RBAModelReturnRiskContext } from "utils/context";
import { toFixed } from "utils/helpers";

export function ExcessRetDistChart() {
    const { pair, fundName } = React.useContext(RBAModelReturnRiskContext);

    const getOptions = () => {
        const dist = pair?.distribution;

        return {
            title: {
                text: "Excess Return Distribution",
                align: "center",
            },
            subtitle: {
                text: `Kurtosis: ${toFixed(dist?.kurtosis)}, Skew: ${toFixed(dist?.skew)}`,
            },
            xAxis: {
                crosshair: true,
                labels: {
                    format: "{text} %",
                },
            },
            yAxis: [{ title: { text: "" } }, { title: { text: "" }, opposite: true }],
            tooltip: {
                valueDecimals: 2,
                headerFormat: "{point.key:.2f} % <br>",
                shared: true,
            },
            series: [
                {
                    name: `${fundName} vs Benchmark (LHS)`,
                    type: "column",
                    yAxis: 0,
                    color: "#FA9375",
                    pointWidth: 15,
                    data: dist?.bins.map(([x, y]) => [x * 100, y]) || [],
                    tooltip: {
                        valueSuffix: "%",
                    },
                },
                {
                    name: "Normalized Distribution (RHS)",
                    type: "line",
                    yAxis: 1,
                    dashStyle: "dash",
                    color: "#57DFD4",
                    marker: {
                        enabled: false,
                    },
                    data: dist?.bell_curve.map(([x, y]) => [x * 100, y]) || [],
                },
            ],
        };
    };

    return (
        <div>
            <HChart option={getOptions()}></HChart>
        </div>
    );
}
