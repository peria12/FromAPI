import { HChart } from "common/HChart";
import React from "react";
import { RBAModelReturnRiskContext } from "utils/context";

export function ReturnProfileChart() {
    const { fund_returns, bench_returns, fundName, benchName } = React.useContext(RBAModelReturnRiskContext);

    const getCumReturnData = () => {
        return {
            credits: { enabled: false },
            title: { text: "" },
            subtitle: { text: "" },
            yAxis: [{ title: { text: "" }, tickInterval: 25 }],
            xAxis: {
                type: "datetime",
            },
            legend: {},
            plotOptions: {
                line: {
                    marker: { enabled: false },
                },
            },
            tooltip: {
                valueDecimals: 2,
                shared: true,
            },

            series: [
                {
                    name: fundName,
                    color: "#FA9375",
                    data: fund_returns?.map((ele) => [new Date(ele.date).getTime(), ele?.cum_return * 100 + 100]),
                },
                {
                    name: benchName,
                    color: "#57DFD4",
                    data: bench_returns?.map((ele) => [new Date(ele.date).getTime(), ele?.cum_return * 100 + 100]),
                },
            ],
        };
    };
    return <HChart option={getCumReturnData()} />;
}
