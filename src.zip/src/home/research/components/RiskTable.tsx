import React from "react";
import { RBAModelReturnRiskContext } from "utils/context";
import { color, toRecords } from "../utils";
import { FTGrid } from "./FTGrid";

export function RiskTable() {
    const { pair, fundName, benchName } = React.useContext(RBAModelReturnRiskContext);
    const recs = toRecords(pair?.stats);

    const val_3y = recs?.find((x) => x.months == 36) || {};
    const val_5y = recs?.find((x) => x.months == 60) || {};
    const val_5y_mod = Object.keys(val_5y).reduce((d, v) => {
        d[`${v}_5y`] = val_5y[v];
        return d;
    }, {});

    const rows = [{ fundName, benchName, ...val_3y, ...val_5y_mod }];
    const width = 70;
    const widthS = 71;
    const type = "rightAligned";
    const headerClass = "ft-border-right ft-grid-th-div-span";
    const headerClassLast = "ft-grid-th-div-span";
    const pct = true;

    const cellClass = (val) => `ft-border-right ft-grid-td ${color(val)}`;
    const cellClassB = () => `ft-border-right ft-grid-td`;

    const upCapClass = (val, row) => "ft-border-right ft-grid-td " + (row.up_cap_color > 0 ? "green-value" : "red-value");
    const downCapClass = (val, row) => "ft-border-right ft-grid-td " + (row.down_cap_color > 0 ? "green-value" : "red-value");

    const upCapClass5 = (val, row) => "ft-border-right ft-grid-td " + (row.up_cap_color_5y > 0 ? "green-value" : "red-value");
    const downCapClass5 = (val, row) => "ft-grid-td " + (row.down_cap_color_5y > 0 ? "green-value" : "red-value");

    const cols = [
        { headerName: "Risk", colSpan: 1, headerClass: "ft-card-header text-left" },
        { headerName: "3Y", colSpan: 9, headerClass: "ft-card-header ft-border-right text-center" },
        { headerName: "5Y", colSpan: 9, headerClass: "ft-card-header text-center" },
    ];
    const col1 = [{}];
    const col2 = [
        { headerName: "𝜎(P)", field: "fund_std", width: 200, pct, type, headerClass, cellClass: cellClassB},
        { headerName: "𝜎(BM)", field: "bench_std", width, pct, type, headerClass, cellClass: cellClassB },
        { headerName: "Beta", field: "beta", width: widthS, type, headerClass, cellClass },
        { headerName: "TE", field: "te", width: widthS, pct, type, headerClass, cellClass: cellClassB },
        { headerName: "Alpha", field: "alpha", width, pct, type, headerClass, cellClass },
        { headerName: "Sharpe", field: "sharpe_ratio", width, type, headerClass, cellClass },
        { headerName: "IR", field: "ir", width: widthS, type, headerClass, cellClass },
        { headerName: "UpCap", field: "up_cap", width, pct, type, headerClass, cellClass: upCapClass },
        { headerName: "DownCap", field: "down_cap", width, pct, type, headerClass, cellClass: downCapClass },
    ];
    const col3 = [
        { headerName: "𝜎(P)", field: "fund_std_5y", width, pct, type, headerClass, cellClass: cellClassB },
        { headerName: "𝜎(BM)", field: "bench_std_5y", width, pct, type, headerClass, cellClass: cellClassB },
        { headerName: "Beta", field: "beta_5y", width: widthS, type, headerClass, cellClass },
        { headerName: "TE", field: "te_5y", width: widthS, pct, type, headerClass, cellClass: cellClassB },
        { headerName: "Alpha", field: "alpha_5y", width, pct, type, headerClass, cellClass },
        { headerName: "Sharpe", field: "sharpe_ratio_5y", width, type, headerClass, cellClass },
        { headerName: "IR", field: "ir_5y", width: widthS, type, headerClass, cellClass },
        { headerName: "UpCap", field: "up_cap_5y", width, pct, type, headerClass, cellClass: upCapClass5 },
        {
            headerName: "DownCap",
            field: "down_cap_5y",
            width,
            pct,
            type,
            headerClass: headerClassLast,
            cellClass: downCapClass5,
        },
    ];

    const all_cols = [...col1, ...col2, ...col3];

    return (
        <div className="rounded bg-white border mb-2 p-2 w-100">
            <FTGrid columnDefs={[cols, all_cols]} rowData={rows} />
        </div>
    );
}
