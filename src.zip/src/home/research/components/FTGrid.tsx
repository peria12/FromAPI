import { AgGridReact } from "ag-grid-react";
import React, { useRef } from "react";
import { format } from "../utils";

export function FTGrid2(params) {
    const gridReady = () => {
        params.init(gridRef.current.api);
    };
    const gridRef = useRef<any>();
    return (
        <div className="ag-theme-ft" style={{ height: params.height }}>
            <AgGridReact ref={gridRef} onGridReady={gridReady} {...params} />
        </div>
    );
}

export function FTGrid({ columnDefs, rowData }) {
    const headers = Array.isArray(columnDefs?.[0]) ? columnDefs : [columnDefs];
    const dataColumnDefs = headers[headers.length - 1];

    const cellStyle = (): any => {
        return { height: "100%", paddingLeft: 3, paddingRight: 3 };
    };

    const cellStyleH = (style): any => {
        return {
            height: "100%",
            paddingLeft: 3,
            paddingRight: 3,
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
            textAlign: "right",
            ...style
        };
    };

    return (
            <table className={"ft-grid-table"}>
                {headers.map((x, i) => (
                    <tr key={i}>
                        {x.map((c, i) => (
                            <th
                                key={i}
                                colSpan={c.colSpan}
                                style={{ padding: "0px", width: c.width, maxWidth: c.maxWidth || c.width, minWidth: c.minWidth || c.width }}
                            >
                                <div style={cellStyleH(c.headerStyle || {})} className={c.headerClass || ""}>
                                    {c.headerName || <span>&nbsp;</span>}
                                </div>
                            </th>
                        ))}
                    </tr>
                ))}
                {rowData.map((row, i) => (
                    <tr key={i}>
                        {dataColumnDefs.map((c, i) => {
                            const val = row[c.field];
                            const formatted_val =
                                c.formatFn && row[c.formatFn]
                                    ? row[c.formatFn](val, row)
                                    : c.format
                                    ? c.format(val, row)
                                    : format(val, c.pct);
                            return (
                                <td key={i} style={{ padding: "0px", width: c.width, maxWidth: c.maxWidth || c.width }}>
                                    <div
                                        title={formatted_val}
                                        style={cellStyle()}
                                        className={c.cellClass ? c.cellClass(val, row) : ""}
                                    >
                                        {formatted_val || <span>&nbsp;</span>}
                                    </div>
                                </td>
                            );
                        })}
                    </tr>
                ))}
            </table>
    );
}
