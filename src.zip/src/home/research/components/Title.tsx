import React from "react";

export function Title({text}) {
    return <div className="mb-1 text-center fw-bold">{text}</div>
}