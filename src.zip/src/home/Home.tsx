import React, { useState, useEffect } from "react";
import { Switch, Route, useLocation } from "react-router-dom";

import Api from "../utils/api";
import Access from "utils/access";
import PageNotFound from "common/PageNotFound";
import Settings from "utils/settings";
import { Dashboard } from "./dashboad/Dashboard";
import TitleBar from "./TitleBar";
import EntityMaster from "home/entity-master/EntityMaster";
import ModelGenerator from "home/model-portfolios/ModelGenerator";
import EntityMasterAdmin from "home/entity-master/EntityMasterAdmin";
import Acl from "home/admin/acl/Acl";
import GroupManagement from "home/admin/groups/GroupManagement";
import AdminSettings from "home/admin/settings/AdminSettings";
import AlertSubscriptions from "home/alerts/AlertSubscriptions";
import Announcements from "home/alerts/Announcements";
import Alerts from "home/alerts/Alerts";
import PortfolioSummary from "home/portfolio/PortfoliosSummary";
import PortfolioHoldings from "home/portfolio/PortfoliosHoldings";
import SecurityHoldings from "home/portfolio/SecurityHoldings";
import Optimization from "home/portfolio/Optimization";
import Reports from "home/portfolio/Reports";
import DALFields from "home/dal/DALFields";
import WebApp from "./dal/web-app/WebApp";
import AAReports from "home/asset-allocation/AAReports";
import SAAContainer from "home/asset-allocation/mvp/saa/SAAContainer";
import DAAContainer from "./asset-allocation/mvp/daa/DAAContainer";
import PBIReport from "common/powebi/PBIReport";
import AustralianRetirementCalculator from "home/goe/calculators/AustralianRetirementCalculator";
import Clients from "home/goe/client/Clients";
import NoAccess from "home/no-access/NoAccess";
import Portfolios from "home/goe/portfolios/Portfolios";
import Actuarials from "home/goe/actuarial/Actuarials";
import ResearchGateway from "home/research-gateway/ResearchGateway";
import { AppContext } from "utils/context";
import AppCover from "./dashboad/AppCover";
import CustomApi from "./goe/apiTrigger/CustomApi";
import IFrame from "common/iframe/IFrame";
import PortfolioAnalysisHome from "./research/PortfolioAnalysisHome";
import GoeCapabilities from "./goe/goe-capabilites/GoeCapabilities";
import { GoeCapabilitiesContextProvider } from "./goe/goe-capabilites/GoeCapabilitiesContext";
import SystematicStrategies from "home/portfolio/SystematicStrategies";
import ModelPortfolio from "./portfolio-management/ModelPortfolio";
import ChartsFrames from "./goe/goe-capabilites/assets/images/svg/charts_frames.svg";
import SkipButton from "./goe/goe-capabilites/assets/images/svg/skip-button.svg";
import ProbabilityDriveImage from "./goe/goe-capabilites/assets/images/svg/Probability.svg";
import PersonalisedImage from "./goe/goe-capabilites/assets/images/svg/Personalised.svg";
import ResponsiveImage from "./goe/goe-capabilites/assets/images/svg/Responsive.svg";
import Background1 from "./goe/goe-capabilites/assets/images/svg/background1.svg";
import Background2 from "./goe/goe-capabilites/assets/images/svg/background_img2.svg";
import GoeIcon from "./goe/goe-capabilites/assets/images/svg/goe_icon.svg";

const getFullNames = (apps, app, zone) => {
    const app1 = apps.all_apps.find((x) => x._id == app);
    if (app1) {
        const zone1 = app1.zones.find((z) => z.name == zone);
        if (zone1) {
            return [app1.title, zone1.title];
        }
        return [app1.title, zone];
    }
    return [app, zone];
};
const getApp = (apps, app, zone) => {
    const app_id = app._id;
    const zone_id = zone.name;

    if (app_id == "research-gateway")
        return (
            <AppCover>
                <ResearchGateway />
            </AppCover>
        );
    else if (app_id == "systematic_strategies")
        return <Route path="/systematic_strategies/portfolio_optimization" component={SystematicStrategies} />;
    else if (app_id == "entity-master") {
        if (zone_id == "em") {
            return <EntityMaster />;
        } else if (zone_id == "operations") return <EntityMasterAdmin />;
    } else if (app_id == "admin") {
        if (zone_id == "acl") return <Acl apps={apps.all_apps as any} />;
        else if (zone_id == "groups") return <GroupManagement />;
        else if (zone_id == "settings" && Access.hasAdminAccessToAnyApp()) return <AdminSettings />;
    } else if (app_id == "alerts") {
        if (zone_id == "inbox") return <Alerts />;
        else if (zone_id == "announcements") return <Announcements apps={apps.all_apps} />;
        else if (zone_id == "subscriptions") return <AlertSubscriptions />;
    } else if (app_id == "portfolios") {
        if (zone_id == "summary") return <PortfolioSummary />;
        else if (zone_id == "holdings") {
            return <Route path="/portfolios/holdings/:entityId?" component={PortfolioHoldings} />;
        } else if (zone_id == "security_holdings") {
            return <Route path="/portfolios/security_holdings/:entityId?" component={SecurityHoldings} />;
        } else if (zone_id == "optimization")
            return <Route path="/portfolios/optimization/:optRunId" component={Optimization} />;
        else if (zone_id == "reports") return <Reports />;
        else if (zone_id == "ftis_risk_dashboard") return <AAReports app={app_id} type={zone_id} />;
        else if (zone_id == "powerbi_income_fund" && Access.hasAccess("portfolios", "powerbi_income_fund"))
            return <PBIReport />;
        else if (
            zone_id == "powerbi_franklin_income_funds" &&
            Access.hasAccess("portfolios", "powerbi_franklin_income_funds")
        )
            return <PBIReport />;
        else if (zone_id == "powerbi_account_positions" && Access.hasAccess("portfolios", "powerbi_account_positions"))
            return <PBIReport />;
    } else if (app_id == "research-tool") {
        if (zone_id == "portfolio_analysis") return <PortfolioAnalysisHome />;
    } else if (app_id == "dal") {
        if (zone_id == "fields") return <DALFields />;
        else if (zone_id == "webui") return <WebApp />;
    } else if (app_id == "aa") {
        if (zone_id == "saa" || zone_id == "daa") return <AAReports app={app_id} type={zone_id} />;
        else if (zone_id == "saa2") return <SAAContainer app={app_id} type={zone_id} />;
        else if (zone_id == "daa2") return <DAAContainer app={app_id} type={zone_id} />;
        else if (zone_id == "style_views") return <PBIReport />;
    } else if (app_id == "goe") {
        if (zone_id == "client-settings") return <Clients />;
        else if (zone_id == "portfolios") return <Portfolios />;
        else if (zone_id == "actuarials") return <Actuarials />;
        else if (zone_id == "arc") return <AustralianRetirementCalculator />;
        else if (zone_id == "custom-api") return <CustomApi />;
    } else if (app_id == "esg") {
        if (Access.hasAccess("esg", zone_id)) return <IFrame />;
    } else if (app_id == "model_portfolios") {
        if (zone_id == "file_transforms") return <ModelGenerator />;
        else if (zone_id == "portfolio_management") return <ModelPortfolio />;
    } else if (app_id == "goe-capabilities") {
        if (zone_id == "goee2e") {
            const initialGoeContext = { appId: app_id, zoneId: zone_id };
            return (
                <GoeCapabilitiesContextProvider {...initialGoeContext}>
                    <GoeCapabilities />
                </GoeCapabilitiesContextProvider>
            );
        }
    }
    return <AppCover>Not Supported.</AppCover>;
};

export default function Home() {
    const [apps, setApps] = useState({
        all_apps: [] as any[],
        allowed_apps: [] as any[],
        hasPortalAccess: null,
    });
    const { pathname } = useLocation();
    const [app_zone] = useState({ app: "default", zone: "default" });
    const [hasErrorOccurred, setHasErrorOccurred] = useState(false);
    const pathnamesubtsring = pathname.substring(0, 27);
    useEffect(() => {
        Promise.all([Api.getApps(), Access.init(), Settings.init()]).then(([all_apps, , settings]) => {
            Settings.setSettings(settings, Access.userInfo.uuid);
            all_apps = all_apps.sort((a, b) => a.view_order - b.view_order);
            setApps({
                all_apps,
                allowed_apps: all_apps.filter(checkAccess),
                hasPortalAccess: Access.hasAccessToZone("admin", "portal", ["view"]),
            });
        });
        setTimeout(() => {
            const isErrorFoundWithNetwork = Access.hasErrorOccurredInNetwork();
            if (isErrorFoundWithNetwork) setHasErrorOccurred(isErrorFoundWithNetwork);
        }, 10000);
    }, []);

    useEffect(() => {
        const paths = pathname.split("/");
        if (apps.all_apps.length > 0 && paths.length > 2) {
            if (app_zone.app != paths[1] || app_zone.zone != paths[2]) {
                app_zone.app = paths[1];
                app_zone.zone = paths[2];
                const [app_name, zone_name] = getFullNames(apps, app_zone.app, app_zone.zone);

                Api.logToLoggerService({
                    info: `User is accessing app in UI: ${app_name}:${zone_name}`,
                });
            }
        } else {
            app_zone.app = "default";
            app_zone.zone = "default";
            Api.logToLoggerService({
                info: `User is accessing app in UI: Home:Page`,
            });
        }
        // eslint-disable-next-line
    }, [pathname, apps.all_apps]);

    const checkAccess = (app) => {
        return (
            app.show_on_portal &&
            (app._id == "admin" || app.zones.some((zone) => Access.hasAccessToZone(app._id, zone.name, ["view"])))
        );
    };

    const hasAccessToGoee2e = (apps) => {
        return apps.allowed_apps.some((app) => {
            return app.id === "goe-capabilities" && app.zones.some((zone) => zone.name === "goee2e");
        });
    };
    return (
        <React.Fragment>
            {apps.hasPortalAccess == false && <PageNotFound />}
            {apps.hasPortalAccess == true && (
                <div id="parent_element">
                    {pathnamesubtsring && pathnamesubtsring.indexOf("/goe-capabilities") < 0 && (
                        <TitleBar apps={apps.allowed_apps} path={pathname}></TitleBar>
                    )}
                    <Switch>
                        <Route exact path="/">
                            <Dashboard apps={apps.allowed_apps} compact={false}></Dashboard>
                        </Route>
                        {apps.allowed_apps.map((app) => (
                            <Route key={app._id} path={`/${app._id}`}>
                                {app.zones.map((zone) => (
                                    <Route key={zone.name} path={`/${app._id}/${zone.name}`}>
                                        <AppContext.Provider value={{ app, zone }}>
                                            {getApp(apps, app, zone)}
                                        </AppContext.Provider>
                                    </Route>
                                ))}
                            </Route>
                        ))}
                        {!hasAccessToGoee2e(apps) && (
                            <Route key="goee2e" path="/goe-capabilities/goee2e">
                                <NoAccess />
                            </Route>
                        )}
                    </Switch>
                </div>
            )}
            {hasErrorOccurred ? <h1 id="networkErrorMessage">Network Error</h1> : null}

            {/* Loading Images for Goe capabilities ahead so that there is no lag when app loads */}
            <div className="goe-capabilites-image-pre-fetch">
                <img src={GoeIcon} />
                <img src={Background1} />
                <img src={Background2} />
                <img src={SkipButton}></img>
                <img className="main-image" src={ChartsFrames} alt="charts frames" />
                <img src={ProbabilityDriveImage} />
                <img src={PersonalisedImage} />
                <img src={ResponsiveImage} />
            </div>
        </React.Fragment>
    );
}
