import React from "react";
import makeStyles from "@mui/styles/makeStyles";
import InputBase from "@mui/material/InputBase";
import SearchIcon from "@mui/icons-material/Search";
import { BehaviorSubject } from "rxjs";
import { debounceTime, map, distinctUntilChanged, filter } from "rxjs/operators";
interface SearchParams {
    setSearchText(string): void;
    id?: string;
    placeholder?: string;
    width?: number | string;
    minWidth?: number | string;
    height?: number | string;
    style?: any;
}

const useStyles = makeStyles((theme) => ({
    root: {
        padding: "2px 4px",
        display: "flex",
        alignItems: "center",
    },
    input: {
        marginLeft: theme.spacing(1),
        flex: 1,
    },
}));

export default function SearchBox(props: SearchParams) {
    const { width, height, setSearchText, id, placeholder, minWidth } = props;
    const classes = useStyles();
    const subject = React.useMemo(() => new BehaviorSubject(""), []);

    React.useEffect(() => {
        subject
            .pipe(
                map((s) => s.trim()),
                distinctUntilChanged(),
                filter((s) => s.length >= 1 || s == ""),
                debounceTime(100)
            )
            .subscribe((result) => {
                setSearchText(result);
            });
        return () => subject.unsubscribe();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [subject]);

    return (
        <div
            className={classes.root}
            style={{
                width: width || 270,
                minWidth: minWidth,
                height: height || undefined,
                background: "inherit",
                borderBottom: "1px solid black",
            }}
        >
            <SearchIcon color="action" />
            <InputBase
                id={id || "search-box"}
                className={classes.input}
                placeholder={placeholder || "Search..."}
                inputProps={{ "aria-label": "search..." }}
                onChange={(e: any) => subject.next(e.target.value)}
            />
        </div>
    );
}
