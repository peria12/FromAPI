import React, { useEffect, useState } from "react";
import { Checkbox, FormControl, FormGroup, FormControlLabel, FormLabel } from "@mui/material";
import { Controller } from "react-hook-form";

function CheckBoxInput({ options, control, name, selectedItems, handleSelect }) {
    return (
        <>
            {options?.map((option: any) => {
                return (
                    <FormControlLabel
                        control={
                            <Controller
                                name={name}
                                render={() => {
                                    return (
                                        <Checkbox
                                            color="primary"
                                            checked={selectedItems.includes(option.key)}
                                            onChange={() => handleSelect(option.key)}
                                        />
                                    );
                                }}
                                control={control}
                            />
                        }
                        label={option.value}
                        key={option.key}
                    />
                );
            })}
        </>
    );
}

export const FormInputMultiCheckbox = ({ name, control, setValue, label, options, displayOrder = "row" }) => {
    const [selectedItems, setSelectedItems] = useState<any>([]);

    const handleSelect = (value: any) => {
        const isPresent = selectedItems.indexOf(value);
        if (isPresent !== -1) {
            const remaining = selectedItems.filter((item: any) => item !== value);
            setSelectedItems(remaining);
        } else {
            setSelectedItems((prevItems: any) => [...prevItems, value]);
        }
    };

    useEffect(() => {
        setValue(name, selectedItems);
    }, [setValue, selectedItems, name]);

    return (
        <FormControl size={"small"} variant={"outlined"}>
            <FormLabel component="legend">{label}</FormLabel>
            {displayOrder === "column" ? (
                <FormGroup>
                    <CheckBoxInput
                        options={options}
                        control={control}
                        name={name}
                        selectedItems={selectedItems}
                        handleSelect={handleSelect}
                    />
                </FormGroup>
            ) : (
                <div>
                    <CheckBoxInput
                        options={options}
                        control={control}
                        name={name}
                        selectedItems={selectedItems}
                        handleSelect={handleSelect}
                    />
                </div>
            )}
        </FormControl>
    );
};
