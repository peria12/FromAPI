import React from "react";
import { Controller } from "react-hook-form";
import AutocompleteField from "common/AutocompleteField";

export const FormAutocomplete = ({ name, control, handleAdd, provider, label }) => {
    return (
        <Controller
            name={name}
            control={control}
            render={({ field: { value } }) => (
                <AutocompleteField
                    onChange={handleAdd}
                    key={value}
                    provider={provider}
                    placeholder={label}
                    customStyle={{ marginTop: "19px" }}
                />
            )}
        />
    );
};
