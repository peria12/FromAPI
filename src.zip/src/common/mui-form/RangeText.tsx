import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import TextField from "@mui/material/TextField";
import { Controller } from "react-hook-form";
import clsx from "clsx";

const useStyles = makeStyles(() =>
    createStyles({
        label: { fontSize: "16px", marginBottom: "9px" },
        rangeLabel: { padding: "0 10px", marginTop: "25px" },
        bottomText: { marginTop: "10px", fontSize: "16px" },
        inputField: { width: "10rem" },
        error: { color: "#f44336" },
    })
);

function RangeTextField({ field, name, value, setValue, errors }) {
    const { min, max, bottomText, disabled } = field;
    const classes = useStyles();
    const [error, setError] = React.useState({ lower: false, upper: false });

    React.useMemo(() => {
        let lower_err = false;
        let upper_err = false;
        if (errors?.risk_indicator_flag_value) {
            const val = errors.risk_indicator_flag_value.ref?.value;
            if (val == null) {
                upper_err = true;
                lower_err = true;
            } else {
                const lval = parseFloat(val.lower);
                const uval = parseFloat(val.upper);
                lower_err = isNaN(lval) || lval < min || lval > max || lval >= uval;
                upper_err = isNaN(uval) || uval < min || uval > max || lval >= uval;
            }
        }
        setError({ lower: lower_err, upper: upper_err });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [errors?.risk_indicator_flag_value]);

    const { lower, upper } = value || {};

    function validateRange(value) {
        value = value + "";
        let newValue: any = parseFloat(value);
        newValue = value?.replace(/[^0-9.]+/, "");
        let isErr: any = false;
        if (isNaN(parseFloat(value))) {
            isErr = true;
        } else if (newValue < min || newValue > max) {
            isErr = true;
        }
        return { isErr, newValue };
    }

    const handleChange = (updatedValue, type) => {
        const range = validateRange(updatedValue);
        let err: any = { ...error, [type]: range.isErr };

        if (type == "upper") {
            const obj = validateRange(lower);
            if (!obj.isErr && range.newValue <= lower) {
                err = { lower: true, upper: true };
            } else {
                err = { ...err, ["lower"]: false };
            }
        } else if (type == "lower") {
            const obj = validateRange(upper);
            if (!obj.isErr && range.newValue >= upper) {
                err = { lower: true, upper: true };
            } else {
                err = { ...err, ["upper"]: false };
            }
        }
        setError(err);
        if (updatedValue === "") {
            range.newValue = "";
        }
        setValue(name, { ...value, [type]: range.newValue });
    };

    const getInput = (inputValue, updateString) => {
        return (
            <TextField
                variant="outlined"
                inputProps={{
                    style: { padding: "13px" },
                }}
                size="small"
                sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }}
                value={inputValue}
                onChange={(updatedValue) => handleChange(updatedValue.target.value, updateString)}
                type="text"
                error={error[updateString]}
                disabled={disabled}
            />
        );
    };

    return (
        <div>
            <div style={{ display: "flex", alignItems: "center" }}>
                <div className={classes.inputField}>
                    <div className={classes.label}>Lower Limit</div>
                    {getInput(lower, "lower")}
                </div>
                <div className={classes.rangeLabel}>to</div>
                <div className={classes.inputField}>
                    <div className={classes.label}>Upper Limit</div>
                    {getInput(upper, "upper")}
                </div>
            </div>
            <div
                className={clsx(classes.bottomText, {
                    [classes.error]: error["lower"] || error["upper"],
                })}
            >
                {bottomText}
            </div>
        </div>
    );
}

export const RangeText = ({ field, methods, errors }) => {
    const name = field.id || field.key;
    const { control, setValue, getValues } = methods;

    return (
        <>
            {field?.display && (
                <div style={{ width: "100%" }}>
                    <Controller
                        name={name}
                        control={control}
                        rules={{
                            validate: (value) => {
                                const riskIndicator = getValues()?.riskOverlay;
                                const { min, max } = field;
                                if (riskIndicator) {
                                    const lower = parseFloat(value?.lower);
                                    const upper = parseFloat(value?.upper);
                                    if (lower && upper && (isNaN(lower) || isNaN(upper))) {
                                        return false;
                                    }
                                    if (min && max) {
                                        return lower < upper && lower >= min && upper <= max;
                                    }
                                    return lower < upper;
                                }
                                return true;
                            },
                        }}
                        render={({ field: { value } }) => (
                            <RangeTextField
                                field={field}
                                value={value}
                                name={name}
                                setValue={setValue}
                                errors={errors}
                            />
                        )}
                    />
                </div>
            )}
        </>
    );
};
