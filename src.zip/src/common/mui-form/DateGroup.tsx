import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import { Controller } from "react-hook-form";
import TextField from "@mui/material/TextField";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";

const DATE_FORMAT = "dd-MMM-yyyy";

const getNextIntervalDate = (val, interval) => {
    const month = new Date(val).getMonth() + interval;
    const date = new Date(val).getDate();

    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const displayDate = new Date(currentYear, month, date);
    const displayDateString = displayDate.toString().slice(0, 15);

    return displayDateString;
};

const useStyles = makeStyles(() =>
    createStyles({
        base: {
            width: "100%",
            display: "flex",
            alignItems: "flex-start",
            flexDirection: "column",
            justifyContent: "center",
        },
        container: {
            display: "flex",
            marginTop: "5px",
            alignItems: "center",
            flexDirection: "row",
            justifyContent: "flex-start",
            width: "100%",
        },
        label: {
            color: "#9b9ba3",
            width: "25%",
            fontSize: "15px",
            fontWeight: 700,
            textTransform: "uppercase",
            textAlign: "left",
        },
        datesContainer: {
            display: "flex",
            flexDirection: "row",
            flexWrap: "wrap",
            width: "65%",
        },
    })
);

function DateGroupInput({ field, name, value, setValue }) {
    const { label, disabled } = field;
    const handleDateChange = (val, index, item) => {
        const reallocatioDatesClone = {
            ...value.reallocationDatesByFrequency,
        };
        val = val?.toDateString();
        reallocatioDatesClone[item][index] = val;

        const interval = item === "halfyearly" ? 6 : 3;
        if (item !== "yearly" && index === 0) {
            for (let i = index + 1; i < reallocatioDatesClone[item].length; i++) {
                if (i === 1) reallocatioDatesClone[item][i] = getNextIntervalDate(val, interval);
                reallocatioDatesClone[item][i] = getNextIntervalDate(reallocatioDatesClone[item][i - 1], interval);
            }
        }

        const newLocalValues = {
            ...value,
            reallocationDatesByFrequency: reallocatioDatesClone,
        };
        setValue(name, newLocalValues);
        return 0;
    };

    const classes = useStyles();
    const frequency = value?.reallocationDatesByFrequency;
    return (
        <div className={classes.base}>
            {Object.keys(value).length &&
                Object.keys(frequency) &&
                ["yearly", "halfyearly", "quarterly"].map((item, index) => (
                    <div className={classes.container} key={index}>
                        <div className={classes.label}>{item === "halfyearly" ? "half-yearly" : item}</div>
                        <div className={classes.datesContainer}>
                            {frequency?.[item].map((item1, index) => (
                                <div
                                    key={index}
                                    style={{
                                        margin: "8px 8px",
                                        width: "290px",
                                    }}
                                >
                                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                                        <DatePicker
                                            label={label}
                                            value={item1}
                                            onChange={(val) => handleDateChange(val, index, item)}
                                            renderInput={(params) => (
                                                <TextField
                                                    sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }}
                                                    {...params}
                                                />
                                            )}
                                            inputFormat={DATE_FORMAT}
                                            disabled={disabled}
                                            acceptRegex={new RegExp(/[^[a-zA-Z0-9-]*$]+/gi)}
                                        />
                                    </LocalizationProvider>
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
        </div>
    );
}

export const DateGroup = ({ field, control, setValue }) => {
    const name = field.id || field.key;
    return (
        <LocalizationProvider dateAdapter={AdapterDateFns}>
            <Controller
                name={name}
                control={control}
                render={({ field: { value } }) => (
                    <DateGroupInput field={field} value={value} name={name} setValue={setValue} />
                )}
            />
        </LocalizationProvider>
    );
};
