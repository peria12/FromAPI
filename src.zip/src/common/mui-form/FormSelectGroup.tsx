import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import TextField from "@mui/material/TextField";
import { Controller } from "react-hook-form";
import InputAdornment from "@mui/material/InputAdornment";
import FTSelect from "common/FTSelect";

const useStyles = makeStyles(() =>
    createStyles({
        base: {
            background: "#f7f7f7",
            padding: "20px",
            width: "36.5em",
        },
        container: {
            display: "flex",
            alignItems: "center",
            flexDirection: "row",
            marginTop: "12px",
        },
        select: {
            width: "200px",
            fontSize: ".15rem",
            marginLeft: "10px",
        },
        selectRoot: {
            fontSize: ".92rem",
            padding: "10px 14px",
        },
        inputField: {
            display: "flex",
            alignItems: "center",
            flexDirection: "row",
            marginLeft: "15px",
            justifyContent: "flex-start",
            width: "210px",
        },
    })
);

function FormSelectGroupField({ options, value, disabled }) {
    const classes = useStyles();
    return (
        <div className={classes.base}>
            {value?.map((field) => (
                <div key={field.name.value} className={classes.container}>
                    <div className={classes.select}>
                        <FTSelect
                            rootClass={classes.selectRoot}
                            disabled={disabled}
                            value={field.name?.key}
                            variant="outlined"
                            options={options}
                        />
                    </div>
                    <div className={classes.inputField}>
                        <TextField
                            variant="outlined"
                            size="small"
                            placeholder="Allocation"
                            sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }}
                            type="text"
                            value={field.value}
                            inputProps={{ style: { padding: "13px" } }}
                            disabled={disabled}
                            InputProps={{
                                endAdornment: (
                                    <InputAdornment position="end" disablePointerEvents>
                                        {" "}
                                        %{" "}
                                    </InputAdornment>
                                ),
                            }}
                        />
                    </div>
                </div>
            ))}
        </div>
    );
}

export const FormSelectGroup = ({ field, control, options, value }) => {
    const name = field.id || field.key;
    return (
        <div style={{ width: "100%" }}>
            <Controller
                name={name}
                control={control}
                render={() => <FormSelectGroupField value={value} options={options} disabled={field.disabled} />}
            />
        </div>
    );
};
