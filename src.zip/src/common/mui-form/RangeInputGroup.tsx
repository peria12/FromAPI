import React from "react";
import makeStyles from "@mui/styles/makeStyles";
import InputAdornment from "@mui/material/InputAdornment";
import TextField from "@mui/material/TextField";
import { Controller } from "react-hook-form";

const useStyle = makeStyles(() => ({
    container: { display: "flex", margin: "6px 23px" },
    hiddenContainer: { display: "none" },
    textField: { width: "11rem", padding: "6px 0px" },
    column: { width: "40%" },
    row_flex: {
        display: "flex",
        alignItems: "center",
    },
    bottomText: {
        height: "25px",
        marginLeft: "5px",
        fontSize: "15px",
        marginTop: "6px",
    },
    label: {
        color: "#9b9ba3",
        width: "25%",
        fontSize: "15px",
        fontWeight: 700,
        padding: "20px 0",
        textTransform: "uppercase",
    },
    subheader: {
        color: "rgba(0, 0, 0, 0.87)",
        width: "100%",
        fontSize: "17px",
        fontWeight: 600,
        marginBottom: "6px",
    },
}));

const RangeInputGroupInput = ({ field, value, name, setValue }) => {
    const { disabled, config, display } = field;
    const localClasses = useStyle();
    const accumulationData = config[0];
    const decumulationData = config.length > 0 ? config[1] : null;

    const handleChange = (obj, objectKey, newValue) => {
        const newValues = { ...value };
        newValues[obj][objectKey].value = newValue;
        setValue(name, newValues);
        console.log("newValues", newValues);
    };

    const getValue = (type, id, valueType = "") => {
        const fieldValue = value?.[type]?.[id] || {};
        if (valueType) {
            return fieldValue[valueType];
        }
        return fieldValue;
    };

    const inputProps = {
        style: { padding: "10px" },
    };

    return (
        <div className={display ? localClasses.container : localClasses.hiddenContainer}>
            {accumulationData?.inputs && (
                <div className={localClasses.column}>
                    <div className={localClasses.subheader}>{accumulationData.heading}</div>

                    {accumulationData?.inputs?.map((item) => (
                        <div key={item.key} className={localClasses.row_flex}>
                            {/* <div className={localClasses.label}>{getValue("accumulation", item.id, "labelValue")}</div> */}
                            {accumulationData?.accessKey == "accumulation" && (
                                <TextField
                                    inputProps={inputProps}
                                    type="number"
                                    placeholder={item.label}
                                    variant="outlined"
                                    sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }}
                                    value={getValue("accumulation", item.id, item.percent ? "value" : "")}
                                    onChange={(values) => {
                                        if (item.percent) {
                                            handleChange("accumulation", item.id, values.target.value);
                                        } else {
                                            handleChange("accumulation", item.key, values.target.value);
                                        }
                                    }}
                                    InputProps={{
                                        endAdornment: (
                                            <InputAdornment position="end" disablePointerEvents>
                                                {" "}
                                                %{" "}
                                            </InputAdornment>
                                        ),
                                    }}
                                    className={localClasses.textField}
                                    disabled={disabled}
                                />
                            )}
                            {accumulationData?.accessKey == "mingipercent" && (
                                <TextField
                                    inputProps={inputProps}
                                    type="number"
                                    placeholder={item.label}
                                    variant="outlined"
                                    sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }}
                                    value={getValue("mingipercent", item.id, item.percent ? "value" : "")}
                                    onChange={(values) => {
                                        if (item.percent) {
                                            handleChange("mingipercent", item.id, values.target.value);
                                        } else {
                                            handleChange("mingipercent", item.key, values.target.value);
                                        }
                                    }}
                                    InputProps={{
                                        endAdornment: (
                                            <InputAdornment position="end" disablePointerEvents>
                                                {" "}
                                                %{" "}
                                            </InputAdornment>
                                        ),
                                    }}
                                    className={localClasses.textField}
                                    disabled={disabled ? disabled : item.disabled}
                                />
                            )}
                        </div>
                    ))}
                    {accumulationData?.accessKey == "accumulation" && (
                        <div className={localClasses.bottomText}>Note: Target Wealth as % of IRR</div>
                    )}
                </div>
            )}
            {decumulationData?.inputs && (
                <div className={localClasses.column}>
                    <div>
                        <div className={localClasses.subheader}>{decumulationData.heading}</div>
                    </div>
                    {decumulationData?.inputs.map((item) => (
                        <div key={item.key} className={localClasses.row_flex}>
                            {/* <div className={localClasses.label}> {getValue("decumulation", item.id, "labelValue")} </div> */}
                            <TextField
                                type="number"
                                inputProps={inputProps}
                                placeholder={item.label}
                                sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }}
                                variant="outlined"
                                style={{ paddingLeft: "12px" }}
                                value={getValue("decumulation", item.id, item.percent ? "value" : "")}
                                onChange={(values) => {
                                    if (item.percent) {
                                        handleChange("decumulation", item.id, values.target.value);
                                    } else {
                                        handleChange("decumulation", item.key, values.target.value);
                                    }
                                }}
                                className={localClasses.textField}
                                disabled={disabled}
                                // min={-100}
                                // max={100}
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end" disablePointerEvents>
                                            {" "}
                                            %{" "}
                                        </InputAdornment>
                                    ),
                                }}
                            />
                        </div>
                    ))}
                    <div className={localClasses.bottomText} style={{ paddingLeft: "12px" }}>
                        Note: As a % of Target Wealth
                    </div>
                </div>
            )}
        </div>
    );
};

export const RangeInputGroup = ({ field, control, setValue }) => {
    const name = field.id || field.key;
    return (
        <>
            {field?.display && (
                <div style={{ width: "100%" }}>
                    <Controller
                        name={name}
                        control={control}
                        render={({ field: { value } }) => (
                            <RangeInputGroupInput field={field} value={value} name={name} setValue={setValue} />
                        )}
                    />
                </div>
            )}
        </>
    );
};

RangeInputGroup.defaultProps = {
    display: false,
    config: [
        {
            inputs: [],
            heading: " ",
        },
        {
            inputs: [],
            heading: " ",
        },
    ],
    value: {
        accumulation: {
            1: { labelValue: "", value: 5 },
            2: { labelValue: "", value: -1 },
            3: { labelValue: "", value: 80 },
            4: { labelValue: "", value: 60 },
            5: { labelValue: "", value: 40 },
        },
        decumulation: {
            1: { labelValue: "", value: 50 },
            2: { labelValue: "", value: 25 },
            3: { labelValue: "", value: 0 },
            4: { labelValue: "", value: 0 },
            5: { labelValue: "", value: 0 },
        },
    },
    disabled: false,
};
