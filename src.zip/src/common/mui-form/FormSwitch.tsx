import React from "react";
import { Controller } from "react-hook-form";
import { useState, useEffect } from "react";
import makeStyles from "@mui/styles/makeStyles";

const useStyles = makeStyles(() => ({
    widerRoot: {
        cursor: "pointer",
        margin: "8px 0px",
        display: "flex",
        width: "167px",
        height: "30px",
        borderRadius: "15px",
        boxShadow: "inset 0 0 5px 0 rgba(0, 0, 0, 0.3)",
        backgroundColor: "#ebebeb",
        textTransform: "uppercase",
        textAlign: "center",
        color: "#9b9ba3",
    },

    widerBoxSelected: {
        width: "99px",
        height: "30px",
        borderRadius: "20px",
        boxShadow: "2px 0 10px 0 rgba(0, 0, 0, 0.2)",
        background: "#303f9f;",
        color: "#ffffff",
    },
    widerBox: {
        width: "78px",
        height: "20px",
        fontFamily: "TradeGothicLT",
        fontSize: "16px",
        fontWeight: "bold",
        lineHeight: "1.25",
        letterSpacing: "0.2px",
        textAlign: "center",
        margin: "5px",
    },
}));

const CustomizedSwitches = ({ onChange, id, name, states, checked, disabled }) => {
    const [isChecked, setIsChecked] = useState(checked);
    const { on, off } = states;

    const changeHandler = () => {
        onChange(!isChecked);
        setIsChecked(!isChecked);
    };

    useEffect(() => {
        setIsChecked(checked);
    }, [checked]);

    const classes = useStyles();
    const style = { backgroundColor: "#9b9ba3" };
    return (
        <>
            <label htmlFor={id}>
                <div className={classes.widerRoot}>
                    <div
                        className={isChecked ? classes.widerBoxSelected : ""}
                        style={isChecked && disabled ? { ...style } : undefined}
                    >
                        <div className={classes.widerBox} style={on?.length > 5 ? { width: "89px" } : undefined}>
                            {on}
                        </div>
                    </div>
                    <div
                        className={isChecked ? "" : classes.widerBoxSelected}
                        style={!isChecked && disabled ? { ...style } : undefined}
                    >
                        <div className={classes.widerBox} style={off?.length > 3 ? { width: "66px" } : undefined}>
                            {off}
                        </div>
                    </div>
                </div>
            </label>
            <input
                type="checkbox"
                name={name}
                id={id}
                value={isChecked}
                onChange={changeHandler}
                style={{ display: "none" }}
                disabled={disabled}
            />
        </>
    );
};

export const FormSwitch = ({ control, states, field }) => {
    const name = field.key || field.name;
    return (
        <Controller
            name={name}
            control={control}
            render={({ field: { onChange, value } }) => (
                <CustomizedSwitches
                    id={name}
                    name={name}
                    states={states}
                    disabled={field.disabled}
                    checked={!!value}
                    onChange={onChange}
                />
            )}
        />
    );
};
