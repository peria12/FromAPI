import React, { useState } from "react";
import withStyles from "@mui/styles/withStyles";
import Slider from "@mui/material/Slider";

const StyledSlider = withStyles({
    root: {
        color: "#52af77",
        height: 8,
    },
    thumb: {
        height: 24,
        width: 24,
        backgroundColor: "#fff",
        border: "2px solid currentColor",
        marginTop: -1,
        marginLeft: -12,
        "&:focus, &:hover, &$active": {
            boxShadow: "inherit",
        },
    },
    active: {},
    valueLabel: {
        left: "calc(-50% + 4px)",
    },
    track: {
        height: 8,
        borderRadius: 4,
    },
    rail: {
        height: 8,
        borderRadius: 4,
    },
})(Slider);

export default function FTSlider(props) {
    const [value, setValue] = useState(props.value);
    const changed = (e, val) => {
        setValue(val);
        if (props.onChange) {
            props.onChange(val);
        }
    };

    return <StyledSlider {...props} value={value} onChange={changed} />;
}
