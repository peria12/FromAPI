import React from "react";
import { FormControl, InputLabel, MenuItem, Select } from "@mui/material";
import clsx from "clsx";

export interface FTSelectOption {
    key: string;
    value: string;
}
export interface FTSelectParams {
    label?: string;
    value: string;
    onChange?: any;
    onOpen?: any;
    onClose?: any;
    options: FTSelectOption[];
    variant?: any;
    disabled?: boolean;
    style?: any;
    rootClass?: any;
    placeholder?: string;
    selectDisplayProps?: any;
}

export default function FTSelect(params: FTSelectParams) {
    const {
        label,
        value,
        onChange,
        rootClass,
        onOpen,
        onClose,
        options,
        variant = "standard",
        disabled,
        selectDisplayProps,
    } = params;
    const id = Math.random().toString(36).substring(7);
    const placeholderText = params?.placeholder ? <span style={{ color: "#9E9E9E" }}>{params.placeholder} </span> : "";
    return (
        <FormControl style={{ width: "100%" }} disabled={disabled} variant="standard">
            {label && <InputLabel id={id}>{label}</InputLabel>}
            <Select
                labelId={id}
                value={value}
                onChange={(x) => onChange(x.target.value)}
                onOpen={onOpen}
                onClose={onClose}
                sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }}
                variant={variant}
                style={{ minWidth: "130px" }}
                displayEmpty={!disabled}
                renderValue={(value: any) => {
                    if ([undefined, null, ""].includes(value)) {
                        return placeholderText;
                    }
                    const option = options?.find((o) => o?.key == value);
                    return option?.value || value;
                }}
                classes={{ select: rootClass }}
                SelectDisplayProps={selectDisplayProps}
            >
                {options?.length === 0 && (
                    <MenuItem disabled value={""}>
                        {" "}
                        No Options{" "}
                    </MenuItem>
                )}
                {options.map((item: any) => (
                    <MenuItem key={item.key} value={item.key} className={clsx({ ["Mui-disabled"]: item.disabled })}>
                        {item.value ? item.value : <>&nbsp;</>}
                    </MenuItem>
                ))}
            </Select>
        </FormControl>
    );
}
