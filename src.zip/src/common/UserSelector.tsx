import React, { useState } from "react";
import { Chip, Tooltip } from "@mui/material";
import AutocompleteField from "common/AutocompleteField";
import Api from "utils/api";

const styles = {
    height: "30px",
    border: " 1px solid rgb(217 207 207)",
    borderRadius: "5px",
    padding: "2px 4px",
    fontSize: 13,
    borderColor: "rgb(217 207 207)",
};

const peopleFields = [
    { label: "Name", key: "name", width: "50%" },
    { label: "Email", key: "mail", width: "50%" },
];

const mapUser = (obj) => ({
    id: obj.id,
    label: obj.displayName,
    mail: obj.mail,
    givenName: obj.givenName,
    name: obj.displayName,
    category: "Users",
    type: "user",
});

const provider = (query) => {
    if (!query) return Promise.resolve([[], 0]);

    const promise = Api.searchUsers(query)
        .then((results: any) => results.value.map(mapUser))
        .catch((e) => console.log(e));

    return promise.then((res) => {
        return [res, res.length];
    });
};

export function Users({ users, setUsers }) {
    const handleDelete = (id) => {
        const newUsers = users?.filter((e) => e != id);
        setUsers(newUsers);
    };

    return (
        <div className="d-flex">
            <div className="flex-grow-1" style={{ overflow: "hidden" }}>
                {users?.map((eId: any) => (
                    <Tooltip title={eId} key={eId}>
                        <Chip
                            label={eId}
                            size="small"
                            color={"primary"}
                            onDelete={() => handleDelete(eId)}
                            className="m-1"
                        />
                    </Tooltip>
                ))}
            </div>
        </div>
    );
}

export function UserSelector({ users, setUsers, disabled }) {
    const [value, setValue] = useState("");

    const handler = (_, item) => {
        if (item) {
            const email = item?.mail;
            setUsers([...users, email]);
            setValue(email);
        }
    };

    return (
        <div className="d-flex flex-column me-2">
            <div className="p-1" style={{ width: "15em" }}>
                <AutocompleteField
                    key={value}
                    onChange={handler}
                    provider={provider}
                    isGrouped={true}
                    placeholder={"Users"}
                    inputPropsStyle={styles}
                    fields={peopleFields}
                    popperWidth="500px"
                    disabled={disabled}
                    disableUnderline={true}
                    forcePopupIcon={true}
                />
            </div>
        </div>
    );
}
