import React, { useState, useEffect } from "react";
import PowerBI from "../PowerBI";
import Api from "utils/api";
import errorNotification from "utils/api-error";
import AppCover from "home/dashboad/AppCover";
import { AppContext } from "utils/context";

export default function PBIReport() {
    const context = React.useContext(AppContext)
    const app = context.app._id;
    const zone = context.zone.name;
    const [config, setConfig] = useState<any>({});

    useEffect(() => {
        if (app && zone) {
            Api.getZoneSettings(app, zone)
                .then((response: any) => {
                    const powerBiConfig = response?.power_bi_config || null;
                    if (!powerBiConfig) {
                        const errorInfo = {
                            type: "error",
                            text: `Unable to fetch Power BI config`,
                            open: true,
                        };
                        errorNotification.next(errorInfo);
                    } else {
                        setConfig(powerBiConfig);
                    }
                })
                .catch((err: any) => {
                    console.log(err);
                });
        }
    }, [zone, app]);

    return <AppCover><PowerBI config={config} /></AppCover>;
}
