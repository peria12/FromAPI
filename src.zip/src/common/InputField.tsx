import React from "react";
import FormControl from "@mui/material/FormControl";
import Input from "@mui/material/Input";
import InputLabel from "@mui/material/InputLabel";
import InputAdornment from "@mui/material/InputAdornment";

interface InputFieldProps {
    field: any;
    index?: number;
    value: any;
    onChange(id: any, i?: any): any;
    style?: any;
    shrink?: boolean;
}

export default function InputField({ field, index, value, onChange, shrink = false }: InputFieldProps) {
    if (value == undefined || null) {
        value = "";
    }
    let key = field.id;
    if (index !== undefined || index !== undefined) {
        key = key + "_" + index;
    }
    const endAdornment = field?.endAdornment || field?.suffix;
    const startAdornment = field?.startAdornment || field?.prefix;
    return (
        <FormControl key={key} style={{ width: "100%", ...field.style }}>
            <InputLabel htmlFor={key} shrink={shrink}>
                {field.label}
            </InputLabel>
            <Input
                id={key}
                autoComplete={"off"}
                disableUnderline={field.disableUnderline}
                value={value}
                type={field.type || "text"}
                onChange={onChange(field.id, index)}
                endAdornment={
                    endAdornment ? (
                        <InputAdornment position="end" disablePointerEvents>
                            {endAdornment}
                        </InputAdornment>
                    ) : null
                }
                startAdornment={
                    startAdornment ? (
                        <InputAdornment position="start" disablePointerEvents>
                            {startAdornment}
                        </InputAdornment>
                    ) : null
                }
            />
        </FormControl>
    );
}
