import * as React from "react";
import TextField from "@mui/material/TextField";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { parseISO } from "date-fns";

export default function FTDatePicker({
    dateStr,
    label,
    handleDateChange,
    style = null,
    inputPropsStyle = null,
    shouldDisableDate = undefined,
    format = "dd-MMM-yyyy",
    minDate = undefined,
    maxDate = undefined,
    disableUnderline = false,
}: any) {
    return (
        <LocalizationProvider dateAdapter={AdapterDateFns}>
            <DatePicker
                label={label}
                value={parseISO(dateStr)}
                onChange={handleDateChange}
                inputFormat={format}
                shouldDisableDate={shouldDisableDate}
                minDate={minDate ? parseISO(minDate) : undefined}
                maxDate={maxDate ? parseISO(maxDate) : undefined}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        variant="standard"
                        InputProps={{
                            ...params?.InputProps,
                            disableUnderline: disableUnderline,
                        }}
                        inputProps={{
                            ...params.inputProps,
                            style: inputPropsStyle ? inputPropsStyle : { padding: "8px 2px" },
                        }}
                        style={style ? style : { height: "40px" }}
                    />
                )}
            />
        </LocalizationProvider>
    );
}
