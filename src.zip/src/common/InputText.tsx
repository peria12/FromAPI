import React from "react";

export default function InputText({ placeholder, onChange }) {
    return (
        <div className="input-group">
            <input
                type="text"
                className="form-control"
                placeholder={placeholder}
                onChange={(e) => onChange(e.target.value)}
            />
        </div>
    );
}
