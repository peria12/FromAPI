export const defaultFilter = { field: "", operator: "", value: "", is_custom_field: false };

export const defaultFieldInfo = {
    custom_fields_master: [],
    fields: [],
    custom_fields: [],
    isLoading: false,
    loader: false,
};

export const defaultFormData = {
    formType: "create",
    name: "",
    is_advance: false,
    is_active: true,
    advance_rule: "",
    is_global: false,
    true_value: "True",
    false_value: "False",
}
