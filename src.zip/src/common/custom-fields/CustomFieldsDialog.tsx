import React, { useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import { AdornedButton } from "common/FTButtons";
import DialogTitle from "@mui/material/DialogTitle";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import ViewColumnIcon from "@mui/icons-material/ViewColumn";
import { FTIconButton } from "common/FTButtons";
import CustomFields from "./CustomFields";

const BootstrapDialogTitle = (props: any) => {
    const { children, onClose, ...other } = props;
    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: "absolute",
                        right: 6,
                        top: 6,
                        color: (theme) => theme?.palette?.grey?.[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

export default function CustomFieldsDialog({ app, zone, config, portfolioList }) {
    const [openDialog, setOpenDialog] = useState(false);
    return (
        <>
            <FTIconButton
                handler={() => setOpenDialog(true)}
                title="Custom Fields"
                btnIcon={<ViewColumnIcon />}
                placement="top"
            />
            <Dialog open={openDialog} onClose={() => setOpenDialog(false)} fullWidth maxWidth="xl">
                <BootstrapDialogTitle id="customized-dialog-title" onClose={() => setOpenDialog(false)}>
                    Custom Fields
                </BootstrapDialogTitle>
                <DialogContent dividers>
                    <CustomFields app={app} zone={zone} fieldsConfig={config} portfolioList={portfolioList} />
                </DialogContent>
                <DialogActions>
                    <AdornedButton
                        style={{ textTransform: "capitalize" }}
                        variant="contained"
                        onClick={() => setOpenDialog(false)}
                        color="secondary"
                    >
                        Close
                    </AdornedButton>
                </DialogActions>
            </Dialog>
        </>
    );
}
