import React, { useEffect, useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import TextField from "@mui/material/TextField";
import errorNotification from "utils/api-error";
import ConfirmDialog from "common/ConfirmDialog";
import { FTIconButton, AdornedButton } from "common/FTButtons";
import DeleteIcon from "@mui/icons-material/Delete";
import Settings from "utils/settings";
import { Box, Table, TableBody, TableCell, TableRow, Typography } from "@mui/material";
import viewIcon from "assets/View.svg";
import { Form } from "react-bootstrap";
import Api from "utils/api";
import Access from "utils/access";
import { UserSelector, Users } from "common/UserSelector";
import AutocompleteField from "common/AutocompleteField";
import { globalSearch } from "utils/helpers";
import { sortList } from "utils/so-helpers";

const BootstrapDialogTitle = (props: any) => {
    const { children, onClose, ...other } = props;
    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: "absolute",
                        right: 6,
                        top: 6,
                        color: (theme) => theme?.palette?.grey?.[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

function ViewsDialog({ selectedView, views, updateViews, filterState, app, zone, getGridState, ...props }) {
    const getView = () => views?.find((x) => x?._id["$oid"] == selectedView);

    const [openDialog, setOpenDialog] = useState(false);
    const [system, setSystem] = useState(false);
    const [dept, setDept] = useState(false);
    const [users, setUsers] = useState<string[]>([]);
    const [filterDetails, setFilterDetails] = useState(filterState);
    const [name, setName] = useState(getView()?.name || "");
    const isAdmin = Access.hasAccessToZone("admin", "acl", ["admin"]);
    const settings = Settings.getSettings();
    const userEmail: string = settings.email;
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const view = views?.find((x) => x?._id["$oid"] == selectedView);
        setUsers(view?.access.users || []);
        setDept(view?.access.dept || view?.access.dept_code || false);
        setSystem(view?.access.system || false);
        setName(view?.name);
    }, [selectedView, views]);

    useEffect(() => {
        setFilterDetails(filterState);
    }, [filterState]);

    function clear() {
        setName(getView()?.name || "");
        setOpenDialog(false);
    }

    function createView(key) {
        if (!name?.length) {
            errorNotification.next({
                type: "error",
                text: `Please enter ${props.label.toLowerCase() || "view"} name`,
                open: true,
            });
            return;
        }

        if (key == "create") {
            const dup = views?.find((v) => v?.name == name);
            if (dup) {
                errorNotification.next({ type: "error", text: `${props.label || "View"} already exists`, open: true });
                return;
            }
        }

        const modifiedUsers = users.length ? (users.includes(userEmail) ? users : [...users, userEmail]) : users;
        const gridState = getGridState();

        if (key == "create") {
            setLoading(true);
            Api.createSharedState(app, zone, {
                name: name,
                access: {
                    system: system,
                    dept: dept,
                    users: modifiedUsers,
                },
                gridState,
                type: "view",
                createdBy: userEmail,
            })
                .then((resp) => {
                    updateViews(key, resp?._id, clear);
                })
                .finally(() => {
                    setLoading(false);
                });
        }

        if (key == "update") {
            const view = getView();
            if (view?.is_editable) {
                const view_id = view._id["$oid"];
                setLoading(true);
                Api.updateSharedState(view_id, {
                    name: name,
                    access: {
                        system: system,
                        dept: dept,
                        users: modifiedUsers,
                    },
                    gridState,
                    createdBy: userEmail,
                    type: "view",
                })
                    .then(() => {
                        updateViews(key, view_id, clear);
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            } else {
                errorNotification.next({ type: "error", text: `"View user can not update the view"`, open: true });
            }
        }
    }

    const hasError = Object.values(filterDetails).some((x: any) => !x.values?.length);

    const isUpdateBtnDisabled = hasError || !getView();
    const isCreateBtnDisabled = hasError || getView()?.name == name;
    return (
        <div className="ps-3">
            <FTIconButton
                handler={() => setOpenDialog(true)}
                title="Save View"
                btnIcon={<img src={viewIcon} />}
                placement="top"
                hideBgColor={true}
            />
            <Dialog open={openDialog} onClose={() => setOpenDialog(false)} fullWidth maxWidth="sm">
                <BootstrapDialogTitle id="dialog-title" onClose={() => setOpenDialog(false)}>
                    {props.dialogTitle || "Save Views 1"}
                </BootstrapDialogTitle>
                <DialogContent dividers>
                    <TextField
                        id="name"
                        label={`${props.label || "View"} Name`}
                        onChange={(e) => setName(e.target.value)}
                        autoComplete="off"
                        variant="standard"
                        value={name}
                        error={false}
                        style={{ width: "100%" }}
                    />
                    <div
                        className="mt-2 pb-2 d-flex align-items-center"
                        style={{
                            borderBottom: "1px solid rgb(148 148 148)",
                        }}
                    >
                        <span className="mr-11">Share With:</span>
                        <Form.Check
                            inline
                            label="System"
                            name="system"
                            type={"checkbox"}
                            id={`inline-checkbox-1`}
                            onChange={(event) => {
                                setSystem(event.target.checked);
                            }}
                            checked={system}
                            disabled={!isAdmin ? true : users.length || dept ? true : false}
                        />
                        <Form.Check
                            inline
                            label="Dept"
                            name="dept"
                            type={"checkbox"}
                            id={`inline-checkbox-2`}
                            onChange={(event) => {
                                setDept(event.target.checked);
                            }}
                            checked={dept}
                            disabled={users.length || system ? true : false}
                        />
                        <UserSelector users={users} setUsers={setUsers} disabled={dept || system} />
                    </div>
                    <Users users={users} setUsers={setUsers} />
                    {Object.keys(filterDetails).length > 0 && (
                        <Box>
                            <Box>
                                <Typography
                                    variant="h6"
                                    sx={{ padding: "10px", fontWeight: "400", fontStyle: "italic" }}
                                >
                                    Filter list:
                                </Typography>
                            </Box>
                            <Box sx={{ border: "solid 1px rgb(211, 211, 211)", borderRadius: "3px" }}>
                                <Table>
                                    <TableBody>
                                        {Object.keys(filterDetails).map((item) => {
                                            const empty = !filterDetails[item].values?.length;
                                            return (
                                                <TableRow key={item}>
                                                    <TableCell>{item}</TableCell>
                                                    <TableCell>
                                                        <div
                                                            style={{
                                                                whiteSpace: "nowrap",
                                                                overflow: "hidden",
                                                                textOverflow: "ellipsis",
                                                                width: "400px",
                                                                border: "1px solid",
                                                                padding: "0 5px",
                                                                paddingTop: "3px",
                                                            }}
                                                            className={
                                                                empty ? "border-danger text-danger" : "border-secondary"
                                                            }
                                                        >
                                                            {empty
                                                                ? "ERROR: No values are selected"
                                                                : filterDetails[item].values.join(",")}
                                                        </div>
                                                    </TableCell>
                                                </TableRow>
                                            );
                                        })}
                                    </TableBody>
                                </Table>
                            </Box>
                        </Box>
                    )}
                </DialogContent>
                <DialogActions>
                    <div className="w-50">
                        <button
                            type="button"
                            className="btn btn-danger btn-sm text-capitalize"
                            onClick={() => setOpenDialog(false)}
                        >
                            Cancel
                        </button>
                    </div>
                    <div className="w-50 d-flex justify-content-end">
                        <AdornedButton
                            variant="outlined"
                            className="btn btn-primary btn-sm text-capitalize"
                            onClick={() => createView("update")}
                            loading={!isUpdateBtnDisabled && loading}
                            disabled={isUpdateBtnDisabled}
                        >
                            Update
                        </AdornedButton>

                        <div style={{ paddingLeft: "8px" }}>
                            <AdornedButton
                                variant="outlined"
                                className="btn btn-primary btn-sm text-capitalize"
                                onClick={() => createView("create")}
                                loading={!isCreateBtnDisabled && loading}
                                disabled={isCreateBtnDisabled}
                            >
                                Create
                            </AdornedButton>
                        </div>
                    </div>
                </DialogActions>
            </Dialog>
        </div>
    );
}

const defaultView = { id: null, label: "Default" };

export default function ViewsMenu({
    app,
    zone,
    views,
    setViews,
    selectedView,
    setSelectedView,
    gridRef,
    filterState,
    getGridState,
    ...props
}) {
    const getView = () => views?.find((x) => x?._id["$oid"] == selectedView);
    const [confirmOpen, setConfirmOpen] = useState(false);
    let options = views?.map((v: any) => {
        const owned = v["author-id"] === Access.userInfo.uuid;
        return {
            id: v?._id["$oid"],
            "author-id": v["author-id"],
            author: !owned ? v.author : "",
            label: v?.name,
        };
    });

    options = sortList(options);
    options.unshift(defaultView);

    function handleDeleteView() {
        Api.deleteSharedState(selectedView)
            .then(() => {
                updateViews("delete");
            })
            .catch();
    }

    // useEffect(() => {
    //     setSelectedView(null);
    //     //eslint-disable-next-line
    // }, []);

    function updateViews(key, view: any = {}, callback: any = null) {
        if (gridRef?.current?.columnApi) {
            Api.getSharedState(app, zone).then((res) => {
                const latestViews = res.filter((item) => item.type == "view");
                let msg = "saved";
                if (key == "update") {
                    msg = "updated";
                } else if (key == "delete") {
                    msg = "deleted";
                }
                errorNotification.next({ type: "success", text: `"View ${msg} successfully"`, open: true });
                if (callback) {
                    callback();
                }
                setViews(latestViews);
                if (key == "delete") {
                    const view_id = latestViews?.[0]?._id["$oid"] || "";
                    setSelectedView(view_id);
                } else {
                    setSelectedView(view || "");
                }
            });
        }
    }

    const provider = (options: object[] = [], query) => {
        if (!query) {
            return Promise.resolve([options, options.length]);
        }
        const results = globalSearch(options, query, 0);
        return Promise.resolve([results, results.length]);
    };

    function getValue() {
        const val = options?.length && getView() ? selectedView : "";
        const obj = options?.find((i) => i.id == val);
        return obj || defaultView;
    }

    const authorStyle: any = {
        color: "#c5c5c5",
        fontSize: "12px",
        textTransform: "capitalize",
        fontStyle: "italic",
        marginLeft: 1,
    };

    const RenderOption = function (props, option) {
        return (
            <li {...props} key={option.id} style={{ fontSize: "14px" }}>
                <div style={{ display: "flex", width: "90%", justifyContent: "space-between" }}>
                    <div className="col-12">
                        {option.label}
                        {option.author && <span style={authorStyle}>({option.author})</span>}
                    </div>
                </div>
            </li>
        );
    };
    return (
        <>
            <div style={{ width: "120px", paddingTop: "8px" }}>
                <AutocompleteField
                    onChange={(_, value) => setSelectedView(value?.id)}
                    provider={(q) => provider(options, q)}
                    value={getValue()}
                    placeholder="View"
                    inputPropsStyle={{ height: "30px", width: "140px" }}
                    forcePopupIcon={true}
                    searchIcon={false}
                    popperWidth="250px"
                    disableClearable={false}
                    renderOption={RenderOption}
                />
            </div>
            <ViewsDialog
                selectedView={selectedView}
                views={views}
                updateViews={updateViews}
                filterState={filterState}
                app={app}
                zone={zone}
                dialogTitle={props.dialogTitle}
                label={props.label}
                getGridState={getGridState}
            />
            <ConfirmDialog
                title={`Delete?`}
                open={confirmOpen}
                setOpen={setConfirmOpen}
                stopPropagation={true}
                onConfirm={(e) => {
                    e?.stopPropagation();
                    handleDeleteView();
                }}
            >
                Are you sure you want to delete view <b>{getView()?.name}</b>?
            </ConfirmDialog>

            <FTIconButton
                handler={() => setConfirmOpen(true)}
                title={`Delete ${props.label?.toLowerCase() || "view"}`}
                btnIcon={<DeleteIcon />}
                placement="top"
                hideBgColor={true}
                disabled={!selectedView}
            />
        </>
    );
}
