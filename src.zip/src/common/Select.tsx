import React from "react";

export default function Select(props) {
    return (
        <select className="form-select" value={props.pageSize} onChange={(e) => props.onChange(e.target.value)}>
            {props.options.map((option) => (
                <option key={option.key} value={option.key}>
                    {option.value}
                </option>
            ))}
        </select>
    );
}
