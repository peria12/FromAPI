import React, { useEffect, useState } from "react";

import { Snackbar } from "@mui/material";
import MuiAlert from "@mui/material/Alert";
interface SnackBarParams {
    snack: {
        type: string;
        text: string;
    };
    onClose?: any;
    duration?: number;
}

export default function FTSnackBar(params: SnackBarParams) {
    const {
        snack: { type, text },
    } = params;
    const [open, setOpen] = useState(false);

    useEffect(() => {
        if (text) setOpen(true);
    }, [type, text]);

    const closeSnack = () => {
        setOpen(false);
        if (params.onClose) {
            params.onClose();
        }
    };
    if (type == "") return <></>;

    return (
        <Snackbar
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
            open={open}
            autoHideDuration={params.duration || 6000}
            onClose={closeSnack}
            message={text}
        >
            <MuiAlert elevation={6} variant="filled" severity={type as any}>
                {text}{" "}
            </MuiAlert>
        </Snackbar>
    );
}
