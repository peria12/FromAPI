import React, { useState } from "react";
import { useTable, useSortBy, usePagination, useGlobalFilter } from "react-table";

import { Paper, TablePagination, TextField } from "@mui/material";
import TablePaginationActions from "./TablePaginationActions";
import Loader from "./Loader";

function TableHeader(props) {
    return props.headerGroups.map((headerGroup) => {
        const props = headerGroup.getHeaderGroupProps();
        return (
            <div {...props} key={props.key} className="row">
                {headerGroup.headers.map((column) => (
                    <div
                        key={column.id}
                        className={(column.width || "col") + " p-2"}
                        {...column.getHeaderProps(column.getSortByToggleProps())}
                        style={{
                            borderBottom: "solid 1px black",
                            color: "black",
                            fontWeight: "bold",
                            cursor: "pointer",
                        }}
                    >
                        {column.render("Header")}
                        <span>{column.isSorted ? (column.isSortedDesc ? " 🔽" : " 🔼") : ""}</span>
                    </div>
                ))}
            </div>
        );
    });
}

function TableRow({ row, expand }) {
    const [wspace, setWSpace] = useState("nowrap");
    const clicked = (column, event) => {
        if (!column.noexpand && !event.target.href) {
            setWSpace(wspace ? "" : "nowrap");
        }
    };

    return (
        <div className="row" {...row.getRowProps()} style={{ borderBottom: "1px solid lightgray" }}>
            {row.cells.map((cell) => (
                <div
                    key={cell.key}
                    className={cell.column.width}
                    {...cell.getCellProps()}
                    onClick={(event) => clicked(cell.column, event)}
                    style={{
                        whiteSpace: wspace,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        cursor: cell.column.href ? "pointer" : "",
                        padding: "10px",
                    }}
                    href={cell.column.href ? cell.column.href(row.original) : ""}
                >
                    {cell.render("Cell")}
                </div>
            ))}
            {expand ? expand(row.original) : ""}
        </div>
    );
}

export interface TableParams {
    columns: any[];
    data: any[];
    expand?: any;
    start_widgets?: any;
    end_widgets?: any;
    error?: any;
    loading?: any;
}

export default function Table(params: TableParams) {
    const { columns, data, expand, start_widgets, end_widgets, error, loading } = params;

    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        rows,
        prepareRow,
        state: { pageIndex, pageSize },
        gotoPage,
        setPageSize,
        setGlobalFilter,
    } = useTable(
        {
            columns: columns,
            data: data || [],
            disableSortRemove: true,
            initialState: { pageSize: 20 },
            autoResetGlobalFilter: false,
            autoResetSortBy: false,
        },
        useGlobalFilter,
        useSortBy,
        usePagination
    );

    if (!columns) {
        return <div></div>;
    }

    // for now use case insensitive string sorting
    const getSortFn = (col) => {
        const key = col.accessor;
        return (a, b) => {
            if (typeof a.original[key] === "string") {
                const first = (a.original[key] || "").toUpperCase();
                const second = (b.original[key] || "").toUpperCase();
                return first.localeCompare(second);
            }
            else if (typeof a.original[key] === "number") {
                const first = (a.original[key] );
                const second = (b.original[key]);
                return first - second;
            }
            
        };
    };
    columns.forEach((col) => (col.sortType = getSortFn(col)));

    const start = pageIndex * pageSize;
    const end = start + pageSize;
    const pageRows = rows.slice(start, end);

    return (
        <div>
            <div className="d-flex bd-highlight mb-3">
                <div className="me-auto p-2 bd-highlight">{start_widgets ? start_widgets : <></>}</div>
                <div className="p-2 bd-highlight">
                    {end_widgets ? <div className="mx-2"> {end_widgets} </div> : <></>}
                </div>
                <div className="p-2 bd-highlight">
                    <TextField
                        id="outlined-search"
                        variant="standard"
                        label="Search"
                        type="search"
                        onChange={(e) => setGlobalFilter(e.target.value)}
                    />
                </div>
            </div>
            <Paper>
                <div {...getTableProps()} style={{ width: "100%" }} className="container-fluid my-2 striped">
                    <TableHeader headerGroups={headerGroups} columns={columns} />
                    {error ? (
                        <div className="d-flex justify-content-center m-4"> {error} </div>
                    ) : loading ? (
                        <div className="pb-1">
                            {" "}
                            <Loader />{" "}
                        </div>
                    ) : (
                        <div {...getTableBodyProps()}>
                            {pageRows.map((row) => {
                                prepareRow(row);
                                return <TableRow row={row} expand={expand} key={row.id} />;
                            })}
                        </div>
                    )}
                </div>
            </Paper>
            <div className="d-flex justify-content-end">
                <TablePagination
                    component="div"
                    count={data.length}
                    page={pageIndex}
                    colSpan={3}
                    onPageChange={(event: any, newPage: number) => {
                        gotoPage(newPage);
                    }}
                    rowsPerPage={pageSize}
                    onRowsPerPageChange={(event) => {
                        setPageSize(event.target.value);
                    }}
                    rowsPerPageOptions={[20, 50, 100]}
                    ActionsComponent={TablePaginationActions}
                />
            </div>
        </div>
    );
}
