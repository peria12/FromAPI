import React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useTheme } from "@mui/material/styles";

export default function ConfirmDialog({ title, children, open, setOpen, onConfirm, stopPropagation = false }) {
    const theme = useTheme();
    const fullScreen = useMediaQuery(theme.breakpoints.down("sm"));
    return (
        <div>
            <Dialog
                fullScreen={fullScreen}
                open={open}
                onClose={(e: any) => {
                    if (stopPropagation) {
                        e?.stopPropagation();
                    }
                    setOpen(false);
                }}
                maxWidth="xs"
                aria-labelledby="confirm-dialog"
            >
                <DialogTitle id="responsive-dialog-title">{title}</DialogTitle>
                <DialogContent>
                    <DialogContentText>{children}</DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button
                        style={{ textTransform: "capitalize" }}
                        variant="contained"
                        onClick={(e) => {
                            if (stopPropagation) {
                                e?.stopPropagation();
                            }
                            setOpen(false);
                        }}
                        color="secondary"
                    >
                        {" "}
                        No{" "}
                    </Button>
                    <Button
                        style={{ textTransform: "capitalize" }}
                        variant="contained"
                        onClick={(e) => {
                            if (stopPropagation) {
                                e?.stopPropagation();
                            }
                            setOpen(false);
                            onConfirm();
                        }}
                        color="primary"
                    >
                        Yes
                    </Button>
                </DialogActions>
            </Dialog>
        </div>
    );
}
