import React, { useState } from "react";
import { useDropzone } from "react-dropzone";
import { getIconFromFileType } from "utils/helpers";

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function FormFile({
    title,
    value,
    onChange,
    multiple = true,
    height = "100%",
    showFileName = true,
    accept = "",
    fileListValue = [],
}) {
    const [fileList, setFileList] = useState(fileListValue as any);
    const [origList, setOrigList] = useState((value as any) || []);

    const getKey = (file) => `${file.path}|${file.lastModified}|${file.size}`;
    const uniq = (list) => {
        const map = new Map(list.map((x) => [getKey(x), x]));
        return Array.from(map.values());
    };

    const { getRootProps, getInputProps } = useDropzone({
        onDrop: (files) => {
            let newFileList: any = [];
            if (multiple === true) {
                newFileList = uniq([...fileList, ...files]);
            } else {
                newFileList = [files.pop()];
            }
            setFileList(newFileList);
            onChange([...newFileList, ...origList]);
        },
        multiple: multiple,
        accept: accept as any,
    });

    const removeFile = (file) => {
        const newFileList = fileList.filter((f) => f != file);
        setFileList(newFileList);
        onChange([...newFileList, ...origList]);
    };

    const removeOrigFile = (file) => {
        const newOrigList = origList.filter((f) => f != file);
        setOrigList(newOrigList);
        onChange([...fileList, ...newOrigList]);
    };

    return (
        <div style={{ width: "100%" }}>
            {origList.map((file) => (
                <span
                    key={file.file_id}
                    className="badge bg-primary me-1 my-1"
                    style={{ display: "inline-flex", alignItems: "center" }}
                >
                    <i className={getIconFromFileType(file.file_type)}></i> &nbsp;
                    <a
                        href={`/api/file-id/${file.file_id}`}
                        download
                        className="text-white"
                        style={{ display: "inline-flex", alignItems: "center", cursor: "pointer" }}
                    >
                        {file.file_name} &nbsp;
                    </a>
                    <button
                        type="button"
                        className="btn-close btn-close-white"
                        onClick={() => removeOrigFile(file)}
                    ></button>
                </span>
            ))}
            <div
                {...getRootProps({ className: "pointer dropzone p-2 mb-1" })}
                style={{
                    height: height,
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    fontWeight: 300,
                    fontSize: "20px",
                    color: "#8380805e",
                }}
            >
                <input {...getInputProps()} />
                <span> {title || "DROP FILES HERE"} </span>
            </div>
            {showFileName &&
                fileList
                    .filter((x) => x)
                    .map((file) => (
                        <span
                            key={getKey(file)}
                            className="badge bg-primary me-1 my-1"
                            style={{ display: "inline-flex", alignItems: "center" }}
                        >
                            <i className={getIconFromFileType(file.type)}></i> &nbsp;
                            {file.name} &nbsp;
                            <button
                                type="button"
                                className="btn-close btn-close-white"
                                onClick={() => removeFile(file)}
                            ></button>
                        </span>
                    ))}
        </div>
    );
}
