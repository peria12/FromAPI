import React from "react";

export function FormCheckbox({ title, value, onChange }) {
    const changed = (event) => onChange(event.target.checked);
    const id = Math.random().toString(36).substring(7);

    return (
        <div className="form-check mb-3">
            <input className="form-check-input" type="checkbox" defaultChecked={value} id={id} onChange={changed} />
            <label className="form-check-label" htmlFor={id}>
                {" "}
                {title}{" "}
            </label>
        </div>
    );
}
