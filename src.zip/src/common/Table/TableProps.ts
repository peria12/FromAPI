export default interface TableProps {
    appInfo: {
        appId: string;
        subAppId?: string;
    };
    meta: {
        nested?: boolean;
        striped?: boolean;
        dense?: boolean;
        resizable?: boolean;
        ordering?: boolean;
    };
    fieldsApi(): Promise<any>;
    tableDataApi(param?: any): Promise<any>;
    param?: any;
    filterQuery?: any;
    searchText?: string;
    paginationConfig?: {
        rowsPerPageOptions?: Array<number>;
        rowsPerPage?: number;
    };
    nestedTableConfig?: {
        type: string;
        titleProp?: string;
        dataApi?: any;
        customizeCell?: any;
    };
    toolbarConfig?: {
        dateFilter?: boolean;
        groupByFilter?: boolean;
        queryFilter?: boolean;
        searchBar?: boolean;
        columnHideShow?: boolean;
    };
    defaultOrderBy?: any;
    rowConfig?: any;
    tableHeight?: string;
}
