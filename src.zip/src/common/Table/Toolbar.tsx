import React from "react";
// import { useHistory } from "react-router-dom";
import Chip from "@mui/material/Chip";
import TableFilterForm from "common/TableFilterForm";
import FilterListSharpIcon from "@mui/icons-material/FilterListSharp";
// import queryString from "query-string";

import FTMultiSelectMenu from "common/FTMultiSeletMenu";
import DatePicker from "common/DatePicker";
import FTSelect from "common/FTSelect";
// import Settings from "utils/settings";
import SearchBox from "common/SearchBox";
import { FTIconButton } from "common/FTButtons";
import { defaultQueryFilter } from "./TableConfig";

function GroupByFields({ classes, filterInfo, groupByColumns, setFilterInfo }) {
    // const history = useHistory();
    const { groupBy } = filterInfo;

    const handleChange = (value: any, index: number) => {
        const values = [...groupBy];
        values[index] = value;
        setFilterInfo((filterInfo) => ({ ...filterInfo, groupBy: values }));
        // const query = queryString.stringify(
        //     { ...filterInfo, group_by: values.join(","), open_groups: undefined },
        //     { arrayFormat: "bracket" }
        // );
        // history.push({ pathname: history.location.pathname, search: query });
    };

    const options = groupByColumns.map((column) => ({
        key: column._id,
        value: column.title,
        disabled: groupBy.includes(column._id),
    }));

    options.unshift({ key: "", value: "None", disabled: false });
    return (
        <>
            <div className={classes.toolbarItems}>
                <FTSelect label="Group By" value={groupBy[0]} onChange={(e) => handleChange(e, 0)} options={options} />
            </div>
            <div className={classes.toolbarItems}>
                <FTSelect label="Group By" value={groupBy[1]} onChange={(e) => handleChange(e, 1)} options={options} />
            </div>
        </>
    );
}

export default function Toolbar({
    classes,
    toolbarConfig,
    filterInfo,
    setFilterInfo,
    changePage,
    fieldsInfo,
    setFieldsInfo,
    // appInfo,
    searchHandler,
    setPageConfig,
    setQueryFilterOpen,
    queryFilterOpen,
    queryFilters,
    setQueryFilters,
    handleQueryFilter,
    queryParams,
    setQueryParams,
}) {
    // const history = useHistory();
    const { dateFilter, groupByFilter, searchBar, columnHideShow, queryFilter, CustomFilter } = toolbarConfig;

    const handleChange = (column: string) => {
        const updatedMeta = { ...fieldsInfo?.meta, [column]: !fieldsInfo?.meta[column] };
        setFieldsInfo({ ...fieldsInfo, meta: updatedMeta });
        // Settings.updateSettings(appInfo.appId, `${appInfo.subAppId}.columnsMeta`, { meta: updatedMeta });
    };

    const options = fieldsInfo?.columns?.map((column) => ({
        key: column._id,
        checked: !!fieldsInfo?.meta[column._id],
        value: column.title,
    }));

    const handleOpenFilter = () => {
        if (queryFilters.length >= 1) {
            const nonEmptyFilters = queryFilters.filter((f) => f.column);
            if (nonEmptyFilters.length === 0) {
                setQueryFilters([defaultQueryFilter]);
            } else {
                setQueryFilters(nonEmptyFilters);
            }
        } else {
            setQueryFilters([defaultQueryFilter]);
        }
        setQueryFilterOpen(true);
    };

    const handleCloseFilter = () => {
        setQueryFilters(filterInfo.appliedQueryFilters);
        setQueryFilterOpen(false);
    };

    const handleRemoveFilter = (index: number) => {
        const list = filterInfo.appliedQueryFilters.filter((val, i) => i != index);
        setQueryFilters(list);
        setPageConfig((pageConfig) => ({ ...pageConfig, page: 0 }));
        const updatedQuery = {};
        if (list.length > 0) {
            list.forEach((f) => {
                if (!updatedQuery[f.column]) {
                    updatedQuery[f.column] = [];
                }
                updatedQuery[f.column].push(f.query);
            });
        }
        setFilterInfo({
            ...filterInfo,
            filterQuery: JSON.stringify(updatedQuery),
            appliedQueryFilters: list,
        });
    };

    return (
        <div className={classes.toolbar}>
            {CustomFilter && <CustomFilter props={{ queryParams, setQueryParams }} />}
            {filterInfo.appliedQueryFilters.map(
                (filter, i) =>
                    filter.queryStr && (
                        <Chip
                            label={filter.queryStr}
                            key={i}
                            className={classes.chip}
                            onDelete={() => handleRemoveFilter(i)}
                            color="primary"
                            size="small"
                            variant="outlined"
                        />
                    )
            )}
            {dateFilter && (
                <DatePicker
                    label="Date"
                    dateStr={filterInfo.date}
                    handleDateChange={(e) => {
                        changePage(null, 0);
                        setFilterInfo({
                            ...filterInfo,
                            date: e.target.value,
                        });

                        // const query = queryString.stringify(
                        //     { ...params, date: e.target.value },
                        //     { arrayFormat: "bracket" }
                        // );
                        // history.push({ pathname: history.location.pathname, search: query });
                    }}
                />
            )}
            {groupByFilter && (
                <GroupByFields
                    classes={classes}
                    filterInfo={filterInfo}
                    groupByColumns={fieldsInfo.groupByFields}
                    setFilterInfo={setFilterInfo}
                />
            )}
            {queryFilter && (
                <div>
                    <div className={classes.toolbarItems}>
                        <FTIconButton
                            handler={handleOpenFilter}
                            title="Filter"
                            btnIcon={<FilterListSharpIcon style={{ fontSize: "1.75rem" }} color="primary" />}
                            placement="top"
                        />
                    </div>
                    <TableFilterForm
                        fields={fieldsInfo?.fields}
                        open={queryFilterOpen}
                        filters={queryFilters}
                        setFilters={setQueryFilters}
                        handleFilter={handleQueryFilter}
                        handleClose={handleCloseFilter}
                    />
                </div>
            )}
            {searchBar && <SearchBox setSearchText={(str) => searchHandler(str)} />}
            {columnHideShow && <FTMultiSelectMenu onChange={handleChange} options={options} />}
        </div>
    );
}
