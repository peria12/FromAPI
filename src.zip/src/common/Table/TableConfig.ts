export const defaultRowsPerPageOptions = [25, 50, 100];

export const defaultRowsPerPage = 25;

export const defaultFieldsInfo = {
    fields: [],
    sortedFields: [],
    columns: [],
    filterable: {},
    meta: {},
    groupByFields: [],
    fieldMap: {},
    groupBy: ["", ""],
};

export const defaultTableData = {
    rows: [],
    totalRecords: 0,
    isLoading: true,
};

export const defaultQueryFilter = {
    column: "",
    operator: "",
    value: "",
    query: {},
    queryStr: "",
};

export const defaultFilterInfo = {
    filterQuery: "",
    groupBy: ["", ""],
    date: new Date().toISOString().slice(0, 10),
    searchText: "",
    appliedQueryFilters: [],
};

export const initialMousePositions = {
    mouseX: null,
    mouseY: null,
};
