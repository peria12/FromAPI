import makeStyles from "@mui/styles/makeStyles";
import createStyles from "@mui/styles/createStyles";

const useTableStyles = makeStyles((theme) =>
    createStyles({
        root: {
            "& > *": {
                borderBottom: "unset",
            },
        },
        tableHeader: {
            fontWeight: "bold",
        },
        visuallyHidden: {
            border: 0,
            clip: "rect(0 0 0 0)",
            height: 1,
            margin: -1,
            overflow: "hidden",
            padding: 0,
            position: "absolute",
            top: 20,
            width: 1,
        },
        toolbar: {
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "flex-end",
            padding: 8,
        },
        toolbarItems: {
            marginRight: "10px",
        },
        chip: {
            margin: theme.spacing(0.3),
        },
        tableFooter: {
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "0px 10px",
        },
        grpByFistCol: {
            backgroundColor: "#b3e5fc !important",
            borderRight: "1px solid #90a4ae",
        },
        grpBySecCol: {
            backgroundColor: "#e1f5fe !important",
            borderRight: "1px solid #90a4ae",
        },
    })
);

export default useTableStyles;
