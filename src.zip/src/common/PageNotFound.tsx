import React from "react";
import Grid from "@mui/material/Grid";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";

const useStyles = makeStyles(() =>
    createStyles({
        root: {
            color: "grey",
            textAlign: "center",
            marginTop: "5px",
        },
        container: {
            textAlign: "center",
            marginTop: "40px",
        },
    })
);

export default function PageNotFound() {
    const classes = useStyles();
    const email = "ftis-platform-support@franklintempleton.com";
    return (
        <div className={classes.root}>
            <Grid container direction="row" justifyContent="center" alignItems="center">
                <div className={classes.root}>
                    <ErrorOutlineIcon style={{ fontSize: "12rem", color: "#005598" }} />
                    <h3
                        style={{
                            padding: "15px 70px",
                        }}
                    >
                        {" "}
                        You are not authorized to view this page. <br />
                        Please contact
                        <br />
                        <a href={`mailto:${email},`}>{email}</a>
                    </h3>
                </div>
            </Grid>
        </div>
    );
}
