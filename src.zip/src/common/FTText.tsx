import React from "react";
import { FormControl, TextField } from "@mui/material";

export default function FTText(params) {
    const { isNumber, value, label, onChange } = params;
    return (
        <FormControl>
            <TextField
                name="value"
                size="small"
                type={isNumber ? "number" : "text"}
                value={value}
                label={label}
                onChange={(event) => onChange(event.target.value)}
            />
        </FormControl>
    );
}
