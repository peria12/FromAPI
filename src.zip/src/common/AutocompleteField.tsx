import React, { useEffect, useMemo, useState } from "react";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
import CircularProgress from "@mui/material/CircularProgress";
import InputAdornment from "@mui/material/InputAdornment";
import SearchIcon from "@mui/icons-material/Search";
import { BehaviorSubject } from "rxjs";
import { debounceTime } from "rxjs/operators";
import { Popper } from "@mui/material";

export default function AutocompleteField({
    onChange,
    provider,
    placeholder = "Search..",
    debounce = 100,
    value = null as any,
    disabledItemId = null,
    isGrouped = false,
    disabled = false,
    disableUnderline = false,
    forcePopupIcon = false,
    disableClearable = false,
    freeSolo = false,
    autoSelect = false,
    searchIcon = true,
    label = "",
    customStyle = {},
    inputPropsStyle = {},
    renderOption = undefined as any,
    popperWidth = "",
    fields = null as any,
    onTextInputChange = null,
}: any) {
    const [open, setOpen] = useState(false);
    const [isLoading, setLoading] = useState(false);
    const hasMore = React.useRef(false);
    const scrollTop = React.useRef(0);
    const elRef = React.useRef<HTMLUListElement>(null);
    const [options, setOptions] = useState<any[]>([]);
    const styleParams = { width: "100%", ...customStyle };

    const subject = React.useMemo(() => new BehaviorSubject(""), []);

    const localRenderOption = useMemo(() => {
        if (renderOption) {
            return renderOption;
        } else if (fields) {
            return function RenderOption(props, option) {
                const first = props["data-option-index"] == 0;
                return (
                    <>
                        {first ? (
                            <li {...props} style={{ position: "sticky", top: "0px", background: "white" }}>
                                {fields.map((f, i) => (
                                    <div key={i} className="text-truncate ft-grid-header" style={{ width: f.width }}>
                                        {f.label}
                                    </div>
                                ))}
                            </li>
                        ) : (
                            <></>
                        )}
                        <li {...props} style={{ fontSize: "14px" }} key={option.entity_id}>
                            {fields.map((f, i) => (
                                <div key={i} className="text-truncate" style={{ width: f.width }}>
                                    {option[f.key]}
                                </div>
                            ))}
                        </li>
                    </>
                );
            };
        }
        return undefined;
    }, [fields, renderOption]);

    useEffect(() => {
        const sub = subject.pipe(debounceTime(debounce)).subscribe((text) => {
            setLoading(true);
            provider(text)
                .then(([data, total_records]) => {
                    hasMore.current = data.length < total_records;
                    setOptions(data);
                    setLoading(false);
                })
                .finally(() => {
                    setLoading(false);
                });
        });
        return () => sub.unsubscribe();
    }, [subject, provider, debounce]);

    const handleScroll = (e) => {
        const bottom = e.target.scrollHeight - e.target.scrollTop - 2 <= e.target.clientHeight;
        scrollTop.current = e.target.scrollTop;
        if (hasMore.current && bottom) {
            hasMore.current = false;
            provider("", true).then(([data, total_records]) => {
                const newOptions = [...options, ...data];
                setOptions(newOptions);
                if (elRef.current) {
                    elRef.current.scrollTop = scrollTop.current;
                }
                hasMore.current = newOptions.length < total_records;
            });
        }
    };

    const CustomPopper = function (props) {
        return (
            <Popper {...props} style={{ width: options.length ? popperWidth : undefined }} placement="bottom-start" />
        );
    };

    return (
        <Autocomplete
            id="autocomplete"
            size="small"
            clearOnBlur
            style={styleParams}
            open={open}
            disabled={disabled}
            freeSolo={freeSolo}
            autoSelect={autoSelect}
            disableClearable={disableClearable}
            PopperComponent={CustomPopper}
            groupBy={isGrouped ? (option) => option.category : undefined}
            getOptionDisabled={disabledItemId ? (option) => option.id == disabledItemId : undefined}
            onOpen={() => setOpen(true)}
            onClose={() => setOpen(false)}
            onChange={onChange}
            isOptionEqualToValue={(key: any, value: any) => key.id === value.id}
            getOptionLabel={(option) => `${option.label}`}
            renderOption={localRenderOption}
            filterOptions={(options) => options}
            ListboxComponent={(props) => <ul {...props} style={{ padding: 0 }} ref={elRef} onScroll={handleScroll} />}
            options={options}
            loading={isLoading}
            value={value}
            forcePopupIcon={forcePopupIcon}
            onInputChange={
                onTextInputChange
                    ? onTextInputChange
                    : (e: any) => {
                          if (e) subject.next(e.target.value);
                      }
            }
            renderInput={(params) =>
                AutocompleteTextField({
                    params,
                    isLoading,
                    placeholder,
                    label,
                    inputPropsStyle,
                    disableUnderline,
                    searchIcon,
                })
            }
        />
    );
}

const AutocompleteTextField = ({
    params,
    isLoading,
    placeholder,
    label,
    inputPropsStyle,
    disableUnderline,
    searchIcon,
}) => {
    return (
        <TextField
            variant={inputPropsStyle.variant || "standard"}
            {...params}
            placeholder={placeholder}
            fullWidth
            label={label ? label : null}
            InputProps={{
                ...params.InputProps,
                disableUnderline: disableUnderline,
                style: inputPropsStyle ? inputPropsStyle : { height: "33px" },
                endAdornment: (
                    <React.Fragment>
                        {isLoading ? <CircularProgress color="inherit" size={20} /> : null}
                        {params.InputProps.endAdornment}
                    </React.Fragment>
                ),
                startAdornment: searchIcon ? (
                    <InputAdornment position="start">
                        {" "}
                        <SearchIcon />{" "}
                    </InputAdornment>
                ) : (
                    <></>
                ),
            }}
        />
    );
};
