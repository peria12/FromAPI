import React, { useEffect, useState } from "react";
import { Switch, Route, useHistory, useLocation } from "react-router-dom";

import "bootstrap";

import Api from "utils/api";
import Home from "home/Home";

import { LicenseManager } from "ag-grid-enterprise";
LicenseManager.setLicenseKey(
    "CompanyName=Fiduciary Trust International Ltd,LicensedGroup=FTCI,LicenseType=MultipleApplications,LicensedConcurrentDeveloperCount=10,LicensedProductionInstancesCount=5,AssetReference=AG-031336,SupportServicesEnd=7_September_2023_[v2]_MTY5NDA0MTIwMDAwMA==3041125cedab58c320bd77d546377a5b"
);

import "./App.css";
import ErrorBoundary from "common/ErrorBoundary";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { Download } from "home/download/Download";

import "ag-grid-community/styles/ag-grid.css";
// import "ag-grid-community/dist/styles/ag-theme-balham.css";
import "./ag-theme-balham.css";
import "./ag-theme-ft.css";

export default function App() {
    const [url, setUrl] = useState("");
    const [loggedIn, setLoggedIn] = useState(false);
    const history = useHistory();
    const location = useLocation();

    const parseJwt = (token) => {
        const base64Url = token.split(".")[1];
        const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
        const jsonPayload = decodeURIComponent(
            window
                .atob(base64)
                .split("")
                .map(function (c) {
                    return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
                })
                .join("")
        );

        return JSON.parse(jsonPayload);
    };

    useEffect(() => {
        Api.start(url)
            .then(({ loggedIn, url, redirectToHome, accessToken }) => {
                setLoggedIn(loggedIn);
                if (accessToken) {
                    const tokenDetails = parseJwt(accessToken);
                    localStorage.setItem("userId", tokenDetails.oid);
                }

                if (redirectToHome) {
                    setUrl(window.location.pathname);
                    history.push("/");
                } else if (url) {
                    setUrl("");
                    history.push(url);
                }
            })
            .catch((err) => {
                console.log("Error starting API", err);
            });
    }, [history, url, location.pathname]);

    if (!loggedIn) {
        return <> Loading... </>;
    }

    return (
        <Switch>
            <Route path="/download/:id">
                <Download />
            </Route>
            <Route path="/">
                <ErrorBoundary>
                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                        <Home />
                    </LocalizationProvider>
                </ErrorBoundary>
            </Route>
        </Switch>
    );
}
