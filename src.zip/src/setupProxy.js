const { createProxyMiddleware } = require('http-proxy-middleware');

const api_port = process.env.REST_API_PORT;
const target = process.env.REST_API_ADDRESS || `http://localhost:${api_port}`

module.exports = function (app) {
    const proxy = createProxyMiddleware({
            target,
            changeOrigin: true,
            secure: false
        })
 
    app.use('/api', proxy);
    app.use('/v1', proxy);
    app.use('/v2', proxy);
    app.use('/v3', proxy);
    app.use('/portfolioBundle', proxy);
};
