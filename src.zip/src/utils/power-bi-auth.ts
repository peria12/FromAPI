import Api from "./api";
import moment from "moment";

export default class PowerBIAuth {
    static reportInfo: any = {};

    static getReportInfo(workspaceId, reportId: string) {
        return new Promise((resolve, reject) => {
            const tokenExpiry = this.reportInfo?.[reportId]?.tokenExpiry;
            if (tokenExpiry) {
                const isAfter = moment(tokenExpiry).isAfter(moment.utc(), "minutes");
                if (isAfter) {
                    return resolve(this.reportInfo?.[reportId]);
                }
            }
            Api.getPowerBIEmbedInfo(workspaceId, reportId)
                .then((res) => {
                    if (res.accessToken) {
                        this.reportInfo[reportId] = {
                            accessToken: res.accessToken,
                            embedUrl: res?.reportConfig[0].embedUrl,
                            id: res?.reportConfig[0].reportId,
                            tokenExpiry: res.tokenExpiry,
                        };
                        return resolve(this.reportInfo?.[reportId]);
                    }
                    return resolve({});
                })
                .catch((err) => reject(err));
        });
    }
}
