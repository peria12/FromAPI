export const errorHandler = (err: any) => {
    console.error(err);
};
