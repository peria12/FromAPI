import Access from "./access";

function hasAccess(info) {
    const userInfo = Access.userInfo || {};
    return info?.["author-id"] == userInfo?.["uuid"];
}

function sortByDate(a, b) {
    const key1 = new Date(a._meta?.update_date);
    const key2 = new Date(b._meta?.update_date);

    if (key1 < key2) {
        return 1;
    } else if (key1 == key2) {
        return 0;
    } else {
        return -1;
    }
}

export function sortList(options) {
    let res: any = [];
    if (!options) {
        return res;
    }
    const userOwns: any = [];
    const userNotOwns: any = [];
    options.forEach((option) => {
        if (hasAccess(option)) {
            userOwns.push(option);
        } else {
            userNotOwns.push(option);
        }
    });
    res = [...userOwns.sort(sortByDate), ...userNotOwns.sort(sortByDate)];
    return res;
}
