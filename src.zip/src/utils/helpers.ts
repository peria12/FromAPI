import * as bootstrap from "bootstrap";
import moment from "moment-timezone";

import { v4 as uuidv4 } from "uuid";
import Api from "./api";
import { screenshotNotification } from "./events";
import Settings from "./settings";
import queryString from "query-string";
import { useContext, useEffect, useState } from "react";
import { AppContext } from "./context";
import { totalImagesForMosaiq } from "./data";
import MosaiqLogo1 from "../assets/MosaiqLogo_1_Animated.svg";
import MosaiqLogo2 from "../assets/MosaiqLogo_2_Animated.svg";
import MosaiqLogo3 from "../assets/MosaiqLogo_3_Animated.svg";
import MosaiqLogo4 from "../assets/MosaiqLogo_4_Animated.svg";
import MosaiqLogo5 from "../assets/MosaiqLogo_5_Animated.svg";
import MosaiqLogo6 from "../assets/MosaiqLogo_6_Animated.svg";
import MosaiqLogo7 from "../assets/MosaiqLogo_7_Animated.svg";
import MosaiqLogo8 from "../assets/MosaiqLogo_8_Animated.svg";
import MosaiqLogo9 from "../assets/MosaiqLogo_9_Animated.svg";

export const initTooltip = () => {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.forEach((el) => new bootstrap.Tooltip(el));
};

const mimeTypeToIcon = {
    image: "far fa-file-image",
    "image/jpeg": "far fa-file-image",
    "image/png": "far fa-file-image",
    audio: "far fa-file-audio",
    video: "far fa-file-video",
    "application/pdf": "far fa-file-pdf",
    "text/plain": "far fa-file-text",
    "text/html": "far fa-file-code",
    "application/json": "far fa-file-code",
    "application/gzip": "far fa-file-archive",
    "application/x-zip-compressed": "far fa-file-archive",
    "application/zip": "far fa-file-archive",
    "application/octet-stream": "far fa-file",
    "application/x-x509-ca-cert": "far fa-file-certificate",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "far fa-file-word",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "far fa-file-excel",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": "far fa-file-powerpoint",
};

export const getIconFromFileType = (fileType: string) => {
    return mimeTypeToIcon[fileType] || "far fa-file";
};

type Order = "asc" | "desc";

function descendingComparator<T>(a: T, b: T, orderBy: keyof T) {
    if (b[orderBy] < a[orderBy]) {
        return -1;
    }
    if (b[orderBy] > a[orderBy]) {
        return 1;
    }
    return 0;
}

export function getComparator<Key extends keyof any>(
    order: Order,
    orderBy: Key
): (a: { [key in Key]: number | string }, b: { [key in Key]: number | string }) => number {
    return order === "desc"
        ? (a, b) => descendingComparator(a, b, orderBy)
        : (a, b) => -descendingComparator(a, b, orderBy);
}

export function stableSort<T>(array: T[], comparator: (a: T, b: T) => number) {
    const stabilizedThis = (array || []).map((el, index) => [el, index] as [T, number]);
    stabilizedThis.sort((a, b) => {
        const order = comparator(a[0], b[0]);
        if (order !== 0) return order;
        return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
}

export function getFilterQuery({ operator, value }) {
    let query = {};
    switch (operator) {
        case "=":
            query = { $eq: value };
            break;
        case "!=":
            query = { $ne: value };
            break;
        case "<":
            query = { $lt: value };
            break;
        case ">":
            query = { $gt: value };
            break;
        case "<=":
            query = { $le: value };
            break;
        case ">=":
            query = { $ge: value };
            break;
    }
    return query;
}

const bases = {
    16: { l: "0123456789abcdef" },
    62: { l: "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" },
};

for (const bk in bases) {
    const b = parseInt(bk);
    const v = bases[b];
    const s = v["l"];
    v["d"] = {};
    for (let i = 0; i < b; i++) {
        v["d"][s[i]] = i;
    }
}

export const generateRandomNumberForMosaiqLogo = (totalImagesCount) => {
    return Math.ceil(Math.random() * totalImagesCount);
};

export const getRandomMosaiqLogo = () => {
    const imageNumber = generateRandomNumberForMosaiqLogo(totalImagesForMosaiq);
    switch (imageNumber) {
        case 1:
            return MosaiqLogo1;
        case 2:
            return MosaiqLogo2;
        case 3:
            return MosaiqLogo3;
        case 4:
            return MosaiqLogo4;
        case 5:
            return MosaiqLogo5;
        case 6:
            return MosaiqLogo6;
        case 7:
            return MosaiqLogo7;
        case 8:
            return MosaiqLogo8;
        default:
            return MosaiqLogo9;
    }
};

export const getYesterDaysDate = () => {
    return moment().subtract(1, "day").format("YYYY-MM-DD");
};

function convertBase(str, b1, b2) {
    if (!(b1 in bases && b2 in bases)) {
        return null;
    }

    let dec = 0;
    const d = bases[b1]["d"];

    for (let i = 0; i < str.length; i++) {
        dec += b1 ** i * d[str[i]];
    }

    const l = bases[b2]["l"];
    if (dec == 0) return l[0];

    let ret = "";
    while (dec != 0) {
        ret += l[dec % b2];
        dec = Math.floor(dec / b2);
    }

    return ret;
}

export function getUuid() {
    const uuid = uuidv4();
    const shortUUID = convertBase(uuid.slice(0, 6) + uuid.slice(-6), 16, 62);
    return shortUUID.slice(0, 8);
}

export function searchByProp(array: any, searchText: string, prop: string) {
    if (!searchText) {
        return [];
    }
    searchText = searchText.toLowerCase();
    return array.filter((item: any) => item && item[prop] && item[prop].toLowerCase().indexOf(searchText) > -1);
}

export function groupBy(array, key) {
    return array.reduce((res, cur) => {
        (res[cur[key]] = res[cur[key]] || []).push(cur);
        return res;
    }, {});
}

export function groupByAggregate(array = [], key, fields: any = []) {
    const groups = groupBy(array, key) || {};
    const results = Object.keys(groups).map((key) => {
        const value = groups[key];
        const aggFields: any = {};
        fields.forEach((f) => {
            aggFields[f] = value.reduce((total, o) => total + Number(o[f]), 0);
        });
        return { ...value[0], ...aggFields };
    });
    return results;
}

export function globalSearch(array: any = [], searchText: string, maxResults = 0, fields: any = []) {
    if (!searchText) {
        return [];
    }
    const searchTexts = searchText.toLowerCase().split(" ");
    const res = array.filter((item: any) => {
        let items: any = [];
        if (fields.length > 0) {
            items = fields.map((key) => item[key]);
        } else {
            items = Object.values(item);
        }
        return searchTexts.every((text) => {
            return items.find((value: any) => value && (value + "").toLowerCase().includes(text));
        });
    });

    if (maxResults > 0) {
        return res.slice(0, maxResults);
    }
    return res;
}

export function getCamelCase(str: string) {
    if (str && typeof str === "string") {
        const words = str.split("_");
        return words
            .map((word) => {
                return word[0].toUpperCase() + word.substring(1);
            })
            .join(" ");
    }
    return str;
}

export function checkEquality(a, b) {
    const entries1: any = Object.entries(a);
    const entries2: any = Object.entries(b);
    const short = entries1.length > entries2 ? entries2 : entries1;
    const long = short === entries1 ? b : a;
    return short.every(([k, v]) => long[k] === v);
}

function mergeFields(groupInfo, row, groups, columns) {
    const maxStrLength = 20;

    columns.map((f) => {
        if (!groups.includes(f.id)) {
            let value = "";
            if (f.aggregateSum) {
                value = groupInfo?.reduce((total, o) => total + Number(o[f.id]), 0);
            } else if (f.grpByAggregation != "none") {
                value = groupInfo
                    .map((item) => item[f.id])
                    .filter(Boolean)
                    .join(",");
                if (value.length > maxStrLength) {
                    value = value.substring(0, maxStrLength) + "...";
                }
            }
            row[f.id] = value || "";
        }
        return "";
    });
    row.entries = groupInfo;
    return row;
}

export function isEmpty(obj: Record<string, any>): boolean {
    return Object.keys(obj).length === 0;
}

export function groupByProps(array, groups, columns) {
    const grouped = {};
    const results: any = [];

    array.forEach((a) => {
        groups
            .reduce((o, g, i) => {
                o[a[g]] = o[a[g]] || (i + 1 === groups.length ? [] : {});
                return o[a[g]];
            }, grouped)
            .push(a);
    });

    Object.keys(grouped).map((key) => {
        const entry = { [groups?.[0]]: key == "undefined" ? "" : key };
        const groupL1 = grouped[key];
        if (groups?.[1]) {
            Object.keys(groupL1).map((prop) => {
                let row = { ...entry };
                row[groups[1]] = prop == "undefined" ? "" : prop;
                row = mergeFields([...groupL1[prop]], { ...row }, groups, columns);
                results.push(row);
            });
        } else {
            results.push(mergeFields([...groupL1], { ...entry }, groups, columns));
        }
    });
    return results;
}

export function get(object, path, value?: any) {
    if (typeof path != "string") {
        path = path + "";
    }
    const pathArray = Array.isArray(path) ? path : path.split(".").filter((key) => key);
    const pathArrayFlat = pathArray.flatMap((part) => (typeof part === "string" ? part.split(".") : part));
    const checkValue = pathArrayFlat.reduce((obj, key) => obj && obj[key], object);
    return checkValue === undefined ? value : checkValue;
}

export function convertToMap(arr, key) {
    const map = {};
    arr.forEach((ele) => {
        map[ele[key]] = ele;
    });
    return map;
}

export function downloadFile(resp) {
    if (resp) {
        const link = document.createElement("a");
        link.href = window.URL.createObjectURL(new Blob([resp.data]));
        link.download = resp.headers["content-disposition"]?.split("filename=")[1]?.split('"')?.join("");
        link.click();
    }
}

export function getPreviousWorkday() {
    const workday = moment();
    const day = workday.day();
    if (day == 0 || day == 1) {
        return workday.day(-2);
    }
    return workday.subtract(1, "day");
}

export function downloadFileData(data, filename) {
    if (data) {
        const link = document.createElement("a");
        link.href = window.URL.createObjectURL(new Blob([data]));
        link.download = filename;
        link.click();
    }
}

export function useScreenshot() {
    const [flag] = useState<any>({ taken: false, context: useContext<any>(AppContext) });
    flag.taken = false;
    useEffect(() => {
        flag.take = () => takeScreenshot(flag);
        return screenshotTimer(flag);
    });
    return flag;
}

export function screenshotTimer(screenshot_flag) {
    screenshot_flag.inactive = false;

    const sub = setInterval(() => {
        if (!screenshot_flag.taken) {
            takeScreenshot(screenshot_flag);
        }
    }, 10000);

    return () => {
        clearInterval(sub);
        screenshot_flag.inactive = true;
    };
}

export function takeScreenshot(flag) {
    if (flag) {
        if (flag.inactive) {
            return;
        }
        flag.taken = true;
    }
    const app = flag.context.app._id;
    const zone = flag.context.zone.name;
    console.log("Taking screenshot", app, zone, flag);

    if (app && zone) {
        setTimeout(() => {
            const s = new XMLSerializer();
            const str = s.serializeToString(document);
            let strCss = Array.from(document.styleSheets)
                .flatMap((s) => Array.from(s.cssRules).map((x) => x.cssText))
                .join(" ");
            strCss = `<style>${strCss}</style>`;

            const html = str.concat(strCss);

            Api.takeScreenshot(app, zone, { html }).then((x) => {
                Settings.updateSettings(
                    "admin",
                    "portal",
                    `screenshots.${app}.${zone}`,
                    { thumbnail: x.fileId, height: x.height, width: x.width, url: x.url, time: x.time },
                    false
                );
                screenshotNotification.next(1);
            });
        }, 10);
    }
}

export function base64ToArrayBuffer(data) {
    const bString = window.atob(data);
    const bLength = bString.length;
    const bytes = new Uint8Array(bLength);
    for (let i = 0; i < bLength; i++) {
        const ascii = bString.charCodeAt(i);
        bytes[i] = ascii;
    }
    return bytes;
}

export function getLink(app_name, zone) {
    return `/${app_name}/${zone}`;
}

export function getURLParams(location) {
    return queryString.parse(location.search, { arrayFormat: "bracket" });
}

export function updateURLParams(history, params) {
    const query = queryString.stringify(params, { arrayFormat: "bracket" });

    history.push({ pathname: history.location.pathname, search: query });
}

export function convertToInternationalCurrencySystem(value) {
    let newValue = Math.abs(value);
    const suffixes = ["", "K", "M", "B", "T", "Z"];
    let suffixNum = 0;
    while (newValue >= 1000) {
        newValue /= 1000;
        suffixNum++;
    }
    let formattedNumber = String(newValue.toFixed(2)) + suffixes[suffixNum];
    if (value < 0) {
        formattedNumber = "-" + formattedNumber;
    }

    return newValue ? formattedNumber : "";
}

export const unique = (arr) => Array.from(new Set(arr));

export const getSlantedTextPadding = (arr) => {
    const paddingTop = Math.max(...arr.map((c) => c.length || 0)) * 1.6;
    const lens = arr.map((c, i) => c.length * 5.5 - (arr.length - i - 0.5) * 50);
    const paddingRight = Math.max(...lens);
    return [paddingTop, paddingRight];
};

export const toFixed = (num, digits = 2, def = "") => {
    if (typeof num === "number") {
        return num.toFixed(digits);
    }
    console.error(`Error: cannot apply toFixed to ${num}`);
    return def;
};

export const getPreviousDayNY = () => {
    const time_ny = moment().tz("America/New_York");
    if (time_ny.hours() < 8) {
        return time_ny.add(-2, "days").format("YYYY-MM-DD");
    } else {
        return time_ny.add(-1, "days").format("YYYY-MM-DD");
    }
};

export const getLastMonthPreviousDate = () => {
    const time_ny = moment().tz("America/New_York");

    if (time_ny.hours() < 8) {
        return time_ny.add(-2, "days").add(-1, "months").format("YYYY-MM-DD");
    } else {
        return time_ny.add(-1, "days").add(-1, "months").format("YYYY-MM-DD");
    }
};

export function roundNumber(val) {
    return Math.round(val * 100) / 100;
}
