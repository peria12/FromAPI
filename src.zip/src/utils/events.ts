import { Subject } from "rxjs";

export const entryNotification = new Subject<number>();
export const drawerResizeNotification = new Subject<any>();
export const alertClearedNotification = new Subject<any>();
export const goeClientUpdateNotification = new Subject<any>();
export const goePortfolioUpdateNotification = new Subject<any>();
export const goeActuarialUpdateNotification = new Subject<any>();
export const screenshotNotification = new Subject<any>();
export const homePageResetNotification = new Subject<any>();
