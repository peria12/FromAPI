import Api from "./api";

interface UserInfo {
    first_name: string;
    name: string;
    email: string;
    uuid: string;
}

export default class Access {
    static access: any = [];
    static isSuper = false;
    static userInfo: UserInfo;
    static hasErrorOccurred = false;

    static async init() {
        try {
            const data: any = await Api.getAccess();

            if (data.invalid_user) {
                const user = Api.getUIUser();
                const names = user.name.split(" ");
                const first_name = names && names.length > 0 ? names[1] : "";
                const user_info = { [user.localAccountId]: { first_name, name: user.name, email: user.username } };

                await Api.setAccess([], [], user_info, {});

                const data = await Api.getAccess();
                this.access = data.access;
                this.userInfo = data.info;
            } else {
                this.access = data.access;
                this.userInfo = data.info;
            }
            this.isSuper = this.access?.some((acc) => acc.app == "admin" && acc.zone == "acl" && acc.type == "admin");
        } catch (err) {
            this.hasErrorOccurred = true;
            console.log("-- error", err);
        }
    }

    static hasAccessToZone(app: string, zone: string, types: string[] = []) {
        return (
            this.isSuper ||
            this.access?.some(
                (item) => item.app == app && item.zone == zone && (!types || !types.length || types.includes(item.type))
            )
        );
    }

    static hasErrorOccurredInNetwork() {
        return this.hasErrorOccurred;
    }

    static hasAccessToApp(app: string) {
        return this.access.some((item) => item.app == app);
    }

    static hasAccess(app, zone) {
        return this.hasAccessToZone(app, zone, ["admin", "view"]);
    }

    static hasAdminAccessToAnyApp() {
        return this.access.some((item: any) => item.type === "admin");
    }
}
