export const openAutoCloseModal = (myModal, history) => {
    const element = myModal._element;

    const urlSegments = history.location.pathname.split("/");
    urlSegments.pop();
    const backUrl = urlSegments.join("/");

    function closeListener() {
        history.push(backUrl);
        element?.removeEventListener("hidden.bs.modal", closeListener);
    }
    element?.addEventListener("hidden.bs.modal", closeListener);
    myModal.show();

    return () => {
        element?.removeEventListener("hidden.bs.modal", closeListener);
        myModal.hide();
    };
};
